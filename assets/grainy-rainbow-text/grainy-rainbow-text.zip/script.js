const params = new URLSearchParams(window.location.search);
document.getElementById("text").textContent = params.get("name");