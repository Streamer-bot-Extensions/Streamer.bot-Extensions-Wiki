const params = new URLSearchParams(window.location.search);
const image = params.get("targetUserProfileImageUrl") || "https://static-cdn.jtvnw.net/jtv_user_pictures/dd70b1ec-b906-416a-8a56-d067bda64514-profile_image-70x70.png";
const fonts = ['Roboto', 'Teko', 'Archivo Black', 'Syncopate', 'Sarpanch', 'Emblema One', 'Goblin One', 'Coda Caption', 'Work Sans', 'Stalinist One'];
const photos = [image];
const titles = [
	"The Follower", 
	"Without Honor", 
	"Lost Bet", 
	"The Baker", 
	"Dignity's Demand", 
	"Wolves", 
	"The River", 
	"Last Rites", 
	"Lost Spy", 
	"Emissary of Pain", 
	"The Founder", 
	"Painbringer", 
	"Painseeker", 
	"The Demiser", 
	"Death Of Evil", 
	"Midnight Threat", 
	"The Miner", 
	"The Ghost", 
	"Death At Sea", 
	"Righteous Kill", 
	"Lifeline", 
	"Missed Call", 
	"Next in Command", 
	"Suncatcher",
	"The Forger",
	"The Boomer",
	'Why, Gone Jim?'
];
const tagStart = [
	`This time`,
	`Sometimes`,
	`If pain is all you know`,
	`When honor is lost`,
	`When all seems dark`,
	`In a world of hate`,
	`When all is at stake`,
	`If you push too far`,
];
const tagEnd = [
	`It's personal`,
	`Honor holds you back`,
	`That's all you can give`,
	`Pain is a skill`,
	`It can light the way`,
	`Second chances don't come easy`,
	`Nothing else matters`,
	`Strike first`,
	`Justice can wait`,
	`Death is optional`
];
const colors = ['white', 0, 220, 35, '#dedede'];
const pos = {
	left: {
		anchor: 'start',
		x: '0%',
	},
	center: {
		anchor: 'middle',
		x: '50%',
	},
	right: {
		anchor: 'end',
		x: '100%',
	}
};

function randomItem(items) {
	return items[Math.floor((Math.random() * items.length))];
}

function makeRange(length = 1) {
	return [...Array(length)].map((_, index) => index + 1);
}

function newPoster() {
	// Grab all relevant elements
	const fontLink = document.getElementById('font-link');
	const poster = document.getElementById('poster');
	const photo = document.getElementById('photo');
	const title = document.getElementById('title');
	const tagline = document.getElementById('tagline');
	const starring = document.getElementById("name").textContent = params.get("user") || "GoWMan";
	
	// Set up layout values
	const rows = parseInt(window.getComputedStyle(poster).getPropertyValue("--rows"), 10) || 12;
	const rowsHalf = Math.floor(rows / 2);
	const cols = parseInt(window.getComputedStyle(poster).getPropertyValue("--cols"), 10) || 7;
	const font = randomItem(fonts);
	const hue = randomItem(colors);
	const accentColor = (typeof hue === 'string') ? hue : `hsl(${hue}, 65%, 80%)`;
	const starringPos = randomItem([1, rows - 1]); // Top or bottom row
	const reservedBottomRows = (starringPos === 1) ? 2 : 3;
	const titleName = randomItem(titles);
	const titleRow = randomItem(makeRange(rowsHalf - reservedBottomRows)) + rowsHalf; // Don't want it in top  half
	const titleAlign = randomItem(['left', 'center', 'right']);
	// const titlePosX = pos[titleAlign].x;
	// const titleAnchor = pos[titleAlign].anchor;
	const taglineText = `${randomItem(tagStart)}… ${randomItem(tagEnd)}`;
	const photoSrc = randomItem(photos);
	poster.style.setProperty("--poster-accent-color", accentColor);
	poster.style.setProperty("--poster-title-font", font);
	poster.style.setProperty("--poster-title-row", titleRow);
	poster.style.setProperty("--poster-subtitle-row", titleRow + 1);
	poster.style.setProperty("--poster-starring-row", starringPos);
	title.textContent = titleName;
	tagline.textContent = taglineText;
	// title.setAttribute('x', titlePosX);
	// title.setAttribute('text-anchor', titleAnchor);
	fontLink.setAttribute('href', `https://fonts.googleapis.com/css2?family=${font.replaceAll(' ', '+')}:wght@400;500;600;700;800;900&display=swap`);
	photo.setAttribute('src', photoSrc);
}

document.addEventListener('DOMContentLoaded', newPoster);
document.addEventListener('click', newPoster);