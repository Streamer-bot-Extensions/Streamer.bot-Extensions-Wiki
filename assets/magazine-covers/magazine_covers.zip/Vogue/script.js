const params = new URLSearchParams(window.location.search);
document.getElementById("articleTitle").textContent = params.get("title");