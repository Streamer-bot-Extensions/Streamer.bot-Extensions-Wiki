// This is a prime example of what starts out as a simple project
// and snowballs way beyond its intended size. It's a little clunky
// reading/working on this single file, but here it is anyways :)

'use strict';
console.clear();


const IS_MOBILE = window.innerWidth <= 640;
const IS_DESKTOP = window.innerWidth > 800;
const IS_HEADER = IS_DESKTOP && window.innerHeight < 300;
// Detect high end devices. This will be a moving target.
const IS_HIGH_END_DEVICE = (() => {
	const hwConcurrency = navigator.hardwareConcurrency;
	if (!hwConcurrency) {
		return false;
	}
	// Large screens indicate a full size computer, which often have hyper threading these days.
	// So a quad core desktop machine has 8 cores. We'll place a higher min threshold there.
	const minCount = window.innerWidth <= 1024 ? 4 : 8;
	return hwConcurrency >= minCount;
})();
// Prevent canvases from getting too large on ridiculous screen sizes.
// 8K - can restrict this if needed
const MAX_WIDTH = 7680;
const MAX_HEIGHT = 4320;
const GRAVITY = 0.9; // Acceleration in px/s
let simSpeed = 1;

function getDefaultScaleFactor() {
	if (IS_MOBILE) return 0.9;
	if (IS_HEADER) return 0.75;
	return 2;
}

// Width/height values that take scale into account.
// USE THESE FOR DRAWING POSITIONS
let stageW, stageH;

// All quality globals will be overwritten and updated via `configDidUpdate`.
let quality = 1;
let isLowQuality = false;
let isNormalQuality = true;
let isHighQuality = false;

const QUALITY_LOW = 1;
const QUALITY_NORMAL = 2;
const QUALITY_HIGH = 3;

const SKY_LIGHT_NONE = 0;
const SKY_LIGHT_DIM = 1;
const SKY_LIGHT_NORMAL = 2;

const COLOR = {
	Red: '#ff0043',
	Green: '#14fc56',
	Blue: '#1e7fff',
	Purple: '#e60aff',
	Gold: '#ffbf36',
	White: '#ffffff'
};

// Special invisible color (not rendered, and therefore not in COLOR map)
const INVISIBLE = '_INVISIBLE_';

const PI_2 = Math.PI * 2;
const PI_HALF = Math.PI * 0.5;

// Stage.disableHighDPI = true;
const trailsStage = new Stage('trails-canvas');
const mainStage = new Stage('main-canvas');
const stages = [
	trailsStage,
	mainStage
];



// Fullscreen helpers, using Fscreen for prefixes.
function fullscreenEnabled() {
	return fscreen.fullscreenEnabled;
}

// Note that fullscreen state is synced to store, and the store should be the source
// of truth for whether the app is in fullscreen mode or not.
function isFullscreen() {
	return !!fscreen.fullscreenElement;
}

// Attempt to toggle fullscreen mode.
function toggleFullscreen() {
	if (fullscreenEnabled()) {
		if (isFullscreen()) {
			fscreen.exitFullscreen();
		} else {
			fscreen.requestFullscreen(document.documentElement);
		}
	}
}

// Sync fullscreen changes with store. An event listener is necessary because the user can
// toggle fullscreen mode directly through the browser, and we want to react to that.
fscreen.addEventListener('fullscreenchange', () => {
	store.setState({ fullscreen: isFullscreen() });
});




// Simple state container; the source of truth.
const store = {
	_listeners: new Set(),
	_dispatch(prevState) {
		this._listeners.forEach(listener => listener(this.state, prevState))
	},
	
	state: {
		// will be unpaused in init()
		paused: true,
		soundEnabled: true,
		menuOpen: false,
		openHelpTopic: null,
		fullscreen: isFullscreen(),
		// Note that config values used for <select>s must be strings, unless manually converting values to strings
		// at render time, and parsing on change.
		config: {
			quality: String(IS_HIGH_END_DEVICE ? QUALITY_HIGH : QUALITY_NORMAL), // will be mirrored to a global variable named `quality` in `configDidUpdate`, for perf.
			shell: 'Random',
			size: IS_DESKTOP
				? '5' // Desktop default
				: IS_HEADER 
					? '1.2' // Profile header default (doesn't need to be an int)
					: '2', // Mobile default
			autoLaunch: false,
			finale: false,
			skyLighting: SKY_LIGHT_NORMAL + '',
			hideControls: IS_HEADER,
			longExposure: false,
			scaleFactor: getDefaultScaleFactor()
		}
	},
	
	setState(nextState) {
		const prevState = this.state;
		this.state = Object.assign({}, this.state, nextState);
		this._dispatch(prevState);
		this.persist();
	},
	
	subscribe(listener) {
		this._listeners.add(listener);
		return () => this._listeners.remove(listener);
	},
	
	// Load / persist select state to localStorage
	// Mutates state because `store.load()` should only be called once immediately after store is created, before any subscriptions.
	load() {/*
		const serializedData = localStorage.getItem('cm_fireworks_data');
		if (serializedData) {
			const {
				schemaVersion,
				data
			} = JSON.parse(serializedData);
			
			const config = this.state.config;
			switch(schemaVersion) {
				case '1.1':
					config.quality = data.quality;
					config.size = data.size;
					config.skyLighting = data.skyLighting;
					break;
				case '1.2':
					config.quality = data.quality;
					config.size = data.size;
					config.skyLighting = data.skyLighting;
					config.scaleFactor = data.scaleFactor;
					break;
				default:
					throw new Error('version switch should be exhaustive');
			}
			console.log(`Loaded config (schema version ${schemaVersion})`);
		}
		// Deprecated data format. Checked with care (it's not namespaced).
		else if (localStorage.getItem('schemaVersion') === '1') {
			let size;
			// Attempt to parse data, ignoring if there is an error.
			try {
				const sizeRaw = localStorage.getItem('configSize');
				size = typeof sizeRaw === 'string' && JSON.parse(sizeRaw);
			}
			catch(e) {
				console.log('Recovered from error parsing saved config:');
				console.error(e);
				return;
			}
			// Only restore validated values
			const sizeInt = parseInt(size, 10);
			if (sizeInt >= 0 && sizeInt <= 4) {
				this.state.config.size = String(sizeInt);
			}
		}*/
	},
	
	persist() {/*
		const config = this.state.config;
		localStorage.setItem('cm_fireworks_data', JSON.stringify({
			schemaVersion: '1.2',
			data: {
				quality: config.quality,
				size: config.size,
				skyLighting: config.skyLighting,
				scaleFactor: config.scaleFactor
			}
		}));*/
	}
};


if (!IS_HEADER) {
	store.load();
}

// Actions
// ---------

function togglePause(toggle) {
	const paused = store.state.paused;
	let newValue;
	if (typeof toggle === 'boolean') {
		newValue = toggle;
	} else {
		newValue = !paused;
	}

	if (paused !== newValue) {
		store.setState({ paused: newValue });
	}
}

function toggleSound(toggle) {
	if (typeof toggle === 'boolean') {
		store.setState({ soundEnabled: toggle });
	} else {
		store.setState({ soundEnabled: !store.state.soundEnabled });
	}
}

function toggleMenu(toggle) {
	if (typeof toggle === 'boolean') {
		store.setState({ menuOpen: toggle });
	} else {
		store.setState({ menuOpen: !store.state.menuOpen });
	}
}

function updateConfig(nextConfig) {
	nextConfig = nextConfig || getConfigFromDOM();
	store.setState({
		config: Object.assign({}, store.state.config, nextConfig)
	});
	
	configDidUpdate();
}

// Map config to various properties & apply side effects
function configDidUpdate() {
	const config = store.state.config;
	
	quality = qualitySelector();
	isLowQuality = quality === QUALITY_LOW;
	isNormalQuality = quality === QUALITY_NORMAL;
	isHighQuality = quality === QUALITY_HIGH;
	
	if (skyLightingSelector() === SKY_LIGHT_NONE) {
		//appNodes.canvasContainer.style.backgroundColor = 'rgba(0, 0, 0, 0)';
		//appNodes.canvasContainer.style.backgroundColor = '#000';
	}
	
	Spark.drawWidth = quality === QUALITY_HIGH ? 0.75 : 1;
}

// Selectors
// -----------

const isRunning = (state=store.state) => !state.paused && !state.menuOpen;
// Whether user has enabled sound.
const soundEnabledSelector = (state=store.state) => state.soundEnabled;
// Whether any sounds are allowed, taking into account multiple factors.
const canPlaySoundSelector = (state=store.state) => isRunning(state) && soundEnabledSelector(state);
// Convert quality to number.
const qualitySelector = () => +store.state.config.quality;
const shellNameSelector = () => store.state.config.shell;
// Convert shell size to number.
const shellSizeSelector = () => +store.state.config.size;
const finaleSelector = () => store.state.config.finale;
const skyLightingSelector = () => +store.state.config.skyLighting;
const scaleFactorSelector = () => store.state.config.scaleFactor;



// Help Content
const helpContent = {
	shellType: {
		header: 'Shell Type',
		body: 'The type of firework that will be launched. Select "Random" for a nice assortment!'
	},
	shellSize: {
		header: 'Shell Size',
		body: 'The size of the fireworks. Modeled after real firework shell sizes, larger shells have bigger bursts with more stars, and sometimes more complex effects. However, larger shells also require more processing power and may cause lag.'
	},
	quality: {
		header: 'Quality',
		body: 'Overall graphics quality. If the animation is not running smoothly, try lowering the quality. High quality greatly increases the amount of sparks rendered and may cause lag.'
	},
	skyLighting: {
		header: 'Sky Lighting',
		body: 'Illuminates the background as fireworks explode. If the background looks too bright on your screen, try setting it to "Dim" or "None".'
	},
	scaleFactor: {
		header: 'Scale',
		body: 'Allows scaling the size of all fireworks, essentially moving you closer or farther away. For larger shell sizes, it can be convenient to decrease the scale a bit, especially on phones or tablets.'
	},
	autoLaunch: {
		header: 'Auto Fire',
		body: 'Launches sequences of fireworks automatically. Sit back and enjoy the show, or disable to have full control.'
	},
	finaleMode: {
		header: 'Finale Mode',
		body: 'Launches intense bursts of fireworks. May cause lag. Requires "Auto Fire" to be enabled.'
	},
	hideControls: {
		header: 'Hide Controls',
		body: 'Hides the translucent controls along the top of the screen. Useful for screenshots, or just a more seamless experience. While hidden, you can still tap the top-right corner to re-open this menu.'
	},
	fullscreen: {
		header: 'Fullscreen',
		body: 'Toggles fullscreen mode.'
	},
	longExposure: {
		header: 'Open Shutter',
		body: 'Experimental effect that preserves long streaks of light, similar to leaving a camera shutter open.'
	}
};

const nodeKeyToHelpKey = {
	shellTypeLabel: 'shellType',
	shellSizeLabel: 'shellSize',
	qualityLabel: 'quality',
	skyLightingLabel: 'skyLighting',
	scaleFactorLabel: 'scaleFactor',
	autoLaunchLabel: 'autoLaunch',
	finaleModeLabel: 'finaleMode',
	hideControlsLabel: 'hideControls',
	fullscreenLabel: 'fullscreen',
	longExposureLabel: 'longExposure'
};


// Render app UI / keep in sync with state
const appNodes = {
	stageContainer: '.stage-container',
	canvasContainer: '.canvas-container',
	menu: '.menu',
	menuInnerWrap: '.menu__inner-wrap',
	shellType: '.shell-type',
	shellTypeLabel: '.shell-type-label',
	shellSize: '.shell-size',
	shellSizeLabel: '.shell-size-label',
	quality: '.quality-ui',
	qualityLabel: '.quality-ui-label',
	skyLighting: '.sky-lighting',
	skyLightingLabel: '.sky-lighting-label',
	scaleFactor: '.scaleFactor',
	scaleFactorLabel: '.scaleFactor-label',
	autoLaunch: '.auto-launch',
	autoLaunchLabel: '.auto-launch-label',
	finaleModeFormOption: '.form-option--finale-mode',
	finaleMode: '.finale-mode',
	finaleModeLabel: '.finale-mode-label',
	hideControls: '.hide-controls',
	hideControlsLabel: '.hide-controls-label',
	fullscreenFormOption: '.form-option--fullscreen',
	fullscreen: '.fullscreen',
	fullscreenLabel: '.fullscreen-label',
	longExposure: '.long-exposure',
	longExposureLabel: '.long-exposure-label',
	
	// Help UI
	helpModal: '.help-modal',
	helpModalOverlay: '.help-modal__overlay',
	helpModalHeader: '.help-modal__header',
	helpModalBody: '.help-modal__body',
	helpModalCloseBtn: '.help-modal__close-btn'
};

// Convert appNodes selectors to dom nodes
Object.keys(appNodes).forEach(key => {
	appNodes[key] = document.querySelector(appNodes[key]);
});

// Remove fullscreen control if not supported.
if (!fullscreenEnabled()) {
	appNodes.fullscreenFormOption.classList.add('remove');
}

// First render is called in init()
function renderApp(state) {
	appNodes.canvasContainer.classList.toggle('blur', state.menuOpen);
	appNodes.menu.classList.toggle('hide', !state.menuOpen);
	appNodes.finaleModeFormOption.style.opacity = state.config.autoLaunch ? 1 : 0.32;
	
	appNodes.quality.value = state.config.quality;
	appNodes.shellType.value = state.config.shell;
	appNodes.shellSize.value = state.config.size;
	appNodes.autoLaunch.checked = state.config.autoLaunch;
	appNodes.finaleMode.checked = state.config.finale;
	appNodes.skyLighting.value = state.config.skyLighting;
	appNodes.hideControls.checked = state.config.hideControls;
	appNodes.fullscreen.checked = state.fullscreen;
	appNodes.longExposure.checked = state.config.longExposure;
	appNodes.scaleFactor.value = state.config.scaleFactor.toFixed(2);
	
	appNodes.menuInnerWrap.style.opacity = state.openHelpTopic ? 0.12 : 1;
	appNodes.helpModal.classList.toggle('active', !!state.openHelpTopic);
	if (state.openHelpTopic) {
		const { header, body } = helpContent[state.openHelpTopic];
		appNodes.helpModalHeader.textContent = header;
		appNodes.helpModalBody.textContent = body;
	}
}

store.subscribe(renderApp);

// Perform side effects on state changes
function handleStateChange(state, prevState) {
	const canPlaySound = canPlaySoundSelector(state);
	const canPlaySoundPrev = canPlaySoundSelector(prevState);
	
	if (canPlaySound !== canPlaySoundPrev) {
		if (canPlaySound) {
			soundManager.resumeAll();
		} else {
			soundManager.pauseAll();
		}
	}
}

store.subscribe(handleStateChange);


function getConfigFromDOM() {
	return {
		quality: appNodes.quality.value,
		shell: appNodes.shellType.value,
		size: appNodes.shellSize.value,
		autoLaunch: appNodes.autoLaunch.checked,
		finale: appNodes.finaleMode.checked,
		skyLighting: appNodes.skyLighting.value,
		longExposure: appNodes.longExposure.checked,
		hideControls: appNodes.hideControls.checked,
		// Store value as number.
		scaleFactor: parseFloat(appNodes.scaleFactor.value)
	};
};

const updateConfigNoEvent = () => updateConfig();
appNodes.quality.addEventListener('input', updateConfigNoEvent);
appNodes.shellType.addEventListener('input', updateConfigNoEvent);
appNodes.shellSize.addEventListener('input', updateConfigNoEvent);
appNodes.autoLaunch.addEventListener('click', () => setTimeout(updateConfig, 0));
appNodes.finaleMode.addEventListener('click', () => setTimeout(updateConfig, 0));
appNodes.skyLighting.addEventListener('input', updateConfigNoEvent);
appNodes.longExposure.addEventListener('click', () => setTimeout(updateConfig, 0));
appNodes.hideControls.addEventListener('click', () => setTimeout(updateConfig, 0));
appNodes.fullscreen.addEventListener('click', () => setTimeout(toggleFullscreen, 0));
// Changing scaleFactor requires triggering resize handling code as well.
appNodes.scaleFactor.addEventListener('input', () => {
	updateConfig();
	handleResize();
});

Object.keys(nodeKeyToHelpKey).forEach(nodeKey => {
	const helpKey = nodeKeyToHelpKey[nodeKey];
	appNodes[nodeKey].addEventListener('click', () => {
		store.setState({ openHelpTopic: helpKey });
	});
});

appNodes.helpModalCloseBtn.addEventListener('click', () => {
	store.setState({ openHelpTopic: null });
});

appNodes.helpModalOverlay.addEventListener('click', () => {
	store.setState({ openHelpTopic: null });
});



// Constant derivations
const COLOR_NAMES = Object.keys(COLOR);
const COLOR_CODES = COLOR_NAMES.map(colorName => COLOR[colorName]);
// Invisible stars need an indentifier, even through they won't be rendered - physics still apply.
const COLOR_CODES_W_INVIS = [...COLOR_CODES, INVISIBLE];
// Map of color codes to their index in the array. Useful for quickly determining if a color has already been updated in a loop.
const COLOR_CODE_INDEXES = COLOR_CODES_W_INVIS.reduce((obj, code, i) => {
	obj[code] = i;
	return obj;
}, {});
// Tuples is a map keys by color codes (hex) with values of { r, g, b } tuples (still just objects).
const COLOR_TUPLES = {};
COLOR_CODES.forEach(hex => {
	COLOR_TUPLES[hex] = {
		r: parseInt(hex.substr(1, 2), 16),
		g: parseInt(hex.substr(3, 2), 16),
		b: parseInt(hex.substr(5, 2), 16),
	};
});

// Get a random color.
function randomColorSimple() {
	return COLOR_CODES[Math.random() * COLOR_CODES.length | 0];
}

// Get a random color, with some customization options available.
let lastColor;
function randomColor(options) {
	const notSame = options && options.notSame;
	const notColor = options && options.notColor;
	const limitWhite = options && options.limitWhite;
	let color = randomColorSimple();
	
	// limit the amount of white chosen randomly
	if (limitWhite && color === COLOR.White && Math.random() < 0.6) {
		color = randomColorSimple();
	}
	
	if (notSame) {
		while (color === lastColor) {
			color = randomColorSimple();
		}
	}
	else if (notColor) {
		while (color === notColor) {
			color = randomColorSimple();
		}
	}
	
	lastColor = color;
	return color;
}

function whiteOrGold() {
	return Math.random() < 0.5 ? COLOR.Gold : COLOR.White;
}


// Shell helpers
function makePistilColor(shellColor) {
	return (shellColor === COLOR.White || shellColor === COLOR.Gold) ? randomColor({ notColor: shellColor }) : whiteOrGold();
}

// Unique shell types
const crysanthemumShell = (size=1) => {
	const glitter = Math.random() < 0.25;
	const singleColor = Math.random() < 0.72;
	const color = singleColor ? randomColor({ limitWhite: true }) : [randomColor(), randomColor({ notSame: true })];
	const pistil = singleColor && Math.random() < 0.42;
	const pistilColor = pistil && makePistilColor(color);
	const secondColor = singleColor && (Math.random() < 0.2 || color === COLOR.White) ? pistilColor || randomColor({ notColor: color, limitWhite: true }) : null;
	const streamers = !pistil && color !== COLOR.White && Math.random() < 0.42;
	let starDensity = glitter ? 1.1 : 1.25;
	if (isLowQuality) starDensity *= 0.8;
	if (isHighQuality) starDensity = 1.2;
	return {
		shellSize: size,
		spreadSize: 300 + size * 100,
		starLife: 900 + size * 200,
		starDensity,
		color,
		secondColor,
		glitter: glitter ? 'light' : '',
		glitterColor: whiteOrGold(),
		pistil,
		pistilColor,
		streamers
	};
};


const ghostShell = (size=1) => {
	// Extend crysanthemum shell
	const shell = crysanthemumShell(size);
	// Ghost effect can be fast, so extend star life
	shell.starLife *= 1.5;
	// Ensure we always have a single color other than white
	let ghostColor = randomColor({ notColor: COLOR.White });
	// Always use streamers, and sometimes a pistil
	shell.streamers = true;
	const pistil = Math.random() < 0.42;
	const pistilColor = pistil && makePistilColor(ghostColor);
	// Ghost effect - transition from invisible to chosen color
	shell.color = INVISIBLE;
	shell.secondColor = ghostColor;
	// We don't want glitter to be spewed by invisible stars, and we don't currently
	// have a way to transition glitter state. So we'll disable it.
	shell.glitter = '';
	
	return shell;
};


const strobeShell = (size=1) => {
	const color = randomColor({ limitWhite: true });
	return {
		shellSize: size,
		spreadSize: 280 + size * 92,
		starLife: 1100 + size * 200,
		starLifeVariation: 0.40,
		starDensity: 1.1,
		color,
		glitter: 'light',
		glitterColor: COLOR.White,
		strobe: true,
		strobeColor: Math.random() < 0.5 ? COLOR.White : null,
		pistil: Math.random() < 0.5,
		pistilColor: makePistilColor(color)
	};
};


const palmShell = (size=1) => {
	const color = randomColor();
	const thick = Math.random() < 0.5;
	return {
		shellSize: size,
		color,
		spreadSize: 250 + size * 75,
		starDensity: thick ? 0.15 : 0.4,
		starLife: 1800 + size * 200,
		glitter: thick ? 'thick' : 'heavy'
	};
};

const ringShell = (size=1) => {
	const color = randomColor();
	const pistil = Math.random() < 0.75;
	return {
		shellSize: size,
		ring: true,
		color,
		spreadSize: 300 + size * 100,
		starLife: 900 + size * 200,
		starCount: 2.2 * PI_2 * (size+1),
		pistil,
		pistilColor: makePistilColor(color),
		glitter: !pistil ? 'light' : '',
		glitterColor: color === COLOR.Gold ? COLOR.Gold : COLOR.White,
		streamers: Math.random() < 0.3
	};
	// return Object.assign({}, defaultShell, config);
};

const crossetteShell = (size=1) => {
	const color = randomColor({ limitWhite: true });
	return {
		shellSize: size,
		spreadSize: 300 + size * 100,
		starLife: 750 + size * 160,
		starLifeVariation: 0.4,
		starDensity: 0.85,
		color,
		crossette: true,
		pistil: Math.random() < 0.5,
		pistilColor: makePistilColor(color)
	};
};

const floralShell = (size=1) => ({
	shellSize: size,
	spreadSize: 300 + size * 120,
	starDensity: 0.12,
	starLife: 500 + size * 50,
	starLifeVariation: 0.5,
	color: Math.random() < 0.65 ? 'random' : (Math.random() < 0.15 ? randomColor() : [randomColor(), randomColor({ notSame: true })]),
	floral: true
});

const fallingLeavesShell = (size=1) => ({
	shellSize: size,
	color: INVISIBLE,
	spreadSize: 300 + size * 120,
	starDensity: 0.12,
	starLife: 500 + size * 50,
	starLifeVariation: 0.5,
	glitter: 'medium',
	glitterColor: COLOR.Gold,
	fallingLeaves: true
});

const willowShell = (size=1) => ({
	shellSize: size,
	spreadSize: 300 + size * 100,
	starDensity: 0.6,
	starLife: 3000 + size * 300,
	glitter: 'willow',
	glitterColor: COLOR.Gold,
	color: INVISIBLE
});

const crackleShell = (size=1) => {
	// favor gold
	const color = Math.random() < 0.75 ? COLOR.Gold : randomColor();
	return {
		shellSize: size,
		spreadSize: 380 + size * 75,
		starDensity: isLowQuality ? 0.65 : 1,
		starLife: 600 + size * 100,
		starLifeVariation: 0.32,
		glitter: 'light',
		glitterColor: COLOR.Gold,
		color,
		crackle: true,
		pistil: Math.random() < 0.65,
		pistilColor: makePistilColor(color)
	};
};

const horsetailShell = (size=1) => {
	const color = randomColor();
	return {
		shellSize: size,
		horsetail: true,
		color,
		spreadSize: 250 + size * 38,
		starDensity: 0.9,
		starLife: 2500 + size * 300,
		glitter: 'medium',
		glitterColor: Math.random() < 0.5 ? whiteOrGold() : color,
		// Add strobe effect to white horsetails, to make them more interesting
		strobe: color === COLOR.White
	};
};

function randomShellName() {
	return Math.random() < 0.5 ? 'Crysanthemum' : shellNames[(Math.random() * (shellNames.length - 1) + 1) | 0 ];
}

function randomShell(size) {
	// Special selection for codepen header.
	if (IS_HEADER) return randomFastShell()(size);
	// Normal operation
	return shellTypes[randomShellName()](size);
}

function shellFromConfig(size) {
	return shellTypes[shellNameSelector()](size);
}

// Get a random shell, not including processing intensive varients
// Note this is only random when "Random" shell is selected in config.
// Also, this does not create the shell, only returns the factory function.
const fastShellBlacklist = ['Falling Leaves', 'Floral', 'Willow'];
function randomFastShell() {
	const isRandom = shellNameSelector() === 'Random';
	let shellName = isRandom ? randomShellName() : shellNameSelector();
	if (isRandom) {
		while (fastShellBlacklist.includes(shellName)) {
			shellName = randomShellName();
		}
	}
	return shellTypes[shellName];
}


const shellTypes = {
	'Random': randomShell,
	'Crackle': crackleShell,
	'Crossette': crossetteShell,
	'Crysanthemum': crysanthemumShell,
	'Falling Leaves': fallingLeavesShell,
	'Floral': floralShell,
	'Ghost': ghostShell,
	'Horse Tail': horsetailShell,
	'Palm': palmShell,
	'Ring': ringShell,
	'Strobe': strobeShell,
	'Willow': willowShell
};

const shellNames = Object.keys(shellTypes);

function init() {
	// Remove loading state
	document.querySelector('.loading-init').remove();
	appNodes.stageContainer.classList.remove('remove');
	
	// Populate dropdowns
	function setOptionsForSelect(node, options) {
		node.innerHTML = options.reduce((acc, opt) => acc += `<option value="${opt.value}">${opt.label}</option>`, '');
	}

	// shell type
	let options = '';
	shellNames.forEach(opt => options += `<option value="${opt}">${opt}</option>`);
	appNodes.shellType.innerHTML = options;
	// shell size
	options = '';
	['3"', '4"', '6"', '8"', '12"', '16"'].forEach((opt, i) => options += `<option value="${i}">${opt}</option>`);
	appNodes.shellSize.innerHTML = options;
	
	setOptionsForSelect(appNodes.quality, [
		{ label: 'Low', value: QUALITY_LOW },
		{ label: 'Normal', value: QUALITY_NORMAL },
		{ label: 'High', value: QUALITY_HIGH }
	]);
	
	setOptionsForSelect(appNodes.skyLighting, [
		{ label: 'None', value: SKY_LIGHT_NONE },
		{ label: 'Dim', value: SKY_LIGHT_DIM },
		{ label: 'Normal', value: SKY_LIGHT_NORMAL }
	]);
	
	// 0.9 is mobile default
	setOptionsForSelect(
		appNodes.scaleFactor,
		[0.5, 0.62, 0.75, 0.9, 1.0, 1.5, 2.0]
		.map(value => ({ value: value.toFixed(2), label: `${value*100}%` }))
	);
	
	// Begin simulation
	togglePause(false);
	
	// initial render
	renderApp(store.state);
	
	// Apply initial config
	configDidUpdate();
}


function fitShellPositionInBoundsH(position) {
	const edge = 0.18;
	return (1 - edge*2) * position + edge;
}

function fitShellPositionInBoundsV(position) {
	return position * 0.75;
}

function getRandomShellPositionH() {
	return fitShellPositionInBoundsH(Math.random());
}

function getRandomShellPositionV() {
	return fitShellPositionInBoundsV(Math.random());
}

function getRandomShellSize() {
	const baseSize = shellSizeSelector();
	const maxVariance = Math.min(2.5, baseSize);
	const variance = Math.random() * maxVariance;
	const size = baseSize - variance;
	const height = maxVariance === 0 ? Math.random() : 1 - (variance / maxVariance);
	const centerOffset = Math.random() * (1 - height * 0.65) * 0.5;
	const x = Math.random() < 0.5 ? 0.5 - centerOffset : 0.5 + centerOffset;
	return {
		size,
		x: fitShellPositionInBoundsH(x),
		height: fitShellPositionInBoundsV(height)
	};
}


// Launches a shell from a user pointer event, based on state.config
function launchShellFromConfig(event) {
	const shell = new Shell(shellFromConfig(shellSizeSelector()));
	const w = mainStage.width;
	const h = mainStage.height;
	
	shell.launch(
		event ? event.x / w : getRandomShellPositionH(),
		event ? 1 - event.y / h : getRandomShellPositionV()
	);
}


// Sequences
// -----------

function seqRandomShell() {
	const size = getRandomShellSize();
	const shell = new Shell(shellFromConfig(size.size));
	shell.launch(size.x, size.height);
	
	let extraDelay = shell.starLife;
	if (shell.fallingLeaves) {
		extraDelay = 4600;
	}
	
	return 900 + Math.random() * 600 + extraDelay;
}

function seqRandomFastShell() {
	const shellType = randomFastShell();
	const size = getRandomShellSize();
	const shell = new Shell(shellType(size.size));
	shell.launch(size.x, size.height);
	
	let extraDelay = shell.starLife;
	
	return 900 + Math.random() * 600 + extraDelay;
}

function seqTwoRandom() {
	const size1 = getRandomShellSize();
	const size2 = getRandomShellSize();
	const shell1 = new Shell(shellFromConfig(size1.size));
	const shell2 = new Shell(shellFromConfig(size2.size));
	const leftOffset = Math.random() * 0.2 - 0.1;
	const rightOffset = Math.random() * 0.2 - 0.1;
	shell1.launch(0.3 + leftOffset, size1.height);
	setTimeout(() => {
		shell2.launch(0.7 + rightOffset, size2.height);
	}, 100);
	
	let extraDelay = Math.max(shell1.starLife, shell2.starLife);
	if (shell1.fallingLeaves || shell2.fallingLeaves) {
		extraDelay = 4600;
	}
	
	return 900 + Math.random() * 600 + extraDelay;
}

function seqTriple() {
	const shellType = randomFastShell();
	const baseSize = shellSizeSelector();
	const smallSize = Math.max(0, baseSize - 1.25);
	
	const offset = Math.random() * 0.08 - 0.04;
	const shell1 = new Shell(shellType(baseSize));
	shell1.launch(0.5 + offset, 0.7);
	
	const leftDelay = 1000 + Math.random() * 400;
	const rightDelay = 1000 + Math.random() * 400;
	
	setTimeout(() => {
		const offset = Math.random() * 0.08 - 0.04;
		const shell2 = new Shell(shellType(smallSize));
		shell2.launch(0.2 + offset, 0.1);
	}, leftDelay);
	
	setTimeout(() => {
		const offset = Math.random() * 0.08 - 0.04;
		const shell3 = new Shell(shellType(smallSize));
		shell3.launch(0.8 + offset, 0.1);
	}, rightDelay);
	
	return 4000;
}

function seqPyramid() {
	const barrageCountHalf = IS_DESKTOP ? 7 : 4;
	const largeSize = shellSizeSelector();
	const smallSize = Math.max(0, largeSize - 3);
	const randomMainShell = Math.random() < 0.78 ? crysanthemumShell : ringShell;
	const randomSpecialShell = randomShell;

	function launchShell(x, useSpecial) {
		const isRandom = shellNameSelector() === 'Random';
		let shellType = isRandom
			? useSpecial ? randomSpecialShell : randomMainShell
			: shellTypes[shellNameSelector()];
		const shell = new Shell(shellType(useSpecial ? largeSize : smallSize));
		const height = x <= 0.5 ? x / 0.5 : (1 - x) / 0.5;
		shell.launch(x, useSpecial ? 0.75 : height * 0.42);
	}
	
	let count = 0;
	let delay = 0;
	while(count <= barrageCountHalf) {
		if (count === barrageCountHalf) {
			setTimeout(() => {
				launchShell(0.5, true);
			}, delay);
		} else {
			const offset = count / barrageCountHalf * 0.5;
			const delayOffset = Math.random() * 30 + 30;
			setTimeout(() => {
				launchShell(offset, false);
			}, delay);
			setTimeout(() => {
				launchShell(1 - offset, false);
			}, delay + delayOffset);
		}
		
		count++;
		delay += 200;
	}
	
	return 3400 + barrageCountHalf * 250;
}

function seqSmallBarrage() {
	seqSmallBarrage.lastCalled = Date.now();
	const barrageCount = IS_DESKTOP ? 11 : 5;
	const specialIndex = IS_DESKTOP ? 3 : 1;
	const shellSize = Math.max(0, shellSizeSelector() - 2);
	const randomMainShell = Math.random() < 0.78 ? crysanthemumShell : ringShell;
	const randomSpecialShell = randomFastShell();
	
	// (cos(x*5π+0.5π)+1)/2 is a custom wave bounded by 0 and 1 used to set varying launch heights
	function launchShell(x, useSpecial) {
		const isRandom = shellNameSelector() === 'Random';
		let shellType = isRandom
			? useSpecial ? randomSpecialShell : randomMainShell
			: shellTypes[shellNameSelector()];
		const shell = new Shell(shellType(shellSize));
		const height = (Math.cos(x*5*Math.PI + PI_HALF) + 1) / 2;
		shell.launch(x, height * 0.75);
	}
	
	let count = 0;
	let delay = 0;
	while(count < barrageCount) {
		if (count === 0) {
			launchShell(0.5, false)
			count += 1;
		}
		else {
			const offset = (count + 1) / barrageCount / 2;
			const delayOffset = Math.random() * 30 + 30;
			const useSpecial = count === specialIndex;
			setTimeout(() => {
				launchShell(0.5 + offset, useSpecial);
			}, delay);
			setTimeout(() => {
				launchShell(0.5 - offset, useSpecial);
			}, delay + delayOffset);
			count += 2;
		}
		delay += 200;
	}
	
	return 3400 + barrageCount * 120;
}
seqSmallBarrage.cooldown = 15000;
seqSmallBarrage.lastCalled = Date.now();


const sequences = [
	seqRandomShell,
	seqTwoRandom,
	seqTriple,
	seqPyramid,
	seqSmallBarrage
];


let isFirstSeq = true;
const finaleCount = 128;
let currentFinaleCount = 0;
function startSequence() {
	if (isFirstSeq) {
		isFirstSeq = false;
		if (IS_HEADER) {
			return seqTwoRandom();
		}
		else {
			const shell = new Shell(crysanthemumShell(shellSizeSelector()));
			shell.launch(0.5, 0.5);
			return 2400;
		}
	}
	
	if (finaleSelector()) {
		seqRandomFastShell();
		if (currentFinaleCount < finaleCount) {
			currentFinaleCount++;
			return 170;
		}
		else {
			currentFinaleCount = 0;
			return 6000;
		}
	}
	
	const rand = Math.random();
	
	if (rand < 0.08 && Date.now() - seqSmallBarrage.lastCalled > seqSmallBarrage.cooldown) {
		return seqSmallBarrage();
	}
	
	if (rand < 0.1) {
		return seqPyramid();
	}
	
	if (rand < 0.6 && !IS_HEADER) {
		return seqRandomShell();
	}
	else if (rand < 0.8) {
		return seqTwoRandom();
	}
	else if (rand < 1) {
		return seqTriple();
	}
}


let activePointerCount = 0;
let isUpdatingSpeed = false;

function handlePointerStart(event) {
	activePointerCount++;
	const btnSize = 50;
	
	if (event.y < btnSize) {
		if (event.x < btnSize) {
			togglePause();
			return;
		}
		if (event.x > mainStage.width/2 - btnSize/2 && event.x < mainStage.width/2 + btnSize/2) {
			toggleSound();
			return;
		}
		if (event.x > mainStage.width - btnSize) {
			toggleMenu();
			return;
		}
	}
	
	if (!isRunning()) return;
	
	if (updateSpeedFromEvent(event)) {
		isUpdatingSpeed = true;
	}
	else if (event.onCanvas) {
		launchShellFromConfig(event);
	}
}

function handlePointerEnd(event) {
	activePointerCount--;
	isUpdatingSpeed = false;
}

function handlePointerMove(event) {
	if (!isRunning()) return;
	
	if (isUpdatingSpeed) {
		updateSpeedFromEvent(event);
	}
}

function handleKeydown(event) {
	// P
	if (event.keyCode === 80) {
		togglePause();
	}
	// O
	else if (event.keyCode === 79) {
		toggleMenu();
	}
	// Esc
	else if (event.keyCode === 27) {
		toggleMenu(false);
	}
}

mainStage.addEventListener('pointerstart', handlePointerStart);
mainStage.addEventListener('pointerend', handlePointerEnd);
mainStage.addEventListener('pointermove', handlePointerMove);
window.addEventListener('keydown', handleKeydown);


// Account for window resize and custom scale changes.
function handleResize() {
	const w = window.innerWidth;
	const h = window.innerHeight;
	// Try to adopt screen size, heeding maximum sizes specified
	const containerW = Math.min(w, MAX_WIDTH);
	// On small screens, use full device height
	const containerH = w <= 420 ? h : Math.min(h, MAX_HEIGHT);
	appNodes.stageContainer.style.width = containerW + 'px';
	appNodes.stageContainer.style.height = containerH + 'px';
	stages.forEach(stage => stage.resize(containerW, containerH));
	// Account for scale
	const scaleFactor = scaleFactorSelector();
	stageW = containerW / scaleFactor;
	stageH = containerH / scaleFactor;
}

// Compute initial dimensions
handleResize();

window.addEventListener('resize', handleResize);


// Dynamic globals
let currentFrame = 0;
let speedBarOpacity = 0;
let autoLaunchTime = 0;

function updateSpeedFromEvent(event) {
	if (isUpdatingSpeed || event.y >= mainStage.height - 44) {
		// On phones it's hard to hit the edge pixels in order to set speed at 0 or 1, so some padding is provided to make that easier.
		const edge = 16;
		const newSpeed = (event.x - edge) / (mainStage.width - edge * 2);
		simSpeed = Math.min(Math.max(newSpeed, 0), 1);
		// show speed bar after an update
		speedBarOpacity = 1;
		// If we updated the speed, return true
		return true;
	}
	// Return false if the speed wasn't updated
	return false;
}


// Extracted function to keep `update()` optimized
function updateGlobals(timeStep, lag) {
	currentFrame++;
	
	// Always try to fade out speed bar
	if (!isUpdatingSpeed) {
	speedBarOpacity -= lag / 30; // half a second
		if (speedBarOpacity < 0) {
			speedBarOpacity = 0;
		}
	}
	
	// auto launch shells
	if (store.state.config.autoLaunch) {
		autoLaunchTime -= timeStep;
		if (autoLaunchTime <= 0) {
			autoLaunchTime = startSequence() * 1.25;
		}
	}
}


function update(frameTime, lag) {
	if (!isRunning()) return;
	
	const width = stageW;
	const height = stageH;
	const timeStep = frameTime * simSpeed;
	const speed = simSpeed * lag;
	
	updateGlobals(timeStep, lag);
	
	const starDrag = 1 - (1 - Star.airDrag) * speed;
	const starDragHeavy = 1 - (1 - Star.airDragHeavy) * speed;
	const sparkDrag = 1 - (1 - Spark.airDrag) * speed;
	const gAcc = timeStep / 1000 * GRAVITY;
	COLOR_CODES_W_INVIS.forEach(color => {
		// Stars
		const stars = Star.active[color];
		for (let i=stars.length-1; i>=0; i=i-1) {
			const star = stars[i];
			// Only update each star once per frame. Since color can change, it's possible a star could update twice without this, leading to a "jump".
			if (star.updateFrame === currentFrame) {
				continue;
			}
			star.updateFrame = currentFrame;
			
			star.life -= timeStep;
			if (star.life <= 0) {
				stars.splice(i, 1);
				Star.returnInstance(star);
			} else {
				const burnRate = Math.pow(star.life / star.fullLife, 0.5);
				const burnRateInverse = 1 - burnRate;

				star.prevX = star.x;
				star.prevY = star.y;
				star.x += star.speedX * speed;
				star.y += star.speedY * speed;
				// Apply air drag if star isn't "heavy". The heavy property is used for the shell comets.
				if (!star.heavy) {
					star.speedX *= starDrag;
					star.speedY *= starDrag;
				}
				else {
					star.speedX *= starDragHeavy;
					star.speedY *= starDragHeavy;
				}
				star.speedY += gAcc;
				
				if (star.spinRadius) {
					star.spinAngle += star.spinSpeed * speed;
					star.x += Math.sin(star.spinAngle) * star.spinRadius * speed;
					star.y += Math.cos(star.spinAngle) * star.spinRadius * speed;
				}
				
				if (star.sparkFreq) {
					star.sparkTimer -= timeStep;
					while (star.sparkTimer < 0) {
						star.sparkTimer += star.sparkFreq * 0.75 + star.sparkFreq * burnRateInverse * 4;
						Spark.add(
							star.x,
							star.y,
							star.sparkColor,
							Math.random() * PI_2,
							Math.random() * star.sparkSpeed * burnRate,
							star.sparkLife * 0.8 + Math.random() * star.sparkLifeVariation * star.sparkLife
						);
					}
				}
				
				// Handle star transitions
				if (star.life < star.transitionTime) {
					if (star.secondColor && !star.colorChanged) {
						star.colorChanged = true;
						star.color = star.secondColor;
						stars.splice(i, 1);
						Star.active[star.secondColor].push(star);
						if (star.secondColor === INVISIBLE) {
							star.sparkFreq = 0;
						}
					}
					
					if (star.strobe) {
						// Strobes in the following pattern: on:off:off:on:off:off in increments of `strobeFreq` ms.
						star.visible = Math.floor(star.life / star.strobeFreq) % 3 === 0;
					}
				}
			}
		}
											
		// Sparks
		const sparks = Spark.active[color];
		for (let i=sparks.length-1; i>=0; i=i-1) {
			const spark = sparks[i];
			spark.life -= timeStep;
			if (spark.life <= 0) {
				sparks.splice(i, 1);
				Spark.returnInstance(spark);
			} else {
				spark.prevX = spark.x;
				spark.prevY = spark.y;
				spark.x += spark.speedX * speed;
				spark.y += spark.speedY * speed;
				spark.speedX *= sparkDrag;
				spark.speedY *= sparkDrag;
				spark.speedY += gAcc;
			}
		}
	});
	
	render(speed);
}

function render(speed) {
	const { dpr } = mainStage;
	const width = stageW;
	const height = stageH;
	const trailsCtx = trailsStage.ctx;
	const mainCtx = mainStage.ctx;
	
	if (skyLightingSelector() !== SKY_LIGHT_NONE) {
		colorSky(speed);
	}
	
	// Account for high DPI screens, and custom scale factor.
	const scaleFactor = scaleFactorSelector();
	trailsCtx.scale(dpr * scaleFactor, dpr * scaleFactor);
	mainCtx.scale(dpr * scaleFactor, dpr * scaleFactor);
	
	trailsCtx.globalCompositeOperation = 'source-over';
	//trailsCtx.fillStyle = `rgba(0, 0, 0, ${store.state.config.longExposure ? 0.0025 : 0.175 * speed})`;
	trailsCtx.fillStyle = `rgba(1, 1, 1, ${store.state.config.longExposure ? 0.0025 : 0.175 * speed})`;
	trailsCtx.fillRect(0, 0, width, height);
	
	mainCtx.clearRect(0, 0, width, height);
	
	// Draw queued burst flashes
	// These must also be drawn using source-over due to Safari. Seems rendering the gradients using lighten draws large black boxes instead.
	// Thankfully, these burst flashes look pretty much the same either way.
	while (BurstFlash.active.length) {
		const bf = BurstFlash.active.pop();
		
		const burstGradient = trailsCtx.createRadialGradient(bf.x, bf.y, 0, bf.x, bf.y, bf.radius);
		burstGradient.addColorStop(0.024, 'rgba(255, 255, 255, 1)');
		burstGradient.addColorStop(0.125, 'rgba(255, 160, 20, 0.2)');
		burstGradient.addColorStop(0.32, 'rgba(255, 140, 20, 0.11)');
		burstGradient.addColorStop(1, 'rgba(255, 120, 20, 0)');
		trailsCtx.fillStyle = burstGradient;
		trailsCtx.fillRect(bf.x - bf.radius, bf.y - bf.radius, bf.radius * 2, bf.radius * 2);
		
		BurstFlash.returnInstance(bf);
	}
	
	// Remaining drawing on trails canvas will use 'lighten' blend mode
	trailsCtx.globalCompositeOperation = 'lighten';
	
	// Draw stars
	trailsCtx.lineWidth = Star.drawWidth;
	trailsCtx.lineCap = isLowQuality ? 'square' : 'round';
	mainCtx.strokeStyle = '#fff';
    mainCtx.lineWidth = 1;
	mainCtx.beginPath();
	COLOR_CODES.forEach(color => {
		const stars = Star.active[color];
		trailsCtx.strokeStyle = color;
		trailsCtx.beginPath();
		stars.forEach(star => {
			if (star.visible) {
				trailsCtx.moveTo(star.x, star.y);
				trailsCtx.lineTo(star.prevX, star.prevY);
				mainCtx.moveTo(star.x, star.y);
				mainCtx.lineTo(star.x - star.speedX * 1.6, star.y - star.speedY * 1.6);
			}
		});
		trailsCtx.stroke();
	});
	mainCtx.stroke();

	// Draw sparks
	trailsCtx.lineWidth = Spark.drawWidth;
	trailsCtx.lineCap = 'butt';
	COLOR_CODES.forEach(color => {
		const sparks = Spark.active[color];
		trailsCtx.strokeStyle = color;
		trailsCtx.beginPath();
		sparks.forEach(spark => {
			trailsCtx.moveTo(spark.x, spark.y);
			trailsCtx.lineTo(spark.prevX, spark.prevY);
		});
		trailsCtx.stroke();
	});
	
	
	// Render speed bar if visible
	if (speedBarOpacity) {
		const speedBarHeight = 6;
		mainCtx.globalAlpha = speedBarOpacity;
		mainCtx.fillStyle = COLOR.Blue;
		mainCtx.fillRect(0, height - speedBarHeight, width * simSpeed, speedBarHeight);
		mainCtx.globalAlpha = 1;
	}
	
	
	trailsCtx.setTransform(1, 0, 0, 1, 0, 0);
	mainCtx.setTransform(1, 0, 0, 1, 0, 0);
}


// Draw colored overlay based on combined brightness of stars (light up the sky!)
// Note: this is applied to the canvas container's background-color, so it's behind the particles
const currentSkyColor = { r: 0, g: 0, b: 0 };
const targetSkyColor = { r: 0, g: 0, b: 0 };
function colorSky(speed) {
	// The maximum r, g, or b value that will be used (255 would represent no maximum)
	const maxSkySaturation = skyLightingSelector() * 15;
	// How many stars are required in total to reach maximum sky brightness
	const maxStarCount = 500;
	let totalStarCount = 0;
	// Initialize sky as black
	targetSkyColor.r = 0;
	targetSkyColor.g = 0;
	targetSkyColor.b = 0;
	// Add each known color to sky, multiplied by particle count of that color. This will put RGB values wildly out of bounds, but we'll scale them back later.
	// Also add up total star count.
	COLOR_CODES.forEach(color => {
		const tuple = COLOR_TUPLES[color];
		const count =  Star.active[color].length;
		totalStarCount += count;
		targetSkyColor.r += tuple.r * count;
		targetSkyColor.g += tuple.g * count;
		targetSkyColor.b += tuple.b * count;
	});
	
	// Clamp intensity at 1.0, and map to a custom non-linear curve. This allows few stars to perceivably light up the sky, while more stars continue to increase the brightness but at a lesser rate. This is more inline with humans' non-linear brightness perception.
	const intensity = Math.pow(Math.min(1, totalStarCount / maxStarCount), 0.3);
	// Figure out which color component has the highest value, so we can scale them without affecting the ratios.
	// Prevent 0 from being used, so we don't divide by zero in the next step.
	const maxColorComponent = Math.max(1, targetSkyColor.r, targetSkyColor.g, targetSkyColor.b);
	// Scale all color components to a max of `maxSkySaturation`, and apply intensity.
	targetSkyColor.r = targetSkyColor.r / maxColorComponent * maxSkySaturation * intensity;
	targetSkyColor.g = targetSkyColor.g / maxColorComponent * maxSkySaturation * intensity;
	targetSkyColor.b = targetSkyColor.b / maxColorComponent * maxSkySaturation * intensity;
	
	// Animate changes to color to smooth out transitions.
	const colorChange = 10;
	currentSkyColor.r += (targetSkyColor.r - currentSkyColor.r) / colorChange * speed;
	currentSkyColor.g += (targetSkyColor.g - currentSkyColor.g) / colorChange * speed;
	currentSkyColor.b += (targetSkyColor.b - currentSkyColor.b) / colorChange * speed;
	
	//appNodes.canvasContainer.style.backgroundColor = `rgba(${currentSkyColor.r | 0}, ${currentSkyColor.g | 0}, ${currentSkyColor.b | 0}, 0.25)`;
}

mainStage.addEventListener('ticker', update);


// Helper used to semi-randomly spread particles over an arc
// Values are flexible - `start` and `arcLength` can be negative, and `randomness` is simply a multiplier for random addition.
function createParticleArc(start, arcLength, count, randomness, particleFactory) {
	const angleDelta = arcLength / count;
	// Sometimes there is an extra particle at the end, too close to the start. Subtracting half the angleDelta ensures that is skipped.
	// Would be nice to fix this a better way.
	const end = start + arcLength - (angleDelta * 0.5);
	
	if (end > start) {
		// Optimization: `angle=angle+angleDelta` vs. angle+=angleDelta
		// V8 deoptimises with let compound assignment
		for (let angle=start; angle<end; angle=angle+angleDelta) {
			particleFactory(angle + Math.random() * angleDelta * randomness);
		}
	} else {
		for (let angle=start; angle>end; angle=angle+angleDelta) {
			particleFactory(angle + Math.random() * angleDelta * randomness);
		}
	}
}


// Helper used to create a spherical burst of particles
function createBurst(count, particleFactory, startAngle=0, arcLength=PI_2) {
	// Assuming sphere with surface area of `count`, calculate various
	// properties of said sphere (unit is stars).
	// Radius
	const R = 0.5 * Math.sqrt(count/Math.PI);
	// Circumference
	const C = 2 * R * Math.PI;
	// Half Circumference
	const C_HALF = C / 2;
	
	// Make a series of rings, sizing them as if they were spaced evenly
	// along the curved surface of a sphere.
	for (let i=0; i<=C_HALF; i++) {
		const ringAngle = i / C_HALF * PI_HALF;
		const ringSize = Math.cos(ringAngle);
		const partsPerFullRing = C * ringSize;
		const partsPerArc = partsPerFullRing * (arcLength / PI_2);
		
		const angleInc = PI_2 / partsPerFullRing;
		const angleOffset = Math.random() * angleInc + startAngle;
		// Each particle needs a bit of randomness to improve appearance.
		const maxRandomAngleOffset = angleInc * 0.33;
		
		for (let i=0; i<partsPerArc; i++) {
			const randomAngleOffset = Math.random() * maxRandomAngleOffset;
			let angle = angleInc * i + angleOffset + randomAngleOffset;
			particleFactory(angle, ringSize);
		}
	}
}




// Various star effects.
// These are designed to be attached to a star's `onDeath` event.

// Crossette breaks star into four same-color pieces which branch in a cross-like shape.
function crossetteEffect(star) {
	const startAngle = Math.random() * PI_HALF;
	createParticleArc(startAngle, PI_2, 4, 0.5, (angle) => {
		Star.add(
			star.x,
			star.y,
			star.color,
			angle,
			Math.random() * 0.6 + 0.75,
			600
		);
	});
}

// Flower is like a mini shell
function floralEffect(star) {
	const count = 12 + 6 * quality;
	createBurst(count, (angle, speedMult) => {
		Star.add(
			star.x,
			star.y,
			star.color,
			angle,
			speedMult * 2.4,
			1000 + Math.random() * 300,
			star.speedX,
			star.speedY
		);
	});
	// Queue burst flash render
	BurstFlash.add(star.x, star.y, 46);
	soundManager.playSound('burstSmall');
}

// Floral burst with willow stars
function fallingLeavesEffect(star) {
	createBurst(7, (angle, speedMult) => {
		const newStar = Star.add(
			star.x,
			star.y,
			INVISIBLE,
			angle,
			speedMult * 2.4,
			2400 + Math.random() * 600,
			star.speedX,
			star.speedY
		);
		
		newStar.sparkColor = COLOR.Gold;
		newStar.sparkFreq = 144 / quality;
		newStar.sparkSpeed = 0.28;
		newStar.sparkLife = 750;
		newStar.sparkLifeVariation = 3.2;
	});
	// Queue burst flash render
	BurstFlash.add(star.x, star.y, 46);
	soundManager.playSound('burstSmall');
}

// Crackle pops into a small cloud of golden sparks.
function crackleEffect(star) {
	const count = isHighQuality ? 32 : 16;
	createParticleArc(0, PI_2, count, 1.8, (angle) => {
		Spark.add(
			star.x,
			star.y,
			COLOR.Gold,
			angle,
			// apply near cubic falloff to speed (places more particles towards outside)
			Math.pow(Math.random(), 0.45) * 2.4,
			300 + Math.random() * 200
		);
	});
}



/**
 * Shell can be constructed with options:
 *
 * spreadSize:      Size of the burst.
 * starCount: Number of stars to create. This is optional, and will be set to a reasonable quantity for size if omitted.
 * starLife:
 * starLifeVariation:
 * color:
 * glitterColor:
 * glitter: One of: 'light', 'medium', 'heavy', 'streamer', 'willow'
 * pistil:
 * pistilColor:
 * streamers:
 * crossette:
 * floral:
 * crackle:
 */
class Shell {
	constructor(options) {
		Object.assign(this, options);
		this.starLifeVariation = options.starLifeVariation || 0.125;
		this.color = options.color || randomColor();
		this.glitterColor = options.glitterColor || this.color;
				
		// Set default starCount if needed, will be based on shell size and scale exponentially, like a sphere's surface area.
		if (!this.starCount) {
			const density = options.starDensity || 1;
			const scaledSize = this.spreadSize / 54;
			this.starCount = Math.max(6, scaledSize * scaledSize * density);
		}
	}
	
	launch(position, launchHeight) {
		const width = stageW;
		const height = stageH;
		// Distance from sides of screen to keep shells.
		const hpad = 60;
		// Distance from top of screen to keep shell bursts.
		const vpad = 50;
		// Minimum burst height, as a percentage of stage height
		const minHeightPercent = 0.45;
		// Minimum burst height in px
		const minHeight = height - height * minHeightPercent;
		
		const launchX = position * (width - hpad * 2) + hpad;
		const launchY = height;
		const burstY = minHeight - (launchHeight * (minHeight - vpad));
		
		const launchDistance = launchY - burstY;
		// Using a custom power curve to approximate Vi needed to reach launchDistance under gravity and air drag.
		// Magic numbers came from testing.
		const launchVelocity = Math.pow(launchDistance * 0.04, 0.64);
		
		const comet = this.comet = Star.add(
			launchX,
			launchY,
			typeof this.color === 'string' && this.color !== 'random' ? this.color : COLOR.White,
			Math.PI,
			launchVelocity * (this.horsetail ? 1.2 : 1),
			// Hang time is derived linearly from Vi; exact number came from testing
			launchVelocity * (this.horsetail ? 100 : 400)
		);
		
		// making comet "heavy" limits air drag
		comet.heavy = true;
		// comet spark trail
		comet.spinRadius = MyMath.random(0.32, 0.85);
		comet.sparkFreq = 32 / quality;
		if (isHighQuality) comet.sparkFreq = 8;
		comet.sparkLife = 320;
		comet.sparkLifeVariation = 3;
		if (this.glitter === 'willow' || this.fallingLeaves) {
			comet.sparkFreq = 20 / quality;
			comet.sparkSpeed = 0.5;
			comet.sparkLife = 500;
		}
		if (this.color === INVISIBLE) {
			comet.sparkColor = COLOR.Gold;
		}
		
		// Randomly make comet "burn out" a bit early.
		// This is disabled for horsetail shells, due to their very short airtime.
		if (Math.random() > 0.4 && !this.horsetail) {
			comet.secondColor = INVISIBLE;
			comet.transitionTime = Math.pow(Math.random(), 1.5) * 700 + 500;
		}
		
		comet.onDeath = comet => this.burst(comet.x, comet.y);
		
		soundManager.playSound('lift');
	}
	
	burst(x, y) {
		// Set burst speed so overall burst grows to set size. This specific formula was derived from testing, and is affected by simulated air drag.
		const speed = this.spreadSize / 96;

		let color, onDeath, sparkFreq, sparkSpeed, sparkLife;
		let sparkLifeVariation = 0.25;
		// Some death effects, like crackle, play a sound, but should only be played once.
		let playedDeathSound = false;
		
		if (this.crossette) onDeath = (star) => {
			if (!playedDeathSound) {
				soundManager.playSound('crackleSmall');
				playedDeathSound = true;
			}
			crossetteEffect(star);
		}
		if (this.crackle) onDeath = (star) => {
			if (!playedDeathSound) {
				soundManager.playSound('crackle');
				playedDeathSound = true;
			}
			crackleEffect(star);
		}
		if (this.floral) onDeath = floralEffect;
		if (this.fallingLeaves) onDeath = fallingLeavesEffect;
		
		if (this.glitter === 'light') {
			sparkFreq = 400;
			sparkSpeed = 0.3;
			sparkLife = 300;
			sparkLifeVariation = 2;
		}
		else if (this.glitter === 'medium') {
			sparkFreq = 200;
			sparkSpeed = 0.44;
			sparkLife = 700;
			sparkLifeVariation = 2;
		}
		else if (this.glitter === 'heavy') {
			sparkFreq = 80;
			sparkSpeed = 0.8;
			sparkLife = 1400;
			sparkLifeVariation = 2;
		}
		else if (this.glitter === 'thick') {
			sparkFreq = 16;
			sparkSpeed = isHighQuality ? 1.65 : 1.5;
			sparkLife = 1400;
			sparkLifeVariation = 3;
		}
		else if (this.glitter === 'streamer') {
			sparkFreq = 32;
			sparkSpeed = 1.05;
			sparkLife = 620;
			sparkLifeVariation = 2;
		}
		else if (this.glitter === 'willow') {
			sparkFreq = 120;
			sparkSpeed = 0.34;
			sparkLife = 1400;
			sparkLifeVariation = 3.8;
		}
		
		// Apply quality to spark count
		sparkFreq = sparkFreq / quality;
		
		// Star factory for primary burst, pistils, and streamers.
		let firstStar = true;
		const starFactory = (angle, speedMult) => {
			// For non-horsetail shells, compute an initial vertical speed to add to star burst.
			// The magic number comes from testing what looks best. The ideal is that all shell
			// bursts appear visually centered for the majority of the star life (excl. willows etc.)
			const standardInitialSpeed = this.spreadSize / 1800;
			
			const star = Star.add(
				x,
				y,
				color || randomColor(),
				angle,
				speedMult * speed,
				// add minor variation to star life
				this.starLife + Math.random() * this.starLife * this.starLifeVariation,
				this.horsetail ? this.comet && this.comet.speedX : 0,
				this.horsetail ? this.comet && this.comet.speedY : -standardInitialSpeed
			);
	
			if (this.secondColor) {
				star.transitionTime = this.starLife * (Math.random() * 0.05 + 0.32);
				star.secondColor = this.secondColor;
			}

			if (this.strobe) {
				star.transitionTime = this.starLife * (Math.random() * 0.08 + 0.46);
				star.strobe = true;
				// How many milliseconds between switch of strobe state "tick". Note that the strobe pattern
				// is on:off:off, so this is the "on" duration, while the "off" duration is twice as long.
				star.strobeFreq = Math.random() * 20 + 40;
				if (this.strobeColor) {
					star.secondColor = this.strobeColor;
				}
			}
			
			star.onDeath = onDeath;

			if (this.glitter) {
				star.sparkFreq = sparkFreq;
				star.sparkSpeed = sparkSpeed;
				star.sparkLife = sparkLife;
				star.sparkLifeVariation = sparkLifeVariation;
				star.sparkColor = this.glitterColor;
				star.sparkTimer = Math.random() * star.sparkFreq;
			}
		};
		
		
		if (typeof this.color === 'string') {
			if (this.color === 'random') {
				color = null; // falsey value creates random color in starFactory
			} else {
				color = this.color;
			}
			
			// Rings have positional randomness, but are rotated randomly
			if (this.ring) {
				const ringStartAngle = Math.random() * Math.PI;
				const ringSquash = Math.pow(Math.random(), 2) * 0.85 + 0.15;;
				
				createParticleArc(0, PI_2, this.starCount, 0, angle => {
					// Create a ring, squashed horizontally
					const initSpeedX = Math.sin(angle) * speed * ringSquash;
					const initSpeedY = Math.cos(angle) * speed;
					// Rotate ring
					const newSpeed = MyMath.pointDist(0, 0, initSpeedX, initSpeedY);
					const newAngle = MyMath.pointAngle(0, 0, initSpeedX, initSpeedY) + ringStartAngle;
					const star = Star.add(
						x,
						y,
						color,
						newAngle,
						// apply near cubic falloff to speed (places more particles towards outside)
						newSpeed,//speed,
						// add minor variation to star life
						this.starLife + Math.random() * this.starLife * this.starLifeVariation
					);
					
					if (this.glitter) {
						star.sparkFreq = sparkFreq;
						star.sparkSpeed = sparkSpeed;
						star.sparkLife = sparkLife;
						star.sparkLifeVariation = sparkLifeVariation;
						star.sparkColor = this.glitterColor;
						star.sparkTimer = Math.random() * star.sparkFreq;
					}
				});
			}
			// Normal burst
			else {
				createBurst(this.starCount, starFactory);
			}
		}
		else if (Array.isArray(this.color)) {
			if (Math.random() < 0.5) {
				const start = Math.random() * Math.PI;
				const start2 = start + Math.PI;
				const arc = Math.PI;
				color = this.color[0];
				// Not creating a full arc automatically reduces star count.
				createBurst(this.starCount, starFactory, start, arc);
				color = this.color[1];
				createBurst(this.starCount, starFactory, start2, arc);
			} else {
				color = this.color[0];
				createBurst(this.starCount / 2, starFactory);
				color = this.color[1];
				createBurst(this.starCount / 2, starFactory);
			}
		}
		else {
			throw new Error('Invalid shell color. Expected string or array of strings, but got: ' + this.color);
		}
		
		if (this.pistil) {
			const innerShell = new Shell({
				spreadSize: this.spreadSize * 0.5,
				starLife: this.starLife * 0.6,
				starLifeVariation: this.starLifeVariation,
				starDensity: 1.4,
				color: this.pistilColor,
				glitter: 'light',
				glitterColor: this.pistilColor === COLOR.Gold ? COLOR.Gold : COLOR.White
			});
			innerShell.burst(x, y);
		}
		
		if (this.streamers) {
			const innerShell = new Shell({
				spreadSize: this.spreadSize * 0.9,
				starLife: this.starLife * 0.8,
				starLifeVariation: this.starLifeVariation,
				starCount: Math.floor(Math.max(6, this.spreadSize / 45)),
				color: COLOR.White,
				glitter: 'streamer'
			});
			innerShell.burst(x, y);
		}
		
		// Queue burst flash render
		BurstFlash.add(x, y, this.spreadSize / 4);

		// Play sound, but only for "original" shell, the one that was launched.
		// We don't want multiple sounds from pistil or streamer "sub-shells".
		// This can be detected by the presence of a comet.
		if (this.comet) {
			// Scale explosion sound based on current shell size and selected (max) shell size.
			// Shooting selected shell size will always sound the same no matter the selected size,
			// but when smaller shells are auto-fired, they will sound smaller. It doesn't sound great
			// when a value too small is given though, so instead of basing it on proportions, we just
			// look at the difference in size and map it to a range known to sound good.
			const maxDiff = 2;
			const sizeDifferenceFromMaxSize = Math.min(maxDiff, shellSizeSelector() - this.shellSize);
			const soundScale = (1 - sizeDifferenceFromMaxSize / maxDiff) * 0.3 + 0.7;
			soundManager.playSound('burst', soundScale);
		}
	}
}



const BurstFlash = {
	active: [],
	_pool: [],
	
	_new() {
		return {}
	},
	
	add(x, y, radius) {
		const instance = this._pool.pop() || this._new();
		
		instance.x = x;
		instance.y = y;
		instance.radius = radius;
		
		this.active.push(instance);
		return instance;
	},
	
	returnInstance(instance) {
		this._pool.push(instance);
	}
};



// Helper to generate objects for storing active particles.
// Particles are stored in arrays keyed by color (code, not name) for improved rendering performance.
function createParticleCollection() {
	const collection = {};
	COLOR_CODES_W_INVIS.forEach(color => {
		collection[color] = [];
	});
	return collection;
}


// Star properties (WIP)
// -----------------------
// transitionTime - how close to end of life that star transition happens

const Star = {
	// Visual properties
	drawWidth: 3,
	airDrag: 0.98,
	airDragHeavy: 0.992,
	
	// Star particles will be keyed by color
	active: createParticleCollection(),
	_pool: [],
	
	_new() {
		return {};
	},

	add(x, y, color, angle, speed, life, speedOffX, speedOffY) {
		const instance = this._pool.pop() || this._new();
		
		instance.visible = true;
		instance.heavy = false;
		instance.x = x;
		instance.y = y;
		instance.prevX = x;
		instance.prevY = y;
		instance.color = color;
		instance.speedX = Math.sin(angle) * speed + (speedOffX || 0);
		instance.speedY = Math.cos(angle) * speed + (speedOffY || 0);
		instance.life = life;
		instance.fullLife = life;
		instance.spinAngle = Math.random() * PI_2;
		instance.spinSpeed = 0.8;
		instance.spinRadius = 0;
		instance.sparkFreq = 0; // ms between spark emissions
		instance.sparkSpeed = 1;
		instance.sparkTimer = 0;
		instance.sparkColor = color;
		instance.sparkLife = 750;
		instance.sparkLifeVariation = 0.25;
		instance.strobe = false;
		
		this.active[color].push(instance);
		return instance;
	},

	// Public method for cleaning up and returning an instance back to the pool.
	returnInstance(instance) {
		// Call onDeath handler if available (and pass it current star instance)
		instance.onDeath && instance.onDeath(instance);
		// Clean up
		instance.onDeath = null;
		instance.secondColor = null;
		instance.transitionTime = 0;
		instance.colorChanged = false;
		// Add back to the pool.
		this._pool.push(instance);
	}
};


const Spark = {
	// Visual properties
	drawWidth: 0, // set in `configDidUpdate()`
	airDrag: 0.9,
	
	// Star particles will be keyed by color
	active: createParticleCollection(),
	_pool: [],
	
	_new() {
		return {};
	},

	add(x, y, color, angle, speed, life) {
		const instance = this._pool.pop() || this._new();
		
		instance.x = x;
		instance.y = y;
		instance.prevX = x;
		instance.prevY = y;
		instance.color = color;
		instance.speedX = Math.sin(angle) * speed;
		instance.speedY = Math.cos(angle) * speed;
		instance.life = life;
		
		this.active[color].push(instance);
		return instance;
	},

	// Public method for cleaning up and returning an instance back to the pool.
	returnInstance(instance) {
		// Add back to the pool.
		this._pool.push(instance);
	}
};

const audioBlobs = {
	"burst1.mp3": "data:audio/mp3;base64,//uUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAA8AACG0AACCQkQFxceHiQpKS4uMzY2Ozs+QkJHR0pPT1JSV1tbX19jY2dsbG9zc3h4fHyAhISIjIyQkJWYmJycoaSkqamsrLG0tLm5vMDAxMjIzMzT19fb29/k5Ofn6+vv8vL29vr+/v8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAOHjQAAwAAAhtDjBNMvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//t0RAADIAAAR4AAAAgAAAjAAAABDem5GRT1AAnXuGMinqABX8gBjFfH/HfGgWw4G4es51uKW9i01FsAFg1kBAIgwhC7C/C8IScgLOPCQzVFPH7mGK9B4QFkEWLb6vkDHz6nnsp7mKhhlT9DG1fdKHn/nmN//pq+p+6bN3+qr/7f///6p0mJdjjzEZmVE3PnsQh22pYAExivhXs7ETgtiAfHWc629J2pppDkAFg1mEAiCQhC7BvC8IRuPCxw8MMcgZFPH7mR+T0HhAWQRYtvox548bMzOrmKhhlSfU99G21MM/PMZ/pV9F6dX6ZhjVak90MMo38xv//T6N6aLsl0ax9lRWsqENZG0qpDCCADcwAxBjCEMiAMhkABBxiaVbNj//vkZAsACIiASv52oADFEAmvzcwAIFF5TFncgArNL6pDMvAAHANww/gwE1ZVLWpGNgfGFoEPRdQltbNOFzOpUPHaJTBEBxlANTjEFg4M2J4GXGRDbSaAxyKQMNgMY4PUDCYYzEACBkWCxwERhCgvI4doy5BiGEcLcOAhpJAYQAgGIA8GJADgIAMS50l500I0ZMWMih0uAQBIKBYBQfgYDAZwCQQIcbE4lzpeNjA0JwxEOAwUAALCQG6QCgcBueCEE86YVHyfL7pjIGpXLYDAbDgxsBisTcDcwAYCBbDsxtmk0TNHNxmzZA6kOIA4CEgQ0VILggMCAIlQ+cfH/80JxF6f8LPhwJAgbaBhMPuaGCJuRNNP/6v////q////N+omOWM2hABACkJBYDgUiABD9O41trIBHX4YK3yA8WNzPiD+LDI4GuaBwgrRMEQckAIdajc3QEYAooQYJ7D0ETUdZNCzwtdBR1fLjqaKoDgQuCPAbESQLxi5gYGhUOGh4zD0w2AiINsxWWzhXKqaflxZBmKpAhAAcI+D/1rNyv1m6YlAOeTI4xOZ4cgLn1W+kpN7UEGNFjiEEAuYLg4BZZfFJh9C7//TL7Vuxum5E1MQATsMhKhySaZSIkT6f//////////5EwAQAAGzHseTFpCDG3BzUApTVgfDhEyDPgYDFsQzCsDjCgYDB8TA4shoajFoRDAkRwweBgEgKFBxvGQCSQgBRMcFGoIifM3hjcIARYySl4hJBQJgiiFFBEh6a6qHckFeR/0nw5UaTR8MIBBMMgAo9xlLFosyUWgyGhUVnSRSCoQG3dYalZA8D6tDSGZk28OM4UfXIpmiixJfjQFh2kQpw2bwBHo64sMSmloX6yZQzpwWzt+4jltjjdJUksRjFJuip8pV3VmVvVRQLC34kj11pdSfW7XywymccMZ2m5emMsu6ceJwBdf2XTlivlfwws1bnLd25Wo5nDHOtP8pc6LG5Td3WXMUcBDgokHFGymagJdtA0EMrdMI49iUi2DsuRaHhE5gJRSM40j4CWi4HUqEKeiYuA60YdAh7KqaK0s2g6DrL+vPTpN1hneoksC8wIavpc6GxFthzSYZrutR6q6M34WVGhacZ2FaiQ7uousz4mpAno4NCjTi6YXaWgPo24flrefWpY2eyKNfXnSpW1BAa8+sz7Fabtf089b7rmErmhRx2CV7GcHj+SucXrq1dWtuu/m/////ngAAcz7u4+Bmo8+7My5MExuCU0aEgw/EsweJYwOD4xbEESFMxMAk//vkZBMOaJ5dTZd3QAKqS0pJ7TwAXWVpOA5nCUt8sCeNvLG4w8DkxuAkRBEQE6ARmBxXmHispNYSOSAOwzOGIOgXA2M3CcBcgsEMKDL6J8hRQBhqAsyRgwzQFVQ4HOGGCmDVhiE0hrgYFBQAxZMmEAEAPBC0YiAmTOtRApQWZoyF6kCMPmWChAwsClMy5C7EFU0n+a+hsEDGnuGvIupKGyPe4DA2DIg3GawG3darTX6WMydL1ub2pIsNemB5CzaUSzOVODDtJuhbIz6D5i7IpqCnGdblqG+ReW59h7bsckdSUTtvdvLWUvl2oDvYYQNKovLsv/UK7ffb99fuCH75lBlmXSBy908apYtn3WcikIJEwAxAAAAHKlU5xkVgHLcHLDBloKglrDgAgAqptLJgzQlZngaw2wcY+jnFcFLAUjPN4wnSQGGSg2VCXUyFWe6Er48CpHSX4WE2ToYU8dh2v0G4x1csKJyUTE1KqHd3aWPe07FM36ixMQWqaJiO4S4hX8trOWIEf01LuSvktbfq9rv1x61tP/9Vr8QsX1/i9v8fWLWtuuKZ1v13jfp9b3iBe26/51ml4EoWK3IjMXbQxzYzfCKPekA/nBTPgdMUBYyGJjUBeMpGowCTjQNzYmtM4Y8diikzjATWYtp4+pLmY8Z/ZgLmdQBHzJCENFKZNjTxGKjMbxEpN8znHvlvhaCZZscGUVIKDgFMMjws8yUHgtIZOXrYgEEeWjXylwSALmw4XSR4WMwcLhfxWJwoYao6ydL8Py9K/29aA+72RNvHaaA28vldhuzBIblzmNaZKy1wpQ4kdgmTzMzXuU9SBJbOfPwHMT8WjGpfr5jHOxS0mGUsnaCgz7cuXse27PcO//ame991e1V+9vPvN65vn6wzx+7EHDANTQAMMCMQMRAxeN+dDniALERhAyYyBGuAwNQQg0Bw2ISUwY+MACjLXNwAWXJAzfIR/CgIAiCgoIILhkTR0ilqkbQFEEEgEYYCSoGoAw4wBE+mKoSjGIdcaEYkwuMCIwHAu+xoIMBQ6FjEFeOY6DdI67L6af8BxYPi+QA5KhWI9DKASkhw8HI+6eEcRRCClGdIdHAajc4LqCSwzjPBHLeoKNavZXwWXVs28ee77NbMuNwROPVaT1/0tuejjhHife5Cfdceca1Yyp3oLpXD15KpOnDuJtQvPUJc/EfuwJY2mWNqMITaMPz1Nh/UO4YcN9FHMVgUMLB/MHRPMzhwMXQJMYw7McQJMDhZMSBLBgLMPdMHBAVkmF4Zrois//vkZByP58BZTQO5e/LKC+nibwxuXwVRNA7p7ctnLybBvLH4GizMMGmjIyHFyaQUYMMoy+TT4Ez0tgFAhyApoNJCNwCEsAFHyMwOYeQwUTAHTEMsEkFCg5KW1FPoHHqUly03kFI8hIKgjdkZEwSAEGoM3W6gCZGpigsu1yoLWuSBlBIIUxHUumAuZVj0C6HapTWN0uDeqVpioXIgxhqs51chzU5owoFN1CsH7hz2wuT9BqxQKBgoqm9tb11mz3p9qgQ66itkekVx+Iu2abMCsFzYKvvbdZ42szUk3rc34/obxxcAAHMKDjRyQO0TnnEFEI6PkAMEABgpcaIOgYgFQMYEUUBoIAoCFgOUq8BLAVE/VASzzUxC4Ii5SaTkCJDMDQBmYGMzESEASFUAXFLkO7IlejIwaRCN/kI1zsYZEwJHdOZra/lXrlcJ2oZiUwOQTFbyDywnjkXA6fwAcCN4TOhxjxkV1bZ/U+XOodzMprORlSU6xs6M7xo1f+zXW4t6jer4Hm2X64731s99nI9rlottdm9l8bTm5BAqmi1hcvgXY41MwbNf6Lr0no/yNyUVOel7NLZhNRaDMpVUM/S/MNg8MJTWDk7MvDCMQgMMQwLMZhtMJyQMIwVNgcNqJA1Y1wsQoQKjNozOHHNsej4ZlDDCZ5njpfZEUy4Q2cAwAQRCAqZBwAlNl5QcmLWDxUdBBUOy8WAq5BIVL1hqYIKDMyAx5Vihw8CMOSUpnZwMGrjWiAIhokMBbE5ByAHIDUC9FdZD3EqcyXgl/HkS8ljOhavMIW4/2I4ibkLdokvDcax7uqmgemT8ZJhbjWOZvWl3WbDxeYFeYCuZ1M5oSpl0zVYbvGJ4yeaHJ5I0eZtcXlp7RoOGZyhP9Vln+ZZJnLFbPgn4ur2YqmGxFx2DwfWKGrXZmoKaMSmXpZjDiAtgoPzCDwxFFMGQAcUA4VMGADBjMxTEjl3nQaHXKmNAUw3CB84G2yFuU1C84B3NBo5wjewRCM9ZBOlLbLgpUEoKkDHCa6VgI7PwlO1WsJCp/yOidZajdGkx1zW+sy6I16PbD4ormaZ+0h52SIa+MMBMZJB0dvhkDxXJsqkEnoJq+ejiYmi8w4vnWiMsLRxptAtPeNDsfYj4zO4uOBOYd49WLVri7KzCfQrXj1ntv8G0tMf3ifef5iv0nJvM583y0z1VvwAAsxnBajSqO9O4I6P5T3NrPbNTzWHhTN3BXNNlTAJ7mQ52mHpNGNxcGBgDGL43H4Jh0M2dAz6o2EI4gc1dM9UM//vkZCCO6R5fS5Pd0FKbB1oSbwxcYRV9MC7p79L0LifNvCW5MhmuQmPEmJJnFcGdACRsmwGyXHnhLDABAfF6Fy4EIg54ZR2amkVDhdU1BUwCY2R8zBZAIDgYY4Gj5jRJmjZpwBiD5e0lYGBEjhVDAIIiAODEAJAITBYku1wHSVtWw7jV2mrcUEVCxtEhYJL8gEp4PK9ql7KVAnJTddF+FWq6WdFmeuC70ddBxGzteayyW1YbJAL6wMsWGH+ZjRyCCYdmbT+TOWM7dvQ7IY9LexeBnblUtnWJUEremX0E/uBnsqbkHeTFWVRqXy61/JXDlavBMGT9/uVaTRmnoZDS6+XZ93VpdEwAAslCDIYQO8zLxQxMoMrB0T05i95kAQkyrG3gWAyqBmoIklo4ZgKAlPRJgjXl8ETk5WjLseRxH5BBWsr2XTGXtavE1AYYEoOyuM0EJBgCACR0OiQcWVBsjQ3CYekKzLZ3XIIX9lc5zT7sfTDMbe6ytc/9iq5DHkc03n26QraR1hQbHHulpjVbDZDAeg3ruInrPJjTecOhR3WPVCbDxIYQXIdVLufTPGaTE0IxoMOAhMVgOMWiTMNk4MpiyMPAwMKAfEioMjQvMSxXMrSzMkQ5KrEMSGTHmfTnR5mVTm/RiEWYjULezCsTawzhrRkiEPWaiNMapMZNUCrAQLJDxmg5NZMQUAy9VAyAw1AoxBAeQoXAxUAjJpSpnRa1jDEDQFBkCgnHgiV48DYGLJEJqYyNNhNqHlzNLhumcBtkLy26WKwJIaZCC3oYQ8kTSZYnQ6i5SkOHoLgoRSXA3mguw+BbG1qP+0ZnQU1nJDKH+/mZILhRl2o4Ti9iMOcRFeyTwLxpJY8mNz01ilszRZsfyb8vi5xRstNbMf7mpAh4cK6m3LaDESAnX+AF2ZAJmtGBiwSFAYDFhlRsAQI0wMMoDkkC4xgAuBhdJdZiHIFKFkI4txQHJws/dhqIBGrEnUw5WIyAXIow7LpK4LWLERkQsTnRTUTL4KLIkRBx5O0lYdYeNVrbE4/L3HcN342HwCB8fU1kE4LK7rSBIpMjL6KCQoygokOFGIJWqQIHYZuK5Gp4Jz3qoxUQGOzJNVGpr/LYYnGnInY3GEm5RTxRBDyymP4ZeW4cgy0RwdKU24zqFpZOxOoATQoUjgENTLNkzQgfT7HIzdEACccCdHUH5uyiaeXmaIBgJieKIGQkAlFGOCIABjXYERwBAMlc4ADOjAQ4GJHpQW4ap5hHGBKFBz6EECgwODUB7xOdIUw3//vUZCwOJwlUTgu7yNTOqYnScwyYXZ1NMk7lj8pXKak1hiIpkxVBEJQYQDVC6zTAEmCqk5EQ1fgkKMkU7cE2SyUuSSS1WHXHI18L1VjqtTvMtLXOg5L+sOf+TtcZfqgiyw0vmZOy2tEZqDYE1Q25RSXItTwBbeWkivJ6Oz2MqrZ1K9+ekN6nx5Nd+1jy5jUx+tU7z8P5r/y1lz8ce85zPD//PX95yq1CQaYdstUAADGFxyZJWZkdAHZlmZpHRlkeAkQGGCOY8K5nkcjoyMiFFHgwkIVrlURhUDAwimPgMTBYwoFzDIHMpAQBCYEAhFYhMAmHkJeAIGbLIyq2hUKiJn0F2KZCoQ8xoeAwFsUGgEewkysRVVUiW6BqUS72DqoxJiKqDDYaa48BgMB+MzJICIkCyNfTTRAHZwueHCds+GtA1UqgM16wvacnUa0rLS+WX2W3b/ei1dzFJjvPts1Wznuf3y1Nmcr1az0wzrM7EWNEKSQgVwpTiUzzblwGMlgKNsViOH1hMinIMClqMeASEQamEIuGG5oGMgOmFgxmK4tAADzFwKywBIKVIwnAQxRBkyzzgJAKBrFgjxmgCtEWzSjdRXMwYwVDoCLlhmBMCFDzF1BSTGhCMTJGQaa6zlmQQIggZGZQ5gkgLUyWk8RUA0w0JyXrWDDaLmggOaLsKDF3VzzjWlUEW1MUiETW6qFuwvpaMXEkGI7CQA0dWxxJRKBE+V4Iw5kwVJy4mOh1TwgsBIZleMkGlDw7hWs3hZdKxKIuPLoq1/8vFSUXLVlYOmFjYqvnsE5W8V9Wzebu50mEnB5u7m2HSZABgQAAK7jERjZ8OPnTNVVeIA8SjLhqtWMX1Ygr559oBmNP1JxzCkAo9i0sBEdlVWIw7G6QaSOSg+kvaVSEJY6MnZMOQnvUhE0s889Bq29ndiSkHOfocJc8akzOqD7pmtuqHiQ4aeUPq5gROZeYHwL3hA4e2lxhyHRTFDGpfY6qVoHy6kzUPBh274syDPRi2RmfLn+IN1UA//vEZACOZYJW0BtPNUKGa1ozZeNuF+j9Nk5l68oaoCidl425AAu83xU3ig1lE6Pk5jI6wwuuImhnRRyyxoRgyMEAwHBUn0BQsTJgosPQcLlKwuggcGAF7LQMSKaEpQRovR+AYlSijPK8IGEaLaS4dQ+GRPmgXInKbJcP5nN4pWFTK6aGYi4iLl8bEfSNccMMOdvyt8y0yJxBSDDqzFU1IEHJcqjkj7oojzUkiWIg6VFyOCae9y9e5qI7MSL0pN0i3x0kF/zn/r/Mdlw2n00saq/IhwAAAu9dgAMM2QQOK3NXBwasKAefRNQzg0s/A5e1AGCZj1HRjRPJTn+ttCtgqxExz4SBSI1+aZzMj7Z+EpU6hjmU1qpzhKFIPHldwIs946uKHF4IciJe7+xnxstS4S5p6w7kWf9t1xIYUMZZL80yaD7Y/w4bG/pXXiZFCGdVDKrCYrk4NkeWWBZtYtHPwOdHOptwRhitNWG0xGLwSPDOoQMeIEwAKnXVlCxBfgN+MNUjmC6ClowgPMDigWBC/ZccMyLombCjcokYKAOXAkgKGDCxkF1S7acRjDKIrCkgKtyXA0akjcQ6qYvwtUAKJeEdTbWLAwAHyrNMu6GEwAIBsDHcSVmESxhbzVVyjUy4gsaqNyIn1mtb1YL5fMcCJ2FkV/gz6fUuxwp417v9Zratt5jdXYuNpkAtcGxCiCxvPx/sp09v/r/6EE72RBg5pRg5oZPFjnXQnmcABmUJSzHNYCmcqRJxXCcEljNa5HkZbtBErLkoatJjFUnl6IK8fzwly5iIFWbQ1IH4u1Er1SqVdI8bImnSui4FgVFAVclJlRjMoGYW2RcL8NujDaAJKkzXRmMSxgopOcDl/SzW6y4jRrGP+pL/S06fDePJYvxV//vEZAAOBZVNThOYS/J46CpXYYhsVUT5OG5hjYnYJOkphg2xAAHDoZ+MLigwzADaYKA4WVCVROYrFZnYylAUMSDUDAEaSAVDocI1omBQCTCUwbBpWFDyRM7JQQULGXaPXNwxoqZKE5ZKYYFAKlAIgeZmaXzEXPL2oxKzl8k1mmqbQe11sME07oyhpb+4tcjsw4rWoaqugzN3odadIIBma7xwzDo0PkqgsKkTUCNCyyk4UGKzr1VrXSeIN/6HfHqKLMXDPCtSVqqy/U4Rzq+4r5HM8Vt18Eg4ABBm/fRAgWcNTA7LSmoKAL+iLwtyZ2tJdowVD28qEAlmilCIYmDQbuLGDAvxGRfH09Wd6xo4IsVU7jtjlibCMUIIPRbtoulSb+4mmmpTrvV/rTCaiBANe5rS0SHkxKEV9B/6RSFnUFnIXhvcYkuM4Q9Ut/bf///QC8YXH5k5Qm8R8aIkAOZoADBhkfmAAmYHKhggQFBBMUAQyCHE/AMJg1anR5YHzHtqWoqD3BaiPIGsXfSuEUx4A1FClFJH1aBepdTfkTVHl7M4T7UOddNJpzjRFnyun4YEfiILhohJYXhQQzFesP3T94kDhxFLSFhFHZc7xcUkB1sxVMPPVXs/ay/ls2e5+cWnUUX/HV36RxVljkdiEysIQqN4Nq20mhf8nyAJAIAAE7wqcuSHZS1ILMHCCtDglerK4GhCt9MYhCIJOFaxYVxu8sLzhWWwLyuToeOmSqerlRJOl0DjiUSnkNsGBgAhHQLSzd7nR7wgfuGBOjmROxmnIwUE1wIHFpofPQGcafmHHkQV/B2PK4FaxCSI1drHplxaAABewIXg+5ouCcmp6ViM6S4klTQuWshOVeULiSbkUWo0uy4CXz9OgvRbqqzZVjj+//u0RBgGZAFEURsMNSKGiUonaYOoT5j9Quy8zYn3JChNl43xTx7EErnYcnYYvCKFINDAuKWx6JxwsaQgVxJJNx5+vqerqCS0D/bZTxu+mcuiV558+RlNbvGdn7fJeMoCkpJLslzXfk6L1ZSXmqQtKaYSp9KIAAAJ3BGYE0zTFzq3RgmOCh0AIwIVFluFO+rRjKBCFr4TaUoawkQtZb6/YCaYzWkc5ubxbCsrh7ARykeqx6LiI+sB4vFUHhLL6Iu4PA83W3+8r3ID59955vMtuUsBhHB1ZkLcmOmXwdRZAjHMiXKDWiTcA64l5IK2lLXWHCK08HmhXRG5uUCFTA6aTSqN4EYxH6gcCChwEmFTWhlwlN0PHzSuOAnQhzgiC9KQu4bDw2IkrMJ8dw42BVKfI6EkdT1JKKKyum1hVkFDUUq55STCC5SBkzeSiDcgxBJX0+VFG6pUFYb5y3hoiWycb/fke5jdLr08879Dfq5Q93sjQ+L4m5+UoTwO9kx3DM4DTgu2PeIAy1Ssb/prucvxpqbyODqOke6uD+HCaJhHCSwTtkcy/M5FEuftaOVZcFtRbOBSVfhhCvk+Z6p6Oywk8tK6aSyezAZIoZTYMriI5miBTk4inE1kUhYYyeKgotiyh0Z43lkx7kc//KqSBIHUwYZWvdtS1QAAS6DEQoEHxk00dA1i3GHAKegXHDIA0xENBIKBQAaEC75d4ZBWXggDMHAGcvoj8vxjxdRVIRh5bBliUqwzqofNPT4Z4uxdyiUX//ukZCUGJNRGTxtpHqJlRAoWYywMEoT3PO3hi8mND6hJl7ErUUnnsemENGhtXrT30feHGTAbDcRMSLEY3hAGwP0SERGhVQoFJ2taZDKLmPCZpqSKM2YO3kxlMGLQo3FxZhi4SkvxmKGb0zHNO+70RMOMpd/AYAAPhKAo+dgZwqCIhA9h7WYZS8ZgrxOtsr7KKQOs4Wl85NEZaLBkkDw0Dqggh2gEZa2iGkpnx8VC7Q6Oyo4OkB0EgcHaxYX7Wtdlg6KLBsFh40i5Knwzc4SkGrT3OYdChLRI7KBA5gYotHRNhiKuaA2GbIgIHUcxoVARGYIHmGiosIGZKxW+WmCjiVmXMzVtYgX+QyeJQFmkFRF2YbkCk2mrqRBUk464mVL6aFeaxDagTnOEz1yIdvRcYMYhnp2XKnSuBeqd7UiRqPe9rIrXl79WzuzOMUlktwt1Pe7zj7WYq7TGfrRmvf8S9h0pvYTqVAhrXmnojvX6NEOkKpkHGNOYZrAGJLdZYucrwmiVFiPo5F0fhUXLVqL8UR5Jw0J7bLZ6dnKTGTkqhaWTIr4fCCQR0HIGyc0Wk+r6TqtPswSVmaPzyFaev/knRTWklq7ZalZjNX0bemj/kx/+KgAGw18MjCBhOHCMyQSD//u0ZAcOJMZGTxOMRpZiQ/ozYYVeU1kFPG3hi8lxD6kph6RwDJsMRiAwKFiECBg0MEhNEQSCgyEXiqyxhCg0SZ8mJKVEC58QQCDwHLAECAAwBhpeuXzLs11ZGspBtLbgmJFIFHgGzmfdtsEAssfWXAGcPR1QixY6MxLSMQNnajTg951ehL7hQayHHkPNw91SfYxFYmuCJe+h1wrtHTy/mZ6drPXSGykLQPPKSJfsJAABe4R0KpzGof8rtpzsLmd94LsyTvLiWoQlkebEYsmdD02H5ItZOH0zSiTMSISq+OKVSuNEJfiMrtA06zPF9bHShe+XnzUv71d6zg5KAfy09hZC7tkzauV1ZWVY92O/f7P9KlAVQRkYNzfDSac3EeMpYwwlMkRTLhMcDDAgxGQHWCoC9icxMBWpJIrCkmHAPJEBjTkQhb6KZGBMJ9GsGILIaqI7/IqoC3kfZU7dpt9HRZI4kTd1eDuToZCe4nVkUuHYcPle5YS5j68mNVhVqX7xvtmcL67afX2mo3vcZpHdYh5Wadb4fz9jfr05+Z3TkwXjuuPc2mjkVJ/+rnUBIAD3BKBRct8ZYCsUqFH6CpMZYTw6xvFwka2s4k2uATJkZQVFig8iXTNyFQnaLEYyXaYfAe16BKn+eyaUZktdJpJ4MtPvAdHqMzgEefc+VUVLmAzD6FvUXj71GAAAFcDiQQ0V7OLEzmhkyUoCJMWGRUCbcwg1SkxBIkYMBr6SpdgRCLSi6Y6ArwLKEQK1sIKF2ATF//ukZBwOZL1BTxtvNNJhxjonYYN8EfULPm2weIGGDuiNh7ERgEYDmiENNACfJ4wknGAONMKMdpbkkTlpVxWKl+zGOpCVdaOBPxkNfrtdsz6HpWVaJHUNdSM24TA0wa8k5lOz7ioudkg2NLO3x8r9tg5TU1pZ9o3aHO3FgskMB5Ow2v/QoAAAXcFzCqAsEea1pM5uqcEpZ4z+H4y48NzUZXOfwFQNoyMjOmUJctNFxwIJIss0mqy2eD0dVNlq+riRZBV19Un+tMx9TPKEd7nlnl9SU/N7DMVYcMmLZ2kkJqdVCltt/cXeDJGUyA5NSFjhV8RhQwEIQhQZMYAjDw8WB0Oq2GbpehUKawFwaH2QqAwcPAxQClziEBcVbQACXoFAdOtkSk1il6IOhhST/0LlS1rwWlZKXS2HxDUpjxg3EdYTikrKo1LitGsSxn/Nx0zmoXGYaOYzqZqznqCVMnK5wnMjX4SbLVqEx3MxKpGwsATQkdGXky7xFFWk3iQglhLchCh6jarAScT0dJBo7SeY6im2eJxoWNrBLLDSeFKajwTEEjhwJMS430QQ+0+OCQV9RO+77WuV6NOaC2vS7upuNrbuFda8/l//wuozXhDdfy8Nql+kv+5aAAAV4MgdTfiE//u0ZASOZIs+zxtpHpJmxFoXYeZsD3TvQmywdonxGmgNp5mxYhThzIxc7BzyugGAZZQFB7AFNkSWoorgYbgFAQFgEu2XffJOIICXNS+W8uYIAVOleJFpiK5WO/apk93mZo476Lmca1MLltxl3HRf6JkigJiAEYIG3KlQwdNB9TEFrHcgmoGQVQcg5apLPAlC4r5WItaZIhh46h6akC5Ag9YiA8cj6adPAe97v2IAAABXCADM01rENSjbZEf1tJlLXUuaClQgo3r6Op4I3DEUi5Q4vjanWC7grEgpCUIjJvwE0uT8ZS2FIaL1TPcvVWw7szlj9/Rypr4ow96huwg0yag8wgMDggZjDxxDmlABSq8sqgaXeA7A5YgVUdFAaKtZUYNFKoql68V5jIKiT8wLERIJsbuMCVof1gCnTL4TYdBVJY0w+EBrLU+6PBiA4SGh4Q7lyyosHZULFjtxs4SYZHd3aA0FDGFeoPLdHIIpEalDar4FSimBOkUzOMzksgkvb6Y975OZPLrNysbd/f5wy8NwMYbMg8BRA86AVCgY+MjSZEvVBMIAg6IdJZi5dvgJE0hcxCyXBdocQxVxSjgrT1dG6lDgI8qzFGKT1Gi6n0XmMjly5pi6ZpoDgYKiklXO+D6oyHbbqGJfay8r+oeXlL+QVUWXx0/Q7pMJ7vkZ8Xv2HQe8VZFS1avy2gAAVeDalDSfx2UThDFrhQMTA1RWQyK0dTBJdB5PkuSXuRsTaL3ssXIFwhEGWBhMRUdTFeVw//u0ZBqOxC9JT5tJHpBupGoTZexmU7DTNm3lLcmHEOhNnDBIYFWWspzC4DL3+wf59XZdNlLU34isFQ9AkYkukIwQTVo2IWlDi8cbTTXMUpK2IiQEkoSuaJv09zHPalkRNz7+T5GhnlwynWPmDkf6IdMnb3IWAAS9wOGSUz+ToiMuMQCLKAwaqbB46gyAoUvYYJmwpsnj+wxjvOYcSvJAFS4H68vaF9CeIhEusw6HQOhiP22IzpUPtfXzFz2PW6X+vjUSEj4rAGOKUdO+MM7m5v/5+V7BP0zFzDTnji97m/7/2v+gXgbrMmYKxrBmZtVGvOwRIAYeFBAlSS84XEgCDgQEJhwaHDVMBV4VUMO5AUAhm0LfhVIBPLDrdERSVIFPQiChinQkCUCIzhBYgBFRh4lr7DGRIvs6xj8zGm5MlUCh7Dilb7RZnrd4Yc964baKKGgJBVhkBYSuJYrjLLWpoYWv7jTSes9LJMZN3Yf9bjFbAsrbCfLesDSpyWjZ7WytOwAAXeE9hCIZQ5qbhxRqtRZgDBSPiYKwDjoWR5DoQ2w7fOwsJysvGpmHiAr06u0eyek84QWxMD0f0bI+3JxYXuPqnOjdh713Y2I0E70oQR2FWCoEAjGJc4R3HRiy+9uhXimuAABdwAyszyYVkNsbiCPSwcWMGVXsGAWgHFAQo5ZBS0GFrjo4mVACWy04Y5Gws2JRlSRDT3MU3oxCaCVKVNnrUuS+ae6qbtK7B2Li2aRtDqbDUOY7PNmTpcJBf85I//ukZC6G5I9AzhtYYnJmJhoDZYJuUPUlOu0weIHLmKeNl424UGpPPVMSRcn3T79fU5MFm9rV/vmdLr973hUMd/fNWOptbzkudv7LEKy4rFW/whmCETu//fgAAL3EwYS4PTNAJKtLis0CA03oJn/d9Yg/Qj6GD5GJgtCPZDsorVZ4uLJIPihYvL3WEau4wLtEHDsv0ZYZUQ0Zr692zIK6KyOUpnse+626rFgv5p/1g30ip2cL47rlWBtf/zfO93oQq8HWUGudGWBgYUaROWSSlWcSCCqLAIQzRxJdKwsymkOB1jpFrAIsKriyZHJm6W7CFLRYVbeVPtdaOigzg1VA1Pxi2wBwpIQTEGiwOlkJPYIqfjag+QYj98waM5RMQxZXKNPgnEmwoohmicYc0PLYzj5lCp59KdbGkRzyy2JdD8nxYdjc/FiZVwJEgfKIRhfcSMCGVdqLpLBYswUR4oOCbrGxAXYCwhZzklJGTQvr5U7X1QspNycSVng/UUx+J08V2W0f+zkgsyWqtKtyV6+4qtqWY0CJfEM4cQtiipshvu6xCrn6USDrWqdIopHSoiGF0JPixm6ObvXaugAAXeBNAMCUAAOGDBhUCzBBAoGTCwYUFFiGJjym4EARCBhcKRzS//u0ZBMG5GU9TxtsNhJtI/oDZeNsUe0ZOO08dQGlFSdJlhqapEIIztL9ZsWaQsOh+4SOLrPwkwq9vEm1AnBTqWOuN8X0Zc+j7ysIhxTl8lFsnnzKzjSxJnCTEhWHyuKA1IpC4vkE2wlG7+i+aVBaUl4hjTrahEfHK/Z4fyptKEWni/ovxbr3PP7VMAAC7wtgxyzJnN0Y6ySJkgBEIwNMFSndLktu09xDcL2yjQbR1wDhcCRuCiWRNkigVcfp5xHOhVE2VDpOqzu0gZS2pYqImhQBD2wVgyjcJW4GvnYJ8ov9i0wybSpI3bPty43LnKW//6b+1Kdbt+xApwJODaFD7kDUODjGwE5QoRbCOQkuU3AxoxIQkAgpgXWR2eBgCRAcDY24RCEHgS2DBgU6n0hJIgXbkAVINFgnQHyH8XchJpGcF6VBlE5N9cH4rVC2E0jSJaMyxDgTjMq6XnhK1Owp313bvUSkoE74URyzKEqKpajZveTz8zzeZR/LJCY8+wEFCMVX3jkgZwwOQDDxCUEoqCyddKGaciNkLQ7p0IDEyRYGRLTZVE2ML9fUYBaS/DDmrMfW8SB+WAiOpWoCxcGQ4joNgPDmDomH1iIRTMwecL6tpadMxZI3v7l9x0ba/jdJhMky9Cgq5cPGziNACUuY4pUAAF7g6dsBLWYCWtYKxMHNKbxQKp3mAjYOPxGDpLA4NSYQ0IQYAASQKZ7GFBVoMHQhQmIGpPl3BAAJgOC6iW6ckWT4Urftoj6v63CfBiBs//ukZCeOZLY/zhtsNiJt5pnnYeheEoUfNm2weIlqDygNh7B4OBxA8wIA+GQ9j4IyYQjApiGsPTw4utH5W8qgmjkduPCcSqcpsh2fJ94yHlUSq36mfJfZOw1Jmm1ydXZLhCaklZT50bwu5u5cEAAAUmBVYYznqKaoQl+10J3qwhDUGmBIMaA1wlKycYmUgy0ohrkkFYULwhBkKk7T9JwXVkVFnM4kPL0jCBK1Gtheki5JxauCZ4tYoLHwj9HL6X0syzQPbvnV/a2tkIFiaJOjNE8DPko0cz/2f2BXgxcSNcMgeUGJIRpJEYOFmEAIBFjOxZWAHAA8LmFkrSAEKl6gaBgALb5rS8UfACMAoFTPuNIT3GgFfrJnALnKdP+yWNsJWk6ThMPVVhkPBYVS2BUdx+UvCO4nJg/oisF7LLqS4iuHRri6lVS57how6v1uZZi6TkOCQzLpEsuefeh5IpU0yz7coRnhwct4rCIX5i5cvcMTQHCRgN8CwSqMfxIDbLCkU8GpVpWKwymAnBir6kWk8rRIR4UiWYBOctHJEsjuPmrBFuX3lh/Zh9R0X+1MIBBdQ0Vi1kRB9qS+s8oDJr9SVvVfUXa19f7K1QAAFcDjQ85M2OuBjVWsw9rMlPjFAwyI//u0ZAuO5Tw8zRt5YvJdpGniZexMlI1FNm3lDcGbEueNlg6YRGk4yQhM8LDFiYyJh7AMlM/04YxUQxTQEAF1UsTVNM1s4wzpVPOEMwdQdJCoIkkYpYke27WEqy55a9pwQAYwEcUQcBSxuKgDHYXGZxjoFRoVAIFg9jsiEsIhEQlpmtYVryWvxel48XO6w1Q6Y5q3W+ZuqmFht1uF+f/5/dmfntpseSolYzd+uvVujddin8faYABgFU2eBgwnONHJhphuOPCpBFACdNM0hywn4uBxkrDeQtlUSIE4RSqH+CjPNSpMqnJ0QQPlormy0JHCmNUZJKw4ka2FvlzbNqQpYqOQzmPKHnzgog5pY56k1X30TCf4OROzj/w2FBNZQDHVQ2UUMOCwM/GUkYyLBweKhJZ4wkJWGR/CpTWDPaCRgKozEjDAAZkFihppQmOEHHrGUzT1JgkGWKvHKXoX2vVgLHHwjcSUQW6rlqLRlE5dcbpE4PcKfibyzz9P9QA1CACY48kOaOB4P0HCh4uYOEEOWeJFhHGk8aGujnukrCJUaN6kNaoWrjcUjvvv2WpdoTqoHtEP/8XA1O0EJ6SQyeI4EsE0FBzFBIjxEYrAxCSypssNxV3JcMiSiH6ZpaCddawqhaSb7COWCoYrx6aLRuPSEDiorKllxpW1ZLStKatPWpFXq461Ut645gDBgDPe0GiSEiBohesluRQXTC9fepUAAB3hMk2IXOXpzhpk4ImGooeFTDgoy0mBwYYRjxyYItoC//u0ZBEGZHYzzZt4YnJ1ZBnDZeZsU41FNU3gzcGpHme1hgmwQQ2b9MUuoPHeNg6AaYSgBi091fAUMHLCrIUcX26sZdBO9YkRUYftUsyDcQxQdmZmXyqVhiyWjwzPCb56Q1FDtq7J481YrG3t5Ray9mfadrPzNf5/o3XdYC0AxbR/lmcpB5i+8bXu3H9rPJ/6XAAAdwSdQmnGsc60BFtEFghIdCOAksyEGAR13i5w9YVL4SU3UchpSmWSlLiauxdRJTfPFSClMUNCC3uJykHSamIMeiiLGd6PSyHpWIpCNBHC6fmbilYkwhQJ+X/vv5cQlUyXztD902yxi78VP/Lvnfw//eazbgECe4OUYjVAY3VmPclzPjoyYKHjEGjg6BmDAIjKB4NCxAKiwNGAV0zUIGDIFB3OXKoaQAQaEiqcrjeFTdt1fIrMqEBEBTQVlr6a+58pgfb3wp73daS3RwWJvlFHehxpOEdo5RB8cuKTOF2RsgYTDHFSiCEmzDu36T0miynVC2uDe84zfP+79ja13eaj4f5eWr7lr/ZprNf5rXe+sKAEAU/Ch4jSQSM8DG0iuL/XuzFOlQdojVW5J1AKEQeBwoJapNCyOhyOAJh4fxlqrAgtjIPTssqT8fTIcFx0scPqvCwAOGILEZSM3vV1ar3RLPzFospSk3R+0vyMVw5DQgNHHn+sCLNdF65VAABe4OmKzTzg+BwOtdDYVBiRUE0rhQiGQUGBQKEBwPXogsW7HXnE4PCd1iwB5QFG0kFG//u0ZBmO5OJSzJt4Q3BwRTnDaeNeExT3MG3lK8mXkKdNjLBgF7Ys5gxRdw29SHLUWlqMKfCgkkfY04sNvyo9EZVDcMxF+px9HFhmPOw89SflsscEUEEwHhEOOpRqQcIQxxQhRrnjBxEvZbuOVcfUSdNb6zNTU2xdVpcpN3B8W/p+M/i4Qq5KP+avmzspAAAZuEBIVPmk1oCjWIkqHnMGPQjAACXI1AUgCMQU3jXbEIIQpkKfniVq4Q8eZtnMSFqRZIU9HS6UKVVF6OYWJ4snEpH7ctO3F+BBh3GV82wjUgeXuTQvuLfSF8kEECrBO8+y1oDF0Cx03cvOwuBqVpDuA8emoD5jcuYIvHZogBQC9QqDmOnpsggIxECAYUwIolVhcEdDIgWYqiFvUVRAEX8EKQUOUm4o0EtwqNMoWARqL7YIOlp1ptZjT0IpNLTHZ9Ik9JmbljYZCCAPEQIoxIUaFBcH7sQgkiA4lRtTl05OjLpNbvRLX4e7rJ1GJVm3sbKNL+D/u1cN1pcqbE9zEP3/iza46t6onRl4kBE4+Vfo5hWhLICxKW4Yc0lYyhS400BCLhECMxTxjukCQ9Px6JQnHSAdD0SRxMjV9UPpMZKhIHcSRxPTEjNKTG/dGlX5Zq7OCA8LPiQ3c0YRuQTU0VIr1LO9n7RptaHGo5rVlQACpvhA6htWFkgwdkMZEDGDMCCAGKjMxYKkRgJgYOOAUQAxKk4WYnwhYBRKioDhZ9VYmcqLoPFlEAoyALxMCBxEAQGp//ukZCIM5OdSTJtsHqBkg7nTYeZqE41LMG3gzcF4DidNh7Do+A0xqihaesbYO87/tKnW9jTQZNSXLTwiqgVjqvHk0KRVPH3n4NcujSHzf2r9HthWwvfVnpX5sHopgIrpxiPpTbR9ZrqjaaI7Re5u5tg747F5Um3L6FH/9dwAAc3AXKvIPUI+FsEe1a2IRMZCpi+6kVdUk78zxTFg7U4UBsJx4c0A6XjExt0qoP9rTjKrEY1KBOBxxEcAcuCoIEp5xQOCkoeJGlrFSBDUkytDEbPvqxefYkWPgYaWekRtJpHigAALuAEGzBwA4dcMgbjBkcCiAiIQaUhiGPHwkfmcAo4IDosMkBgaXhBIhsgy5VUDLE2CM7akA4uzlQguqkEWpVyjSNPUtJTO7FECmZvwsWNL8ZhWhxnTImvyiHrrX/tU8POzWrv7dGBAIMDkXO2rk9ZAhp8xWH/74l9RT7n7klpTdF7717iHvPv3v8+bLd2t3fzXnX3//J+zf9titU3CPokQGSFtncoVA9Be8kq2EyNhCRgIfVNI1Fk7IMuEWzIaJSdXSyGZHY5jYG8Rg1cwHk+YJKsimaNfAtgvDCCoLBdQ04eGOWSig1zuXNHhUVzXsp/xUKOEEetW97UAAF3A//u0ZAIOZN1Py5tYG/JiY/nTawwYE2TzMG3gb8mVD2cdhhpYzK00Ag9yIwYk3AY148xAM8NFG0KOgKYMELNsYLyI8pNDoAQgR2A6kq4GKglocMSaOGBAAwcQTGIRJhRgAmU0WCVgGgCwolVYgzBg0bZXH2JusxFq7ktwYrSOFMSxw6Shno/E6lSDpbNUWEp5y7WyrBXxQmk5LF9fYMDMINDRpLyshaZQ+/whVy9tFMlGGU0o1P+ZkSg13zgAB3YIIpGDCJwiYQZFew4pKLNPlhslYM0wfCAE1nSG8IQlFRsfwkkxHURDA8Ek/JojtnZBO4j1lpacOKznDbI1v2ii2YAMbKXig0sFF3uExGUAk00VcG1oaG9h2pd/panfmE7gaGOhUPMchzOSpIMDDA8DmLBJMJmSAgEIQUsmJAJhgu5RVMwAFg4BPSS6AASVVLqGRLBjIC54+BgxEpJcvsyMKBS6Q8TIawlG/y+IpQTEPvot5jbgSqLy5fz1supZRAEH0VNHHll09jJYzqvTZUV+lwuW0Rx8CChhwGcRhyqYg+JDVpcyPisNBjUC1X+LW7fAkHJk9LBzTlNtBC7hGQPygHETjHRPOKFRBZlmyvE1GhtIbE8TgL7k8dZ2yltGaygtlwexaHCItiApZOzEyInGY72CUGwMyqOix0vkyApr5wS6jjDYWH9f+MKqCBQCH1k0DzzTCi1nDbM08XhJbq0KAACm4MwNzNGEwUCM5XQlKMkFwIBAEdUpFAUmGTHhsw4Y//u0ZBCO5N5GzJt5Q3JjxmmzYYK0EtEbMG2kfEGSj+dNhg2wMDASILTqHQS4yIxzCF8i0gXHDhBptIIkNZCCAoiHLoAX1L5t+hJgFUinUDroUflLgRyPtZfx3cZVjUajHJx7tQ/F8KLKXhMUJLExYjjCR18wSDdioiz4KENm5uh1wUrErQ7W6e792v4v4W5797SO7ktGZUoW4Bpm9o+sAAG0BkALE7IisjeHFS3L5IIggSZaI0gaIhoTBR6e183aUXb5MiWLX5Tx+VOu0G1B8ZZk44yasbj0RQj4QBxD7njFBXonTlfSv36beIRgSsxFv3M38xPUc0yoLFEizVt99yFxRO4GcBBryoHg5g/gKRIsSggaAoQCB0EEadhqoyk+MjhixQgkIjoSDDAAQVBEGSQHYZHVSxUGkqt+QYBNNbVKFPIWAmYr9da66SpnLWc0eUNIVttwbI3RcR+3cgyhXnOxLdK5duuYAyQlExOSoO8obh0SiFZJWCzmJoX5Tejjx4HiXnTafOuf3OfDhnT+GugdYpTNKfItFnfxBzanBBStAEX4R/aatNAMuxlqol+IgHIWAmUAbhSJgAwYDSRYCOQXCoVPPhEl5EcwL0xoce4SoD4dGU4iAJOIHYnQEKGi7TCAKsNMKuB06sRPIkzA5x3k8lRBFymudRTQ2zDVAABdoO5KzfyQBHBgZQakbExIYsDmOk6QxADmYACEgsDoFATDiE2PMj2VGeyJ+IHiYgGwLJiySXKtUyYno7hF3oaw//ukZCEORLMxy5t4M3Jlw6nTYexYEr0nMG1hDcGukCbdhmJQIVr8Epq4am9C4oIa4vxnlI9jtrxYemuy145iDY11yIcljsPTEaImMK2inOnuGBIxyHP0ijtZFZVMWyFgYHjhfJa6+U0wE+oBqzfZBVQm27pLXjUNQABd/EOqUAIIHmXFDAz5fJQcv8267xP20Q5PSoY2G/FPUnrE0XKFSrhPF1CghLp+Eq4zPLn8ZsTjgfV4mDoFC04cvDrIIgudEZkwHg0gaCSyDBQUCOxE8UU9gwpelZGtEA1bl7PLu3Y+IY1xkyj0/aE2hliYgIE1wXGmEXQehOEI4CBEARLYv+RYP3VMUGWzhRICgJHWGaULMQeEol6krVdKBvG/T0MXXlDyqL8siS8rKZtBa018BIHzL8i1O8FBuXy2mw3m/4hjRQspJkYkqKZAoUD5p1mnjA5JSHtygkcg2r4F+OeT/+on+Zr0rvv9b4arjx4Pxa+uY//vBAACmwa8D4hShr6AzI8Aq6mtIpi11nKXLXGItyWFZ215pd9l5eKU2x+F5KBwLTAO1CwinK41JBgTGTVt9aGJxl1C05Exe+NJLq1mXWeZ42KwQATsOOOiI6ybygQbaL68XaA0sIpCa7SOJP9i//u0ZAAMxM5QTJtpFqBqBTnDYSLCEpTvMG1hi8mtGCcNhg6RAALm/N+BTU+Qxs/OgITIkQaJDIwQw8lAocAjEdA0F1qmBgQqKgQJLaFlxIWa2WvLQkQBTI3r0EYCkyonACwyLMOSVN5fTpNDTCVLF3vZfJoW3Vlcvgto0ucWGQHMEALPRECbQ8uISeMWFiWJVuKt0s5loSJUVpRpaPT7AcowArmzNLu6PZCXjy2VlZDSFX+rbMX1HO8Z63f/qAALu4TvRxQvMbBUokhiqm8ogNTBrTmI3q+d2VtQTFctuK5oTIZzGNQVGnEjr9RmDo1E6vGxtUsXJZPIkCqTYIhwsuWUO4tC5JwuTPO+7pQ0gUYatjR7zramyD4rQ4maawA0jRClHXOKEqAAArcD7Myfac2gBLxshQVIgZunoYEKaFWY5AocNBCNjgi40TDWpguwJNBvhbjhIsJiwlOuLFvYmhMJTl3nRYAYIFnBpUNPdZdByGsQS0Kel0LhyBJSCZZWrVaEJ6EuN3tcWU1GugnKZ90jvHlkFja3o063buMTpaycrmK79a5e/VrubLmlr48SHrX+0m1OJmv57B1agACV/CH5QGHWAJbCybKPIYBIBCNEWILoaJBDkrzbnZUVeGH4ZxrR6XrgpjNYiPXl41gfNTXx6aORHUqvYWvWXi1dardTchCiwgBlr1kzpxT/yIuB+ONI+p/+58905YcpNnv89SSdXxk29nydAAAUoXKbTImcKB3hIYATmAjBjYAYcnGR//u0ZAwOZRRIyxt5G/JbY4nTYY9oE8zPKm5li8mXj+cpl5mooJgZi4JpA4ZIPmAgIcMGdh6ZRkoEbpQADCABG0ATTVUHvzQXCCk8lwDS4XGLImOAXhQ8KgxEMdCKV6Qih84go/UMupDa1n5ak8q2WsQ+8MupoLfN1q9t3YrA3Zypb1Znpq7UvynEbBgjSii9jXhI0pqTWkR5X8iicp+Rmth8yX3ydUDvCcvUTmv30AAK7CUgQbyMPSyTidaSOo7a2rkuburt5QpDYGZMVmRUJweg1GgkD0XkuLSo4W0MKZSNcCJEXoUOViltrPvEE6gKASxE0WTQlrx0yxBcy97VqudXPpoe+lXbytIcoNGi00WBTWb4PDHIJUBkMwhYEmNA6GM01CQDEpxBgNAxpiSHGQMtsZBthsIFFZijFzBuEaJKEAeACoCVUSFdgxjyYAFDF10uU7l9FzlUmWvukyy10VLG4p9MweZTFnT0KNLTYcB6MyUSTAUWGFUZ7sB3V5MnW3dd62OfS3VmuVnZs2oe62s58pnvi0ULCFZ0kuTX9MxLL/WBn5cb3wDBX8EojFQEUZsKMhEyCgztVas0tgivC+bK1Io9lRg62QoVMpaQidzLRlrKqQ1qma8Np6vXyjerl0eBMlQmwGdbFoury54u5YFGWJ32Lx4HhMkZGFUKmVBtJ4hOCVxDIKYtZ4UetqoAAKWwUETSV8yQHBEkdYehgaXfKwtthY3L2AAXMJFkj0viybMz2UIepKBgeNHYKAUt//u0ZBiOxIg0S5t4M3Brw/mzZelqU6VLLG3gb8GEEOaNlhqQT1SuBaGwnUwMUDBJqFq33cYtOreocpq/a1Y1CV4t3U/ArWHTjjhPZGpqzPx2RQyziS00gHgbEArLiG195qRS2ws894aq7+h2R8nmocZWcQSEtyBAgepIoVVXJa8DW//oABL34ISlwnUCYpqjD7IPB1AsKgUhyVEnTaSNdiYq5Uu0KOR4Oom6vTGkmhjq60eZcF5GUholEQpD0oQyEonbVSI3KKvIzl0jmuXcSqfNHRAF3/bmrfzd9vf83bW7a+m1CnuqJlnG86cs/YP0y0GxkoUiTzwUJTzmFQvIYYUmIQRg7SIg4ZBCsBIAAKBD4F8DPwRXghODAuiBUnJyB4HtLxZgjkROMYykBWALsEtsnRtURUFa7SpewUzpcr8PzLVhXvZS/tPAz/PPHqaGn9pLUal8vo4Yuy+3uxlSaw1u0BsgUOECK/LmRlihUD5URtUEVCN4UjEE2GqlqGfK2EmcOTKLU9jpHk2vjgABS0IByIcJZAwpgUjAxc4uu0FQF2Ell9q1uI0l/JI3FxogumKw83z9VFy1oCL5XCWgtFJJWDOIvCS646tXtlMlJGPUs5ImsdtNbYmHyvjEObf1ZJO6g6pNz20JZT+sjA0AAGXAoRDylg4WLMaUAaSERUgBMbOTNCocGR4ZJl00EeMOFjEh8x0zN8W+FYjIXSvBC5ZoChmAMDi1eqOCx6cKwZaUmFKAV9mSAgOKEGdsoSja//ukZCkOVSxRypt5Q3BjI+mjYelMFHzrKG3lK8F7jmbVh7Cw0n8v6cb9g7xSVYtR7ohLctPhCn6gKPZ8tPgqB4IjxgjmCcRBxxNkmm40bE3czJPni5BbRZ1VxHaTULX1NO8PcZi3t9zYpIgEHTFQr1rRFRBHWVSwAArsEdTg4GgBJR87SnDRCUDGVkwC9JSYqOPQb6+dLKGpJ6SFWGmbZaRd2N5BRW1mTy0A2XIwTQuUJHkJfRDOfXuW9Ka5wBFXtLY0LmSBLzQiSNA4fL3E9oTYkWfaLaHrP1yZcgOCCDdaYMAjK0o3KHMjVTNggoWQh8M6CBwlFCw+vz4LNcQDYnIgAoRGuKQL0DHiL2ZjggCGQzVRFwUSC9oQ2hJS6DAUAgcGhguVcSH4OLgBG9isJiT9vVKWqq1OmKg1MkAGAwEgUPEo0FZwaIFGk4wYR80uW9to4IdYuKS8a7jbR6GQyWyzWcl9U3thWgKCU3FwTWLBE+FqYHPpFRPCn////oECsAWwARi3yCgjOfLILshwmRIlItIe5vmwpCRshsn8aJcqmIQxk0yQoAM+OJ4UiK2PY4o6UIjqEy+peysEGvCwdB956WvMhlKLb4sCKRqi88/au3e4WqjZVCp8MMMiigAA//u0ZAEORPcySht5S3JkI1m6YelKElTLLm3lK8mGGWcphImwHIDRE84guMfDjcKs2YEEaGBhYxcgC40ZwuDxcYMLBgQ1McDCjUKNGQmGLhSgHDAkJCIy2hY0CEm44FDCYUs2XUJnVaBJlpapGFr1h1UaVavEcFhmlsDRKZ8lA2NgbuMMiMddtj0DS9vn/j8TiRoBi6K1xolENS+3JCxi2SvYS26yMUa0HKFxcOcj50vm5vryUImrNJJ+O2dGf99RugYgAAAVdwtMQlITmuoEGOAQDt+XBRfTqoIOc48zaP5IGYh1DkTrhCYEIShXq5gqeQCRCdgFyJptFjD3NFiVZTEhMQBkCCwDLD1Oe21qPAKUsMvmiQvFZxzbac694pHi4uXYRSsy4GumwJeDTZQyA1NpMzIhIDHQXIzLhIaBjJQMLBQ7QKjDpIsIYy4EFLhozlgdizTl9gJEzoQSI4Awcj4RDIPJ8SBzZKOhpNNMlEFKA0CnkwYe41qSZvjAMsUHwTOyBBkkBMRzhZF26ksuhqTDVttJQxa81vLnnnmw61ITKYKfhQ9AjUb5a/aMfafkKFB0t0rvH4wAAAB78NNIRl/CREYglmi0kxFgKzIVO36a9ENLphEQAueDA4cAiRMHCaS8FWwuMJpL9CumhmjmsnkAgGc6qy70a++Qmrp51ovxJnMQWSFmmSagbW0APtZdOsVbRUHWuIF1VQAAXIDKZY0dFP0wzubAwEmMPLDLyIWQQIRG6lJhI0ASYGihmYKY//u0ZBMORQxEyht5G/Bcw0mzYew6FDjrKG5kzclekmddhglwOBDxWBh8CiDbhU8KwmWKdAh3jGQkYAqMAUKX+gHMY0SGMBMtwYgQsy8zPCY9rTDU31pMkUqZoxCXtPhmvGJ5drrxtc3XWgqZh6pYtxunl0WluFPjdopbnQjAVMchDRiogCeBUoga4GTfNpVinaYZ+P5+zN8wVcXrxzH+kAAKfhKSBguQHHMAU10cXVPEY+jsTKsLwiixIlbu0Io6SiQgnhSeCVAXROMYnTswEkKtowXlLGldU9zHDg6NIaY3niVjkdD3/0i54ACRw1gWQHnnXEEqPyJNp0QkjHAcSUpjZRnHFsZHUBgYOmIxaDj6YcI5kIoGLiQEDowaDDFQrFgUWcHKTF1O8gHEBUIucaoAqmBkQqKYbJvUFoQIQgiRaCxo6S96XY0KNUmWI9ThDQainVSK9RAqKVt3Tkel/4Ffl7HRkT8Yt5FoMfqRi4CmVoUQ86R05CDdfWgs/QMvdnwol8LRvIk3d7bXs72g9Wt3/qnw9jp/UqA3/7MSEAAUv4hgvasKI5pPJJNbgaNKdrOd8AVxcbj7EK/EgVPlg+P311lxsQSA0RNMTJDpupjCFFDDHSKZbOdS85W8GqefTm0KCbFktXapzYw+lYZsPMfMtXacQgAAXKDIqk2ooMPEzUhchKA6MIRQBJByr+Z2qjogYeLCMeV4FAsx8RGRkMHxEMY4iJ40hDRnQBRYAFAoR0AUm+6NY8WWrRGWePEA//ukZCUGZTFMyht5G/Jdo8mjYYaUFD0dKu3kzcF3Dybdh7C4AYsiuVQBWx9UhHoUxhIkHTOjDidMBMvg132mSxp9G/77S1+Jbal7tX43LaTdy5PS2V6AwQQDFBiogaCJh6SmiIZ2URCcjp9WTIv/hluRkfLCCo5ob5vg0IK/XYcAAFbQzwIQoCXaAfkECdaFjqLCsoTRVMstl7pOC7zDIpfgprLVumofjY6QwlKxdNKEAhJSanjYLLewRfYTxCkwcHSMgTgUw4e6ybecFK0PceFmNHtuWtepP6Hr8fWkQS2AGHPMRg4QNMKTFVIazAEimLBYJDzNygRExhhuGHZlQYZATAs0BgGKsHahY54VZTSODyRkE1xgM8Cj12l8xGUGIgIdBQFABUl7XtdRMZ9YIaU+yhzwOTDT9OzFKCNQFPP1Az8R6DJc06MysmbKi2NRQVp9GJJQufCu/ac38IeWz7kLZvt7Kq2/cNjVP+651veNrftpQdFyJMtiRbA9/+lIyuwZGLeQdL9jzlgS3hNcvxwoUQ0b56KsW1xTm0QaylcmobkY80jHCQTUqlajOlxkgpyozAQyYxZPamZejTC/Voke97JeYADMRewyEyqbGNqI73EUpcu10S5BTix5lQAE//u0ZAEMJG9AzBtpHiBgg5m6YYZqE+VHKG3lDcmDDebdhJmo99jB0ww4QM3DTgCoMHSZcMlCy7xhooZIJkwArKoKYIQkQU9YsGJXPagVLC1SFBepfpdVV6cbBKBZJdZkCwrtMZUk7OeDjtWgCoJydelxIa1oovFWxoy9Y+iYHqTREMGETfLu4cQTUwPMhausagIyiUDoqsIFCQSDsKfmisxMqYUNXkSoecTmVev//ioAwAAAFb8IyiEZpceul+HbjtKslerTy6r/NpARhYME9SQclsEnwRKr6UrPDkU6LnDI7WnqMyqwRO2guo1lMicgsWEaDRK/V1aVxoDJKgpeLmRqRm520L4PBoVJCRZt4hJAABOYCWcZETGIzhyJ2IXUzAZKC0wQIZQQmpjYKUNgQgAYOFhMwCzRBMiNQCUjgpZxlAGbQ1ERgqcDyjBAXGYCdZii40f1px145S1pWpZD8Py8LLpfGIJfRskofZ3pZKXwllNLasxHLgRlCYXsccNYqD6RzgrBiwQ4jEjr/ZMyOVbj4uLjqLlLuEq59uk/njOSReurGzY37GDS0JLp7HxxiTbiPhQasIxIECiaV7eJhKxtedSJv219JBgWGyguCZCBQKlCQeJipJZGwTo2Q2eTF0iQcRNPKNJubSjRk84TptP1pEZ4HTBAS2QZgA8Hb1sFXKGnbW06iptccNPQkEVGVQAAo2D34c3VfOiWx5MNJVSEKBRYY6tBc+MJBQEhpTm6qD0jaPBHBPaIAjR0EtjF//u0ZBeORNE0yZt5SvJhY1mqZYZaUqErJm3hC8G3JyYplg5YMKhw6mAri15rlgU9BhmqcheEt0xEs2TBMULuIrq+iyYKG0Rai9dJTNBeJpDcmltYDZKVEACi7Jk0AokpEovtrorpApk2CmnnkS+rszbQ1Cr68n7PwfqeJhXRT+siiqy3xyVqIiFxD9Od/80AkAAACm/EBgSwSKFtHVDhGdwwXfe8aJQKPB4IAZm8J6sn1JTHtUmTe+tLaNWJR3lUDHkI0o88pVOO+TTR1lv11yhkLeVrz+y8KhFt93tqi2FjHzZq99+A0RG/reo1787aouQHbjpyAAYdMGIEJ0qKhIMDBzDB0xApMjEhJTMHCCYxxur5yRKyAkTcBxwhH5ppGIBeXu9hchWGUrBAq5CASEhnDSHzSmRgpyNbYXOZXVZbD7lsdttkeafEACSBoJxZbD0dYeFySUJUQuKJQgbXUkyl8UvFzdmr0OXXvblFqpqE7e5lWi6rqajvT4b8Y9LtUU////6wAgADPuGljxQB1KhIIBhx8WiEABWCIiGQMwfmPMOgWkfdp0RsKqvHHkokBEZsjgxZa+UT5ksrzk1egctGVUfUhgNTd+HeGx+fwoeUmzOhQiU+3QQUmAnZYJ1dJu9hn3h2/DvSl65H7+TvymIO2lUAAGSg8G801kzzUzeY7tsz7o2QIyRgNUCkwzosxCYygsW1hy8waQHFyiYhUsYLBzFii4JiwktQ5OUYgQFQkSHAA8wKAKj8MoWJOvoq//ukZCYMJNxRyZtJHpBdBhmzYYJeEtEZKG3hDYl3FCadhgmxu0hxGuRCCWVLWePTrQ41aimxWF6JSJCs00Y1g3NHBPwQ3W/DQZk3pDaIptiCEEBMAoSFaZx/rpyScPnSP7mxzIJowxTIWhL/+xAjX////sAAc34lICIOLSYUtX+05gzFlix9c4Mw6XJxJEUuiMoGBXKZ/AglhYjWq3y0eOISJ7mKdbIoYj7lt9LY9CE2JVLtWkipXob/sEFFEymUepSxEenmnpoJsBlpK4NMRoAATtoNqJQJEgO4Aiqdcpg5aERiZKFgw9MjG4DMXJxU7McBFNi3pjWwsKoLiG9S6kqhkDBRcBVcZC0YwSQuoqNLx02ELaRseV9Ydh1stI0yVv7HH2uRKxGxwuFwGNhCDU8qBUFQfWIBBJUup5KC+eqyqi45Lglex0jXOG87zbXefNKltEw7S6vxK2iwN7yqj0LBvL/8oiuCF+4fZpYOcCojDmoR9biXSGjN4JlC53jIZKDo8fA3EZigvJi4fuHReOj9bJlQ+o1WzLTll0Lr2V7Pq/nLb6MiOPaeTOvskmc+jOsCpBfmIc7/tf9DjMh+vlGbMvuhAAMkoPARSrLGKI5mC6bbAEz+YcHghJDokhAx//u0ZA2MxOFRyZt4QvBhKEmTYYNcU307Jm2kekFtnSaNhg0wQCHkpwzaMCAAah4ZC8toAzk0UACpx3aCgOkt2A2YkQm7jwAStMyD1zQ1XoGbyxWN/5K4sBOlKZmKRx/aYJQTEIIjhKcYKixoNyA/NYolTyZowYDwsZRj8VtjTDlvV6cm2mbm2ruKTT9l+anvRfqqze7+86jjpvuXiuBmODP////0gAvb8YrkImBmSLoIGsO8d5di94ACVe8vFbyDg2ShCfB4HBIw4TQ8U1uFZIyqOLWdd3Fi80N3UgRGEKxLYZ+iepGWjqa3gninsVcyqn/81y89C4efmojgLXvj48udlG2ZjsABOSs3RDEEYZ9tGmRRu5gZ8EmHEggOTHHMwQdL4mGDZnwyYaQB0MLB4hIjEwiIDgtTxwIDwUJL0VsRYZakVGl6FwUxokxaSp7wS6z0RRnblO41fOHHIm5DSyOJqhUTwkuypAkjJttFjS88WMI0sousZgq9Yg51y1PYQUMyam6XeRlPz6mRJWYGuf5qdZfw0QEt0FGR8P//T/69tYAM3+EPK0A7gKaRdgR/oEWktMdxuPRnEZgiRSIIY3HaEkyUis4gNUgOVr1jCwtjMjYKZntKqmvlatyebWVt3MyOI8WSfC+ZUstSOmfcxjwsRPkCMEkC4h789p7VABqD0CJNJJw4aEjD6wMNGQ0wCDGImDlMZkYgQ0TCI9nwctgANA4OHYoXGKKzNdM5ABmmICDWBvYQFmwEVG0BghAZ//u0ZCEMBSQ0x5OZQ3Bc4zmqYYZmU6zRIm5lK8GEFiao9I2x2RAAUNIAdKfclIYAy1FtU6ukWF2pFNqo8zp/4bgR9HOd5yItA0BzGUmj9LSxABYG+I1MeMGWeqxTHHo6qXEoYltFfdvKsPFwahoXYdLmB542h5kqGblSrAHZIy3//1eeGd7ICoAABd/4iRjSMKDDvInVOsCWOsdtUbUcWtvEA8kHthKVvGtS8s6KE3ENFQoYFwGOt9XN1zoVXIem/lO6mV/6p6pfmP7CfBsT/8nK3RfZitKarm2dnd4I/XVuf/5AAFRsGhCGaZR5lcJHBBWZyLxgEFmRwgYhCxiIHgIcg0ZwyHcGSgECgCRE4BVIIy+oNRVwBbS85iNAIt2Up2uKkct0noT1SMVAyiH3KbM+MtWnNReaeJqUB3YMh6RCokXCkAsOAmmQLzey3I63VN72GVIXkXecfUPWVLKuknZjwUBQFlA+l7nDGpPKGKMCqhGwBvGCVjQpGO///0d0WAKQABGf/hJBAA5QA8OAeJohUgpzlLoEPIWX1xC5GMImwWLrgQVMF9MkplMSSi8sHsMcs3a6lsNKx6la2/3t7m+VO/x8oXAr+c1KGuuPP6j9lTn2/6uCtX9crrm1uO6s72EAAuSI49hNLGzOQU0pcPlMTQUoxYLNLGjGyMLhZjYKDi1HcRCoXCxGTJWFAgXKMhAzGwEECg4GIUrZRRaA+okEqWAYobdTBKl/16NoxaDVwPYtaCIZbE4+bbPO3zIm//ukZC8MRQlPSRtpHqBdI1mqYYY+E6kDJE3kzdGQGiZphg3pePEGUhsVkRVYgLEmSYGLLIEesIGl5yOXC9inFiezfU7tBUpnHO64mbuz23tjK5d7ekSNy99ovcjXmwo0JgZ/+z//9oAQAAAvfcWnsIgCJqUDJLr+ryQTh/OEwlKDZYSymPkBaJxSo8h+vaOGS4BAtlHJjDxsvwfE0IhlCdJkMosNGUQpEJBIvHKNCYXUKmRatI2hqiKLewUhaRYH0AA3cgAGoNblzHW8zJSNqhDbAAGhpmBOYUVkI6aMCGDnRVDhZjQEmijiKwYmETg2w3QAmYvOpuDjDWBGgVgjbAEIBepNEQAWE8VpJ1JSpVoLPsnKzd1rUKjrpzKE6CIKet9ZfMy2pt54tejdieCI4MEDbktrd8R6c7sbLxvb5mQ+ftcPDxGMru3rHue/bz10g+LOJMD4TAlBgXPvAP////6gHAAHf+MWSDI29Z4Xca2pQPFIw2FM46pfHmL3ZRQS4ysXikpNSYPBeJRaUD2EaKii6Zv3KQ0dMt+PqdDuxof8Pnfz+mdO8VDta/xiUtaFvcWcf6kaLla1+8y66qLqC436skIphQALd/TMJ1MADUwCPDhKdM7DsxMFSEUhggQo//u0ZA0MBO1NSxuMHcBZgwmqYYlmFCC9JG5l6cFoC6Zdh6RwBASY6CgiYIEQKAwBBAGCyEajCNJWAi4i7VWIpGFAK5Cpy/JVAwkJat0HAVnCY8qAr7YemxO4hKSanCMrwmUZiWS2hylKSFAzGkeUVhM20MrQp55hcvcoxle7nILWxexxCWlLa1HiKl0w+4zjHsp2LHNzwzf0AfIFdaxAiYZYwYc/7FyYGoAAALb8OrE0kQOstqEBQNCIJMSltmtJ8MGcYQiV58mQFpyEw12XEkFB5MoDzhiFOSTaaJWNZNCtg+0Z2X3YcGAmmLWJLtmy61ZV+gDl5M8bDusYdIbD5cmAAXHAcHJACapmBEGhX4bVGZhMMl0QhmmOB+ZOMBgjoEQsmZ4YaMcKhWaELlIYBdODUwGRCECgSy0GD2ZMGAhzVSNs8ObZQzZE1cIjLWKHGytHOMo7MsE0LmrS4nEo1wiV+5NjiOZCIdlKwn6nHBdy7jO8TQcZreznqHnMe28atW1/HcHTQGNBEBG0nFoeRK5gbMGCgJES2IDW4jP////7t4EAAHf8F4LhLOirhUpJFE4K0pIBsB/F/Gujo6UFiQslYjEg0AJrDZYDQLBESshUdRjIpk9GuxrQMqagUCufahy9AQjkkXvxS1YsNCb6yTyi+MNmmRa56d5WhCoAAOOMmsRi5VmW2mb8wZg4NGGDKYKCZdszIizMYbNkY6UhRk3GiQ1PQwDjAnNcYMabiaRSI5RmCrFYFSpRmaOCRRFo//ukZCGOxNcvyRuZYnBW40mjYekYFE0bJG2YXEFZk+YNh4k4BR1A1pq5hJikPQg/KX5T4Wyp4a1wfjsB4gNHoHiEsAEJRXaHFGcLi3V2nJ71noup7rNa+313thyfymvmkhY8IFixIGBG1gNj5YnXQKDT7E2g2PewQSf/0AArf8Nyo03wI8kpWG6cwhqjJsijKJijWyVILA8SzLaeWYKgUAQFwZTchQhYNSZczByc+xKnWD0KB0VVQjxDKteYUuLkSxuwioKBGUsF971iJURZoztSbckZwJODBo5BXPBnzBSozlABg8YKIE8GRORoBkYSDGShBk4KTSJgAIYkAKTLdBjmYgClpkmEhAUQAITGg8aMjGw1TA2QzT6R4DANCa4IoCiMAd9ij+qZOI6zrRXBwYfZxLKOA09XpemC4ZnMaOH61kVgOBkRKcMgbu4JdGo3ah56mf9gGLRySEd5tGjzUsdKyvt0KrM4lwgmDxwe17f/+z/+9oAAu2EYeaBweJdj6KmzZEtYmkUmx1o1/AbWWEl4KFlsQlLP1HFRAtaEH6t4eJFPOHtDlihw5CGaQ9iqRLbNf/4OVmK7hvPj1mWFmpi6rsNvGxY7YxyJCgAE7IzORaM0BA6SBzM5YOIE4xsW//u0ZAoMxQw3yRuaYnBag0lzYYk6EV1HLm2kdsFqkiXNhg150NDHoaBwgAQJNCRCCQPDGQAAwgu+AFNhApCoMvaCoJjACNZM5aWFRwGVoSG/EApIQtzAjWURWIItJettF08YBYWA8qDoDUVARLxNTobBkTFAtKhqTPfRFlItceUKpYY/1Zc9mZfr07N+3dpPs8/t+l9nntlU02auFFAmwGyA9kG2qYJnB8Bgs0qA2/9+wAATaiNDAw0Y2pIBMKBlhz0ZA8kjEgNAbKjMLQdJJaHQhFd4UD4VGANCgToRtNVMQpFYs8+c0sgyLQkDhkk9TNysZS21+KlhwRtc1I8iA6VlAccJT7XXZ5Z3jQAHv/yuWNAGDsVg18GAhuLGBdICiwhDC1RhQGXMSlSxS4L2hgIjcgkLvJ7AoGLurdS1KASTsGSdX5aXqqOQQAy8LioOFqCaEKIyyqJUiqnahTy6W+tcSsXDf235/ukLMbMwKFLRIJXOijNSXWv0FqjGcz0Keb6kxGflGGl3tRjkNulVL3C/1ReTWpoANuwAqBOAF3B4QKCDpQsxTZo72rFEskoi2F42CksFQciePunqQxShTY2FiqzRUfO3tWUvL529bstARRRZSUyBzT8UUmUjGJ/6yFssv5SNX7r3fB5KxReL+5JqAATsiOSBcyeOzUCsMdkA+IAHwF+TPrOx82AiQhQ801Q94BSrvM6yaxyGCqmuZiAliu9fxctCxf5b5YNfZCV1YaZm/Km6Ra17q+GxL1fF//ukZCcMRLIrSRuZwMBfZnmNYSJsEtTlJG3hKcFnDaXM9hlwNOrTPdK6kzG53Gzdo5J819Jlcxop/lndjK/jzHHK72xlnTX+gIAhtw8sD7hw8UFQXJtam9RZwZAnMCNU7iF4hWtn/2a//WlKAAlAAAAFL9wzwKgTQBwig8sQwXEu1TEGAi9p5YMBSzQ2QIlGhOnWOULsEZiTa7yiyXjJdZHCbL/CWiXcxWhls/Nyzq1Ono6qXu4KHiqFSN9rHkVI71AQOFxY2FQvcYEIADmkhzyGOK5aI7QoNkMwsLmHAplIURIBkoKaqCBJyEFtCOgYxNwb0JJEJxpxpSt9USlLKWtqkUPT0Tpmk+HhdeLteQzDDw8jhA1V/QfIxEooyfI0aRAVWQ0XXijzki+D9kTE37NZAgNb2TD8s9meebFuNLaaVmxrGLy9VSrHulRjAGoLYsLllix5cVDTxFb/kkav6d76gAVdsEaJqHsQoRMYpSGWAnnMWINJSnDpDeIg/LxHKkK76n7Cxavw4UIlyVgKJPj5WV6WQF9s+HlxGWZreo/YLGlhUuuorYKRQysYaRoU7HvDuKFWBwV2DFWuABe1tMUCTEAQ6UJMUSjCUAxwgV+MjLGAKTAZIVGBfodFCzUG//u0ZBIMREU0Sht4SnBg5vmKPSOiU1zXIG3licGCmKVNhgngBXCBUkdhUAkwaUhuhmpsNDDgr1gxe8vUtgd+4edmAS/zbMTZtSUYWOSaixas9cWk5aRBOOGIHIBOErJv5SZJnETnoFKUlc1r3xn5Xv7EBKOC48H1qYbFGmLjyioneJne3qf/8MgQAAAU9/hUM0CaFeHwLcSkIQpUqdSoSEyHKezYsK8/kXHVyKVCPeXlQpNDlssJDI69RoqD7KxNRsjFvr2U0v//x0vwrVM2l8ku6f/w/BGgigYf6pflUS0FbbjLP/lN/93AAC42jxwsyRnNS6z4Y83VhARYZKbGOrYkAGOgA2KYIgOmEKgNMEwTY5Z0GqbBYRionWYBiR5EApBZIWYdQvKnKSBJTtNQ4OS2itSpVfM+vJmyoJxSy0h1bGxaPy+/XBcwiubrUKy3okc+zS/ZbbsXW9almMSPT1pbn87L220HoFVMNWSxphALwm4CS1JkVeKPB+Kf/QKf+RL6QIAAprQ+L4BgS16hoKG0kvsIgMMEiqnYdBDwNfW9Ex2WFIjhcqWiQPZeUF/4lx4cttvr3nHPbDuKjjETPY6Xpu9e/mVGohndbewIooGiwLIPhMVdUpynsdGQLjkEscsagq4ABWNor8VqnWF5rmKKqRioSAQAw9xHjAzwIItDVhCHDNaBCaPxmQHGgqRFI44wckRUDwJkDmIEJDg4F/4cakVC0QFiq0ufUjLZ4dlSncxE9QSwcCOQbBwvH4/Z//ukZC2MRL0xyBt5YnBVIvl3YYlWFKzTGk5hMQFmjOXdhiThjc1KXFh9h+fUp0cdullNnKTtnYTV5Vd27d7xezz/MihYKQaW2KIDFiQSHNIzNptOeY5MR/+7FPb801OwyCAEF76iwLSBgyKIlKVPu01njcF7MiFZy+wPad9zjA4fOAJb3nYpoO1BIZGEhT2UDNpgBYJiILmBBT03Ac6MUbJHhGRFxgqBgiRvRWe2hLFm199Sl6wBukFnYxgVTHalMbCAzgXAhulgdmDj4YXDAXBAiE5gwQGSxU54CHoJDYkKw4gAJPgosJBEwTfsBPL4M5FTFJyqpKsgWIEgSr6pJoBF6quedt0WIYymXQbI8Ts1YiyK1FODAoXPjBDiI4TYyXIjLD2ibIUYaplFDLl5x/uW7VS2e7Vwes8EDgFCRRY4aGmAFahgZP3QGsEPhj+btUs2nuFdUCi+h4oYAVN/go4hPZIVGLPmlTRMugYJw7GZOOhEKh3ywqn0mikEC8UlGtQPhAP1CMzkPib6g4pDxVwsVn72juaQ8i97Lyd/2xFhyf6HnDEUr6r8PmrIoNf7qz+M//YAGbaw8sWBCiZMVGCoAYboplwTAhZSkWJgcxCoagyp0RcyE12EVygCiQ8Z//u0ZBWMBFE3SZt4MnBehEl9PSZiUujjHm3ky8GlFSTNhg4ge2ENsFkCacAMZSgm3v0zT3pkcYi0ZjM/NhQw9APLFDBgeymb7j8FAyRbSflyyJ3tBPpQyU0kyMvvgxy3hrm/tOiLh4YJyaQaAJskxIUQw01YlQ8NCQmZRd/0jxR///QACVAAAA7/8EUGEOgegCqbwtASM/C/hWNwgaweR5AiWJh0pHH2BIQc4Wzu55LdjmG7RIvWueicstvba3S1H25KuVAtjKssdjGpVfp//kWNWu/f6ZqHV7pxvPvX0fz/0AAZGyYSwGnBhsw+dQzAJLB7eQDosAmTGJg4SHKqCMLLgI8o2CJDArCCgMCkIYSClhMcKAAYQyWm4joCtAMDiBbNbag66EV51W1+Wd07wwPNWZND9SD5qap58FAThyJSiUPKEH2WaxT40foxDmZb+Li4bTmq/kd8eJntOLJAYQGjp+g0EwxQwJBe6hjKXf/pU2n+961g7A4AMuobxhzjmg5jdQfiPARxHnLmXiuticHLfo6VtHGjrBQvBHnywfDoymJDSDkT6tIrcTZRY+TzRfsL1UwpzEEIqF9IxiVYMUh4tCMh0gdpBxYLmgZA4gDazoYN1Bo69rmx4f////3f/tXVACAABq/WwXTDGzY0ceMZYzkRkx8Wa6YEFGDjo8ohgeBBBAKSAAGLAwnS8UrFglRMeCS+L/oxy2HnQazLlV2mt+u1yYcji8qGcoqqHSsJYAkYvMHDhlVZeiQGaw+e//ukZC6ERH5BydNsHcBbhPmKYSN6FQzdHG5picFNjaXNh5hxf5bWsrFyvaXvLjCuzbNGea5y27WCPSRXK8KWBpmem9Z6pea8PGeuKkwsQdXFtL0fvo5AAIAAW7/8KddoWOhPbeJuLFYwu6NRK4+rvulTPsQrE42XQFU3JRImG8qXUkygVld2GNaU1i4CEiwUfF2BEpFI5ydAjYbeImiYi0YE4sx+46dCiwohdKmNY5v3eoAAxtA5MwTP7kMWIkz0iTjbQMLDkSDQ4EjNDPNHHEkCGUjHngnkInjfgRMadQaZ+ZAuDRJmIoCHg5GDiBhSQBXg4wiaksVT5ZgqDAwOpSk4WXUZLm22tsrgJkNAVwUA6I5UKxFUrw5Jq8dl55dQfKaPwnilD1j2kfV+0Dt3HqMJ5d+tL/D32753+rtMef8wJXmDR8SuFJ6wgTCDG49Tnb//fynY2vYuqLgJTf0Ys6QNDugYiJLtGVSHmK3mSih+G68UbmrlIogCghSQw3Rhp0qKspZLa94weCiByY/T9uiaQMrAzH0WvxWWepnUM9KA4c7hnjW3B/trBFPBuwIAAAANtgD3QWmR1EOeSjj18EB4cWmEg5UDy1BpiGSkcMJoFCAU1Ti2TKUcWdKKoBQh//u0ZBkEBKtESNN5QnBuCFlaZYN4EtERHE3ky8FtjmWdh5ih4GArLIESoIHAMLgcKAuwhDAjyv+0uGHEiLru1HLxZAXAXBxRFJJGAJixN0h5MLRtJBp7z2w5LJPVDcibKItZHLFTLRHZFSMNHaxco9pHM+qXUXVzjiKVtBV5fG0Pb///of79YEAAAAv/4O+Fgg0s4gAjc4jEIxQ4cFEQNdsb2S6iX697XzwzHwUj4fVLggie+gPPRon1VmoVuLVvO3VeIRQQLZrC//3mRSZSaRx5jNREKnl5ZaHH7bEDkuwNMmpn5nBDoBgFRi1bQ3EdMt////1gB+h0wmKMhyfianVHsrRwo2ZQImdpRmZwCmgw0jEAWGQmMyLsAM4PPMMIeLDBgAUbxCObborjJaeJeZBMhwTGiKuENVptuuGA0Rrc07z1SqLzUcXlei+cskBiaAIU5AMRljCRhUJIrfc15cjB/prftV39pvUd9bv6m4ptm+2ZnfvWI9mvO2rC3uPd+7/9Nvfx9q0H1gIYAgAt77B62DIfEQCIoYk2LEtalCvolCV2P0hCIKBRgDCSOrmFjkUCJVuFHt5d+6TgFIksChsQcGAUPf+nam9VrMrzN8YDqwP9nJCT30y/91r/7Hpbf8q1n1u/GRUAAuNk3k7NQ3jKqYyK6MUmjXTQhIA5UIVI7tjMpBzJwMYXjMEA3heM2LzJSkx0bFSEdSQMHmpoabKUZCHhBkTQoEQiC1wFNnI44eiiuWrLaJPsOWHLWKmp//ukZCwMxUI5Rxt4NMBYA6lTYYZYVnUNHHXNAAFqlOVOsLAAF1vuxOLtvE30gpTuNS1stqbiUrtRy9lk4ovR9kjEpxCNL5BI2EpvxT62KrGbLTZ+0fW89aRQ+uyRYwOVjjsbDRwkHRIO//q2alVOH1g8BkLALW+AZSp2SlL5oZt2aY7jTW5uW5ZdHwDYExSBozFyYmLlChSPatDVijlYN5nXChjkGJrIJSoegYPUmw2lQe/3f3wyBBC/RIFVnwWgV5VCR31yLfKP4i/8AAA5EDdYiNVmUxvZRxxCVJBg6BQ+NNHcyMFjIBoCC8AhaYiFpncLGMgMLCouIYDCjiGUUGAvmOLmPBkyAxI4AMQu8MMMWBJQ5QBFBBeMwQmRFtUcy8KQrSso83ZO9+FsJFZXmzwzM9+W7qPe6sSo+6rQ1Fu8q75+Ou97vOnlkV5/dcq1cs6vdfq1+sv/uW9Wfx/fNdy3zfeZYflzd3uH7x5dA4ioLKWhzbLv//662MfYWkA6AC/sBHFbX8Ioqwwu5TFYn5f5sLCVpRh80UZQRVB3jEEAbTQbwgdPFa2XtHSSTctIpwfzQlUkiSZOe2o2tc1l/7oh9bvmPk9TUQ2MGBw0DRrKNbYs10HB+BEARRGgAAAB//vkZAKACF+FxRZ2oACmJbkNzWgAIOnXGFnqgAJSlqQnNYAA5ODQklTm2CgSS5qCOxt8zZlWSpi0FhUW81eJI3qUw96KAAiiYBCyZOKkZ8AUc9oeaKNWBpEYAYJKYGahIBhsyAeww4Hkc4BkALAYHAIGVRmBkBCAZrMYGrTiBwI1gZjDgAw9C0MCoGAkEgFFmHTAYsFgGwWIAwCgEHcugiBYesHzuFgAv6HQgNBcAgBAZkCIbCAkWAYZAIAgBBQEjNkqREm2FABzRHZbIQ0BYBhxodkNuHJFArUbboEWPoPTTIsYHCiovLZ1qQWlMFIHnu70kamVp1NXv1Wqdaq/b79avU1LpdCp/VU6lujMnQY4dRTLX///SWYF9ZlY1ZZl///6Bu7udRl4vGYAAEAkAAACYiKSADAAIUSBCYKoBI6IVBk348PdQs6ZIIFi53HppG5p7QAPGAAHrPGWdgZsZk2CBpqyQEgmE0OPImPF2DGlTGk0LWBGOEz7kO4LH1YE+DIsGuiIWzsvhBsEw8QgUgWctYiRQNglkzyXXjqTdm7a1jnru5daz1n273/z1vDv//ct34Qa7V78UVWhv/+3/Sv1ocdD6v/wCsyKt/9zoQJrghFAAAMO0CswVgVDDOLwNEg0IwUBvDFoCLMM8VowUAaTBSC6ML8HAwkArjDyBtMFIIoEgzGCwEOYA4NRiwDUmOYMKBiMgAYhFIHD2eBnEwAY0ZoGqCqBuATAFFUCgYAx2nwMoGsDLY/Axu0wMSl4DDY6AxkJxnAQBoDM5DAaOgKCgDHIUAFBIOBAEgeGLxCUWENtC5gCweAiBwDgWIDgWB4AAFFsE6h+AWpGOGeFkjTImGphv4rUSmJsD1iLBfwcwc0ioyJs7IrsI0PokHOGRfYjieLxNIm/17smtugi/11XX7b0N/1b/9W3/6n9f9N1pUkkUTJabf//9bqfSRRWxa/+LECh44NAAAwAwgxtAAAMC7Aqw6BNZJqzJuAgFTCoswqRVQy5cDKzaFw4QIiQyAEQQIXFlUbinyIAqJGsIwzVQ4aOGXQBJBAEijRyWqNWxwnjj6KtO/ySCqlLSQ3EGgTdA98oTXe2Oy2TUt6nz+P1repZSTb6xXOjy5lj/93Ad/Ptmk1aGiRv/3f/////Yl+3/xelwiLf/UWVIAAFJGTLBYxmMMkeTKFA2YtMgOzFSIxQGNwEy3pkIUCTYOBiI3InIABhg4kFg9JkANLbkKhvLpmpJa4tSC2wOY3jAwhrHBCdP0uipkrYp9V1dP6G//ukZCmOxR4yR59vAABVRQlj57wAFBTfGG3pKcGUm+TNhI3wF4tLmHGe+GJdnSWKeUTM/lST0/LqlePU2dip21LqtruV/DVLZ7U5lrePNf+X5b+r9dJUyQAoK0F0oKhCOQePWRZFYp6lf/p320XuHiqBcm+wAKf4Atp+ivrgZwqNotyTz5WIUwulKq8s7YlVwmYJQsaJf1zJeijVD+PrLyDq8XNdTYpqt95v8V3uB/S1vnNdf/OPiMSc4KGhm+02VC3YNXeMSlyGk40yAEU2mGM56Du+g1JDC4KOARAFGGoY0jqWGlDhdMBRRZIGGwGhNYTDl4XBmmlmgLloSsKpQDRAGjNhAoJGYRiwoPQ3GgTzo4vbUedjjXYrLHKBJGBYCiwrFJ5oiQDAu8sKoq1yFV6aJtfvqke9mdxjUydSfjtwWbzKn4NSvY7XUmLLsDeE84xHPIVItzcIf/MHV3kizjRkWKtBAUEp00DoKl+1Ch6E4QKQoGk0cmWDlLSoi9kMu09cua7VDpOCYwRilEAdluJ1dN4nZXbETROaP6jJQZBfH03nQKIWLRzVqTJtDiVDTxpRLo7ZU7YpcQiP7lmRQhxh95cOm6RedPCFdOinRFYBuQO/pzHek06NClcFCIKF//u0ZAgMFSZtxRNpFqJwY7kaYeY+FM3DFm2wWMmmjqRdh6UYgKQBxSMbMS1gAGjFkMRFJjA6GH6LhgZMFgUcBB5CAAuY8GAJKSzEJsNHQ0EoqICS0KCZCc8aODssCfRwpfGFzwh9JFQK5aO/Mvqy2GYQhSFJ8gVZg5EkyiNpTZGG9ir/FHiybcGFaqFOgmv2M8m7HeWzyIhHetdsz3Srf/9+1Ka////XV53vaVmSUjspqMy2dxzJImwIQAADutga2igZQH9wxBmqQiZIly4LwGUIYhCBH4bxpIainon6GQEUWKZhi6nU8GZahQWlZfNCyVhJSRX8sZc2WRFgXBUkYWbAYjF1B1Jc6DwAGjVzIwYdeCTVFipgkNF3hiOCuhCh+1////7WWHbXAAKJEnzoZyR0aVeHnYJ6ruawHDRQZAqG5ExpBSENhi6aODAJAQYbGCBYVCQ4FgNgiDZgQQREqfQWADBQsRApg4O8DAC6jyrRdt3W6S9w4/ZdGjZI0w8HgFTgxbItEqqqF68pWpZmIotJoHMcow1sU5B9mfepdt9Z8VdZ7er1RUrqku9nzfaZ7InpdN+317In/138n6PaiOkjHklZTCDKi3RiwYyBVXAgAXUipSPgS+EFjJQgEFpBQywJgkZQ4RUQIfxCKMZeBbxIBCJoNrjBUCyJYsXgxFBqo2ULyicQtQi0v2XoWmhQiBxAWEwfWFTqARDKSSZFxQk6Bb7DBsobg4sQm1qqc58XYmpP///T/wrVABlbROTO//u0ZAMMRKIuxpt5SnBrxPkDZYNsFBHBFE5gq8mXEKRdnSRgBqUBvEbKUmQgJphaPDABBTDAIMEDVkEpjqNEYheYxjEvgIq640UHJpForrsYAhu3ZJhqabbjqxRNoEPsLU1qS6RUDgRKwbRIgqhKwdaAhOER3bqcvCRLiT5yRVtQkvJmFwXbU3Up6yMOkkAJSjosusXCbXtJQgeKoqS5ijyVz9X/m6cLMS2LuWWLODAgasAqaxhK9L8MiTNMxkJFM4NrhcZpyNUUagkiyswEgdg4OROH0WCeUQtAytSMDv8Elmp26VF0PKrPr1ixzoJ6GGlJmy1ZmZmTP9BUPCJIZBJc8NFhzDyRY4MJMTBZxIXGMA7f2Jxf///u1dEVFgG5A1kngdKTLiXMyn846GDAwoAAIAQHBw7MeB1CqEG05qUccgCgDskoaXA4IKuFAhcamz/rBtYEQ0MVcMNURBgXkZI80tmpc6cOvM90/LYxyGZZNznLAgHgEMCmD6CIiIRQC3GOph6iyFIJFFhwvR3EBZkGtnLsrOyOKnZLTblIi3oqforP6e//0///9ORnWjdHZUstSxNZzuVSipGQyj5xADdrIHEYCcShl/nbeh0IMMMEd2OJMMydxt17guAJg2KwVPCEbFYMgQqWRWNxOCw4K3taSWj3kbV1JZ2Uzcrdhn/tJGwUKuQkCHAtUC7VmkK5QOML6m64wf7Uqet3aj//6/imLUoVAgAAAO2Ro1Y2Ah0Y8lmdURzdYZSKs/MgEAxI//u0ZA2EA/UkR9N4SfB3Bsj6bYOkEbG3Gm2kVsl9EST1h5joIYTWckHFKpgjK6k6AucImvJ/F2wCNCQxfVkcFwGwBtlzzM9TucuMQOio/Ka+qpW1JEnJGiSTZblBdpeOmWJKrFoWFSwxRZQGNBVQspag05LlDlHrbkrZf/0//3/sMJ7WlnlRGBAAABVtgA4CDgWYuTnfb5kukdaGA4hLdCELHgIDASSZbkta88odplypr7Yk50oXyglwqVczWmdCPQLAPBnLh8bCYMxBcMlZJVIkOn3uDjJFQus3A7dTjy/Il4Z07t5ZF5Qs9QaDyQqKGG808HVf/////TretySQJljUBlBCFEA6lVIQgz0zMSGDDgoQi5CTmNBYVMTIScLARjRAXbMXJwEDo/ppo5qJv4kQtld7oPI8ztsesMkeeLu2yMiiGAoTtCVcfJydl1oaJA8UcPLMwx6UlrUE3VRGXxm2pc5I5nEsWpNG1qn+96839+1/1mdenQvX/////Xd3drq1ER7n1JvaF1iFwCAAoAG7/YIKwckFYKDjVUZmpCNxzwj8UhIT/elkS2idazIRen17EpwBW/M9GPlU5sIgAgMDwDgYDBw0jS29a/u+YVW8PguRB0sI2EY1yntLcoyBT7VyzHL////9P/1KAfmDuFI1ytOcUDQw0wYDMMN0KgYHGwTYCDAhKMoGTLhEEgxl5YDh5StWAWEi+YUEWEIDAcDJXyIMA0iWIwGPBDyKww66S2Xnhx0snW+akg08w08C//ukZCoMBJVwRRNmFjJf5EkKYeY6Eq3DFG2kWIGFkaR0/CQoAWEh9hbtGdfZPLRr0mVrot8xd59lWqzGKat/veusjMv0bX/9yMf9f/X///RfToWNRlvsj7saUjkcK0YxSjgAEAAAq62QtwBPgb9WwARfIuKUBKcUO2kug6xNXEpTwOdqWliRljJAtgMRQTj+AQKOhbLIgiaY+tVOgToGLTouo+ayIdFg+eOrYYYJBqKCltULgBdTP1ve6o3///6f0/jwAY0QDgC4uyYhSmSvACHjFCgFBZmImZogtVBSkEI4sUCIFDhUKBwIEBoUHj4w0DJhtxY2kDpOdUSGCsrvqFNae+XQc1lkkZsRqJSKKdMoVB1C8S9YbbFc0DD51/8Z8iXUUpxjt7iDtYzI+dksznIbl0VHM70sutq1tQj///9v/+/Rvv0K+zGrRTI8rEYs5kGGg1ObKOoEpRLBIN9tAWQ/lAwKEIGFDRpCgCgY8zp1XKdZywgdE64CJoBVjliM6WRkRLJcNrqMMQtqrVUxfI38qk2EEdYz6pBG7qg6TGma0PXvrTlVR5Y2tYnetUchP/////2Cq9iqqjAAqfWRDXJ5uiyBomhUVIBJxBtH4RiICFE4uFA2GtHX23NB1c7P//ukZBMEA5cmyDssNDBpY7jXYYZ4D5CNGu1lg8F8ECS095h4heAUshmO56vD2VjItp6EQUUnI8uwsiSg1Gmp7ZEKZRdNb7om1jmSpaadHmHWIUIgWQHziRWRvcgcbKvJL7ZpT3uXQ14xn/+1f+n9g5IRAApIwHXEVEMyTYRxMhiZnInCSvZe+6JzP0mYIZg6jDOmAETUqBYWUE7C1mIs1KqaEknJ66YrcyU8GGI5YxlSV3OLDHmgyhExaYMRkm8OAQKpKmyZgo2XNWMaln////0133KShQiE5wUEALsjZCVgWgmqPAqesAaZUPgocJZCFwV6wogAKgY6CPApdIE2kIbPuz1FuYZmOhPRQCQSwxwkQl4ceTssLvgeig5bEncu2Z8/l0V8rd9a7muBc2PD5IgWgsg0QMiqzYYCTx6kNVW2fhRTWq6W/f//Fl15FxmKipguJSgWtYDrAqAj/2gCmNsnILc6WU2xwg8hbQKSEsKMQ5yVCVBvPDdSTQyxSzlYmvKT2SATBI+rNAw5MokSKN4EcRGDzNjr0HGuEZwGzJUege+QudBadAgFQGbH6v/////9e3xSCvmB9AZ5AZYec2GAygKtN1MKGMafLNmEEJ+YoIHXTkQzR3GhqyWarDAY//ukZBUMBH1xRRNMFbBkw+jXYYlgDzCdHGy9LwFgD+Ro9iEoYWwZsmkhooKoe6C+oW7FLDLYBcuOCselubrkA/WHNsVJHVh5djaVlzsarSnt067jOzu7FPI+QjMRkqcq+jM1dKPZ1VLWftqneVLf6ev//0qmvurOd63PSyLPc7BzMRzHOoCdBAc8gAHZGwEJCaYGWNKRsgZAeqqnsytgbhsYis2ECpUYAoPhUQkdgyGScTLG6lPyyH9feJSYMPoofeuK2WYpyzVFAJdkqiAj4pSP2tKtSAhskk1DOGFWkXf///97a1sHm7xc6LqNoYAZrI0fq4FRA+4IOAjT+gEFPcKGAkAHLqvLjpdIVuaJKKSLYY4+BTCpQsyxlA3VacxllsMpYfsKSQR/u560m4zKbC3etTRkS1ElccQ9CHopa30EXecXLgmCgFpIuHCdVQFsUtA0hpcWMBAhh72///ZXt2WxdcaLLNgoHAUAL21lZuHqT4fAF8aBNDfJC2JlwgvsgkE4GeWAWbtClYV3g8tBxj1RRrO8oDYuSa0JsB4yTSDySD1QeueWF5qYoE8DE2Youbnvv2srq60Wr/+jWv9fIwAo2kDtx4zcUHYADShkCyZcUA0CY6eugXx3YPnHZiXS//ukZBAERDIkRZt4YfBco4jtYYZYENSfGu1hhcFljeOY9JnMjZtoyhWAqnZmQLR5Ldl5wMIumsNBTCHiRXbLGptrVAJYGg+ajOW0DsYWg37Y7QLEOF9846+63Z11kzP3GjQ4ZtI6nLKRRFQ0aJjtyEOLLYigUX3P//6rYo+sgWJOGBcweFRZpgmFQABAAAQVZGBWdJMEde3jitNZEm0wtuaEBwTmAYG5UP1hG46Wh6SjjayxIDhEsiTIztHXJmhyU4kzmWfIJgZAnAuED9h+lR1D2RZDD6hv5n////+hFJZdREc2bicsCAJrI0dEEacaGRQdCEnRCJHohdg8IwpChRQYOi4zTS2yPjd0MnZSwqqYx1YjS1uTS6YWQg4DcJxKMjxY+dH7M9/Po87HnTxxp6BvWMQolbu3eHIf2LP2c1bxuWB2GTKEjkvCyB5WHVF2nw0eEp1aZGo2LI++r9+OUdOtv4qfhsBgyXCZ00Hw0bkA3wrgnCCj4YHxOkIHAzIchaokaFo5lBlcGMPB9Mmj4BpQSRoJRVJApR1oF4i5cWWWLHQ6gWCY86Yk32Zo0UdFwHFKWwlP3sxTf////9fNscTaSSJCLSQcDMQMwVXNZQjOKgpJjLyIwMFFhoWSgsBh//u0ZAyMRM9xw4t4E3BaDcjHPMKmUdnFDk0I3UFoN6Nc9Il5UCGkoWAgqDjIsd3GEwQ0XgiUa+K3szSlM7B4atyQ6gbqq2OS2BrTB2Bvc0CGXoeZmMOxp/pBDrrRmivXpJfn7dPy1V1bq5BVO5svM7Xr1qmmT2b/dm/6pppm/Xf/9///TWZX0KyEIiXRSEICRqEKDIQ4EEZgMKcCCq5AQAQWKDDMIAA1BoAvp0iHgBoggvTLU5BDwVDGj3E2cIh/CiVuulRKtUiSxAQ5HsyL8/7TYmTGEu+RaRR21eVsW/////T+6N6IyN707f73////////fv9Pv70eelYMgQe2DygGJJHuQg/ABPBxEJyx8YMAfMeKHipjBYIDNKLNJpUgEArOC5AOJAIE1tarDImmPUU3ZnQxFOeB3LuReRU8DS+ayrWtSi3GZdcv09dx5ZSXfsa7nbsKrDMjuhv6rv3qnX1Qn7d+j33u/mZvdf9f//X9uz5WdGIrsh4aGfGrUsbLNK1KZUYbzA+CjSaECFQpuwNgHUG6FcOgRRNuaFGVMwrZAGBJA2oNqoIEqG5nIzpd4nchYbTZRLwTKsanjKleKEV3ctW5VrX////VV/1TVqJ9bcn7r///////+//Xf51boiqQrnWCJT0BIAADEiSAWYJTiRJozBVBofDwl0lYg48WtWOOgxwGxCdQllq1NpYhTDK+nielmbDYytadLpFCcEhZZIUmDbPUMGkKbSJJOiGRVCkfucisZa0f/129Gd7V//ukZCwABEFxRFNJFTBkzfiCYYVqU1DFG0y9jcFrE6QokbGgZaM+f1v1rXtfqbdjnl7k0rb//+nXW5JMysDdkmBlVy1BmZwju5WCiR2DFIHIHY4yAYIDvOa5hIseQu5+ngsuW60CrWV+2EnrnS8TDIfwoWPoaLKI4VBiaLo2nPjU07Q4JXdSvmYrqayG//////oqn/p/W1a/3y0f//////yorc+VEnGHmMx6WHKccYOnAsBUERNAikoOUAB3bRoBoBCM74WeBQ486W1RpQUiqhqrVvJQo3EuYTIMJZYzzQLWfywhSiUKFKhRqxjPRPjdHUUpXG0TcsBlheDIJ+bgupRF1NIto/hrEMJOcBeycE7J4d5mg8HIhCKIwtG4eCIWyYJZIK5eKZWJR6bIA/nh+cNp2ENIltV8EECwsaFWKHt73oSwWfu////6yppwtPiUXtPyYESACX6MAQB4hI0lxMNiltCwJEJEwxJFymLks0sIdxk+UH5hCcEMqkoslFALZ4SwKEAgiYOI5DqRiIWy2eHZwnQoWlq152OJ8EwgJgWM9/0J////////8uPVAyoIQAAo2kUAP6hxAUoIlAzyJ6XocKENRRRGA1VU90EqXM4i+mmiqwBBYua0GSJFK2wG//ukZBiABGZwxFMpLTJcrciqPMJuT7HFCywVOcG+t6FY8Kdx/MNNIRw3yKYmQtIhtR42Jpkp9W7haamuvV4RiIHK9Q6hnqX2tql3R9rVV2XoznlP+e11STZKNZG0uq2/X///b15HOUWUpXSUzlVKEce4w4qZYdBilKUPh4eIjFREgADcYJAVMorTMEIQqEq25wQlXtk7wAucAgoFJO7nWlkVS52UkQlHSuZeCYxWMWXRqMHVTaWzrWu9P///+v+/6dZv///////X9vUrOv+tzqYrpNcKdDlsFOJZ3IABADQgAPBS7QNIFJXLmU++UNUTOn+WeX+QYrpjUsUh+SSqV91AMOxrDlWXdxzwfaPy3K5PXqaEQw1RGMM37/+n6/+9F3qml3R0Kre7IyK5CGMW2jsxd762T/6d/bnVOrts6qoqJy16nGMUQgnGbp9hEKrvJl9KvRMvmGOSKAFKQAIKlUxJwcoiJYjJjPDCXlGZ1kPVjKyM6ESuXjMDk2xYvx90nrCYsucTcF6+nexa4zlGpOG///ZZamUkj+nl43ZaGTXfHDNJfLM51///67KMwJGMAWIjUzbdu1bYfmtoqKI7nckoMPbIVwxNAPoGQAJEa4E6A4qBClK4wqwXqdOlsVSl//tkZAsP84BxwJHiRfBuDjgSLCm+AAAA4ACAACAAABuAAAAEiqZ29hK6fFs51CjfG81erfo/Vpvf/6Np8u3L25jPLzK3K0zlQurGVnMVHLmAm9Zvm///9fmmuv9ppskVR2mJQWOa2einXVhCHoDZgVBFIcjzQ6PQ4kGoAoNmAkAESSNoEIOVtI2JJabFY6YVOpMuD0t/91/xfhDNfuLKTTn/kYf+GH4S+LMJqeIUoSmhHNC+GaCtFWhScR5oUjJP/41ux957jDJKu9WhzymQuTJZFZwbJVppGhCFjWIrLFwMnEKFRsEWVRSCJNJMQU1F",
	"burst2.mp3": "data:audio/mp3;base64,//uURAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAA4AAB90AADCwsTExsbIigoLi4zMzg4PEBARERJSU1RUVZWWlpeXmNoaGxscHB1dXl9fYGBhoaKjo6Tk5eXm5ugpKSpqayssbG2urq+vsLCxsvLzs7S0tra3ePj6Ojs7PDw9Pj4/Pz///8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAT9jQAAwAAAfdC7PBx4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//ukZAAMBCQyShMsMNIrIDkdJEEBEpDNHBXHgAkVD+TysDAABKhTlJFAENFhACAQBoDQSBLJZPMzMzM168IIECBAgQIECZMmTJkyZO0IiIiIQJkyZMmTJk7iIiIiIs88mTJkyZMgQIECCBhBBO7Tu7u0IiIiIhMPDw8PAAAAAAMPDw8PAAAAAAMPDw8PAAAAAAMPDw8PAAAAAAMPDw8PAAAAAAMP///ggAAAGEmIlglAQmLB8HwfKAhdWD8u7BDWio5/cUKBjz7VHOT3f//Of9X//JnK5UYiKRgoSCMABwCQ2SuRSZU0llK1YZYi7rWWRrbBgCOJAqD0VZpB+FsXb1KIYSwkiNVClNyAxLzFHVaXhQXrpMp9TqdjmjNzZR9aj5WObI4va6mZHU+7QoDy2PmkWua1znGLYxJSmK5flyOstvX9l+v/Z0n73nZl//9+845zu1fwz1O99XN/ys3iqEsoUtHQWLiDAVREgCQEmBI2vw3K1j2Z3cqgfve4a3/udrnXckQQ7jrAM3+YizDi3NAiGnUyQYQRAUL4fJ/gDL/wwt714A9f/5r3/d/yigAkGRiGgyIhQKx4OhQDKwAT4NPBDA3kyjXB9ZY7SYQQBjm67Oar9XkHqtRCMCk4yYEg//vkZBkACI2Ezm5ygAC8sJodzDQAIiWBU7nNAAM+MapTNPAARJwuwnBQYHenAYxKMgH7sLkLgeoBxzYGtTgNMiPJEiY5Y6CNAywgDJGgUKjlESFlkHMCADUJk4Q8AouA8SAUfDLgbMSBECIFomSLEYVTYmES+BhAA8AwUBhwon8Fg5eJc+eQmJwqHzAqG6QBAQL2AKIACQYfcAouDehZIMTNzFjQzJk2N3SQYBoAAMcDIYYzBueIRBfQG5iSSnTSZNJlMnt4roj8MTjJCPBKA8E+R441s67u1lUP6F2ycMhmDw8DLm40yKEgNAmyf//////7f///44x0EQFyF0g45ZPEQPgAkULMdCwRDoWDMaCoSf5Hi8jpc5evK4FmU93WIYtYgcwvGKRCC0F8YjOxmQA4BG1G5cJxNJIhhvhbC6SJqaGB0kS+YrC+AZgn5HCRnkE00jYuJmC3NxZBcAkA7RKwkdJ/oKVQjuGQIwPEYMS8hqr336adRKFQ8Ey6MG43qdfWy7M/8TA8MgcZLhfxPCAFwGP6v/ug2g1TDnDnjsGwLwTx5hzycSgwhqU/////+mnV////8cZ80Kix1kmS54AMDgMCAQGgQlkxyONQ2VeDlyVMkl46QvDa+RNVK04LBDgKQMZFEMGphAqAECmhyydNzJigQBBWEgqzgbXHusoqmkJwCxE+5wiKDlwWJLeJA8++K7jLyzYijSOUhGlMmUPfxj4gZA1WYqUbVebdM6CtzLk4YOYjDEVxwMMJTNAiswBoITgUU804ylVZ0YjDNeXTM1Lkfy+I4NRwIhScyRTgPdjEH7o4zDU3KqLeGwYJCgMaIIpOKAhxblxXRi0M01HDMFUluL/YjX1JajykpGUMkt3GZy1hQFYKL4VrV7HfPyrSm3RSS5TZa923aicCM5iEniUjh2GZyVfd5hr/7rX/+d3eWsf3Zy/94ZXVnAZ//UAAASwAAQAGLzFADKOUNzYQjRADFkTHDyY+YE2SK44YcYLEFfBgQImmQFgOBOwE4nIhyEEkSJkBA2NRk5FKSaWUSXVxuCeoYxEkJmN1WK4xC7BerLAokGgXpxKsfxYVKkS6Kh7hWYUTyMweE+oeS5VxyohWoc2vIuLRX076B7a7efyJUCGrpzP6LmSDmm8/etRa1qp1hOvGZPKtUsKpibtNPbMkLOtf6/+enlc5KWGqV1RXNsZOrjWL019a364/3/j///+KxMauYXitkn//a1U8TMM6zjAqLAakvgcAxkYDB6YsBIXmMfDTMXQ7MPQS//vkZA+K6CBczYd3IALBqkoB7WAAW4mBQu5hjcMjr6fNvCW5MVRWMBiNMPweAIQkAIGDwgA0BTFWMY8wkjD6OAs4UkJJmzG8IC8TIzNVFIMKiHocbcBJ2GBi7BtrGuqCUkKhYALCDrIEXS5TJVM3dMGYFBRGiVlp9GiKmIQgBCiAQUPQTl9UBam7tgqRL5Vda7ohwBe9TNGooBe9x0/0z4g9zhvNL2lPvIGhomshYA/TFYVIobi0vgWKx2WOvKZVL67gyupOR1+5+CuwfBzSI3ek9SVTVugzlsXq0VnG9DlyvfqTOF+gu5S/cqvWeUGN/LOtuznUs2rus+67zXMuZay3nrW7QWAMCwBMOPCQgb1OqDHe5xmZhCZroaHQYRmGBgZ6YUOXFCAaIYIGBxl63LXIpQoSXadtxDeYBET3X23IvkUdQFEkV6CxS2yHqmTCh4KihWNB9cMuYysCm4oEtFrTqSFlrrM3fd+pXD7pyCWRx4cvjT7Q5BcpoHrisuidJKrtekp+3MK0Tk+olncpMcKaevU3M8c8M63cO9u/jvvd95ljlTZY/nXsXf+9n/dY36e9jq/jrn9x5X7n3Xf/VtBdaaVHoBoRV/riAZeaGDZpSbHYTgZBeRkdLmtRyYIDAOOJiUKgYrlAXMLAIIApUBoyEB64OQnOOgqKapqJ6vukumvGkUWHBUK5lVUHEBDBmHNxWFhaCrFG/T8Z4/8NphNf9iqr3LoIbi7TmysiYO2KBYDjMjDlPgcAKEYOx9Ho+PQcWHYpKJiflUTqFRk5dLxUoVTx1A5g/WtQFZBPOP0Ovo4epOOxBwJIlIZBK5MNlpBPj4ULj2LShAufbVYsXUL5wZNifbVy91DTGVUvJmvQx0ufWKqpi7ftHO1ZUEtaohceqZUPrgEwwYHMFljdrk6JjNcXDdikxtDBAiYeHGCioNIB4KIA8w0KMUCwCEIaMDMXRAIzrLoGRLAkeEOQjjDIUJXWOKBXCkMm8oehLLlBgxaEbj5fMHLLhl8GUMGdlOt4WAZtLWByeNUqxGWrzgaOQdYkDAZCoUOWQAgmEQHFKMIgWikO6YFyjODhwXUgv4xNNwcKj05QRoW37HHxmgaMMIGmWWW1+ylJq59XKrGcmiVT6z4xRNq3fSTjbpJuYtumyiSWPpWSeSlLpyXbZQABczYkYyza8yyAEyfMkyfFI2RCQykC0eQ4ytGEwUGkypA0hGwxsBAxHIEHCcYRAgLHKNAWYFB+JBEEBmVjsKAeiqGBqZDZyPBp4EQHRDXt//vkZCgOZ7pfTZO5ZOKzK1nybSPiXqV/PG5h7UOuL+cZvL24AKq+B9wwjQycLCgUUdFBI6AtG4WkRKaen+sVvRgUBDojlYwICbWB1NGzjwL7KAF3mfwEMgs7aTSS1UVWWOy4kCL6hhtHWeVwloUEtYC1lkLE5dIHmeV9YDuyxQxEJ8a5anKag/P0iYCh8rJ9z9cVURTORrEs/Fxg75PPykOBYSPrzttSpmApr3KHNOjZbb3r5D/1v2chtJFuJG832Ipq5Sr207pvRoMAAB0AI8EgI+PMMwc7AIkBxuZ0XmAh4JHQMCCQwYKDJ4DoE7yIRawDAa4iIQSPRURqRcAIAjKraocxkuuYCAwCFgswIFMABU5lpJjv8j0rWpyjixBG5zmdJ7IzTTWmxs3qwZQxOCn6kUolbYhZkEEY4ZXFas0hpc0QrtAzqKDZ5XoOT2UGja46g/YcTUUDFnR2gpgJuCGArrYR1zmYxGZ4fF7/0dwSf5Z8HQjekvPGNgxlHkC3Th/SPmSg7prj6jeOcGw1GPDTZjNbmsxtBTBQYMSg0KjMIIYGEphgOGJw+E9NCiAaQUmF4ng5iYNER/GYqMkhBKZNMLtWuapFrE8TaMtolHSAAqFivGkAkAzy9hJgeoV4GdiDHFsLsVoixvDbIAX8RdBm8oy0Vsp8k0Q2Ehl1Wwo45iel2MhOVRCVhLBvp84ToT0JWN7QXUfyIFIDbQplVwklkgXB8dZMjolowP6nEfKPLiV58KlJE0OtiyjFWhirYG1kU66L6q26M+ZXFkak7K0OcSE5s8V7Ftdk026eStjqPIpWvLbAu32wpXskWsKfwmGLYECzJxUzvFOlVTdzQwZfNJajNhs1RaN5QRChmBFBigKpIxIAMZJTIoP9U1Jhko0YRoI+T0BAgVOcwRAhdJIgoIMskDCEIY+KBWUw2cu60QOXQSEISRaJgOiNAd019iQiJpdpwguNNsqDClYYiud3Uv2HuQ/1EpXyMV69AW4h4NJ3ObkqCdiuKdDV5O2X1yc6QXKdldH+o0PenI4N6HqRlO44UfRnZFwrF2x0rPDiqJwned/IzxY7FFYoLlrNbvDrLxV6wKt+4SMa4Y8Zb4zky1/w6Y6RHSuVivgQIbO+Z3ub0xDc3k+O+eWjvnEAAHMFxvOhUtOReSOPPzPFBlNuFbM6x4MMlMMKxAM7j9MgguMiyWMkQuMIxaNGU8MRRgMGxNMMT9M4yaAo8AkEjD8ZR4IB4ZjCsFQsGQcGphYAZh4IJhCJolypaaQgh3BY//vkZDCOSORfy5O5ZWCgi7pHZYjEXyllMi9rJ4rMqqeZrBn5oasnOA3DOVDFzAbOAIxjTRiIpDKnUEFszYPRZM2JIcBcByY0iX4MMcgBAoQFKTmQ5vwhkJLgYMIITmWOmYnmNBlnKeTKwNABwLWVH34ZI37YmVIlrmcZLtIVjTlQE0ROp1pxrcRXkpe/LupEpmM3lamSqqlsEvvIJLDwihMqD8nF8RVJ0pIRwZmJUUMuHmHDBwuaOlDsdUbFySfXUtNcwv5StjXKTlSSYpOSz5SNlBk3aNp9UVqTf98tRXCAAASXu5hkDCFMxKDIRR/LlmOeJjobNkcd3W1XqzGDS3kXdJxJp/Ys0p6puOPHG4nDDTI7Pv41ttVH49hI5c5hkRB6MQqZFL8ZZZWn3Wfqy2ymXKcXbC5E04duwiqOYc1lKsEpbXtxLqakXByZLCz8WirQtiQqDlVkgRsc4yc4KjzjLKOZhoweKoYbSVjyjtxx1CEbk0dZGKjYUYM/NgcWCY/YfxknjhmPkkyYuYb5gFDNGBoAmVAnTApBDOqLPinHlYBHH9NmGhHoankUiKmeZ8IcAGmqmMMPQEGAQmzeHOLGwsHEXCopR0FJgB80q0Eg0OAXTmQMxM3yAc6CsAseKJAAEGgA683xYCOCQBUEK4CJBooXEDrREKo0haQCFn05FEoZfpajUlrLFL1tLLrq/hhpLDJQwhBK3SQyxbq6Jp8I3DMNSFyF4PA/0Mvm3eIRGX8hmNObMRGHqasxmMUFJNtPwuUtlyJTWs1Ybs/T4SOWT9zc9dwy3T6zq8vVr2O90/67v9fzHv85rDdnetf/eYbu9WeoC4p1RAAA8z4gKDjkHDmOT3pDCOR4KaMGYiaGDwKNS3UuRtVUZUAhCq5IciAbgJ+JngZaZxgApu19uC9X0TwS5aStddpEloY8ND9EtXqtiYkDtgTpERAUhsoYNZ6jzOWBxqMuNDEceyOyeIOzOQ9P00M9lt+/FJPWbcimWndWmxmSocCUqjUi+edpCz41b0h/6TmU33O2+Gxs7u2eMqEzDjMzbiOanEV7pHcvUWcmXzwgCdldZwtqAABjaQKxVTTOm/TCpDDS0ATCoGTJIjTE4BBopTCAYjBgJDIEOjEUHgwnjA8MwgVgEAph+BYyEAYCQjBUwYFoAbxtSgRHmrbG5kykdR9CvzzQCPWGGSqKmMzhG8yYheYu8vemCFD0wOARvL2lmAdxDJ+YFU+JXZo6UtfZxYGe52VItkYSqOSwzOQdAzeTVMEY1rkp//vUZEmO5sVIzpO4ZGLYCznRcymanm1JMC7rKwqgqyeJpI+LV4yMCOCgnlQQjLdW6bHoJFQdiThBJg/LISqZKyQY0f+G22PXVqYnH7T16bFs2pn3ow9Z1cGq/wC2qYfLcmUxkFkscnk/4AJgEWmvxWb9HB4onGxygZVHhg4fhhsMcBAx0QzFBTMBFAlA5gsXGFxOYWHxgQugI1AojDICMMhEMRoqGxkPBwOMS4CpkgpiuIWlYJcVOcMkMN0tYCBTIZMgBFY6bhANCVtgwUmvBqwiTEaJlNgAowSghJcyPSPS8lY0k2UrNbV4pIylwLOTY6SKwDNTrxRqkzYCQnRLGCy4mpoyKAaLCxVWMhsZBC5TOsxiIyQTWRkJCeRMzq4NQudbFppVd1VKFZkKr/IwjW15b41d3eV6+ZL5CX692joCUEzejg/vOg0OWox6Io0xI8zVEMx6H8yUGsqlcDRyKg0mRgahbGAFZlVZOnMGkOWFOQkQLMAREE0xJQyD84isqBjHTh4KYoCuo2WT1IKqAAVARgIKLBxneMXBzrejCpAKaJpgqpEg5oANPuNOh2ZCOCkgIEXaL+thBABWSWZWmmYNGpbLeXaiKwVnCVLQmSxkuw0m/Nxd/2NQ+qFdMIfVpayINZrBkQhuMSm3QxJnTM4VEXbh6PS+pH4Ff+mZ9QSq/Ju34Muy293GxWhqYwzjmFzOxbpau8JdTX6Wdys9s48wxy7lbu/l+9fWBegi9eML8oqrqAGAkc4g00kMyis7Qo1js0YwwpIODBAUqgzFDhkAsPPmWCAkWBmQqRQcYeu5YzcUqQsAUAEQWGUqEZmsqwP0i1OpCsBgJkyCqDr2ofqBEgNpTJkHZTEyIKnij6yx13mgt1bUu5G46iGkSMqQkh4mt543muFMkaS7zIqoiYlS1wKXigKMoVkTIwJF8Tpw+sSW65Tql8YzucyohVLTmtnWIKobl0L19S7qCtUAAAFUxA2OjkTP+44bkMXAQCGiwUCTABPIY0CMGMGEgYGF//vEZBEOZa1Tzxt4M/KYiioaaSPUV5l1PG2kfMozq+hdlhrRukwUuwoHAIGJQsDLCkqEbQAJaQLykqWmFlpJqkdoHCTCATjAlopeVEtRlZSNjOGNFgSQrS1Dlzs4Q5syjbS2EvRDFSvBFDKcI03OQ5w7clkzK4vZxsUcjB0wgCDg4yeTJwXYbSKIjT4PtJXdjcc6yT6ekYlBRpT7Vw/749Z/fjPtJf9/83M//7M/LeWBbvDOZEm/6AEAAAAIUwwGMJGOOKUOMgHFi4WOqfAycoDFkTIgy/rhNGRwSBDBzlx5OdV8riErctQZXqwLPlQsSaYk4/c3LbLTHdjbOXbhvaXlEpi3R/VF31i64GEAoIIk6MaaZRQNKIDEkpNKGVsz9dpJXx1rr3qzV8rbJOGfGYzJKzTMjXMidiX/zd0hb7vV64Uj8ZHNzWsfYif6BT8OAOY1gZNFRD5OM4WdNkKzOBowoSBRSYsEMxIoMv2YOUAQBHQJMsOJCYKQfU2SuLJMRUgGAzTGxo5pNITS4qQqlTO6qpmrLbjaxIgmJDbvPw6sdZqydtFPMaYLONQg9xFoyGHIKl1M2QPgOIgNCEULCFA22SFYiYkwmXoyVYD6ImnAVo+04lchdq8IxvahGEEDhQYAMjxklMMKK3RMaXnCCyqdh44VV1oIMGJAFsypUYkyDuRzZBR5N7FCGQ2CGCrxGUHvCxBaYBKqTAJTrhCDzjRBbZMiIWmQIZKK3HReWagBrbDauEXgygjF+vCqJfIJPLyyDA1NAhMhHjLg9gqJak3HL3YUiSFvaIHOG7SL3bGHu8xqGyXKvHjJZyDf3n8Zmv31+/QzbZtVzGJ9+3d9+9bh9fMa2z+Ku6LrfH6SLs5epMWxZwADfwlxAegAAAFz//vEZAMCBHBM0dNMNTJ9SWpNYYNuFLVBOm3gz8oUpOi1lhnx8/JAOME7Mxdo17UQFiY6mOBABYCBgZE0tqlqlZDb1qtdyVwp+nkpnihThuUvVpQ7FgJVg1HZydFdQHRWUI6oaKp6yvgVc95dMrKT6uMwRNDpNSCGR6oqU3wGKd5zFF9jiSR1RL8N7aH5IqCWyRqvu7nlKu7tR3ztbNMRVHebnD5gL0INM/LfVQADEAAAAQ7+tg5QDQE8XFXhF3WHoR5bJApMB3GvlglLwkqeBEPh0hQG5OJtGBDTFFw/fbRhU+ShOJxWPTpREuS3WjnG0ust+kfeJWiKja4kypHNfzaXVVRo5rmCU0jpo0DAQECq3jMaSh1AQEKUh5kWS7nwM9IYzZGSfqV7gDAcz8mTGxvpCeiSGd0Zog2YgHyEycHBQgDgoiBh0JC4EDQcWGE+wUAlvxrY0hnAICRHbkpJ/VATOYu6KCYiDUx5syasENMYXedl61LVgF5KJuQ1N8VnpDvFRrWh142cNjooGiVmG4DjEYguR1JdDVmBrm4cpIygYtrTVIMPGGHsURk8wlaTMfNTtZPmc1xPfs3vvm/Kbf/2bYd/FSgVhTZHb5ylNgCosAAAAJTgusgTCJRWALGIOAo02qhKpAa0BgIJGBo65GDPa0IdSIB8HR5LhDEshEI5J5qPHlxCaUFBYdJyoaCKSkPYlZqIzMJAhOkpnNXOyNpozMfd06PeH3FnY7inT3oakmig22xVaTmO/+z49Vk5S8/jytVfW3pmR7qYSRA4Gf5kqGYgAAAKeBpskeZiTj5isqxECRcUZDQlsRZ0nInWr+gUwdNaDvxBoTyzj5xxwIk5UXZtFn/llDCjEcj9E1GFRiIBJI4ggknYaeIIqFGO//u0RCYEBCtL0TssNZJ+6VpaZSOoEJUvRm0w0UIZIuippg7Zk0MSw5E1FiRxSScxK8cvLF47Facd3kkcaYx2JpyV17H/3Jz2/ecbvud+33/2B9BO2xnpEnZMCEAnRG0AAAFvfmCKfpafICZBcyJwESTsg4eBVrLUoqIRsyiiQjCHEdOGbceeiA5G4FlocyNERYTq51wVCnG2cLMFILTFTdMSYwpj4uyDuwq6CWfer3BwwetVRMQTEtDYMTRXaRN2kWhmJJQjK4p1pBuTKU9u1CgMigcqBRkTv7Oj+4AAqXgMYESw1Rw4QQwg1CQrQi+5qA5LlDmq6LLOhx+mRzsIVXEE7PBpHMeBxIh2YmIjRkAvjuTXAGGSqhiDckm6If0FAPFxKXRzZ+bWclOzQZ6cCqiUOWbltKVJOdD2yccvUkqk/ij7VaULrH2J0yoe80yYqW3d31pTfKdplEvDSpApchYBoAAABKcDzQDHBW4aRIEEwgSBhAXLoKgkGqFG9JJqKz2xKwrvWv1OeQM/UBY+smGXxbV6Yu87eOQzJ4R5GIwTHPCSActBC4Q0MmMNGS2KFyJDg/5R22JUtj6kf/jlw4UsQOGldBrFFM5R2Y0iAy3T8lEEaLCpVe1J9L2CBLqcQmFndlWb4KoQAAACvBzguPJBjhKCDEwM6TPAAIXrMWAyEDJAO0oahfDzH4fRPRkTiQDmuWxlJoT8fh0EGetg9BujoRirbTfWShWXahVg1yyL0WIn10MVl7JPTMzKmWVh//ukZCwGJHNNULtvHGJvxTnxaeZuk/EPPm3hLclzDmldhiUok7kxLVXGtHVfl1SjmDWDsfQgrgoiBAxYlBV9n6p9KYqHqNDjWmWe7hi0WjEJZGeQZqEJHblxYDL8AA8RYgYcCOZhRpiQKolMS+qKBb5rLhtcDcMYkQ5Rwp4qTSQyw+BmqtOltwPgiidK9GIQXJWicH+dxnijB+kuLgcdYRjIadb6LAuhjG5TtTjKgipw1xDl1mvdWkoQJMGlvYKlkinxRkq4+/NM9IVwOQLDiDk+RaNMNDJRIwYQKCawYmLmAi40VIFGBAhj4K1xbLVC74NugIZSHPNsyACBh7WEAcgLBViQ2T4Dxl0FnsQWKzsuWqRiDB0PH7iUFNbqvorhW9cjjq8LoKZrCQ7JLlJJ7UTCCoceSznRaCEbaIEWLpznBcnQpV770u5VqVfaTuN3vqf2mVlIpbroZkrqWTR4GerWL5VaErf1+tQIM3D2K8ELlKDxGFMumlsMPdS4fjyXUQhFIwMyqLyoyHhFYtGkJkB1ccFR4kTZ5lHsFkJaKngMoWjJ4H2gigMtY9AsLrQMa9F4PQ6GRLRpCLDQcNKcuKgepLuxHdUAABTgRCZmhMbiyGBZpl4EBBQyAAMQAzBg//u0ZAyM5KRF0JtsHiJnJOonZYaIEmEdQG080wGAkKiNh7FIFroUBE6DFQ4GAKR4hAAwHQXDg5JMLgwKCggKYa4aAFli4WTNlXUyNrigSGy24A7XTKeJkLFW/cUg1BslJgiCg1EpN486bgsZWu6YWINFr6tbmrbtWEqGGDGJEk2dVGdKwaghyuweMae8pk3DSF8zyb7cOdVn+nnZ/GW9cIAAABlElFRQVEf1RgDI7FoH3LXw60yVQ82doDvpgO2ylrjG2ycuLJCIaGYLCqOjgQMJguOSaWDRg2WF0rPNicenTzY3AMlyCIeTtRam8mW1PJpwXMDCoKJY29gsC+rLpDLKN6r4H0AAFPcHLrmMKosmGkk5EHASIUXNMeGVvMABCAIQSeIHEV3sST0awi2wJCWWfYYrcMctSXQjMbCCiZFKpVcdRsKkXE8QdpSJ1nFiTxQKmdXpxqOuGyN6dQmAzwlO2oHIksAyzD/6OJiiRREaCjCcEcicQR7b31kTDlzk05sfxXGwnEwRzmabUyi7FV2KK0/UqBrQhLlTCMkizwAlaDkDIHYSdZWqm2jNScnSY5QpovoJuiYcQF1whllbpiKomS8XyCFpJUjyOKQ5sHhQQWgbHZIcWm2WdZvG13PNehBggPD9Q4sVQOStAcJwfamhITmHau5H36EAABXA7O4EagawFGnKpQElUYMTGjBg4qAgkVJNGEggKEEg2sqlXmzBMh01WI8IfKgSUBQlIlL0s2apAqBsjWsrxVBiyVDM//ukZCMOZJY9zxtsHiJsxIoHYelOEik3PG2wekmoEygdhgpgX2XC4zwN+AQDYeCQPIuDgnjsECZXcoEwfoyw1GmWwJF92u1tiBpCJRcbALEu8zQ4MZsyMGNM0plUyzEHAtidPZQJFFalWoh78+JNrXCAAAAKUIbDh11EoktUzGuEJ01UtywCpbFKRiRWoxDB6FpMkhLNTikj0qBHJw+04vm+2l1LJdRX0JCVbYZDBMBkoQSkBwXKmcFZPjBVSSiLx22eDp0LLNAgdOXjibqS08uH0h8iRetL0cWauQkQpwL3RjhMBRgz03MPKTAxlK4MFxULKEcxkDLqIIl2u0sArKSAbBliP8BAMFBK1kAAABVMhYcSHaIBgNO1XSq7rLJYi6zJGJtdiatigdpVB4n8poXu6w4f2gpNgMLHDyzq9QhNbZDw5etRhl9ARup0GX3FZaYe3u8Qvh2G4E0PNGMpu5z6eR4Jcm3+oUovJ9aybBDlDcQjJmeEMTPQGslBpo8NOXZHm2QEr9mICftdUDvmvavCHLBsA0D6RoCwgDyZDkQniQIaEkJQvEgkCs7MCaWSAuH05MEN3V659rMGXGec9gwWRJFnWsKDTg0MHAshph73i5ZjtzvT2aEEAAALvARW//u0ZAOG5G88z7tMHiJmBoojYYKKD6yxQG0w1onzJChNpg6ZE0wO8mZtGNIAJYAhqCwVEGVJKtW+gQUvW4gEamX4EAVhTaL/VcluNCWfLuSNQ3pnaCgV6niWcsC30VWGZjDMKibyCU0B1AAwP4+jBk6Io+SfJFJLPXzVJSpcXlzupde57AoXFwYgHkNhDc0JwilLcnIzhdplBIJRBkBZ273f9iyy/PbjT9+AAAA7w4Q0VdwgK0RHBbDLldImsPUMWq1Fpb3UcfddelCgixCEPi6NA6QKRUoKBVQR3qOhebuYD7FUvEcFyY0vu6bKYtjuhZe5DOVyvolC3nO8+36I1VuCUyVoKALcuxvFE5zcNIqcFODyXDTiiROcsMmeYQCTFGkpJxIeDl2jEBC0MEqjR+QAqxLLRNht0WNKlUtfJN1fsKXPZmGwwGsMJIakoER6fBo4PoSFV90XFg+ULqjotPzJpFjep0bSw6WMaGMnudqTb6wod3nITsRPM1/53vbUW0xwbp5SvENT/oY2Z/6LvEBhQ8YUKAlJrZAkhBzlgAKbppruR+RNTlYbDzFFh2dPuxtQSNtYhpwKFRly3VGgayeDUREyAOAlpR9efE8SQF4UwbmRVFjxNXK4XHFb7bf4RsfPLrOikCyalI6lkeKQRAoRqsnnzng6Um6MalmcsPU+bEIYLiPZr9gd+wIAAAu8HwGjxACQgH3BVMGF0nVNUckJjaCAI3BmtoIdTl+AQCUjcjjDejMADI/FEchMy8Eg//ukZBqKc/Qr0LtPSvJ3p7oTaYOYEJzHPm081Im9GOgVlI7QeF8ZzGkXRPVQlD5Ra4Q1HpoyXCeLHiPUVEKBiB9E+D3U1BF02YyjJJVeknVuJ4oRZDq/ZEhoeS+VWKgN95nKvla1MbCf+9f/3lAABd4UtMSGMYIMBKLKCSQGiRIiAgQMCpXjgdhxd5ECokgxOHmRsrdeONDaELiiiJQaMkI/NCIdHTsBeEsYKjKxZOwSJoGziJUsWEo/RMn3LrP76uI4fyR34tnplDL2YdsM3PVuF9ZThk9EGTzgCha4XYwg0XHepqd4O1dJrRurp3hJEhMCKCEQCHAQYUBwMpXKhmkCIgY8LWUsRPYmH0yZiPJap9GDJWrYQ3YQXhIqI3SAHNO6PdfL6hiTRK7QpPoFIOCgOVpTAJoBCw0kkSKJLrOq4ZO+eg8pC8E7UznqrnWRJhVKgZGha/2Tt1JUN0lsf94tKiqIUC+65ysh/GmiEY4QkjDNKHSmgq/fpQtahCQAglFEFWasTfFpj4MHpYquVms0014Wu0bUIpA8pjr3gaD4KC4oAYVAFFDAfDAXs8GJDVHH0zLvEXzYjOFzqnD+X5fbeoAw6cMlcXoCqArFHDHHUH2MQm0kP2JVAACe4OhP//u0ZAMOZFE+T5tPNaJ0pEnqZwwuUq0fOm2wekmTkWfNl6U4McFONKM9tNuaDGitroM9UVbiAgLD1zorrUcEAiV7sDAIJ/FNmINzZyrY+qvowXleZ2HoeBibaSA3zPQlaQ9WJ1coQrXypOWVXKdzePlekY6wrGR3ZiFJfIcNeNjUtIo6iL38avLsT5uH09w1y1fNy0iWFwgxsMV+yDY5GOxVUWMI3vb9AQAAAAArwj2DEEA5s/GSOoGoMFlAiaDYcRja1ZhvV9KAKGP+76karXH4Y0yxbeL/vOJVEoXrhyLAnCSKA9iEzTEUUHISUwuXFBMffdhpC+fnHIViuQCUld/LR/+TyeTFmW/b7r4jD8SG7Wf5KoP3tc+7O/9kvcHHj5lpWakHmPlBn5OZQJltDCBYw4JCCIKjBasGgQ8OBwcpiv9JseFkvFnjwgj3CUZkdbLRSzSPKpFTJMQ4kExVuLTVF4DUUhxYsDNBjj+rLZTCmYWnzBFODeY7xlA7q8YrD15x+CJyv17FBBwuuJBeDUE+nTD0KE6WO7tDOFBY/DDjoZrWarkaE62i+4o/tDHif4wVcEJZoSBd+QA0NBMiionAhaksD4PIHdXiwFmGCXFkaWfSMJaQZ+4IFClyaxlKQsGaMZvMhPU+rnMGgvzJtUFRmhflCVhVREWRXPN64NGjUXF441Nmdl0rtnRQGgtn2YbTqtVv7AAAHeDjQcMty0QBLSMglZDsvBLISWIDF5VBENU9lzNxRlT4FgvAfqUD//u0ZBSOw8EiUBt4eNJ1RjnzZeNeUTzvOm0w2gnEH6fNh4m4gKRsLkJKPlbLcHyW4dTexDgV6Fv1enU8ukvCY2RGKBDJ0czMz+HtxY9RKzy+NaUqCIVqtZ6DWqXfTBQG+9wunnHc9PxT/9aH1Zz7f/v73QABDvDVTeqXSghMYA3TzSIMN0GLCI53UWiQiHJ8mIn4vHo11YS8uYm5zptCVaoT9UZuO4TScDe8ULOMBuYDDL6Q2GnVW5ErixWEiZhQUcGIFOmOow8N9yPpelmX+WeDWrQ8TAsp/yTujvZdu3HYkK++/nn/XgFuDoqj7ZjiaT8MzBFwNWMkXIQZfAYMiImQhwguxMFGra6GulymJLXRjXowdvygE3pcVNNOtQZ7S477uekJGIbuqErIU3dB9FbmINNdqrHJ6MOiSWFZMFqfuX3iJ+HplOjAFJOky8I63n5ds+/WWl0qiefEvm15+RiLJYKRtEdBp/JjCQv78+b38MAACXh7i3AUCPtgp+1ps8IrOWmUsAGBTAYa5DjG+ZMpfDpRLMdRiEhZFEWJlZF3Ba2dEKw6E6Za8dZavjwO+AzJ5BnPK8a4MXFntbbhuenY7sd3tq92Wv5mMCBHVlIqsvQrTnfeJdp4HFouucpOKlTKlQAAHeANQAMxM3BTW2EQn5lZIjYGCI4bFvVpGGDpCpeIc9MkXAK4TlBTlyJ9FajSQCiXIBRJ2hxxoTYkh1+g58sXY6L8MgZI9aVz6rxUEaJBVt9IvD1P5PVlxSMI//ukZC4P5IMzzpt4YvJq5HnzYelsFAjrOA3lLclmkShNhJogDNcU3jLSEc3RKnDHFVHzLKv/1P+95nJ3f7u6Onx/CFNQlzcxLF4pf1TeGfVZ+PjDuV1PfMAAA9gBGFnS9ZW40uLwo+JajUSgKl6ZKGLcUEzAMtNCOuCGkYLuShxP1AMqVPovS7YGM8j2FucnGVEtjgcyGNbIqT0aDoZnAWFQICrs4s/PNz/jGhYRgQusAo5KFWg0qv2B58u6Rsu3upmKDpAo22ZORRjFTgKqpi5QYkTGLAyAUeODHgMzUjAyWDikx4oCKDXxOUkaTEizPJTDOAMWdMdct2SChVtf5AQo894GPgYxDoBLwSxUKMrppJJzJgP5KlYHfUHbuX4XhIYDirL3/Xe/DuPjD0Ycoo/BzXLgWB7z9IGS0OwwsrcN24RuFVOpnV3r0/yl/DP/NwihLCw+1CvcRsUeAK32OdE4UkMvCWgXMrCUVbAvNtl6rLXq/LG51XC9Wg321lbUZYHh8rpGAYnEJwECNCgUJwFHJjKNsUrhUkLshkKJwNCizkfFvDUuuahIOHLAm807dkThD86m1v4FarU2hSoAACbgH/Db8TzWyF0ZgmcgOYAAHJhUwDFBoQBmQgYKQJhA//u0ZBEO5Nk/zhtYQ3Jlo+nzYelOFNFJNG3gz8F6kKhNh5k4kvWXeCiQawgMl6GDBsVkKDgG4P6LqWBLwmAL7JjMDfZuKXaAgkIv5JFVFHd/H7Zk7yYTMl/O247y0FWNzNIs3FvqGOyoFyGBUTkiEIo7og10RTzhkir0lpwsEk8j65NpnT9Z7Ow4Ltsi1kaNEhf+kucqX2xzs66rVYAAD3EfAqi/onWHUDnjS9ZWtc0jBhMIBuPPQVI8Uuhp2nWe5hDsDpgHRIP9QqhzPTRjy0aYjxRHscHgSGwsiEDIVmohIXbjEB4USGDp16Q6DzF9yQduSc2dahI08Pj/F37wqyZUTCnBzuODkkSpwNQlmQFPApZFEExM8MNGTFBsywdNQBTPwwBBRjIkVSExALM5wSMdKioaYHRZtQNAGplyQSkxibkDhsFfCC3FJGucvp6UwILXY8CXrWYOYCr9qaYLQ3osP68LzuLRy+MxqDIpNtrPyWTS3eFFL6k1cj5h15KBye9kPkbo4g7eWR2b7zr5l4rFZGd3rx/nf7/+lmOUWmdZvKlv3+bsP2SU/C8S6YKgBqrNX8vBarO2UyJ8mw7CcDBSCoYpms/8OaIQ1dvTnXB7OZxsch0Il/SC0tSrU4WaDkAgUejB4u8j2/h2LBpbAMomZPmNmUa4oOFmPeqSSWOJk4J+y/f6WQAAHcAhHN0DzDrgyigOFGzJgRcoIBR4nAySblBaR5ol0X1Lps3NB0eUiocbIKnWg5LeMMWDQsUg//u0ZBwO5FI6Tpt4YnCGR1mzZYPCUvVFNG1hDcmuoGeNhgqYnBALhNzgaDHXUe0yh805nClAAxxQFwecSFVSnC44wmFKjjbBvp/YvuwOOEr6O5zcrK9X+y0zO0nsg+u1avFec7vzOraEYx77HoBliDWiNXXdewAABzhLpTAWQAiJmNmCQcYRtYmnsTaGOogakQABwYMVAGeAAtdi8kel9GGNF5wGBw4jA0hSpoaaKrS/zepqN4qWEK3MRbEyqTgLUVXDdxQhl6SWvMVaAffAklwwkUQzmIwTnWCCapzL6v5FsGLVFEF0+yEgrs0ekfUM/ltDI3tYPFiOsiREAO8G1VC/E9NY1r0VXC4kDHSwpCApuIJQPQmmQEmEIlyALE5ZbUbCmmSBGCofl3wEAxqgYWU0FW41nBgGVsuQkMXYIiqoq20wlSnqvRg6/7K7K7OnUeOG4i5UWd6YfuYp3DhmLEHiylkUD0wRYs7g1Ue6+t1aPaZY6bHzF4vLzHfxzz3azPVRzrcTPNnXXd6qi0OdeaZbUc0X+JUgcYvhmwOOkhgukEDAXllLrZ60sYWuhdb6NNjcla1G5e4TZWauLC2/EhDViSPx+cFI6JsCVauDQwgLVzQ6LRm7Gip50nX2zVaFs6LuSypqqHQrtRdeRuz2XfM5iRt12BB95gVllBHq260AAF/g7DE+HA58A2B0ZsHEIiiAw4IIdgoI00MUXGLOrgDBAxIkQte9ocBtXLTOdFkoOIshfzV1wz028AoJPdSq//u0ZCAOZHI+zZtYSnJ6BhnHYehsUFDHOG080wn3EabNrDE5UO0uZ1Fb35lpMjXAGWGC6MTAxNKQUECI4NEhA0rijlD8G02bpOTDPbNTlLfPM+5Ut1zEb9Kyrf57+W+RqfnbI8TCS72zKh/mpOi2Y+BmxAAABTcFQQtoN0TFMsgBZGwZiD3o6pXIXpjpQoRkrKglZ7uSCJsLOLoKQti5jdTYNhdnIYbaTtRO0Wyl3GOdBvL50NaujqBYRTJeWCrFGs40sx7q+iriOqlWmla5lN4qoktcQ2eKOYwjf57qlJ/y1fDN//gf0b22+OwL3B3S4PXhVUfi4dNuEATDmVzhwIUAJwuGqQKBGpO8nGx+nLgsPQoEIISEpoigQSFnoF+ViaEwLwaysC8OEoyeWMohCiXDwpFc2ssRiy1qhgZ1yqZLsz6NqQKI3EqgtOMZNpNfelufLnGZiJv6aHf33/WtNJo1ZuLv+9vbdmqqtzv0lL3CJYcJNGiTTBoYwoALmTSQzIGjYAQrQxsNjYoWvRGe9nKxlLVhnWaKy5TJnaYLN2RxN02YtzZnIVbmsslfV1WbL3fN/wJuhEfGQ7CXCZkkckEndWn06B1jJ9kGBxL2A812utgsb7rs/RrX7CLkz+GFg/9FTz03GT75uZvZpQCQAAACn4C6g8Sk6xc4+E1aQRLhARgRVUxREoKUoCbrhT0MWDWgFxQUBsEb1USSEaBAVNhjLhILsgO00ynMMLgAZGEZZcjOPAylwh8ZCC4HSjF2//ukZCmGxJA+zdNPHTJzyAnTYYKYUxDLMG3hLcl8jqfNhiWAp0Sr0qoZZXmGCEvx2RBJRhYYCD7xwpgwIGOYzkSZvu4HDOvQ73HPT0phnLMCMW4k1LL3k8PIGIECoiSeh1nbAAKn4QzIQy8LWPBi57bEK1VEH2so/oOl/y7LXE4X3ib+us/kOMIW+BYC4ALI6FlAeNz8GwJnxJBGE8JpikMzuFAMjNGXDt48dZ657HFIdHGJGOGUrGUjtarXR11tfTa7J/3obSHiowEZt7aCfx+ntQxGelQ7gc8HotmlvpwSAaMtCA5BQAYWrGVBJkQkBDUCkhlIiwAeMwLULtTkMolcL+JBkUDsIRoKAJHGN8EJtkRSyZaJlK74YHRqNNbChEFn3iCdTHF6pDLMXcSlZdAS3F2diUZd9m0J3DkRuBtajCqCy8CMxBlO5s3q8orX79ZltwniaEpbLD5JNBYvaFz8ZjLTxmEaVq5k2j5hZEAAK/hMVHkSoXoJChio2vNlCY8fZu0yqyQwXDEMnwzNY6dAaIMdxM0GULR8oHAgCopJdGR5ChRBtEJR6jbqRpOBk6wSBgcbCc6NE40vygTYowiWtGa2EUULZvQljKdFigAAZfzjhk3FtMMWjmhY5gbN//u0ZAiOZQFSzRtsHqBeg7n3Yek+E10zNG3hC8mSD2eNh7EobNEKQEQggrMjDgEemJjpiQ8HCboInmBAREOg0HGQAuYXVVmTTL9vmWgh9hQcGs5ZG1wDDKCF8mxvy5r+qmZ4zJR9XEANfbBEJ1uj+4Bi2WzrrIaIe0yxw8utNSqhLz5wty86nxnl1nnMpTM+24HgcCR1plU7eg+0bn8IrfymfnIULemL3RM2TmR5xxv9+4oEAAAK/hhgcIxGHyO1Oq3L/Gib57F/LmxHKnS/zne0C1rtEK4yC9EreIE42pgVjEb3JyUTKD4oKggbc9kuvYmWRIGWJHjbACKCpqJpcBklfgwlV/VKw9Ds5QtVjIonUbeDFWk4OlNugzYmM1gaAIAYmIGKjZlhMvQw4QMNJAFwYIFDmewIMrejyWjFBvEHOIrsvSXeMaK8IoJIoS2z5W5Bhby71cSNK1RdT76OiztoDCXFYk/DvyikMEIThUOhwFhFYsWH4OigoKAkaIlMeIIuQKHM9XdDrb+44PNDih7Laf7Qnw27Sses1PfUz92bcPPLS02x/VDgFWqzfxJFkjIjM4DDgwgKh0IiMeD2OU2wg6eP1mIK0mchSjOF0zPniEqZQlkRWUhbUnxdOifhX0RAaC5YaE02EhOh+TaPOr16wQm1vBpTjoRj9nQJREtgKN8LBYsOSJ6rtL0rVMqi6AAAJcBYqMqUTr5wwOMNtEzKV8KEBio4ZWgGGJRlJoHG4AFzEBEwUIPhgM9IYQDA//u0ZBeOJPU3zBt4S3JghCnqYew0E2VJMm2weoGiE+cNl5mw0ywM8lS6BMyJIFUpuDkt+Dih0Ezh7iTAyJHsRwQ8Q9laBl1Jou0pIvysI+j9wMwSdftrKw61b9q1HcoTIY/hk2PIjpKgkgdTLM1Yvms+GR8I275NpV/a8/n/1j98aDVKtQOAXg319DB0yNY7a64ktAAgAAAW2CDxatjgGimaw5ZLNgvRKHGcj0eaFhEQGSS6JQsHkijgJ4SoA4Akt0+OkHNWlotL1pXUkS/noGBCRo1rhl+xMNuX2DnQgxYxEuRD1K9o4yJyqhBLo4uO1f/9Nql4NzuTh546aRMRFzIzQFAyWAcJiy0aCGCERMcAVYF3AQUQhaEIR+A1ahkIZFA4JCH/dx/n0IghTFAE3qRLPHcBQcna3RKV8UJC2HOZk9bhPivCfYau6dlgMTwWDr5SeJZmO3klahmqd2BUtcrTedQjOBUtprMaFe0/aACCAhIUUGer6/e5ZGuzIX+WZss810dFeSwlWXZQUhYUnLQrcFxBKsfZMMp12LoFBgSwjIkkkLAwBDiX5AGQfrpoISWFjTRcVhHLJ/KVXwEKSx4ngp0YpkKQcIyT8L6yGWpAIyNhMqh4PRBdwWiox/nLb3X34WGwsHgaazcLxe0UI6H0NdvR6/+mAACu4Oz1NU8N4zMgZMOuAIsOXjgwwA0wo4vyNAgakHIENkkVIoroqrUU5SKC4ltpLKcQ6x5LyLq7Zm9tLFGtJ0JRrAum/i9n//ukZCQOZGU0zZtYSvJpRHnTZeZeEzFBMm2wekmXEOcdh5l4PgNtGcSmNwRB8SiswGyYiJTKhltG0VxyNCyiXyUYKQiMILVevkE63XSl8h0lpSalbzh+uWzKbn/+42v2q3kKuHbHi8EgAAV/DIQoSc7QoWMHuqgwreZAsrROehGijTBQq0wy3NjInFCt4RyibGJmuloSSY8s7AiGDnW+T6CVRpRo7I0Pnl0KXjly3zO1v1q0AUHSkBrZJyRescB88CLzTDZgXQRsKIGR8VFElnxEbuD31I2EvMvAzaUM2sPMTIJKVQcxknMPCiYXEAQjmY4GCMALSKxgoBMEDQsHskLfOIkSoIJA5gQAqszBWxwnWY/I3ldhky8XIZyrAs+XNYWLDzQlpx1+2m4uGdB6LD0cRxXPsnC9MpIDhbO49cyrTrgdsYEOD9mMz3wweDbihzMRudnJqml3pqXWzhOX/V9FHP8hZu5HQSpBRAuwT7Ec19r5i6cb/JBFpi1Sp2kF0cSCjfQ4lRPCWHWdBNziinUoU4xKFvfQbIS/IgfjtjW7vVCjEq3vtMqHyK88FPPHLzPM4ykhwLpItPI3KyYqQDYecRZFVkbJ0X73bZNNgekG1QAApuAFxmKnR1poYJKG//u0ZAcOZL5RzJtsHqBhRGnXYeNeEVzJNG3hKclvlOeM9Inw6ogyIBAsZINGBjaFYIDUHzABgveXGBQQp4AhCXiCsOJFEoCnQ+K11+p/pmt6NAWK9XIWuX4AgYo2X/RsWin07C08H1j1e1Dm2pxszuHByXispxtBMy/CYmrkDrWQL4EdvhPatonMhdntna+EhtQovlWcLpFA8Q5qkt+XOUy/u+xvnKYJCYWdJ1gIEAAAV/AoFAAapDcwcRYeGlvDwbEMrAoaHG7XZ9n6nVepzcP6mT0U0dTxWJjrAL85i5wy2UUbhDYVlWrmK44vlwETF3plNEjEMNOPg8Lb+wJyUc/pbUNLtvG12tsPN2uWJlPwdwDDBuZ+5GBEYJDyIyHiAueCiBJRjQNEjCFUhZxuEkUmQLESqUCC44HsoIkySYrxLBs6fxu7hwygxHVTMsian4Fa+lPUHQ8GUZ0AbQbJxKJyhxCiCg4Sz5UkYDMTJgEC6LmUEGpK3Wxglv2HSSyPWby83ZLuP+cL4AxjlWnhNumzAuI4L785nBy34LAXEJaHIIwM1AHMhA8i3PzVLJDCDp5GEYRHBgMihGChVRCaPPGohc6AozBYrHvTFB0hZJCuoDEnQ2WZlWfVMtttnQYj0VGXOAoEHJVMSVSGmj5g8x+KXEqYRQAAXsDoSvM9EozEcTAhEMSL0wuVBAQw4WpHkQ/YMY3KAVCpUCwGAQDiu0EmS5PixJiM4NItGXJWr+KgW5VC4sUXIqxOh40mEylA//ukZCUOZOxPzBuYQ3JdxUnXYYNsEvFLMG28c0Fyj+dNhiWg4nKWlO2vVaLHVjM4fl6oYZM0lzHGuxd5Ieh2/IZJTAuJE+FRweISrhcRB4eQcIJou7EvMMq60tFMv/fff/rMKZBTyvMdVUDUj6v9fSK1Hf+MrXZBgAABzYKAliIWQBSnMCHdzEvC4SYLUUEKRTssVAMVgtA2tOzUvluI4Pz81BsdPjZ9yAzSnYgHD5m26Pi4vnCWHy8AqbmkTL+fPtrZroLEsMB2cFK1IMf0NIfou30aTLgbV6mUFJ7F6ZCRGeIJrxmZMaGVm5gZYasJGKBJiguCggeKU5AAFDgIOBCID3rsTMJAIw4HL9sRDA4xnDoAOitTgozzQgoEiYZpELG4iBqOy0NpCS5K0mxeyfmIs2YmNgVJvs14VHbbI3xHDtmoU9OIUKGQK57Iwn5AxOi1QaEZPnvfPcmIlSf1DOXPRsn7ycKd7xPu7i3PxDJRIx8AUTKwWkq8UAtmGlTJ/F/3eXODpLMQ+WH1wMDuU8IZKRMmJ8aphOeaD4Lk4jL6yos2ZiqSj8Fm8ze+XWmHJPvqUVBXuQm5v5k2HdJNKgsH49ExFWABveoAAK3g30COmXjd2ozgDATYGN6RZho2//u0ZAsOJJZSzJtsHjBpZjnHYYKKVKE/LG3lDcloDudph6S4mwKAZi4CJAwMCwg7CAlhqI5blf6XAkIJqJytsEBCVzKS/LsCMAbRY6TBbyRr/Yaj83STQtrMBQaMQuXBQmL5g4TkNa0lHJBvCudutVHsPQM7T2r1yu6rlnF0/+/TKM+FBAoVOqsjZXXPhXVennD7/Nm4gM34SvFBqnH25hhAAABbcDS1jAfKDwUOXQCoV2lZkt0aHUTGXi+7hZSphMy3AlD8HosAsfmYKiKSyUTDhs9JpLQMaMo62Ccx1ih71m3nOd/+mvnIuR96WferN/fccvUzrOvfvP3Q4vVj+3ep0TNXlZ3N0+yZMDnUo5DIMDejd5U/IUMkDwaamEgJjhuPFRMpA5DLkNRMVAlrkoRYOMQs1SBFCZy4saWZSNEApcgaJT5NM8uQYZygQEAcVUyCi9FysrkzN4HTYSoCwMMNdjEVeejgKIrsb95Ou1FpQ/ll7BQVB0NEBwIouHmQNLosh2QREHLaPT1bHCw/t+jT55hY1Jaav6/W3ri/tm3HHXC0cdY2GaDyI+BrcYYAcgCu4JBhUpfxK1l7oFOLOd45USCARtUJVR1Ig0WU+F2qeaLecrE9SQrjARzaJA0Rqk6rfRIThzJWSVJWXYs0ZhBq1oqOgD70B0y9rkd7Edj2qF1jDVTflIvVAAClwPmaDuZ1+xm6J2JJhAAjBAkMYIsCkAOKGLEI6jwcMbI9ma6AkKjXKLFTkAYmOMIEjJRw//ukZBsOxIoxzBtYM3JipBmzZYOWEvU7Lm3hDcl9lOdNhI4oGKmSRZcguBBXHwRfTfUpRWdJk7dlKW5NaWEjLAJyMTEEXbj95XsIElcIhE0540/DDCxSiYQgeicRHld/ZEvcf3NZCqXKO4MMLfy75+mnf+ja/VIXgCv+7Qn0EQAAGbB0hDOLDrfQuIiFA7iatdQpuMcVvR5cBoboPPGXzaapo7MCjJK/AvJ6MmIjJlUsPKEhhIjLJaQSCv2FhWQRQKNMOYY7DUwsMhhyX259LYvRuYCZQd3GjS2CZKlogTl4OGXA8oPMC2za1EiVBkONGA1BjGSwiGC05jBEgJCCBJUGAqEJQ8NGGCLZAyIiKudORgSmohClGnIDsKXrCxcWQ9CdoVOX9TQV0rtLVPRIRuL1QNCL8Lwhh2nHjzeP7IJ6ikckpsQeDwdOD1FmChIkJ3csa32KI/cczaRSU89dc/9RPVPe1XG0e/7TZhRQ7abNeEnlpGWPnHCwAFP+GcFskwDLZYJeqx0t32Zi9daddmISFlsDsutUw8IBICi5vEIQm5TGz0ThJCTCrOCJlBOdG6JmPsZ7vq0ud3OYtTRpmMLzO9KB1xAPDygAMMUPFsvKMosSLvoBJ9AAACSgJvTO//u0ZAOGZOZNSxt4M3JhI9m6Yek6E+0/LO2keomOECadlhogk0zhRNACDYU01gNXWIz4zklGlcw8BJRgiFzBABD0yBKr05jTlI4znDqlpxLItVA0OMbwLERVXYQBZMgLLypIoBi5aBbLVhWopbK5diIF5YMVUqM8f6Q5S+LQbKYGic/GnJe5AEAa6PTURbkpRIpi6yKucj/5+anZdTJ7N99w3/8d+2PM5v/bMz/Iln29x/2f1iPrp1dkAwAAAAbsF2DbRCkKAEtw4EEIRiFGgmXoZSWLih5PqWWTWQ10vkiKCgUCs65MAouJUDyM0K2RwYPh/kzUYr6xly8abo8OLONkwqIlma3+0UYSOqufEcLDGWySFMykg+c8TiKXA0h9NSXzHIYxUVM7nAxKMBBQENmGF4somEiZoA+DhYYFB4UAxUNHask+Bg9IVhhEKociIGQGt8wqDmFDxO4rPE1FBy/8vRMTKLtuQ4yTSY6GzDlmqdLuxZUy93SwVGx1pQTtHyiZJEjV6jaQiTWnz80IWRIIKLRRzMwnmyE/F4RogGqeV6VVC9weZ7EuWcR6IppaQIwbOKM1W4xNXIIzYKJOuZEqQoRcBkVVUTEDhoJYFdUWdht4y60Vf9ZcWAsWWkJkTQvPgKrA5OFxZOCusXGZUORGOGIGH1j6kaKHWONx7L5UANbRBdGjCa2sTmDPYy0tc0mW1sILslRAboIDsH4AC8P7H2MhYoOIzTVNQy0JNpTBAcHBQANJjLxsxg1MLACA//u0ZBEOxSAxyZN4TMJdQ3nTPYlkE6EfKE3gcZmDD6bNh7CweMNCjDg5BIZgSImGEFpEVGMgphqK3UEg4KwF2Fqi5g+82NB8gEEMKZBig2BFpEHQMclAk2jKzpmzNl0IbOCmoQAuLApgMxcprDdpNADrafxwyXTbBIANGRvFLmVTZIcnFZBc3v93uRnGcWM27VxndrQpT/cvN4w5jK+GmWnrX5ZjXQAC9+D8gklC4IGK4ji3F/L6cQkQSY1yiskFYSIS43D4vNxHw8PIl3LFF4rKI09LsWMGECErPvUTmDQcJBdzQGHHjohOiyaLG0JYcPskGzT0uCmBkGXSLhGla0WMSkaD1asx1mObvTRaoz4hNJHDPRcWYDKWY2oOMlCAaFDhQChEycvCxUj4ygoQVa4eKTqVvCIPCYgsBNJVEGsNYmcocRkiznUFCve09NoDLc+AWJo2SG0w99HvXzOQN2NvznblDyuw79Ndhukp5fEpbDu4fuY8v1AEWgRBIX0Fm+R4nPnVq3TTIvI9lyBlBa9M+g0bQkxo3W/porFQI2XAACuwWkOBNrFWLGXSZZsCZkliErJ4hJRSnqdyUaFcjkcVaLeUnQdspok90a4xOOFo8CSXz1dGhxpV1HXLsQZ2beBCxYIhp+WJJQS6wA8qfXmqGhl0BljaYCZ0n2EGLnICAABcsORZTbug+FTM2VCQNAoUCjFMkVIgMVoEjDiVA4raDGhY00MAayZ4JZFSQkerpUJZkxkFqqAAUZt2CIo7//ukZB+ORJ8xyxt5SvBgZjnHYYJeUvlHLG2YfEmRmKaNhg2xUGS+L4KaIQAklEZXKVzZXclLPE1Wyz7wq2zr5vVDIjYTWBNKJUVyGisEGJwZjWbIi1nfSmZD3WfMylD4UHCox5pWLpvADEkj0WCguPGhcmfsUp//1hgAAK34jQjKykOmwpNCCH8Q/eBDNmQeEEGI4jqoNQ3bLBykL1z4woXDwmpXk3rHdWsRrYCsvRPPWetjhQo6yqWdVLS/7sz0ft/HsMBI/Yu+2/P/s/uHmn2qw7fjl1f1TxW4G0rpwyGZRzljsMtGTLQp9xUGBoeHHaxw4nCBsRiC7kR08VMQALGIiRdRUc+jgGADNlUwMEIWIgoUp7JPpSIDXKdBf77obKLOhAzhM4fVncATLlRqfhmSsOjd5/MX/xeKRP8kcHE1RQXdGzbEQgR4MV5Lp2huwrIheNI1GN8HnC/hx8yyX2sWn5oxKqA1FSkL8cH5U4GVAAD24gNZcPDT4PZmuRS9KpShRWG3gjzN0xNJejAXiWlJoHzNNq0RyKPp+6Ux7RVfM41Sm7ZjfLsWs0Io9Q4FEt6Mcan9sL+ebfP28cEQzTHIu5GXy89bhmr7cbm+k1CC7c4ZuHUAGsOu8jfI00TW//u0ZAUORMZSypN4G/RqhSmjYYNsU6EnKG4keomHjuYdl7EoMAdDEXQxwEGQIwIrDgweBwEHGHiyC6xBIeLBUpkr4icWyIjMRa8pBNdixIIDESERulAyFCyG2SteLBVupbpHMNzf5wFbXVT1UnDtBOQTIW3e+BKKQxymp3Y+tT/cn/p92p61Wyu3lCgAoBjTd6UlgoTUWas2i3vz8y55l9K6ep7BQymeUMeCzgFNnheYuBwAFN8HCXiIGiu2Fo3JKr9ijRXLUzkiiRfIvgGQQAR1JBKHyAHTEkD7EOSgyKh4TRyKq0wfIBKP3B6JlTQvXWqdaLDpQmW9HGdYubMQMUC+P1ScNhVrcWImVecIbiyTe2dV+vX1/d7/7/8/TLQdeJSGxltsEJ1MAA8mHg0CSgLGLAWZHHZKFTAIXAhGMFAEwEAIXIwULTCoTTxUOLAHRziIhArqphNxBoYaspUwNVd3mNrsS8bgpaMgMt4rWtxt3KZEikxWgafL2ktDAYTGw2QFxQKCeUTSw4bJZEybePfaGRqKfYrNyMLzdlEooPbQphpPyzqs3UUizP368Zr6ZB2MbGOxPBoSwkIAAO2hpBEUB0wuYY4g9wJGCxqboIAR65JSslhK8h7OOy4sZyIw6iwtpXo5YRyKItKLL7JD1COzI7PTAqieGSR+bId7onnqTxUIsMTuGTqhaG0zC1EI0PEQHJzWpnlrTTq1qgAC7bj7HcawDPCwwAUMGBDI0Iwolb4QC5ESCoKW2GAueAoG//u0ZBGMJNpOSptpHqBdw4m3YYksExjXJk3lK9mGniaphIohYoNqEioTCUYFdlyVLQYDhQKAwSkjATlKqqAu83B0JQXyRqWItZh0sdNkLBIYbSPtBi0MvVy8BkEhIhXGeaTRQFJIkwyvI5dT1VsSs1B9v+3Gth4wUIpChszOFh9ncqWSVOU6fsz2iSnF4VtjdeLKKHAImr9o3tMHRCAAKf8PAmqBEqYj5VbQCA4ZB0DBYB5GJZgUBIIJUJ9lxwYk6NCIKTJlC8YMEaaJx6DREJw4FpJb6e7HtFaHuGOKIEq2MuXnwLDypCwExSlqFjHwRsiKo6FzUNDBqgAagw0gOv7QDaGkzhpZGYOUiRCARogBjJRsyQOFBMEqhBINVL1IWAYsw2w5wucBQCWAeBBpwYQOoAQAKgF5R6KWq7YYFwYDlSKj2L4b9hqlLRZxTZsa93/ijW2UuMDxChBEmmE0Qa5ASMIbK42PoYVdMFqbhBztQ3U5b8hU435XU9x1slNQk9XnRukTiNaAX9XIgtrEtpIOzADAC/8QoZMbAhf5QZShuc409IAuPB73Q7R8iFSbexqyYgHVERggVGUkZEiIT5p0kihpbV8UI2mdb9zWVESx0dHVcttXdTyovf0mTNORidt9oR4T8Uf854CsY6ujdpOT3PS1AACjgNLZTu/w50RM/7jm2owwsATGRQBhiUZ0QGMBCXa5AAoNSCysijAL8qmNcLtmCiGgIAVHkTxHNLYHmUnWUSSkZQWDMHQyL2qC//ukZCWORMlNyRt4QvBh5Tm6PSVuE90/Jm5hDcGYjyXNhgpYuwyV3WARl6qqwkIdm5hAYTHmg0FGsXEQIQkATIEUXgZaiZFFRpUSJ8OtD7tt66hBeLRGXqJWqcySz67d7umi+pXf1q+Y59fmEuvGRSVIhAAAACt/whgh4jgcIIhDkMEnURcoqBPyAQVEJxcZHTDchGGwaks2SEZdvSfU5kL0lIYhKkAaQsJxhWsz206lvMSktd7kDVqMe8oTWCZYRMMsbc7QkglKwGupcgliy9DXEo1ywHFzeFAcGEsySLDDgJMghNaxi0QGExmFReWAQAgMHFgLgEEh8BwEoDgGVD/wkJZQ5dAJ0EjFy1SRCVrHS6bwF2GtoiNlbAnGzxlTDM28clmiJqwzF3KZS7D+zczRUz9wDcjlnOzNAJqaOVjz48wfYtkKyWMp3WCImWNHFXCp1AziVx9XVjEtnmpY6Kq+55aIr/heumSdlpzhkn///9YABltCkWsAFB2aDoB2WcBwUklKhgCOqVz7r6dqFwwvuklzJVboMjBJJiQxMB2OCmxyiEclhMhGRTbYS62pRzq9gzpGjjiGBqRXCphjya0AZQuoBXkIAQAUnYMBoWujRoSSwT1bWZIACX7858PZ//u0ZAOMBElFzBtpHcBjRhmqYYhMU8DfIE5lK8F+jeaph5ipyYo/GMoRp4cOBI0bLtKogzcuKXOWSyxYzIaBu74Cwcs2hcVTh4WSRCA4fXNMs8lLlwdDIAkIKJqDpMyWeaMYTrNFEt66u9tNfT7SBsqKhKsozBSLqPG8QwnkZ+tuDNgwyhjUhOEXk5uGvKeiHxy+lZH7h3SyRUICUHEQAD5H7adhhQEAAABPf8S0oinGgNDIKCExGDpczbRHUKTI9NtuMQPKy0y4vPIuggOY2WPxKzgqc44zC9o6xT1ZNKp0setdvT1H+iS9rvD9UzDJizMRXvydJ1K16n2sdujkZvH2NvP+uET1qIAD2H3z+YvN5upymGh+NTYab4cljJQWFi8ShMwKLDEoROBJQIhWOYl9i5BiOkU6mIR06BOeRCw/Gy3qwMQRZQ0VsTwTUAoI0OjVTp2vImEojcgBdCgLvtMmVhIebQOyC4UPsiCZCcWH5LWlrVtuUg5PMWi29SlN9q//9GkrjWerhGkqTUhLAPSqMKJcLLWaOhdQJCUbAp1n//Z9XQt9IAlgAAu/8O2sxQguY8pERWGGOEV0nJcWMdoZI4jvWcpyYrCDgHAlMQIAQeSZIagRJAbqlBiWSp2dKoPTZmKpMt0ek7VaD9zfSqRO6/p0LFpyrmZf8hr8Nh7Lu/Td/00cAADsrOHNjYDs2zAC7oaYbGGBQ8FGEhpjwkDioKgYGIDAwoACQIEYbJAIILQYHppkgOkmhKbAw9hi//ukZByOZKpMyZtpHqBlI3l6YexWUvinIE3l58F/GWXNhgl5aTKHLQoaY5SxVZXtnZVHWttZib+vayNpFBSO/IZ2RyiSC5k686UbQIsdT3RQttXOOVXJ+xb4VC/v8KvGwzhFMRrdYPYqnCO3hNfL5f9oiMaOkrLnRhjhCJUFv/uBhAAAEzbBXSCIEXZODQIAS3qilVqaQgc8nos4tyhWDDOvCEUnKFyPD88SpxWvQGlhdMNWMrkLKZ+NWtz0b75D4Pb6v//v5Jub+rWBJHbNW/yHtiRL+Yn3rP3nJhOHgoV82Tn3Y4/p2EUDEE4yiN1pDVkA3wTAKAYelmIENJHwGdohzVuiDGlYTpFCiiqxupsmLXsLQQizYABUCIRSBVV6M6mJVAC4SakvAzB/qkW1dG+Z57qxzRMIpyTmEpFcvncpEIovqB4wZ1CftUGRhtD/iZvVsy7zGGBAaJ2QRLmbT7hEoyQeUhkOBEagJndwUDzXrZE4tCn/9v2dNSrXz7CSCIgEOIkIJ6iUqxmMww/8QcEIFR3KRcEQahsCqcciIrUFctCAQjusnrCmqBmsLHECKGiH8K+6oHWaiqymZ6sj/Z0VHd2++7kmF2IQOC7hrqLT/p/i+9+3iv9C6hHOAAM1//u0ZAGMJLVPyhuJHjBZA2mDYYY+FNULIm7kzcFvDCZdhhlhsO0CQ0IPTNaTBRFDlkYoAphYVGDQsYIEjXjDAiCodTuSkDBezEZA4sD0q0N1BhkDIJ0QUPoDQUia5Hdh0v6pZBrvwQhej3H5ZH10PRTAsCwYEQUFBGgVtJkPFUdOMpUuPrtO6Vwm7POkomsgt/CoPv4wrx9HBrZ4gdCIqURiVrw8y5vmha3KF3HsuWXkJFD5f/bXWAAbrgtkLyWAYqjapyn7JhzAyXQOB6KTxyMsLCCIKUvmhi+VDo8gEorOncrskiD5ARm4eMe00INBoIKEbCRTViIUYk9uB8sTvI2jmEt6EChBGsB4qI05qx1gAALjBwgFxlkX5rsVRgKAAXDcxbCExtAwSBkGDMSAiYMBcCQFDgvMDgYMGApOU82HE5AE2mGRXIqoHAOAgYL3hAaerrmW2FkBQZHMLBq7a1QvKgneeszBKBLdAGsCWrKApA1icsOG++pA0V9ePzNSuR0EFaCwegQQWZzEuTpbRgP2/j32MaWxm/+s3d5/x+rbrvut/8/NEwhtc5Aw0Ds4F93///+550Gl/4XiXIRHQZDFhxV5v8pewJXK5yMIgmowgEEXmLpEJz8F3y4nRoSkmWhIweZhlhY5ROw2nELkd/4p///9e2Ycz5P1mDH8YGrVhn/T77K2zr7cnySSA6Xu2Tr8AABkgNyE0BJs2SmDBu8NwnwFWYFLExWTkTDBwySLEi2RLx88lDtZCPTW1G2D//u0ZBaORR1EyRuZWvBbIwmTPYZmU5TfKG5lK8FcjSZphhloNhEEBhRmCOGcAIoUAVhA7KSqUAs2FEIkgOAw7tIykACWid76TCXyXzKX2g+eR9yqQe7wcWDcNQ/hoVDUobGxNLkjYvQJGyJY2ze8zpQ5Nsuu/qruXPqGduvdFOnvs9cxPMc3DefXtEKlWC4TKjhFKGlf///9kOAALf8MYBWCSEgEXLJbLgnS8HEIsjT4YWREOiCMxYUwkQYCoNLJbHVRInp5LFEyyGHcRnWZr9jnfx+B27/44wpHxT8N2+UpZ+tfczUE+S/tOlvsgf1Br5ce+iv2a2GxS8YtUZgxtHGFaBtWOEIw+RRocA4CmQQuIQMXjUyMBEZPT8DBQOEL5iphnAGA2ZgwiJcc1gRo5QNHooLCCF1CjUFsCBAzW1wPM2zW3qhD1yhnkLfSVw811XbWCPNEYtMkFJg6KT5jfFapVa8/pGICFlGYblX78+RyomVJ1FhHL59tUPCV49Z8mTLhZaQcWoWB1Ai54k0VX/994A4AAn+DQ4LIBFuVBlh4Cawn01eUrXhHdckCUlCalLx8pJ48Fp5/VR2whUoaGBBoovD6QRuU/hwCNLZSc39C0HvQAjgskg22LA+Te56HxKNJ6TimMdoYigAA3IDyIdMgJcxoMDoB3CwNAxjMSiUxwDzHRFMXjAKhIIUBl0KGFQY+oYoTgCMEz3m7go+BiAc2UgQSKYFz0b0aEhg4YADpkmUGmGjyX5CoqaSdsKS1//ukZCsOBTRISJuZQ3BaBdmaYSJsFXTnIG5lLcFik+Ydhgmwp0+GSPmt680tcs1LXFiLgQE6V2H5XhGbFMIITwaxBpRRR5IoSfkDExuSXdXpwiv818zfEd8StVF3PxUE8WvFbaxSm1BMFD6FLKgld///r9KAIAAABO/4Yu+C0Rr7hZNza5TM5ikXmG/pwCOH0xWkYAaBAbLDJ0PEkpa4mI09XJFpU12T3xz+jMShrrV+3+JMVpu1kYQ/pjDoAEQbaDFgBCfXEL0IiIc5MgElGwdbFhz1EmIgSaTKgcwRItmBwQFxKZVLBgw6GEhkNGcwyOAcTjEwIMhwRlJVlJZnyhDx93HMqjYIlxVMDLGMwFRDAOMowS8cxPtJ0MELkoHpjotJDq7SvjUQTUX61ZhC2EhG7SRW6PtvBMRxgmB3/k7qEjkCiiAcILOylGkVmyzCTG4rF253twun7c/Kr2ozZ+Y0hUWaakjSTwIjR5kULlHuFQudN////6lVCQAAL2wb53kdCUUTaq05959ei8n9cJYSOHgeHCYI7nBOYSFQ/SIyop93Gb1PY8bs9AlW1278MWMrts0mqu7n9MZRfbzZMQHr10teWegAuchQ95vPqtISaKYAAKyEyfEUzUGs51Qw//u0ZAaEBRszSRu5SvBToymTYSZoEZj9KO080sF5k+ZphI2p0aRkx2I0HICViKARYMQBJJQ0MRgtFhYCAQPecmIAuVsNstQgVXOO4SyLRgIExg1LR64DRpmjAQQaiqpbUQiKo6Vqon1VhQkKxRN+2SuK4sro4KfuWQ6FniSYZDIGRZCCLWSaIlnmmos13MkqGNSanGvW5mft3P66R8ESZ8GwTHC7iAMSoVKA+NcHFPtAKRQkBjTAE//9QADvuDYFZx0SOIYFY0QdhTl1nmybyPOyAA6PHA0JeBXXFIs0OoDRMxSQ/JJMjNJPu6zBzY409h0s8cBiJUYsCqPHlKQsFR72mSSpuL6PzKj3ka/tEAAW2tSELAcBfhAwOQiNwxMUNRFMMaEhiihEdIgjBgwUFg5ZlEcSSIKKNt1LXFzU/xukZLCryuHCDcZDOE9UYZpelYn2ND2NOv0PV5/1YkKjPRfGwa7pXNH7cuMG47s+6ig7jSTGJbu3SDNHfsXub3uryX3K2KiMkz8oXeBCaSziBGLFnblsFX/1qW+jAHAAAr9+AEggK3NVeu47EGHM2kzeZvOj694UIQqsRkE4okcdVhrCGVNrjQGXa3sbEilosy2+nllCrCCRLnwmdhSmZf1X2epbdfM/+/GpNPcJraVfP9fk3AOzfd76htUAKf/46AUy+4zjcwlwzbU1RwKjDKIjIABgGmeGEDAAFxp9l3AUEhKlGL8Kdsuk6/mSv8oZPNTVDAPAHNgDAcHKDQLk4EiY//ukZCMMZIM8yxtJNUJapBmKPYNOE8TfHm3gzcFSmOXpgw4glSNiqlWVDSBCztJodOkqg25VCygUYhab0TQs26HR6mtpynMroxX1C2Z/DFS8F1DuxXUWuDHnTPPx7QRD2g5suLBUA3//+//3/e+AEAAADP/gGiAlD8BnmiIWqwfY9YFMULwDwqikJ6QqvplhYmGtGVajNq/1BCLZt+od3ZVAaO+xNwpc/HCTggPHkoOtLPWsKzYRYokoaCgDMKaLSQYef50q3u+NAACjYNAQzaXs59FOe2DC84zErMDOjEyoyUFNUSDLQYeMiAmNAMDGSs1TDWmYCDYH8BqnNKmBZ0qCUSA+S4jQyz7lkB1tsqdNUjJSzLTX5WK0xauDZlqxuK8f9/pRQ3r8XuvvSZzlax4UQkiWReTo23uSmOKp9+fP8xzmeYh42a95hZkiPk4QbEJ8sIQ5ngeHhp4TDIoo4M//v/B/l8uBB/oGC0DBQwohK10RhbW2/8Rkynb9s7fqCqOmgC3oQMskAzCYxQaZTOgjg0vGEBdXRjQzVGLupVQitmcMr5YmS3NuuZsUYtxhhAT2nFFr7nrhgZUlABm+sEnkyA/MUqREkGchpngMEDiEswcGMnA1AgwLHBRSSWjS//ukZBIMBEg5ShtvM9BZRjl6YSJqEhzXJG3hicGFDuXo9hloksFJp1RC6jZKkI4QMjRxDcUUBWFjTK4MsWhEKB4f9I7AfRNy/xFY1wo0RsJooEoyck6gCQPegow9EgDZ9KPJ7zkdykWbc3Md0IP7y5eZP78s4xRp6Q2ExdRxrmkGFkQG4Vd/+ylDAAAAFfsJ5lBME3gZvNCV1Is5p2Rzkw9zPROEngoKQ+CKQHmli2NtLZkoI8jje2jbliXKhjmOVV0pojJ39mmSi7UXtsFMFmtJlouasa+yfOIeXQs3c9raZMAF3WQ4AvIA4zsdO8WzMoEx43AAaCiYRkwyEERTVoFGDRoHF5guJ3HMSKchmhYIj9F1ZwgabSKzI0DWxKSQkMHiSuJPOSF1nceuGRbcnki5d5a+pzE2r6Slh2JTzJ4uYTo0323Tl33H5yu7Btq/BR3tWRO12be4SCwLzQdHlSSqRBBSlahO7bILo+/nUjEN//UEgIgCc3+BdQ1AdSPBpAa5czaSybF8PMkAAgZOXIUMLbJ0p4f8SD+FEfKCxrWEA3WjQUcAhIJNsedgchvSwPgQDqnDZtzhKbCCAgwhSRInpe4WDIQIBQ4ou+PcQ3Noezi1KhAAEO6yH6FxjjyY//u0ZAWERHIySTt4MvBhhJlKYSaID+zzK008zwF6GOWc9ImwYhmlkZlIIVRAeFgKCDQiPAi1gQFglKwcDA4S+AKVQMuWiHLzAlQwv4whEMaUGHmXPbxW9ThlTiOzKKNsMIkMDtB9+cqaLyybl+mIuTuUjRc4P6QYFGnXC2tC4LNGObOZsPNv2YvuWE0goHgqZOEmmgkWFAyBygaCOn1dyF/7o9n/8vpAMAAAFzWCPAyxmYTMJQqibx1S7qgL0Rh7JK8kIZu3BsDJI0AQNCFzLwWJwVUHyghCgrFRxdhu4IwJfGNJ3TI9N2ntXks7Gvf08W9cncxk+8VeDYFYKXsFgXQRsm8eG1M1oAkASn/tPgxMSuEKAqLAgsAA5mAIFFGKNkgVAKmkYIADAC6WIqlshUhtmEdsANN1hgNJIK4NtvfnSXRkxAZU9EbncRdJAYUwMbKCgHp0bKB9WhBkEmhyksegwVDJJOebs1k0fj/K6T1e/+O0W2ZVWW7jYGDhgqIAi2jss//fa0eIAU99gUgOMDyB2JQUw3zFIcn0eW0lyjOsw22BYMCGaGBnsFSUwQHrBOdMU1DoYSRsH043PUqjgyh3lIqtR77UwdqNkqy2e6BzjgdoSEmDXFlN3pJHBfPPbHtCYutEpQAaQ5ixTLZZMnEYwCEjXpjM7B0yeDzBwRMMnsZHZiUYhw+DixAikeb551lGcaxkF0GK8YqRhFnuEZZLgoSCYJKUioQSK9h0SFA0xigJFIOplNyQDupJi9Cv//ukZCyMBSc3RhOZSvBWJDl3PYYsEODzJm2w1IGkmiT1tg153Lf17IEhhjTnbFBoLETTI+yhZeQokz2yqWZGHf9hCOfZXD1Cf9RlC/vq9y3ULEhdIOxUTbHA8RqZSG0br//LdvOmTjxS8cOBAMC4OIEACu/wUYBIcYNUkjG0QCoHAlGZ2PQHqmIkLD9wvNwKrTOMoiTrZi6BEEGHPCVXrm5mybH39/zcSJpJHx62LF71Q3NF3CoLxVtbjBoDleEGPzhp6inqABe+sPFCx0PEQKACoyRQMCHkfgYMGDExMFEAIW8MSAleg0DVnaA4jgrJn1eogtFUShxkDNVM5BJQEoP1AHREc4mjgJ4jpOhQPS3utdCj0oiiBzViJ+RJ2MRt/nHLkthW/Cnz+ZbEY3YlUtkMfE5j6+by1ioFjgI1ZYOD2GJYLUZdH/xs3//pDpAAAAAC2sA0DhwYTECcBicuHGr+LBoAUkXRVyP4NTALi8URCsIxVPGajtY7RqVi1CPbEpx9EfCC4cNMyWsnYF1xQkUbyz8z7w+0/JAy0LsXuqNSnnyM4f5YqRKsZy3oT6tbke+93/+tqgADG2jepJMqKAyqHTKFaNMPMxwXSEEBwvHhyYTFSI4YVzCxRMFEcVIQ//ukZBSERRMvxxuYY8BUBSlTYSN6D6zXKO09K4G9oqTdhg24schwAgoEgyYimIXCmy7BrUEmUNFaw+ZkkkhjYOQ6KawqAvuxuG5SkcwOZn4cQSMPyhI6MSoRCMksWjlSrOYqOtJLv64xK7O1fNtPIFtO/2rblHYnV1BmLEyhEaZMBNBIBmXOScNBdN4ZKDDtN/+lXY/G2HxmYcK1pQADPsAx5EZOoQ3YA0B/ou5T6NgfWechhLe00tPuPJCcAo1MaFR+BNE6x2oxcvRJapVbreUWpmJshyN8pzc4ie2SKNLB0IKGNvY+MfkguulB9QDUsoEAFP9YecgayGCvxuoJSOQcGQRdpPZVQhDsoSwNMEoqw6C2hokuBHMBzHQP0g59k4eH0TaDKc1T+jOMdZNliTS7KoA+mjY8cWWT6B9tVIyStm2LEzDfy/C5KihZXGG39I6zL7D5v8YelJLw8DgMt4fYVYGB4IMcnSzXuH//oGACd2oZ0IAAxxddJQApLPFQoqYtkms3qumgywWjd4+OgtfPGhuWQ8gRkeMsecmaVyPHi8eFdqxXeea+OPVj66CGlXKt6Hc1BhL5+uzjo3qmQs/SSd/hfen0o1m+5I6e3lARzMZKO4VrrSW////u99UA//vkZACABNouxp1zAABhBTlarCQAJoIXDjnqgAMcwuMbNzAAARsgzOfjBiKOzEoo6RkmemHB2RIYwSARQAg4TGGAUnGMg4eCJdQYAoGLJfVA8mhJEZAwJuqtYv4ZDvmWuSuLlgIAKctJocKQSsBja42ysggaMwA7TzWH+mZq3Ny+XYx3Khwu0E1yjyv2N9525hhv9dyy5hy7c7zlNlWti448LwdD51xqoYFVYjAA8Y02n/6P/6kXntp3QxxQk4AjAAS5/sH8R4FBtZBhGtP4z6HYGuRMQhcZlc08+SgrBsRpGkFuLUqU27JZmpGTxQhhkWUDLOVOjk26Yhko3+6pzhv/zffqUUqRDBMATpZ4ZcwJlQk+WYwsqnEr8se26onGAAMcUBswgBRDMwJxMMsPcwMCVDQoJcMYAG8wqAzDCoDbBQdRh7AaGHaB+YbgApQBmYYw8ZgsDHGBmLUYygMQGBxEBi4Jgb2RIGHcwB14gA65i2AkIgMfBoDjsNA1auANpJ0DFg/A0cPQMMK4Fg8BiwNAWNQGkB4BnhRgFIgDDI6AoBwFgQFkYGGw+DYQMaBQSgaJJAGM0wBJBAYwEYGIBWBhgOgEAIDBIJAMAw5AlMnyQIAJCUwMDBQAoDh04ZFEJiRAwGAw1ImiICxDtNDArmBQOMaE+W0zxZMBrkmVy5RN6CaTMamqTr2M1Tre7UFGCBte12f2qT/rdFI1dS007Mv9dFnOXvUhZklJOsi5USKxuWzYuk6RL///smmZF0pGaZJl8mRbf//+aqk0lSJkyNiAloQCCCAABAAwyyMPJDDZgMdQacmZApvZIBBEWICgnMBF0EhgoWCgULChhwuBhEx0ZIqBlGCcwAKgC1C18AkIQlEPBs0EAApYQgDFYfqM6J6BEUR2GAgIDDGYbMFwYguCgwMYRXBBYDQQBaoN7A2+J+DB5BAtCE+kVLpbJ4wIucEekSKRmePFwnDEh5fPbqdrKWZXahZbpam6/V//V63/9P7fe7ProLS//V/7Oqqmtjy1KNTD///nEdFJJA0OIv///1rTU9VI2MFqAD3TIg3AgiMWWECAY2U0TRhaCoBCoRMbGYAhkwWLyUZmAg8BAGIAyhQIRgVQYIKQUoRnqTASpqkjJoQ2yQzzyoDByXYOCMRSyJIAYodQaanQnkpelYtZgrYoovJ9GkYy2u7EseazFJfMx6xjO0+61+tQZXKbHmOF/G5PTvztrG6TCrEPiilv23dn/r///1j/Qwj2MMuWFAZAAEIAAAU/+ydEnMC0//uUZFKMBMIrRxdzIABXpTlt56QAEWyzJHWsAAFkkaTOsMAA1200j7MgkhBzoN2PBOWY0IxoHhXyjBCIEkcnQLI+VfFQ5ePVczd+6zqSVqLO7OvH79z/PHerKMlzg2BQsE9Pv6yZZU09vo//+z8+ADdrYdQAGjTO7zoKwuYMEfKo4rEmjKGQOmgNhYoIxyBNWIwYJYdWcmeDhKNoAQMVdLRH9C5kwW8SSpoaceo5jc2DM7XLEWGto16HqkSl0NWsK3KXXOVrcppddmsbXXalVuYxsVqtLWywlU9jS8y5h23gHISPCYiSORzQ6Grxehc+LP+3Voa5n8roWgAObUBqspaKDBqWO1kwyMxNurW4eqYxmahYgwH4qVjzKwGogllgsonknmTrBKty1a6vRMupr1p97L4Hq069K9NJas8Mx4SJqWsAuelmFlM9ZD7cL//////9dQACQBATVhRDSIJjlSRD4bUjGUZzwSvyY8zRcdTwrJj7FxDOJdjI8fTCceCw//vUZBYACfyFxRZ2wADAULjozVAAEFSzJn2sAAFrD6UrsPAAGZ0opBjYMhjaOhgcd4GAQBgBQAQNi6OwMBZngMDYswMRRrxCYDCcBwDBODUDGkFgDHGBADGYLQDJUEsDDUEcDDMIcDAkDYFATgWA2BiNFmBgLBGBhHCSCgKQMGYMgMBwIwMCwDgDgQgwB4eiG2gYDwOAYuwdgBAAACAmBg2AQBgABOBgZB2BguAqBgYAqAgAgX3IOIDjWIgmAuDEBQMYBQEw/YDAEAIKAKAwIgECYDQwiBgIAKIaGXXL5omeQUGBA0AOMYZAVuTwYJLxPF80JkitStmc9Om7LVNVJVrtW3/1UffQqZH+vUtNv6lLs2lq16lpuzualIyYzSN///+pSZ5RkyCJTNjD///ooLWtbpF42NUUIAAAAAIADMEQwqtMx/ERpzsnAc8MWNB5I3DASpERAQDRKMYQ6acwYkMBkwXBg4OBpUwHYVAaZaBZKFj4W3CysAYGAgQPIlMSkFjwbwGXxnAwMG3BqgNUBb6LSFk4YzLBWJsG5ABggMsEyFgwyYOgFahYiJMck+o3PA2Ph6AnIPgHAOYLlFklg2Ism71MhJwvmqTIGiaaSSS2+3/q////////U/+rr//6lrWqo1q///9noOtBJSKX///QskqueZjYAB/bQ5Rc41QdPneshAk1Y4w4gSZm6AAY4vZYwMDgkCvREdJRhajSij9MpZMYgExloFAVNkvHiaUmeyVmSuLrIIyo7DNaajk5LplyJdPyah7Sx3Ozdp9ava1qcsWd9mK3cv73t+mmOZVLEzvLCoBB7EGOcFb3V6DPwGVsXKHPu/X6AuAFAAAT3AkJJSr6TXW4yZrVAn+nqxSXKxPK68tnH6ekha2N44Icrs6c1awtj/0j43CzXFVffCLl1e02ct0ePSLSsoOQfAMQaQ840cHBN45CoIPTS47/////1c0qAHoCvscesfMkbXYAGAO3BCozJEIcF7QchOkDIBRpTwOhhSsxFU1AYqPM//u0ZBUORPxwxZNZE3BiQ6jnYexKE6nFEE2wWIGekSO1lhoIJJDphdM7HSBMCCG2on0lIXZFiC9CgwVAQTA0pxW4FQBBMutP9CwQhIPNZTaQieOKRatK7fY4/1WljN6mjWgjgQQWHupQQpAokMGGSZaOZS3vp6F35V6JvufburM7f/b/////9KJrVpH1Q8qPMqPcpwyx0LCqkEAABkQFIVCoBzy0uqI3dUBbRvBRClFSVA4XzGyFuNgny6ORRRFIH8kD+LuEsQEhMKMcEJyVTJ9UJSUqD9GsTTVezndCElCgiWKRTGGiKZtZh79LT1Bvv+/////1/f5xKGgCRDjwc6lvB3scuEgqBMsQggAMiDxJEMnGDHTpIBQERDgQBCMAMHFlNmDiMOMRDkOpfpdjDxoBEgtdL8lQFFQxCJAS5ij79qXPWkTJoCWFicEoRSHoZRIEJEIR+yXfjtV1fDVx2COFEsbsz+ZykRlZENs01kd0S2j2nT+tvJWz/8/r/enp//69uy6UWrFY7qlccOFcymIOaKIKOViAZwKKACo4wVKy3DrlaxovIAGYNEOltaECNqyBjrcGcQBUa0ps/zA5Kg8THZRQj41rTHgnDQ0lyTCTwVVUZCKC3R8vPzdxViFN1Ce/QgeGQCNJIHBeqe6yO3///9gu/iUmZQous2KFCRddEAAFI2yG6zbcwQeELQ5JsiZNiMFQE449DylyF3vuLhStfRyVYFOgExDqnYnDTBRc7JysiAsHYRlyM7r1yFZW//ukZB+EJAolxjtYYWBfI0jXZYZ0E6nDDk4wuImBDaMdh7DYJZ+X0smHrv7YJkpJVy1535oudtB3f50pywWcM9yVNSAWigCKiYceYYRHJUKUof8bT/9yRIMboApoGo8gp6zCSYNnwwAAuNINaaalwCwwkOC0k1bBU512Ev2j3ag2kTkWkHI+iCqHQxeUnhkJKqDyV/Uh/dhhE1I18RXKYcgqODzyJlR7rC9ZdoorCqSVwyt/b/r////TFbIpCQsMDIXtJm3gEIALZxmEzGfwyFU0alDIckTBAHMdAImZhhEArsCwUCB+YGE5cECgYtsgoKAoQgARBhHxPhW2nWMl2hSkIzIv2/svTna4tlqlAxVlDXpQ91QJR+AHLaU5KsaYzXLj73Nagt6/djTiXD/bz0bP970/X9f9Mr26yVUt6v9T/9v3rT//28dM7EM2rzDXD6yTuMEA9QQWPcQKJi5oCCAtMAiJEKbJglyTMc8BDCqCgAbCUp+jdiB8I5ILkqojIPn1IfOmJKqU6JBKMmi0/HW+5i56CGd/+yA+Mh2thtgtQdCgoGmNEkXT5raS2LUlFFiEI////uqPCqFOseZLF3Cz3AJEAACiRIOJKDAwszUrAg2a0XAJ9aIYaErAAwGL//ukZA6BBDZsRVNmFiJXxGkKMeYKD7G9FE2kVMmeDuMZrDCgeDAFADzJ8OEx55GsIhJGuo7bDmRP6mK5bEHCh99Yo9TF7r17pNx2tjFAQDUHRK4QYUQIAYFU0cXAFmqgSix6Oa1labl1b/qepVdV3pn6af19Mi2f//f///v2N9GNXnY2Z2RmdloJRilsEEIAAhTWutKHoi4DmEKBsCwIQI2QQthJGUt6ZGKS0AFJkmyYBJNpifXeaeF62QWEEAxWfvamIvu5F+b1y5JII76L8bEak1Oijdn+N29fqZ/1W9XHLYc6VKAsQgQgUhGgnB4QIOzPgExIrHk1HwCgwsMoKgINQyAQMpe5JWAwC0lYdrsNxtejLnalizXtRJnBwjUFQVA/QqFjipUsWXmmrKaYzpUlY29hISzqyPUszptt1/f62blszW/+7f/RKf//////2nTPqhSme9UOZ0K1mJYKDhCxpwIA/1DsPYKGQZAO2SJQpmaDmoSUqkslG0UUKUtmXrxgQKQHLSE8aGTVYkpjSBHFLSGyIJKEolPHJyyQBgstS99MVuxSeEtHvcW6jzPUPt1qiU+yKGG89///+T1qYwYSKgNpEGgeQPF6EABKAGIJYs+nKphiQiYWJg0JUPMD//u0ZAqEJCtxQ7NsFTBu7giZPYJuT7HDEUywVMGgOKIhgxZYC2JXjBAZiaqwEAU8gcDNnLzNJYA6zc3lj8O2FYWDN7TFgLHnSUnXLU7JvS0LDqRq0Na7Gufq7SWLfVll+/pRPSj2t0/7a63tkqumu9F0d///3//7SU2TSM6o5XmYhkBsiEDgyBzHKQjBwIGGHFlcYEAwAAWKgnAcQOUGMEGPIsg8hwkoK8710HOaAFX4HnTdUIziJYJTCtIqMoqpvQVMDKlM8YlY9ZMm2aPXMWvo9e2T2//6//0XonNzU+yPUzM9bv+v/p/////Tu+ikQqt1OaiHNMpaMxCHgyAmHQMg5AAoBxIBADciSJlmnjSF1B51gjfIBHqWBWw4SaVM6Lcn2Yay1wGhMsdFlDuvg/jJ3wiMiwE1nILt5GsjhbXuJGb2ggQzxcWmLUhvRx/bdX++xDs+qfd//+u/btXq1KvQ9KdP9f/+38zUS9yvPFmVWYlINVncQZRASGBkOKFiGAQkRDpJKKuERI7JnqR4arST1Cr51WbPW0lpr3wNKZ2RvB44mnSOl7Zhdz69FUdJpEzUNLINFfe7/////9vLQxV2un9f7Pot//////+laH6q9NUVyTM7IKGYrChqqcSE2Ehcw0cHzBY+AgBAAHCQEoUwbIePgECEQCYm3YdFL9BIKOCIA3NWIAhlF0eEkHeeFLrGdiixXTfSkvyqKRCnoIvP6nJnGU0s1Ty+W3M6v7xu293M72s8s63//8j/Q6/j//ukZCuJBD5wwrNBN1JcTiiZPMKIEGHFCi0VOcGiuGHM9Il54OrgysPzRJjd6EKj3rr//9ZyIc1IzMAgGOsNlBs3AQ+k0A8BuBEUBcBfPSsAgUDnbJniEbBAc1IAegAxDVAzG5KzExDPM1AX8NjfLLYIdGySBpcL/+4cnlPmWgVeYhTaM+j9P////+nrpu6M3t/9v/+//////01q92Yl1Q6CNNhCIRmBMGKdBFIkIUIIOPwQKPJGQERmHEIIUUg4bAqwSAFVFA1ZzDZqdYy8zT5yHJDGssZmUPrJ6WxDNrVNLJ+WZ0lrC0KBgMCMzFKYeUhUOyo7b7/9/+qTORk10dT78rnKr7Gul5dby6Zfv//+miPSzM9VYX6HK8KmWdZ7+cW3JKzVWmZFUkjcDyaRIJCCyFpCEEgBWmkPWQshhkszkhz9TGkDbLDZFIziibEdukl4KlidtckY2t//m2IShMuflu////+X3vRTbv2q6M25CIh9t6O2f66f/////vZXdyKt3lRARg4+xyHODKguDijEA1AxLnFIgMQADzUArQgAHgpFGQSgqRCFvm6Oc4bvt2d59qSWcnaCCpHDNLH6XOvYqQ9PXKaPUcVtUuMqlVexWof3nTUu+9/+fy/5/+i5//ukZCGJ08pxQrMhTuBhDihSMCbODY3FCEeFOYG8OODIsSb4jO675Pm82MImA5MxmVglsvQHvn//+y2YpAJNcQUiCGHHXAxFObUMWmkae0sghhmaJ3XC2kLSCZABQFwJDiIo6oA5K04gvnSHAU8brvffLfvW+mQW2XV7X2xhejNEMT/+X89f7+R+ZZr8lIBBQmleY5bmcc/f/79f98enpEZoYwiJbeEytI2iUmiQNlvgYgtSECITJtLILdXQuhDgbTKpnNSLJO8IYc/Q1GRmrEqkhvu8vTfzdkleVgT5k1bP1tHvD90X/+5ZfeXvq1w2fmQ8dpBrI3DyPwMJ56svz///2d/LlU6r1CaDylEtaJVi05wWjFZfWC+8sbPsnHRRC4FLLPawmQiw1A+kHHp0gkbmzF3KtXtV0P33F/V7/Tmd0qut//r//XRm9WrdFY1bzGuRVO+ju1XNoqxmZSFRxGxlVknpejun6//5/1LqEfXfckPWjcmWTs1YBYsTmkbkkaMmgdVFBUUaRiJERLEwfCh+j44ES1IAAEk5mSAAHHZ0lXGVFdOgfPa2hdadXLuvXrrYYHq9NafatL1mtUQ7Is1GpV+S/6o87ul2zVJWamynee7pdVKYEdXs7v3JYiMl//uEZCSI86ZxwtGCTnB0TkgRFGz2DZXHBUKNnsAAACRAAAgEFst6Kmlbdv/l/2mc52VnKdyldSE6YdcHLwbQQR2XxEicPXRMTXETrn1R1LWAKMAcOiiooiIh0VUxUNUrUSlS/myp6df//6/TJ+xZ5FnkVbinMtqECvDKHimwWqDcty3K+BF2JUSGCIz+Rcobsn9npm2/a/z/6wh+7rNIbomqHlkb53DcuO2MIWDizhfKpLutKRsRRwSXHQ9LxgJg9GqZ3hnLrIAAiIqAw8qKWWxdcrbaIv6WX63//tv31/+XYfnGI+HDyLpSl2whRy9NdSY6iVqf2RmMt0UqxORH6qv//PncmZm00fyu17023riZzWlblminSGUhkhqlB0dpoSdZYjVnELr7jrwlMrAqJPVMQU1FMy45OS4zVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sURA+P8AAARAAAEAgAAAhwAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",
	"burst-sm-1.mp3": "data:audio/mp3;base64,//uUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAwAABxQAAICBERGRkiIioqMzM4OD09QkJHR0tLUFBVVVVaWl5eY2NoaG1tdHR5eYCAhYWNjZKSmJiYnZ2ioqenq6uwsLW1ubm+vsPDyMjMzNDQ0NXV29vg4OTk6Ojt7fLy9vb6+v////8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAZgjQAAwAAAcUDKr67/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vkRAAAA+VuPQUZAAJ6rfeQoyAAJ4YXDzndAAUDQuEXO6AAAYWnv7QQAYWTJk07veCBQUFBQUFBcXf63FwaB4ZTli59u9y7u98IhiJX/y73//oiHu7///wiJVu73//+iIguLu5Yue99/wiI9///+iIlf////6I7u7u7uiIiIlOKCiVJYuLh+DQGgNA8FBRJDsBQFgeUWLnsKALgvD88PHgAAAAhjnkyZBCIiIiHcXFwbg3BuLi5iJX6I4uLi4uLi7uiIiIiI7v/+73////8oiIiGJom7u73//y4oYlffDvf/6V/////vf///////y6In//y5YuLi4uKCgoKIiECguLh2DcXFxd3FBRJDsBcAGADADgAAAgCgNA8MQgQQRxRgQAAABIOIGfofmBQLHMpsmAYM0dC18wGAAyPFcDI9L7C7QgFzKQXAKAcnvoJ2JnMLAErSSL2/FkxaRAcLezBDsbtLLWrssMsAIjAcHrdvUkqDgDJFM2d6MCTBIcwAgBDBUrzP967GJZfdyWSc0oEBDBKWFggYQLt973v9zicPuPcsTttiRhhQNGF2GDmVIiIF+et55d+kvbzp7c/bBIPJyWhgpGwBYQAAM9f/5c7/atPR1K9HuX0mKSrEggMzUu4wwveWob4ACt6///v//4VZezhxNrofycfiC3Xe+WwOZwMHCwsCCHgOBrAJchcWYcmIQRVCCESCBXKG3ZqzNmWVq1SWf/////////////2qWu/mU0/9qxYms//////////////xYGmQEBAMvDAE6OiQhWmubYc3GLhYCYAAA4C50zfGswPAA7pHUxLKWrgiJFjNMezcMpXDZupq/JkIPhgsEsC4g4RQnARGfu1KuaYaeF87Js0po3kC1bpMnbUvNskN8GMmpqY0+d9l6D7KmIUg1DBgYQBDAg1AMsNf343D8/MuunWKoQyuGfg6oFQjefT8yu45wE/CakYhzkgMmLMyjRBRAKoESEGFG5YWN8vZT+mDvowQHA2/fQIBoXgJoDlaOYsRNWNDEzKs893bfNfrN+68r7fzpZPhSBUArAl2tpriFflkKS5h3/5vHetV8bFO7kUtrok3XfXO09k8YpkNFrzg0IEj5Z0iLhx0wpcKiB0sGADJCtyiWSu1TSZ5XctuZJf/////////////5TjO3vwgzKLzMfgv/////////////8w4syZs0IcWEIyIiGQELMgQ2ImDIiqQAMAYCtBhAhg6HI4NJjdbNXhTp38zZdNpQjXzIy8SHio3lbNnOgu//vkZBOACHpaV35vYAC7bFrpzDwAIf15SznMgANcL2w3M4AACjQQoIdzRnAmJa0GhQCIDAgY2pNPR8zIg0ZCjBgBDQz8FMFFzQV8y1IChya4GzKAdp5rZKa0ZAAJBoKFAoyIldeJOwEC5gwEW0bwyQCLVBACgqFAdH1S95W4S3NgcqMEBC1jeIJ2lN+2NkroxqCJXPw5DdstOn2XIRQdQuWAQOJQVKYZr01WBHbt9h+xUVjTEWJAjO2HtPUEfbj+ztNVoKmWVF2/rLJiEUa+/8Xa4/kUd+NtjorEXnJm1urXppZI79bLDDLcXcSHJZG43L38lli33d7Gt27IatzPKrjKd8q4i5or//+p5KAAAQAAAAADCBs7YwcAExL1GurrwsRMBIgFcmLGOLtaYmm38NnGKYSMcNnREO9Tkthoelu55PslRhxDnNNneJxkyIQnmI5VCl1iIqoD+OrGSIo6oeonsKzAyOeYTNHu8eRGeGzuOWZ9dt9nNjv8x4lKR77iOEJykZZWHVN0gb1+8iR8acPi0ByhQZmHDdGli5z8/7/+rw7wHlH7+OyMkR7aE+y9gwrQs1g/P/+f6/+97vHkSPcPf/LFlhJQAAku3CIAAqvRvGanEJyOJ8wCjTAYxMlEI0QYiITmGDqYVD5jYdmfymYcDRjkUCIGjIFAR7UrASQ4CqujMYRRxRD5BmAGEIFGBGCZoQRoREGkEYboIUAJCvh5IWKXoYpphhmmQxhTNO9QFxWNaWg/otegogMUwac76YtKsdfbOHTsOFYcGPICC4hQGpepWxQQisNVuSul0AuszWJvzAikpXDkuksHQdYdt8bjrQw+89hqvdYdRNdjUE09pz5dBrjTsCuxEmdQp74Fj8ESOX5y+mpq2dLHq0umr7+OplIsn/Z3uxfi8zQ0Mhfacm6tJd3dr2cKmNikl1371nc5KJR3ty1T/2/PoUGl//0vFP/5SRAIB2kskiSjlrbck13/cgwyGjA4pa4wQYYENxhvlGHmDEziVJhUdTMGBRgKMrK6EgRMO1ElEBrD2Ruw6SrV3wahT1em3jaA+bXX/UBdRFwLijDhNaaO2WOKFujEGWJXvBQwzAUGX4ZislsfBkv7epr1a28uHYNvWNS6vXoPs55xefo/ziVPR0knl3dzuGd+pMYbl9SjnqfOzjSSSpK60dnqbt2pQczsRjCpjqgnKbOtUn5VvGxR3qu4rV5TWZbyeiMrguzKJFKuX7VrupyJ2tUFzKUapNS7KgAOQAUQCSik5JJLgpacsj9j//vkRAiAB0heVdZnAADoi8pizeQAHUV7TzmsAAOrriorNYABO7BjM3NiAI/SdMEoBdM9AaoJ0L+CFVHIvMZjpeAQjSEJYQNL0KsFjM7WJByha/3dS+XyxGVq+XQmey9hzFmnQleLKm2WlDcud5x6rbwDEmnPE+tFTuz8QgC6/cIiUMvg158o7Dr4uFTR6rMxeNO3BUSp4dpY3KLde3bgCHYA1SUEolz+Ruae2jlFWcgWkgitDUkemjlUZvQqmg1sPv/GZuCocopykqWcKsal3L9ubwobssjMBQFY3evzfM8bOcImZyvlL87Va9upagGXTdHHpXMyebqalIRsAQEBW/EJ+bG+Ihm6pb+m9QZlokCio04iM1FAU1lswETGFhhixMJFOyEcARoZKZ0DPnHSSOA8GlRoRFg5BB4WGqPA7THItbLfBcV3VK2zI+NVVyPGyhNBxS2RUBo2WRNzWZtcYk87KVVGDOa2KXrwX5PM0Y1QyhxnCrvq4MDRiKRqFxtScPu1GYbvxaJwxMUuqrjSOSTFWR0svf+alMYmrNmipN2qWZltLHaGxEpums2pPHblJTRaP91R0dy5eg2hy7N0M7KcnLh/GMWqSkeyPXakawimWEthiddOdz73uvsRjnc7WNLbt9haCEAABWr///MLPIthiJx4BJvxB2YpoUA46NHuEYIhuGnLl1h50hmQCDGiQYDJmR4CjLzPQFlq7L6AFDnOKzYtyz5k4OMXAL4S1dzhIrJCF3E+5KoanxabsuGH2GPcpKtA7ltYYowSCYZfyR0rMK7tPtnAruwa4j7zzVoTC2dNnoZdH4o30Sn4nI6Nx5RKZXNx5lzkwiTXoEhyKvq1lkcWvv3ZirP6RypRWuU9PTwxQxCUfLtUWsaOYllNIKWm/tyralFu3GNyymzj1urV3ner85hqfobG95Y873mesN5YWrf3Pyzt4d//+LqjKrrColFtySSSSGZlmmpGKUCuA08ECITighRkAWQ4EMOMUvJAgsmQCghIuYsB1/ETk00+gkYoFuLBgSaqrlgkClmnwZUvpg0MSJezCVY25M0RFHSKbMwV6zBNlmTlNOf1rzssgZCphJWauBJ4VKpVD/ZQwJYdhcWbnDjZKj9syf+Rww1mWVKO1FoPZS27hXIJhl/nGg58GI2Yq9kubgySHZNDkfon0paSezf6m3dbvEpDJMoehViguRO/L6tW7WlWcuqu9LZbY1MYUlilr/Dk1PUv1956+nsz1JW/WFJZxx+nqS+9LqW1kjAqgAAKIAAA//vkRAMAByRb1W5vAALly6qHzOQAGnlxRn2sAANvJ6fDt4ABAYGBhbA5PlMLnjRARGQCgJkI1ASOJkg8ZIKEAqn8oyZIHIDA4YT3gZJI9rM82nrWblDIQsHIMxEvl8KXzKY9wyGMIww6Csoa05DjUouNHwLEVyX8LZIqpUqYwZKcXodyuLUaamW01vZe0p5o3Lassu1JXXqzq/4+4juRCblF+muxa7H4y9cAXY7LXgl8QhDTHcafN2pY+tNGpVjjhjjh/6w3nLI4yhyYYdemd94I5uZuVpVulluWWdjW8P3j+pdI2JxN+GAQh2/itnCjpqspwrZ8tZZY6t9+7ndrWmAqWAAAAIFIklpaRGQYpRcSpG5jCKN8k9pDweM6dORrRyEMUDkCEWD1RnW+BTU/jHAYElaXTATgCULRSgxCbzvobl3C46A8DCsSAoTztChytLH5ZWsIEDNMSFZa4jZ84w/UwhglCzuAX7lDBo3K7WqSQSmtKZVFHHi1Azicft+68NRF14zGWkyme5M2IaylzkOJCH/jcbsWY4/Utgq1DVLWlV27R1LtnLTsOxCIbf974EpH1azKspfas2LGONJ3PWFXHP4Eh7sAWe9isXp96wpaa3TXZTj3sYrYT96gqZVLX/VwMf//JWLAAABdNIJMnCOFrGpZxwR7+BsRpj+R0hghWg4McEUAR5gSJQFGQoyJGRb9EzS18NpWW2hJ1KWqFoImmREvrBot0eXES1RIEoWy9fAgEu9LxP5AS2ZsrWmIpptCaK2i7Kr+OjbdBnEBQZMRVxMa9+/EIaiU3EL7+WYrAMRkturSd+bws3J+pNfLqWN18asvfzGdxmZqhma+NrKWSm3Kq/J/O3+/r156UcwxwtWN441fp62V788Zf3HG/rleVf/9x7vOx2nzpN1bOeN/G5et81cwNjSH6DTikyhqNGkTMxcRrR1qAMsRjkwcsiGfhAjOjOQkLAwjGShkMBDB0pCgKeFvaKHB80EYhQ18diWVAaAuwxzC50+kyicpNdAMmyUHaogkQGg1oiCQgVKJGTEXyW3B20NmSSuMlrUx2xPW+isK6nqcZ9Jx4qeklT212hZ8Zk/EYj8tkEOL9n7uprOQ8f6XRODJfMO28sdhqaisdoIQ1jKMRqZh2V52oJhx7Ksjux7D3fi8N25uVU3Pv4YWu2N1sb+fJzXbO7tmU9xu8wu2R6iCstU6xdPIsIZP3zm/7+oATdEsEiRjxmdR0iJ8N8kjP8YxZuAWIa2BGqnSxwYYGMHBhQoBBxBI//vkZBQO9xFdz4t5Y/Toi9nhcyxunc15PA5lj8L4rGhBrDG63I2ERwkiCDGDHlJpzJBZmiObbYK3A/ZpvmbaPVgl4s0ZAglmYY5fcqmgQgCOMqEoEmXDe8MQaQicgAhkOJFRH1bFMOevRi6hiQzwtfeevJ5lzWIuIlhTtCeOC4alohLiQbhWS1p0SDJWPh4E5FMjotWRGxMHYRyyORy4NyIXD/DZepE9HBCsjXY7U9MUi6lYK7BzVKJEkCbptbrUYWWabu22v3X56frOtVj/73t3TN+/5eqJCp66sH8MACzMzAYTNJ3MGCwMMAGZRgVLHAwoZDARjQLmCBOY3A5h8JmLwEJDY54Qr8Zg6H5aMETi0YAWAjQOhEBCSBvIGsUFWDFGL5CF8eLMtMBxmwsYRS5BGODTxkI7YzGVQsZ2arMPqHnWAIShQZCYZwhjopY2pYFgE5EAl5qLABocA5KCVQKCWQ3jc4UDuPY9CCT3iwcLGZLT5dNlpwJavGDo7OVbN+EQeFJqw5dySccy6gQXdRMLL+xs+dQFRg+tWtuimz99bb2sdIY15222vXrzhxYiPNUtZdG3GnjxV9X5uh1u82k6t9QIYPmcCaYyDJ1FjGVxmZxB5s0WnGy4ZcPpjlmGihiY6UolAQUaTGA6QHEQSMXgIYFgCKB7RhLLHMfoCyG8MOCnMKZARwsCGAMJPBEAMmomX5MZcvClUEehRUgNDkQIGjBmhcWdfcrOMBlQJRgigDFDFKLhLFh+NShlJACiHNQw6KHZfEEM3bRUrEmlPBF13PQLgPJFRXA6JY+gwBMDQ98lI4HTctGBBGJ4BgT6HA5BARU4hnr7MC80NEi9Sh07qp46QplK9LWCFqBNQ7Soel1o+aMnrzlZz4GmreuWrVq2tdrW1mqd/TtZmclrw5lQVfwWEYtTcBfTFTgq1PQFPsbBXswms36A0oA1pAIRDoV1BA87ZOjTGYt4l+iCkgBrJHEoDKg6NDKoKp6JFBkicw0poT6F4kiib4ksGMCiF8jC1fv8xNxlbXmARU+GVwwwd2XyevFnUSergbHdU58dvgzSNLVp0w8PB0el1aSGFnsH7C1M/83Qj1Mthhhj3WEJlyYmupjH2mbJ6tt7Pd7OW/Mu184xa9rfa17OzR2e+Z7tdrWLq5a1sae0EzAuN4iPdVWAAAIBd6CEcPjdjc+kePRaDyB46paM3XDbAQy8eNeJxwIJmBSM7jxkY4wl3FVswqxvwdhEYL/jDomgERCIoWYZWYyICVS4GlRY0Qmh//vkZCYEZ8hgT7t5evDLDAoaaYbkHhmBOm3hk4NLKCcBvLH5wwCah0eXbGreMmpRuUVgUUPuux94AcekqICforwixqC1ElJAjgkQxTPOc39EiCHs2WA6x621DkCf5cFAukc0oFCCMwVY+Q063BGtLUjtltfqF2hjMrYja/WYx3vVQsJ8xJUJLslppD+Lo+UzAhi6L/CutsRol2V74+T+VxLjWRJ+n3pNmieiSLls5X0WkPMRSLqI1wlS/NZ4q1SxKhiVKowncKd/LRfiq7W9/qaAEAAAACXTFMQsfMCJMogOQoBFQxwM1RMwIka+GTHmREpRsvXol6IgKOSShd5hBCKUwTXEhSgZbVqBEOHAzOVMk0WCQ42JpCe5ENEgyWgXAlok3UOqt8AKGNUZo4S0E3GiJoOjGl7yC08113YaA3UGxKLbxMD506TF9VhwscOVhvCcalLLDKnK1ZbLzK9o6WWRkgl1OebPZsTiqIxWelua5Eo7PjHpVoWRIhNHpKTrUFJmeaJqYp4gdJEZuCrMIEAZJMs8T4gvm2+9ywAAAXRtWO4KzAEw1kHNwejnKkysvNcSzEGYwgiN4GjF0sxUTCC9jIkogkNFDQzcDBhS0syUQL1GPEAsNArQMeJKAZAsg8kJeKYl3R5w7MHbWeDCPcWtQzKzJAggiVq7WysecKMFwm4oCmWocS4qKzJWlMddSmhLUkc0auNTWDaFI7b61X/dqpDqxazXGssgqPu7G3Fpb8Ln3diZbAYWCUsJI0uA8jQzrT0rlpkvMxhbcplJfhcfIB+cpsTpo7l581QnXmyOrstPwNKR2SH9qFU5jKjR+46eWUPL1q6BEaj64tcMUcRjpkT6vNxuonofxzgsbiTCZIJAbwNynzkDoxIPNzSB6aATSZaPiogZkFFQnElYiMiUhBRKPVHaCCsg6kMAEfbwgMBE8YBC6JhBOCCnkWgQOooBQAQiaBQ4Sah6ZAY2g27jLCBNdBmioVDT0WLdgQMtaj0mFDl5rbvu8y5nD/sjzhDBFalKX5dWH3WdOJ2boKh64GIWAYLQNjVSYpVIQFwVwmiwazxryRheGQhCKnM0MdXGI1kdTvV5r6tYqKqbVnUZOaxQ+01XnJYo78zO5XK0gu1cbiUKS2QqRdLa7Z2lDQQAAAEvcBikQBKqCVRjlxrggQSEDALpA4IGJQSCUoEgiXyk447zSmsppIjvJBCxoHgxtXVZGKS8HR0My2SiqFZqXHyAEpPYfEMs1TJA/eH0tu4eRrerYslFYXMYaiXJ//u0ZDACVRla01NMNUKCiOqKZYN+V1V7Rm0wfQG3rGoU9g3wHX4GVuec4SMRLijJI3ekRqpJJvpzY8NveIdRcLPMjzRXExt671D6EwTMOCdOOZKd2Xgv/yrEn3XQqqlsZor6bVzplO2gAAAEp3v+aBY6AKqgYo1RA4czb1GxYdW9dLhwp0X4e1ejJyRBUlUE0YwHRGPDhteVDq6ceCydPnRGUIdx1InE4qltx0vHypva7MGJ8jiR0Y+GKHe2Oexk0YjkmQlsMTE3aGJVsmVMHGXOJQjbcMi8qoRJsE/KMBpsuHfL4y3CtIUiT2F1xmTBtV5ilhySAYHMoPNCUBpM15giIlmjNFXrSGHgSVAECEhNGteidAiBAEKgKUufx22TK8QZRQa3aVczKRkxRc6XrltsulLV3lvP8u1uzsioJ8GdMwfm3GpiWOKnM7NmqlCNZRUQSEY8dFs/VHESQQ6utOL21qVhMdrETrNFdoKTfj5vD2BDtVikTx9ZuaF3mdpR2j9nfhmcWk2MxRURytjKaL0kMFct8t16+tU9fqS+J7Ovx8E6iAH2ESCMCHhYqMJtBHaSQ7T9ZGQlLpAdKdCoclxYNwqipqV1KtUKYLKU44k9cnbHph1O+qSkE1QGWs/HoL3ikLDVDfkTUo1hy/56khcVX8sv4bN5NSjeh3/0/IzIzrxzap/9I5268z3RpwVDO0uqADAAAABydW0biws/lAjAE8ycDClqUv2CjRnwHjsndxQ2HVzrnqqMPEnKyBxW//u0ZBaCJH9C01MMNiBtZAp6YexIUqEzS0080UmWj2pph7FRzvlXeZ2m6vdB7jwG1+Uu04MMUMwx5KZKwK6XISGwsPTIqMpjhS2+lLKEezU9Xq7P12mYg0Xq4q31n+GyYATuRpIs0meRuz8yUMgtDzWX7qVfGInzbD/QYyPnjxIyeJOaZsveAMAAAABcjpq2OeBkNQZqnMpwTHh0chbhfK1CkAuiXMbijhu6dv6Ok4rOKxpPU9n1thAZL5IxfUdEEnnReOjEmY87zGM2YYjBCRcgUv7X/Srz/f3ijV7NuG4xI8Rh0IOKX/dYl3hFD+P053///0AJAA5eRqAoQMglKq8xrBXoVBmOFmOBJ0pyg5ul+8DzLRdZYVOQChVVQ1Iqy0NdJD0E7UhrGUToxxboW1Ghi4IhkVCjJ+5nzdX0UjEpHjyZ+o2tUxevvbQQImd5RAi3s+DG3Hb3nzfFOciqaTzasYrC/r1BU0jSF/KQ89m+pZ23L07Jr32jNh1W3Np1FG8HHa3cV+LmgTpASm8RXPbRsWWPHa2rtzoi4SUA+0+zqKOlEShSLOrHWnqVN66q5KZnkozlpBKdEZ4ewezh+Ntjo5nT/tfxdhs0++z4Zr+8jYcStSf7+2XEsvv/FL0/2U2yY2b5c/+3ucvS//o5ACAAAAA3cBhBbkDChkoCRBRjSCYMHAUDBxeYMAmCgTABQATlWDEISiyjc0p006pdAb+NpHYbc1dTaSCJQU/7BshzHhg/JhNBgTV5k2aFxSVE//ukZCiGJKhH0tNsNaBlRRqtYSNuD7jBSm0xFIH3mKkdh5m5wPFZXZXrjjTqNOifL4iOuq3JRkPBhUvn0qPX+ffO3k3bVX/7604Ub7PMSiK88mj9xsjL3pAETPcYIEA+J0OIHJHI9BZIJxAAAABy/rlUFL9B0F2KGMSgQ4ELpJEtNWSms5BIHQ2Mjy7oEqyyJl5jGTDjO7NNJ/I5XCr6isw2JxQKEH91/za++fYRbhq5sCKFDwFSWda/YFSIvIsDrXIzwwPmDDlCJR4DesF3nCEloyyQGJGDZNTS/DEZf9AeCQSA1d7mxWAWWO4uSA1UKdxH6cBuyzoEvuuEoFSyAU9JjpaKh8gLTxPKjjk1aVPoQ0IxVFQ8awtj3KooWliaNPVzhn1zbtP3UUYJksCA49IUCIWJsSkjA42EQdeKiS8CubygieBbChr0EgCEu5XkDqRLbBUgjUHCAeHWeln77JPr6UUQoeRIBDFeZJYCkTqMZ9qpQNrW0JwW57GVZjMp8IcujPT50I05molpezwOlQxX7E0sz5XO71ubZsNkzpuAWcixlbHyIO75je+UZEZw3EsK/+8nee6G8+UvKp2zeGe+1za+/21/eoAAAEqXoJxQpMZKgMEeuKwGASciezJ0//u0RAuE5AA50rsMHNB/BXpDZYOaT3CzSE09K9HpHelNpg6YHIOgp5MXoii1WjKRWJFnVlwOD6mUg3P9BwyEgeiuJBiAAFZ8sYPzpCHk9VuFMuSc3z2Un5vrlhutdS1mlHnK4MvvSBkuZlo0JyckNxrPLNSGCQdPCcLBooKHxXFz8ufi5sV8KLvVPxfpAAASuBpbdy4ImUmmdswy0Ckh5ZOtQ9VVlDWl4luV2vMmQmLDDMI45LjioJScvHZIVKujmhrsHA+BKywVlgSyEfE6A2NxJJg7o0TcR0v+LV5SP3a1fYz8ttXB/CpjwA9ukCUgmguYV3wRhN528P1Ct+euQzlVf74U+j7+/v6/2AABs7I8BEhkWk4Y5iPKwh8PGTCCzNDwqGTSYiHsgbJ8GSBUC1hWKJjJxBOojivTphxX9FhC3ByPQ/1Y31MmyHmsaa7Jsjdryy9CswMrMpI6iyowR7lyhDE0cdOVtbS7saYdQgSwzIJe9JluBRU2lTKwy4OHWPIMfdZSvpKl5wwIkKUTQEGgEokiQcsuWZAQ1MRoZfZdsD0zBYBZqv154y3kqdCA2asrdqUojYlOCRJYHGpyVStc8EBGodBqUxrUF1tWs2OtVWa3IeDNqfa9QiZthaNTOb4BjhMNwWZlbJzV4HY4CKA9FTjQ4ULonB6uQv3I0yZzogQAAAJ0B5mEFAjBAqfIVgo4NCIRYUKgVFFM0qWCpOKrtRQ1XakKw2JrlgODmtMjYnUrvHFGs0y5WiOmag+a//ukZB8GJBNBUbtsHbBwg6paYexKEQEdRO0wdsG3o6mphI4hvAZeLA9K10AGYUgdGcqkQ9nDWXpHHRhAQHqx85YuxU/GweRQlXwaNCHMC6okIFDVBd9GTQMdzKQwseDi6zEBtIo0krmAEAAAAAXuw9PVkqT6TYsYCNFTRBRE8yftoS9PrI7DcLk2Iae6YY2p8gUPUSjiE55eesunx7F5+tbOyuvOAmQTm54kenTsLCggAgKBIGBRwuMeHZyVOKuQNc2aIFQCQukRj9TjMDuKvW41WiBGm4vs1CBSgFhhCKMsaMQAC4Vd5igYBHM4EiDbIdwEJS5a46LMXiaW6SFsRLNv7DDDo43j6K6j8ertTtv+OBIBsJQ+DMG42EA7SOiUoSDBSXiaXLNHi41WLS+UX+dyxmtu2vajxqKGF4p3EFTRZVCsMMQdjSShC6ZIpvQrEJcWJBSeNLS+GgYEI0WemtIUKAJz+fY3HkhGKI2CAqYNlriwS7mHyFVkMT7mNFf50RGShUgN9oRjcUvZ4VtEi6EwsVaQEh9ChFIsy0GMxhJMTG6MU3ZJ/5SorxhyI651kjZucaQTYUMjtT9JTZW/9C/yolqcheBiLNf//29PXgIAAAJ0HWIGWFFzgSCBgocd//u0ZAiGJHhA0LtMNbBox7ptPSOITzENS6ywy8Hupujplg4pTplgIYnHhKKdxhq4Ukkq0hlEmELRfgt6ui8obAkYfp3mJQOttsjOIW0M+AIYg0ASLgzDpMNQNj9avRlkdD6glFmJDWDrY9aTOvk2paEuiUkomEeES2eDFEyhbJFPp0QmIXpfgx5KLU63ZunK5n7BTwbiDHjQuF2HhASHi+zuCAzBAAAAKvCcLgJAAnkNC7LcLmLYOwmy7cnA5GVKHMfx1HMGxQ2i0FZqp7SNsMLMHpnEKNtkkNIz5s0VzRmHWBhDt28V9y6X9W+lu9yPT6VMiJa+d/XzuT4I/yIpWq+dcwcBSd93WvdsAAQPbiZsNNKLtlH5ImbZKph4sKkoSGAgdB8EwHjAGgyWgDnIhiQOhwIoyLBOF1hwsocsKSe7Y9eoQ1a1NrhdWnyiw6NVlJXRimKJINvSvUjtzXaIozKftrZy8L7Zkv9X9rYxnJaYvLW7tdQ8fDEGAQFAgLWvIAH7us0UAApwoo3ItSZAYCOMjcbnWSYoZqkjQqSTX0OzZ4okW05VKcjIkDIrFoRAAyoJJPBsjEQ9PCuT2BKC0ez8OHBHsLE54WjRhCbNnnfX7l42gh4wJ1lLpaXNIk33Y+4Ne8prkkMvzzLBnesafnDlvbkTUBUKQDVWQI81XC8AABPAu6bYhnTHisA7jUkEgjFSLMoD0ERQGLBJjKwl7IdYFCEySYdERTFTsvaxJx3ASMcJsvrEgTdRvVMotKmk//ukZCAOBEJIUJssHiJ2B6pdZYN8UT0rQmwkesm2HSjphgnxrzjTiK4QAwzUFaAyCNYcqTg9HNsSS8rLrqhMoWn3VTc69GZgKbjRXIrS89hdE4QRbKZP2yML3kcEeS5clIj9kFJqGihx1amsoAC0QAAAnNwITD/UTCEQDIxYN4VQJrJQoZrYjjc4NWJArDBE0miLxnY6QTkQkJISYGkjMEUrmQpVpGan6HZw1cXIS1yl96vW0FQxjgjW6ymSKZSsGOqYnuNBKig0StdtYWxgR5CjEQwSHjT6axo0d0FutmlFfsuYHEptYEWEhnMpkoXMMyAqQHWTIYotRmCcdElC05UsBLVa05rEkvXJ6x9TtquEwupr8HzrMWxsQhU868aj8XoXHmKzuxFpcdJ1EaolIhMHyBholLYjTgSY0QLwKE5DBnZqL1r053d1NRHFlIhYxNSruFe0t4NrJC45U2ZCWdpgj+rFTCa+5VDa0sQAAAAAO8NPDol0oPQoDijKUrFVplZCm0ARB1FmU9OwRRxDE9JItH3yOH5CBIgRFQ1MCsYnaQjJivVxg/5KSS6vXEs9xj2YI+Y7czhC36upKJUp3s+1jOwd5tTGbsaF4ZPQMm/+h5IaNasb5tUqAAAcwOET//u0ZAMGJJNKUBtMHkJiJQpHYSNuEf0dPuyweoGkEWidh7CpMsFEi4IWAAOWhMMLMqfAhNa5QgLYwUAAqdydElQEShENjq9mwxKbkzE1VnrWOtNwXpg6BWltu/q32sxmHq8CB0IpvQXIQ7GYljMtDsobJwosPyeqRBNHj+I3mydTQ7aVqZZq9S0Fsm092HJcgipZ7nJ/3O/r7+SBQ6szjhMrrlxCzaDM1uDR72ed4kLAIAACd4YzDUPNqkjNKXkR2L23qflvG5vUBYJkjY9Iai0P2RIi9l0dyUHsA7A+SiUCyYgQhYiH2CZWJNtZ6dfq1FVdIe3nRVSLCwLmHFwRIirSDUcq14igNy8a0VMSbQ6qzqIBl57PCEYypxk8nAFkw8w3BBrE8j27j0JAO/kCITgoEyNYRk6A1WK8wZQyHVY2HN8tdrKuVYQctK182b6+HuZlJICZS6a/42qmuuUz70vIrTAGfOEhyTwkEsz0tiQJNBIWoSEWefafP3z9xiLHZ6KaX60rKnsZAG4lN2tNBgiPrjcfBJw4xXrkJUBAafMd0iQAmUNJYcECFDqQK4gsSGmGKaDbIWh4gKQaVcP8O9xRYHE5KOTgviABVQAwmDYLnB0N4T0mGKQ/LxYOzg5OHmoENFdoqKIqsO5BfGH+ZQVarRDQa7egvmZdnn2P//XN9JG5JzdP+77Oy7UAAFXg9An4Bo5n3oBDwTNIECKCgqg6haARZCPTLn+lLKwSAnUsWXqbw26LMFhVyqOuSw1u//ukZBoOJFNG0BssHcJtpnoqYYJ8UVUnPG0keoGYmaiNhg24EIa01hR85EgB7ogBsrGsKSuPZwYng4Ag36HYwPPiUmMJgsl4udW04kqYzzCGsl9Ylli9t2j2yGUE2fudaGZKbQQzBTPKvFSm1H2yqDFQHh6K6CMWWQ0wAIAAAA7wmgulr6pZe+wyaNoWT7cntZi11vHwUlQh0UglESJkdHC4fIEieDSpZleNaUfxFHpDdD9NHdhbVgfaxM3WVPr0ozqsCNDEs+yVzTternvKPYpB3CpBLvpocwuMCeUS+nLZIEkvPUfb6wZQBthgSxox4VsAISWkQEg5EZkCBRqOyTrrLXZLEwqAZWYUGXZclrJeBYZuCk05XXSBZeyNVOLM6cNp7NGdyOzboWsqZubLnNtyV3rMfhA48UiRcRGFEIk0iPLkMD6HcPoXSTTRSzYT7q9mth4gOgdlSTlBmr8+kJIqCDpVNyNYeSeTXrXGYeQ+0RFzBVZQeCXJWoBrJ9KZIRQe9inbEXkfypDH06HglBlCrJEZUK5FJRKHdyNIlHlGPXjiaoFvgNTOFSkhZJ0DTSOLIK3+KV8HCPu6w1zyzhmZyv5mDRBs2QQojhycYtwdS881B0+6/lkA0AAAAZeA//u0ZAOGBDhJ0FMvMvJ0RloHYYO0UpUnOu0wekmZE+kplhkx3NE8wwTJdLwAV1GsZKMckZDHgi/Alg8iSG2SQPgOlEG+vi4ELHGXE9T8lHoNFxzBQTMpnqZO1WM6iUdjSnTTOim+RwHIOMBVogpsGWgjQflZlG8lLn4lzv6f6+UjAswL00/ssXOiJivjos5bNO6/rEsZ+25GfX06MuEsWuQfqv0GAAALvFO8aqgsMEjFohUwAMoYXjL7lwRZSSL2M5Wa2zLWQt3rQ61mVTbnQIsebo4lQPZUasEhEVjiEotPiuSTJaHhkvOzQ4NmfYZW++1t/coZf0oaxpoZQ+fCQ01EyaFdQVZTrTk1VQVn/22G6vOX3/1floEF0HvfGqcAqqb4MRSCuyXEERAi7gIkXoEYpNoHCA5SJFBo+6goAUcMgKVUawka0su2nMYMWXzYcy59bKlCirPEwAsADgDOGGLxfpW2ddFgLZ6yvJRS5rl4wLLJLYLiGtcfYxS4YO3SHkDDmAChAoQ2XNcyxswkoG7uUSbu7ue56AECSFfMiRLxEQn3N3FrdPjh+v1mYeAAARd3EfnRFGXMYi2rcEcGQA0Qdg4EArktstLwauhKU42ruHx4TTpTGCDqeJEYQyF0aQPI3gGQCkxZPSoC2VGRrRjzUe/8ZAEZ4hsZvqpCs9AT8e+0oAPD2/3ycPszfN8d5DVuKgACw5uUHkDBlkGCRUsAZ5eaJgYycFp4OBGWAFqANWAIYxrhG4ucpcZYERQ0//u0ZBYOBOg8zhNYRGJoo/o6YYZeU+03Om0w3AlQHqmo8wm4Y2xQwiQcACUyIS9we9uyq6PKU4YpznJZsnSnQmgTOLcfYVGXbWIsIxNdJeeWR5xWSsFvKrMPikCu5LuT1jdeJOLqVz9/sriIQh4JnpZN4U3QYRdlKOk9oqHjoYU/uQUNRDrNLUZNbisFE+Vfmdt7v/IIYQAAQnOGBtjcBE8tGYIEosR4sNMQfoOyCA4c7DANjFUTxBJZw2JBiSVpycnNnKsGWvvJvM1DBUeQ2HTeSMHTz15QlmHyWFxd7Gi2ti/+61avjHk1p1AxMNMu5N//oDDHDiMRq7Jtn4ArA6tACJAYBNylMSaNCBMejMeQLDQAKDPHwMpEjwCKFgivRdgyCTBBxhFNH9O5W8teXLGhiCzQIgQAXnYCmet2FLXbq3Z1IJSXftZ7xFu3Gdhy9wI2dfbOFZm1xjbKmXyOidJ4hWDcwMyqj7zxkiamRohBppW6ijUKbx3PqPQJQsgkbcTl7/1vUdlGPu/M/jvXauVE/ENoyF3GUXtuzScUCgAAAnuMGEfBiCvEJM0u5bJnNCiCHGfwUsccgLUQPJhQyQRrBZYbUZlEQgwDhFU25asu1td32jKHOyP9tHcu6/9L9Omr0qgIijhGFwi2I03Di+gAAAuA4stAp0auIGgDphxchaMiJtQEDhIwEdIiZhIVIUH1RMvf4AAC5RkC+GVI9KKoxNuHIQkrFDAKgX02dTNCQ3IiSjwzNZ6eCN5ex+0U//u0ZCeOJQ1HTxt4M/CN6Un6ZeZ8V5khMk5l68nfpmiphg3xHPaau9H9iblyVrEDuWzaWqXUcHxJwbkmjMajUWh2Jy6Yit3OY+JJrMILKO0rotEb+yJkS+tOF5+3c2NTLPAk5n6omXUTbHt/2bGSAoSKROfOO1ACSAAAAnRBSJgKREYhktkBpgmn6EbQQwEn4/IosWdUoGh0AIKDNATGKgCxFhUSWO01EwhJ1rCHk+Nw5DzMNvc1AX4zScIWVsZGEQrRDlaoVcxJhIpR+4ODMpbgNEgQBy0Aly6bwzQ6d7Wf//953+F9t+xUN8+X61E693RNbDO9b8963fSXSekQ2qdwi7egsOpggxKCxkfGQCqaANZioCmIS8YuCJgEQGLyEKEkFC4kBFUzWiNFczsAdiZkKRQqIewwGELVhGIQBJAaQZEQNTMVUZADAxUxW0MPCwL9EwaaRFSoEpuyFeyiiy27jBZMomMqKmLwUQbACyZZ+shK0IHEuDSF2IleCuQhLHA8XBc0+e5uoY2MiqPNaYrty7ZokLX95ML09I95603Nu27bliZ98wMx59barYg31CvJ7yRsVh7xAx9aYsc57/mwEgBS8Jhkamgqzp1BcRatG0ABRplzqLHWwjeqSVuOViagjuVnWoTSFBcTlA5HER1p/CvXFUdjNIShriEcuEdswaOqntDBCWwdeaIHIIHhayHBORMZcH/n0RTFEcTlszmG4uy2YOVaKlKfKjDnqJQ8mMM4laD9nX3VAAGDWIQG//vURAMO5S5IzJNYM/KjqfmjaebSVPUrMG3hD8p3pSaNrCG5CASMpSmNAnNfGYQj1Uyb8DIRIKMmTAGCAkGLy/6yQhOXqBYxKSA8RABskzQ4JcpIxgMNF7VgEtBJY6VK9GNTBYRHMv+xBWQiTBzzDwEzVTw+xVZreSSCXwT3ZorbA8NxiOQQ6MTcRZa+ZiNvlG6SUv7XpUUAtEigTQOttKDlnt7Yq3fEqUgig8v97X3+xsNnr1jVvf5r9dmtuugcy/zn7AAACoNcCFuYHJGIlvwFzBl1IqCCWoFOogoJUXTHSA68bwqzgHOTEnjCkgczEoaggyGQbEQYv00qGoBR7SbTQZenS240KUCZzOqVL3RmfsvGyBHNDZiS1ckkmxtw4EmUbBzqVp/N6FrDOci7NFkRqpRb+FAy9Tkj+FHxV26S5/zDEj7ti8pH/urXbZgrS9eM8B/TM/jujdHIZ5NeEEqm2xWIGSzgGA6BBMHDjDDoycmMbJhYTMZGjDBoHDYcDmIARigqBg4wQFC4SzFEshHAX0DnQFIjizi3gNaXsh0iq00KAWI8zFFV16zgQNu8NgIYkFL5eRbEDWiltfjPFLFNYBYOqCHmvuM/EklTuuTU5BzySSHJdKolUfGTXJU5VEH4kDZAj5R1nh2QS1nGLSGjCSbKlbdEkb/r+bElfPMbT3KKePdkUYTEjCxVHbEB4HyOgV0EFTprjVmhg4dMwPvTLDzHAmAFuxY+oeaEeMoL5phJfAsxFssdeULAIahZywiiCCMgMq0EBQALVTCiisU0VgQXoXMd9DxU7jKZlBEw4DU1d6KsfXu7Cv6V/oNZJK6CyNKCcHihYPxQIyBdhYwXQPzCyR/eqWLbRVtnVb3Emf/3Jka5DI6yx1XV7V2aULkNQ58sUVcvKVFXFgAAAqDgAAMYI8lGIBVBkkTGTQ+ZbFICGxjIAmUh6GCQwiH1LTCKXAKOMOm0CCQdFhkWhgQoFDQaYxAHZjaNzd2DOLUVDdLQWGVIRAxZwAw5FICo//u0ZCmOBf1LTBuaS/B0p3oaYYOmVS0nNG282IIPJedplI9JAUFMASHY6tYKARCARBBAaIJkDoNEVwXfSML+qKNMeFRVyVSxtH90mxNNcJMV/KJsT+K2vVDeMfhEqa6DzwMikgLmSA1OhEgT7uwxi/tt1o1VmHZtbmI6RrO+1G+/5d+VVVwVxpPERqBhptSrYSTAAAQU3Ddn2CgRF0yCByHYaaTeExMykjXEPklUbs2Tuo+7y5wfAq9moLffp25tG8OZYsJyWMlGwpTH7xLq9B4gMEsvDiVUGqwSk6x05WoONomhcLNWc6xXy/ThVmd0B8CpTy06wIcYLSNgTd4qAnnfcB3WQnufQAiRwYsQmcAQJFjHSswdLJkcyEeMpCVBTDBoxw4MYCEeyyINBhQCakWvJSIGBiJ6Jyai/S+gFAkR4FBQCxlcrQWel6ForoUk6ReVJRaqkRORxB9AVgmCgFnDGRbIGAIe3Ieq2FZL8gFpmRqPRDWoVlvlcYrfCsOhw0AAqLw2HvFRbQmMrPUP8i96MVoHptPzfua+72z+viV8xqojo4+CsDj3JL/6G0gQAAAAA7wXASvSBNEoTHegwYDcXRsKGE1UV42qtBMpzUDYZD9Wedtr6drvsviyVb3ZyOG23aG6crgGJz6/p6XRVgjY3bn7XHvVVeNQBzZ4iTaQnJNvI+m9a6ydy7Zud/z2//hr8H3ogNvlohAxRvmRlyl1UkaS4sG+EUUYIkDJz3ctnnUQAAADmB3xmJCgADgM//vEZAaGJO1KzjtsNpKEyknTYKbkFMUxMm3g0YnpJ2f1lg6Y3hh2aQMAkOYiRIilSq5h4EZyHAYaRUBoIj+pEtQ1llxgIEYOEU8PNDQjBQwnMu5NNfzAXsW6+Y8DLBx124HddXrSHedxKvOGfVc3j1GwkAkJ5SuRv9AFBsdJjpcqJrK1e4v5GcS0Rz4Jpu722V97zY2jGMluuH752aN2GmO7si27bYq+SIMUZbM6ch6S2nyO0AAApwJMZIj4wkB1BfmTIZKVmiLxI2moY4du5c0mKiM6ayI+pGhd5hTV38S7jkMOGw6J0DQ2RUcUxjb9P3BjcXZmmQNIljxtRdeGJRBcVpp2jqS7tuy6bhATGnQ9TFNZEvWlnSS8yvJsjfzMzUdP95y3+3Nm1wzpECZNG7QysjGT963muYA4AfUGVEBiwyCp8EghjpWYm0GVEJl4gZGKAUaMXLUuQYEg0qHQMwoKCg+LCJkAGga14lSdSIomAIdoyoLLgIDF0zRUb/sOVpEKUKm2SJYWjo6694YGQIjruTLZ1DkharMUbtZ00N4yF56sAxa9IH4hEbhimuRWbqX6QIJmgpZA/u2SlpFsxMk9P2RfZ3Z1s/lnRp/qHyK/y8vd35Hm0Jht+lxlTrvIUIQQAZeB6AzAklEUR0Etwh1LdG1GnXTggZE9RRENGwtupQuxHN+4MbA/r1PexyfgBw3iweEhk2JAgVSEcvjwJBbEMKBekXpTq47kY9OsR8zNafI+Rx5r2UyW5F/MoplcmyMqkOdt+L/D/TK5Hj0n9gwkq6EZrFYU7q0CAAAM3B2UKEkGhjSAi0ZgiySoYJHhA8dQpTHb5YyK4AdEYIIZYvW9EECObA4D3HKBhYH4RlQIokxm1YFYdxx1NxOtxPlc//u0RCMA5DlHzjtPM2KJyYnDaSPUUUT/OVW3gAoUH+eOtRAAi64UbfxZwPrCAeQuBIwlsoLo5GmdZydaNm2vPW+u/RQaVyWqdst9VNM8eths1tq1532Z3Mdkr02bNgS5KspYwm0AADLwesOngksRGOmeMGGGk1JH5tzJCyQCOhy8ZZpmKFAFEMWUUqUjqrpeNvmLytqz8uqmC8ELUzdt03SkjbQ1OQO8MMTjd1AW1k8M1XCHmi6aAiTLPlM4shPFO+XfPHz75nsitfrbnkfYwYKpgVGSPQpooNPh0izpHkfbP2bxxFJ1tMaGK/FB1nYAYAAAFT8HPhJd8HE6q7GkMUcwwPHgduydTcFf/KFyMwXwj0UVQ5CwFhRrGojYEPGGTw4trothcCWPlwThsXDO+iqsyUizu3jAjmyWz3EGNFjzanxuBEjzV1E1RtpCgw/bG951eF62vWu4Pv973e/g77/HxuSH9/cW30+2eI2DcB9C1FcZXK9sd6UvcCeIwYMeDMGJhA8CJi5ixJdgMGqDydvDCDHiC40BJwETAPgYDC9YyYfiKTDV45wuhJysS5NFMjCJkHGTFAFUskWGZICxEy+XSiThACAHioR5RMkiimeWmmgaUEUlLUpmQVUploJOrUt/RQXXVW66S2QW9TTyC7Kopm6CTw+6simeytEUAAAWAgOswqMYjAPOS8NISgPOzKMNR7MSiAMUhGMAitMRB2Hi9MDQkFCPEgjMDhMMCQlMTwKMYQZCx0MHG9kHDDnI//vkRCEAB2VIyRZ3QADtqQkyzuwAHXEpJlndAAOno2UHObACJmijGYRgRGFnpqjoAFhz43TYITmAFCBIZQWNCA5yFwZqBBkQwALHAJES+RBgyVv6YswROwwQXJS1MUgAygyIMEghwC0cuypahHPv4icIg5ed82aP0v+BiIStuQtCf9rzN3gruhF2hQ1Br8YvxEoeaC5bA79HckNPhG79LR2qGWSujpK9ncDSOApVGJzW9/n////+7lrW////PH9Wv9//+64Is//S6xv/0aiQAAE4H5SX5iiQR1iBhryIALIoxsEgyAHoHHwY1Hu24KJsywD4zLBAxvKAeFcwtCUxbHYw4CQwsqM1iCARX2abFnJxZjJYYKdluQKKCxkZWSm5iIEGwsOmFABKGDgGZYCtdCCE0MPN4ZjJjYVAzFAcWKi3RggUYSHJgpeGBBhgQOZoQGQhpEELdEA43d3mIo9wW2RAcrQstk7+PsY4GBhAJCZEDydoT5NTYe23IAm4fhubl0onYhUY4yd8YtfjkPyuej9m1RzkC6wtUmN/NgkId597kqia6Oa/////+f/////2MLef/d6/79j3f/9yAAAJQPDqcATK0sBsKjBU8zV8tzFgQDFcxTFkNDF4SwSCpiqCwUCIwwA8mHAxBCMxGIcxYCwDByd5MauoYi6cAObo4aMWbt+FAxjDxqz4GmmWCmpLmmDgKsaV0bqCbZGswQB1DxgeZwUFjp8GZlmBE6QJqlMmOMuERKXcsEARYYXMiOVSUUMuKQwXK8sBSst6tFBCw5YVxJQrpvX1bqr1pj33os/VLAUMOlfrv/AsbpYXJow/1PJZiUyiq4knhuR0zjxh+6lulvvDI6lyH6fvO//////1+///n//ll/4VL+Cf3Uen/R//9X//YIgBAD9oNMtAE8eLjLr9N1nUykLzTodNIgEwkQzJoGMkoc1gWDJDNMywMywbzGozAQSMnAQ6vuPhlDP4gEAoVFxpXNxvjMwEy4DBJ8ClcDJhj4GFxcxsGMDMTH0w3VeMURwE1GFAw4OmKApjgQJaxa8w4HQAt3MABDCgQu8WdQBGEDjAk/WRtjMaORIJZ8/j9zIQELnaw7bgxNli6xEAPPAcGreQdvv9RzE/QQuHo9dhEBuQ/FI5DvUD6LpdWktVJTBMJiclcTLl2nttZi+Ws+556yytfhhvDnf//3zHHK+CRM5///+z//93/0IAABTgy/wAtguvTkCBZhkxnl5oV1OMlTACUajBgIcQYL5EQ8WKDBiERC9Q8DAi//u0ZBcOZWROzB9rAABqJKnn57AAVFD7LG5gz8nIIibphg7RAdQWgQCUiNShRfwRmYKhwU2bjDytl9bTcbcac9kSfbEF3tbYGthNeSvMt17nWbNdh9W/TJnYkW7Ex8AzVJT4YWL3dUlJLcKa9hf5jjf1lWpqbPu7HKuVjK5vn95l38MbOP3v7jrH//HnOd/8u7oL286tN/7t0u8aXHH6vHKiGEAAAU3AB0KaGKpDGARxDX4KNYL2iD/WTRemuaAchPAOg5GghHZAIzD6dMZPrC8eD0RlhnbDPysZXNGhxNIzFW7FD7zy/Z3erf+l7zvebiGidfF5ZpP7Xv07eSt6mf7ushuVyhnl3/t7tthWg68BTHAVMOGIEmEyWMjDwzMRiQQAkBCQIHxWFzBYDQVMGDswGJV6oSRAF26IZl9A+ZCFtjJOBFAEmAU0aoyFtyQM6XoWvt0kdU4E1X3ackCmLA8DNab+NO2sWNsQlThSt/XWUyeJnUWgmlj1uXP878UiMWzsztFFnFIO+QjWZluXOKI9OX3dvPOl5G5y03efEH3XFnXqn10MjhRwj4WX0fKIEZ+GTtFEgEUWWNBDmqJtfTrRuWxF03l/OO1RezBG7Kdva7D6PXuI2o29DN5HPNtSxYuukhNRYoHgYqlknvGVubTJWnrspYb65ZGBOG5gqiQyaMf/8821ZiKM5mdKsZwm2851VNpw3HBd9PVpx96v/cXVAAALgOFCZMPAhLIpwGNQPmBoVGIYSCxgDxIgUNDX//u0ZA8OJSg6yhu5emJtRwnHYYOIU6DdKG5h6YnVqKZdhg5p4NcNKoJTCLQM8ZoqCMWfMiAAqL/LALhGcSYASqIWLQBIagY5mDsmGImoBRh6zuFxT7OtQAxQa49RSiBpU/jEFSplMXFHKFvRrVHIc8TU8sIyT+c2KI6c2GLAenC3vFNrw3CXM9aQIGr7lv65rv4tb6zjf+IWmKEoIho3RIY0bcVWR/8q/a6iTwAAXvwtF4FZAKNOsqAEIC2DA2xrlUYTRY7DcN/Dy3XVSrPSSVFQyhfZVlypk248aECyqK66EyuWkqpCohr2lOzM8xmSjNONI5izET2K1jq5dO1qFGG1jhTQFxke6IWzxRj4v9Y5xTmLDjSZw0JwHZjSADIIQSZHOplIikUwHiIEAQxQIDBIqMYDrc7gCjRxJ4erGBSB/QvUDCDihrG5qWDo0wFog7wFOCHCTFBH9YoxQxQX5NCreE7BUBegZC3k1Up2tahQLKFU0ptlXikO4v6sJ6hyha9P7v3CPNWC1TJZqjv3HOtxfbEe26/OX0fGPfcXd6Wky6xQ41PRgvt/aVgExX2rAtmTvskBApuDIdvi74kkAlOagxTzlpWrVUwkKUuIlEWZN3T2QKqw2yeG9Jkw0n4zKYEBIJhfcFhyBgfzhNIAxswWiWTjhYvcZZRdL7vVfxPNMnNzMzPyZjtUYyrST9T1qqfPI8yu0hNGThtPLY+p4M1X2J1jlTvnmJxCAABdoOyMDHSgLg4sxApCMpLQYMmE//u0ZAqORK9QSptpHqB7hrmaYYOKVaDnIk3hkQGGlecc9I4hCTTDEhkKBYQECIMDAJfTCDCxsSIX0ewKAYUA0nmzQamIIQNNaEg4AcxfDP2hxpnTN6zXLsLjjiwy8rNYdj0TjUVxhAkHhKqWF2hWMa0ysqyU6gQcm51MqvLqxUa8G7kyr5SDrBITVwqkgqR33fUwSOcOkqhJ3PnLW4f9fZuWXACUQKgAARl2A9RRcQnBuXwLVClB4jLVLkNJeWEizWVPEw19H2X4sYmmgMrB+aoiaYkYvDWiJQ5kkzUnyiM3JiwVKRSJJVd89TFxQk8youejeBogVa4M+mVFiMw4k2Emoz+R4jM4FGYxHZV9Q3IXh8yAVFGMZ/7sNwcpeav6w2H5RhnZ+Bvcy9jMOkDei8PKDI4QWVzLz00AOMrHBCbGmIRoyEZY2GPLZqYeYKumihI4cA5ol+cAyAghrGiw/DMwkSio4EtEhWpgzZS1lQwRrgVIzdlSEttFUn1LRN0WcyddwbKh6uOyoG5aHg/RHg5pSOFVIF1WXrMpn7yw7R0/YvXH7Xr3TSF92D4b7tn9fmzFEgNoTA6QMGlJiETEhM5gFFwLAAfY7//6u30xAAOX8AFhPyGn1EAhvxZF2nmxKNwtok5ysCskVhYQkOizleB9KBRCipAFFqOIW2sWWQGlg/uNEomnCWJ07DdAJu1cj5lWUV46jWrqsZ1bWJqoawfVP/vQ+SdM73N//717pwABAAAAAC5QZaAJhACmGzab//u0ZAiGRNdRyuuMHiJp5NmqYSOmUxEPKG3hi8FuDKcdh7DhehBEuAUfQgjDIbMZC0wYH2UpjuAY7BIIAIAB7TRUFiMCEAJVwNAe4tlPVWxIVaSnkZmml7iUAKecFza8DtfdqFwwwKbIgEx4Kog6OfcKDyhDoQnC+UvejLjLR/qxAhbeXqMFiA7IOQKiVZmQ8UEAnoLzMe5qZa7CqX/PhSLfs+qv1i1ehfs/7h+GAkAAAKd/DNFbF0gpIxhHQhagkcpcrJG+exSqutJ+obaLYyZE1JoL+x9nNZ/ZWXsKsqTGHaTGe7CwG12CaesQkJ22LSuWVKYt4iOrqORZi0rm5Hf/4vx8ybgZdI9DMbzpsSZ/2tdppxv7oUsB0O6elBnGAJrLoQS5mxQb6FKHmKjg9XFU7IAoGYdUyjESUtCESQiVrjl6QK0AGQlCASCSMJnL2X+SAWK0taFHDqQy3Gxs9kcgcRfzDVB2st5CHfmIqCJfaf82EkmHXRl9h5MatKIOYlJMVk7735H37mzW37dpl5Y8/TpvPVmaXXRN+01O3pMGTOTT7aw8DXKQZc0AtwyBAQAFN+G6r0ArEi1YY88y2Vs8TyOE6BzDQZjp7tNocuMQYq19nmozcpH5eypgdLuvZxD9k+t64YF/31O+0HAWscv4+iHvf6zr26uhRDRt1PFd7M/jv/z/r8c+v8YOAACd/BwkXmDxMCASIQ4YlDIkOgSABgAI8r8QlAQBssV+RAZItDgzdmEvS1QysFglCUBE//u0ZBoGBAlIzLuMHGB26SmKYYOIEUEPMG48zYHDKSZphg3oSC2+T3gdNGjk4CciHAKCIy4c0Lzb1qsUZjXu5mw/VYupCux2mOp937y1JKsQ40Ni2oqmuSZbrLFyCQSsf2dmXq2l6SB9zDtNqYfRiAuCGAAABd3oPWoIW8b8uICXiiy5Q0dvgFUYQu1SgoK9rvxhlarkyi2JQpOh4A8ZowMdUtgyaUGKNURkJeVyIreKoweOU0bzDqI6GTexzmXL9mIWWvlPqVl13hqpNTQ0Lm8LQ0tmZlCnv34Uq1lCOLigmkgzB1v/6Jfsc1EAoMVeGABgUDYVAquQsBCgDUaFQ0EEYQwEFQFANSfJ6Ms5RCC6DPTKXgH2TQlZPzGKBqWmtbP1lXZRBRlxRRiyRz8zAcX3lQDJOFF4EHG4RgsHn6DqVLGc1BFjilf01K+ZOJJHRnzr3Ilsz2XSLve2Xv6OzKOb0jIfDaywmHqHOEqM1/0zySANAAAU39Ilq6R1LJkAIBGzSNZLgx1m4QsacIEiwVIRyIKxxNB5L4kFaIKlbvmrhO5d6G4oHY+g8yMjZd1Dz6gyIc+EV5mG9HikVyS9NzLkufKfCE/WOGRd+ohkpaZmuXcstDYnLLqs3uUT/zUau/+qBAAAFKwdnMGHhCcBiLiaILjqQTHokIAo6C4AX9EAGCEFmkxBGVA51konQUXHhpuphuKxmMP2u5YNuKfrTVqJftxl7Hok8LgRygm3Bf94qCtKpRUZ8eIql2EhqhRC//ukZC6GBB02Srt4QvB0SGl6YYOKUXTHJm5rAIGpmuZphI4hpYVJkkXHp0sIbzOcLwlZPMQ+ddKOrupkoDE0y5h7RA6lLApf99dIAwAAAJ34I9IDkzAWozmQzPqC74ZAkGoeOmVjXayV3GSNqyB031HQPy2UTgCQMA2hGxwfq2q0qclw8XJrpCWfnTo6LV7S47va1c+fkPHVbRs4871LGIqmeXF4FiH9v5P9VAUCpM1uS05CHjGdhuY/vLP8XvqcAOnGwxOTzwnDyIT7wTaFTaGDCsjCICCLbgwAw1xw6RUOPisMud0t6XhLWLMCNFuWbw+pYYSFV6h7EGgN/GGFPgXiazLLK2YEUdZHD8ES6wuZmsSdR+otQ1ty+VZ3bE/TWbWX3cq2rOW/72tjW73DeOs6/P7jY5u45sATDaCBA8yaetQjPf/////+oC1EAADf+C/j/o8IzIJlNgVMVYLWIquGoK7i4X5ZyvWOsoflxgoVNzQqDI7FG9diJWchAmqcsSxkqr3JpqDhwTw9D32q+pc/7VUqpG5U7I9fJWY6WJ1DQhIWuFqwmovWgc1xXfCf/X//ZXcSAADv+xwQDGJRIYPE0TMJhJDJmgVABapnilSICvlfuguyBW8kzdm1S3XU//u0ZBWARBFBzDuJHbB25qkzZYOmEDDXKG49EsHHGKUphg6ZuODWVsHfRh7dkrnulkhlsdiKBRAHWQ2oMge2ubUXQKkAby5OkzGXP2oj1lti219zgQw8JCVIgh6tIEEGFsQYVFHJlnl2vE8/KRvBgUMjVBdfLXNy3/6FAAByMBiCj6ZqfAbCAwjHdCEwuc+4soyUAEpMFB6yWWMEXq/bWmAtHWanU/TnMBtvcO4+i8cowfCTj0niAPZmGI70LA/EgoCBVMexVrsuU++oAKZEn9lKRK6G2e5J5Q3hUszDJBYssg2pBA6g842Znbtfr////+sAAzVs6QbTE4jMVAkyYMmPAwBpggIDgYXF0VbS2zJ1rJItVZ5Tl5BkDv6iele7LyCWQpmJ3ktihlPFHEyLejD+PhDCess68xvutLtzVbMGw2HdNKwQhYKUsstT66YinQUcZLnltRxw5UlLLUkwefF9DjpkCgUFxEVF6X2quaj///6xEgADLYARFXAzYeurSR2HimkaJq9kDFg4YUGSvXayxUrzNwUcZE8kPshREfWKQqPh2YListU8RFBnp+v8/LJ0S24EsqfNLLb3zK1oZJ6wy1q6GKZo2EYM172D/lKNEjKX3RPDHGZNYM7m5d1v8j5qj96VAALtjMqhTQlw0cxYkcgmpKFuDAhszMrFQVOABNLCCA6hQ0sLiXSoA5iRSdC6GCKVCRXHXY0OCWfStu9M78620fXbMsRgRp8vAyeKiNMUuJioVQP00/zW2Ck2//ukZC0AREQ4SZt4SnBhZomaPSaCEKD3K02wdQGhleVdhhpZNXpRhuCOTFpO5jLVhi+ZVS2aSk1opwuEU7xLzeIhkoPUMPBkkNQA5LzpzIo//qFCAAgN7/AaZiqMCiDZBeFyjlsV6BMAnVVbHQ8uw/aK0uoGzJCKVlBbBqiQ0gtblWdFHWcCWTxkUup52ehXiHI/P/9+ugH9l75ysfb3t8+Xc6ocx5hIXJEWC79DrHLZ+VrWAYgAALe1gLGjCRQeSBIEMQQAcGGGAI8dGBC4GEhYlWBL/JWLQQyUUvooQUsK7DdYFbBKlCJHPq3CsSgSFUAfn66Isvmo+tLqqR9Jv0xDXRL0ie9kpwy4tO4DzkFacNtOK/aAgVVyJytNGmTjXAhQpIChKZ+CDSH2RQyyws0EIs7/6P/d2hgAG3AP6jcgGL4m0aQxbphJGkMKJCR6XS+KarcVVYeUOUdVM36uVMnHdCZSNbKg1o2V4nhLJBDPmlxXKnNHRzBzMCYXintqnZXHu2eHx/+ncnpTjFi3tzMQAc7j70oQu25BAU2MYS5jlQAArGDw3wwRTMNQjO40x9hMDUhqqCpGZgdCSuCMDzQU2dTuZGXwN0ofBoi77XC3G0eWbspWehLcparBFVU2//ukZB8OJKQ6SJt4YnBn5qlqPSOmE5jJIG3h6cFomCYphI3w1oM0qKRgliEDz0/BDAYiQVjEf4QOHQ4xLy4wdn7ihHCu1jFaPHG2jCjfo0Lqf1YXns+b27UsLh4xi7L0xq39V7+jcB8wLgGNOlRYXAhqnmle3///6bbAEYAACU+oDEIUzAFhyhkggwvwjJxi0EmOcv4OEm51ofg5YxvvX51Gk1KxesPA0WbZ149A1NxFFrXIRJOFkKxXtVNf1UjxmbrlDIsVHyjecp5vxQhF1w0DGwqCwjcwwolpEYhErH0v4obGhYQHFoDTxwk6djrAhRGEUEvQPSzi0gQTC1QMgBNNGTE4wgAb1MAyQVGpYgCJiIWGERNNDJSSqKhiqywKfyIb+StrrBkKloqlSOT6WQ9DhF+LucJZKs+VaTFeL8qTpLclzhVCdgLmZkYYTcp0JU07WucOX1nH1LJeute28q5CGN89B148CIB8DAhGCoPoU4TqCCHdTP//8p/9+0qBGoG/AXZQQ23BGlMYcTATALjB0OjiwRSNzV63QaB0IgTyYCRGlMlMilE9mkK7A7FrIwiUmgFTSF8sNHiBVdhaV8m9yI3jHSMEHNi3EyXU8ggfPd/vUcl704QVBAAAHYAG//u0RAMAw+8xyTtMNSCAxmkjawlcDiTHKUywzwHQmSUNp5mx4zgFQaIJDJk0oCBBxYcdpBpQsie1eI8JZkxyGGmIpgYIou2J1HwYuoy+TbPQzMCpdMAkPgYgWKej2h8XxrElDH8gKhzRqVgHILzqJxljED8bGfSWJbqPsm6UZr/26F/yBLc0BipkyifYPeeNxOWYlpz/////+l0eAAHawekuZYuasWFFJwW4iMGoXG4BmQPBUKIQpoRKuDwcxrUDOEm5KyhBU1y4aN5cZL59Ich+Zdbq6WkORbgt8WvzLkTUN3qjZMDA0wQsJWT/TCJJGu5lgxlVVKn27v7iUW3N5m56u/e7OF1ODaFCUMnigXBcXFUlhpA9B3Zy11lAABAAAu62nSGDhUwDLeNM8FGkUrDU0RpdeCl66nAUcRVmVNiAHQHxaZg3GYGVhMWD8JxqtR/UHgiibMIC9FtBRoKgME6DJauL5vMo8uO0LxyOaH0ULzuVJXuv7ZpbXMDZgQqcRBEFXt2dGa/o6v6a+AAAFNQBJeODxHCNGUSLIiAMBkUIHHAukQ/LOIcEVlVARRfQPIQEUgBuFmQtTpVXjdVJ9qhHPF6KhrUYKSZ2I3zZbV9cMpwszMc9WqOmgkVecsuaPYMWyCeVU48xqU51HZu/+pykaXqUKs3GJZmfrQV8Fbf3iAgABPfTBNKNwqQapS6CyLNBatqBerBWB0XkVJAsnanFH4eOhfGRTI88B22EAcRrI+LEOU0ib7cFyJ6slygU//ukRB8Ew34ySrspHMB7pwkzaYOmD8TVIm2w1IH9lySNphsID7e1aBDF3CLToFBNYYAchYGeH3ZdYGFscADQg58HRNDpMOAkWKgnJodPJZ//d9lNlrwAFdQx9oYYOYFQaUADrowdBIEzYtHMwgBQQOFBUAWwTmEQEDB11tmHhaR6t40HbqrY2i9HOjUQUJoRSWx9J5s3AJBwJzhpda4aDgaLD1ehfde3DTJ4MTGnBm4ryhg0UQT0XCM65/gCmQs0OVMFHiqVQKKvIhgeQCn///0gAKyAAcADgdNYKiwWBA4ZaiJGRhAWmCJBiHrnogqWqAugtecWEc1VRrDoziKr1z7BYBMxHRDkDU8F0A6CERAJgs4Ti2hqErMI+F9AWC0ek5CDaZYUgUT7pZJsuDwShJBakVUkh57+2z+GdCnl2rYeHVAkSiyIM/////p/YlawAnbAD2Ci6SXoIXITBIyLPwcNMgIGQIKUpSAECShCqDcpP5DqrIwEv0gaiiXBRpVnkDQZl+H+noTKE1oZjN6VzumuKljAekk5LulVaZlI2WJTxGud6J14ELH4emcqCJctt0SmXNmdrCqOBokAhIAzAtUfDymzbhi7qv////+/0VAAAK2SHBIDUhCKUKAwwteh//u0ZAiEw64vSTsvM8CA5HjiZwxOD8jhHu0w1kH9kWOJl5noUncmahKBwaKyEkGBRB60DI+MxBKJVE4LFofdpTlfOCqaSxqouqxFbpVE/i3SJpBSTo3V4FmrSSU5jARdyaeSUkfFfEyzfpoLDwVb8pY5KWHljHPMIFCNhUVai0vp///yqf/20aQAuA0XkszJDIbwx8znwidBCa2gMQRghI7olCFRvaBWjAmElvV7iQy7Yk1XKaa5WvrKWgpCu6L5KxwBFGutYl7lqos0ayHycfgHC1UEYwHQHm0y9mTpS7bKT2ytWGyTA0ETZAw0DBoKrFGIKMPAIfMC3c3Vf////62E5atsiDziilBgAFVgGchABADhZrTKBA0AMwokwYMICqdq4RsL8GQFIc1ByAMudlLApC/L4rQlCajKKsmeSFK6nW45vKJKsoEzSSaldaLlrUb3NH5Ely6CUXl51PlcvaMeWjJx215ns1sz5hrRL3ej0KPU54xaxcOnzBtlskFf////vrs7O9YC3gSXGoqgeaiJxIGaocsYKXN+YGXoyApMefHnhCMEIII0uhtDtJWG8B5Q5cCxkiE9QlNEmQ1hOw5S5hUExT7HGiYUCaPM4kNiLmyeToMnYCwaQYxb1TuiJB6g4JQClISDDXIFYss8DgSQPY2k2B3tPtCT3f///yatm8/qXJk6VQDvAz8wESZqRj0mysYzIKfBARlGEQQXGaC7iKzGG4q8CBQsIs1UzHI4qqqZOiAJS478iIMwEmAN//ukZBwEA+kzR5MsHUB8pqj3ZYakDijXJ00wzsGOmiU1gwpgfCMN7RpaFQrloiL/O+Yp61Oruyht+/buYhcK8D1WnYaLOGIbmxmpMbuWDQ9kBlxg4NhsuZcCLDzDJHb/////iX7mrHsM4AAATjBZEYyxCSbRBAWIvDDmFUlAyLgEBtNcpUKGrLGXJRrxWcp9HJ3lrSqNuTSPG0Q3HEzWLQmGZGBqwo4rg0Ip6YWXxvy8WYc1xSow9xP8T5Oto9T318Zmyn9bj1m/bbMpMWJFhEE4DnhZYHUdAD////7l/yKkpQ8217whwCZLZDolU8bxjCpEWQCPeRBlcoZAkYW+U2qO6/kbVtAUKvOoSKmSHpwsNniqlcMl4cOUJQOkzB6YCBx1wtyNoZBpF3gkUcWiMGl67IFfrvXydNu4bDH6d4Xdl+z1pg2HxDCxVYNs4Ta/+7/+n///jhAgiQAAnJbam/MBQBmIgCAJ0UEzUPHNSpTBay6jXcLkDU9I71LNTEhAIogLiQ5h24z0MboXAIcEhjmJoixZz+Sr7yYEeFIe6Vd7vkX/eernNGhQY5JRwyggr7vyf/9quo9//1IIABdodtEwJvSLODHBqk4NECgkCAklkqU52co3MuFeNA4ECTNB//ukZBKABEY8RzNPM2BlpNkqYYNeD5SxHu3hgYHTE6Oph6VYlUfSLKo0DxM5LlmZSkZ0edA9i2KtDXJ6eSbcUKVh3qRiiPKXBwvWg62tfLv7+yyCZdFa4MHUkXpRflZ1nSQTiIapnFzOvDbMqxvzyYaBQFDZ1Ice9PZo6v/1/TNIYNHljVoNOAqgAAqR1ouysuEPCzAuyjgSyZYjETMRVICYNg7XlcTDhOeCTCwhuHBglcNOd5nTzCXC2f+lhKlYVLj1AxCWB001eJqbKa+gZ8lFzrzwcoasXQZOpcEjjxGZWJzSAVWr/p//Z//9AKAAZG4jhihG0x/OkxqGgMAtkgaglZQh3WkXlUAB24CgUBoGRBEsrjFNonA1bOlYalI1Oz48TklkxTHjJQLSC4+y37sTbMdjpt1Z1ruevVK0Jxqp521vevz/QwRsCYDBMDNEgNAcXFjTSS03lkpZ3ut///b0Xpru44apTZMCQAAAKmgA2KNa6lqCzDFEo0CsAYNOyBHgkqVKYBYFfBIF2LwMY3UGLFQFCERkhYFpGgimSkrgSB8GLWJhSGVEcEJBsaOTnHcgnlC5DitzdIVKoda3JSYuPLNcOG5pDAsetQeUxCf///+Lx+J3opvS6Me0Nk4A//u0ZACERFI4RhN4SfB0xIjcZwwsEPS1GOy9LUH0NeMJkwtJ/cPwBHHMJHRgbMaCDIB8x4iSsec/YlKEwKkEHC5AKGx9oaAmGGblmFgVnpfLlkbmOuyiClqxWWv42YThhCjFRYH2WkiNMKDjZxYTzl8X5VB0hUK2GGjB9CijGclIOQaxNn715zfS8UV3XzJ5LV7/7gO6/XS9CBT1P///qUzckuNeF1HBAARRSgWABEAAAB/Aag1lJhDgAgBFgABncC50lSohPmDYBWBTQTCfanXokY4s2sSWGRivhHMln5qhFgLTpcbPnC9DO8semxNwg+xEzb+xzrZV1c/u1ajCCQkLDAUNuPRhYQroFz8+k7jyrKQuiz////+q6babDAkIixIEABNKE8bTOgBPprAkLprxAJoMicY2BU5CgN5ENEWRhnlUBiGmG2bwE8G+JwTscp5F3OZFj6Kctp1sJ0qIsbElT6a0JDKMEhGUgZjjTooVcdvYt6KmxrILK0xeXP6nmVrvFIHgdDbWJFDLDo56kJy4fMqDi0FyLv3q3/+wuQQ0iv1kWCo4PoDIBcgFYBgEuqYTiWgERFDyaQeBQGNWZS16MopI9TKx3lp4KeJrLULVdkVl9I291K8tNAbtMmhigil2ef6LRmQwC5UpmsLl01AUgILnIbVIpnUnd26O/SSXKxgtJWcKDrabelkov27fuvT///////9vTtRUd+fSl3qsG1FrNQ0CABegcRH4KGJgEfmHxKvEFAUBshmyjQKZ//u0ZAyARCgsxjOZYXB+xQi2ZeaWERijGu5l4YGkE2OphhpQSdbIOmqZpysiT0DE1mLYZ0/aF5chYRMeJsfqNiCdtKHA+B6VT9YXiqFCU9XLz7S8f1mzSW6lhqzq6KrJqfP2XT8Xu2tM1l6c/vx0lBpwooFXn0i5MXtoZzKl///+yy95UIwOklWaBhRk4J2JAgAXMBDYdQw4RnEtRfQ86DeJXoWvT7LpglCHH+jqsSYCQwYErGhmhiudSsXEqCWG8j3Ehh/HTcgxgDBKNtQs82lVsR7ODdZYb1ezAsj+siQSytoBkFt+mjjQcXaIwq8GDTUF0T3DAxDc/TtW/QhnZ//8u+p9AsIykcpIfAwoWGAAA4nCcPC5UAAiTOK44lDGZbkAS0TzCCNYCyDBQECtEwUX6UwAeQtTOEtEMFfENA6EEfKFOl1MMi4aoQLifBso401TBUcF4xsyjT7+d44zbf4y4RJ4fa22FGVmH8bFYE8Xe4joUUDgaFr1e3e0UcJrxaQEBe9rNGj2/9I6tgq/wLUoXCjxYTnxNQAHGkAVMsixBA9RNO4xbCLIzlrh57uI3AUC04YcZ5EtoduRJ725NCOUjgmK2YDtaiscNEo0ltanJEihpaUzEYYzthva7sM0/GzWOlgJrP2icrShGJtb1t/kTFP///3JWOd3VlBmTaF1AGUD2wgwc5LAgYiIGVjSAYSUUPwcNiyOUC6UjBwUQwcy0SASsHWcmcy8uAWpexurNQuBTLJHfeVZLyw82RW5//u0ZB+OBEdvxZNsFiJvg3jaYelKE93DDi0wuIm9NqMZhgohtWsyuA1SuhF5aFRiKQQMkFs4LJ71WUUs0Yq8ugQzhm2wZO37FW0yI7uV7Jp+n/L0+6pf5v///////3fpulCpSiSvvGnZ/ZQRY9YBAAAACNMFz23SzagoCWgA6ikpWs0UEKNccg8yMluM0UEATQDiHyFUzQT+NU3UGjmGRKjJDx8sY0H8LMiAFR5cQwPRmm2JTYcCZATijekH3rqnr4sgJtWBm0UtUi3zmZ7H//9dJ1RShRkiVlB1giMwOh8MAAEUAQ/DFLjdsR8WVqjRoAwDGEZDGAFyIftoZYmhdAZeURAG8aHKl4vsu9manK1kxUUGQKzvs13aJcMPDAEw/zgAbE5VQOCop8nLyuJahHC060SjtLY+ZPWltJVsM1dEjMTElKVEag1/bMipf3Y9ku9SM1m7+307////tozbuSQ+Yzs7vc6MQRHuJoHR4cMKqdhCIsICahTB0amBgC3MkQ0m5EAEhzWAwaKBYAzOPOuXbXgx9rDYncW6/jpgSJyErUCEWS2VV2ceLnliGPqw7QDErqUqs8VKvQsQoAAnKRqDKiGISW7TeujnlU0639Uotj7W/79Nv3+n/////9dVb7tT+ddLU0nCVaV1AGBAAKtJk64WLcAZgQkzSBoDEE3ne0LDLPMSaGnMhNdB/l/B2qGsXgVEQmGZdLy9aDAdhEH5oZGNZhXa+h81Avuw9HlGVtFsFZfbl5B16KExZWv7//ukZCoAA+EnxlN4YGBuRNjdYeZYEK3DEs4wUUH2uGJZlhZhsbNiI4Sh963Hnn0Wpot6WKhZzytLXPLK//06s2qavcwgXSbFAgLLEoQJiAABDsaATQSvXsgRInM3LTIGl11bUvxCMZicK5vb4zxRJ4vTCpZ1BIjFiQhxBOzvAUFI3KIVEnEAkpDpgQ0KNJH8iUbpjkKOmT/enBYRGnBRg9ZdbIvagc7K6V9g7///0/svGpQpwaWTFxCpYIAGkA5sFjAAMGiOOEExYBwUhUFQMUggRNsIwCgjLrF7C4LBUzmwtcVxPjgwKBKBuOzSICo+CUfD4Ww60sj6grByXopgYPkyefvVc9G9TNpewcMjA9LKZaylQyFYqtIpnTPVE1ferUX9d////////+n7WU1Wat3QiazOrHaIUY7GcQacIiEQAcggAOUWNGJhgcAmGajBbUHUJmCABNJnCjarVXugwdGNp6CdDmuZm7yh6JhPMA9K5OLJVqNymcD+oXkMpE4kPDUSF55Qp+dHkMBxCmdW7pmeXIk+XZNPRf2/7f0t6asuz/f9//////21RVNrcxD6NZEqiEJYkqjDDBlwfmoABREAEG2NInyBmKDbAiAUtobRFXDUV2K/RkL9V21bgz3N//ukRBEAA5QlRutYSHBjBDkqZeZKDtnFEE0wUwHYOGKZlgog6XRlg4qSiY4bNEUZIXYSIVY6yn0abVkhoy9dtqFsICiaSqGai+JJ9vu7A0KrWATI8wHRd42w2NGFXCrNClf9P//q7HoGXXjlQqBwjWPBcMEBTYRCf+1zD1UhAaCmQPBoMt6hMRXgMLg5DXRAfJ0q4hIojhhn7Y/XiLQ5YboggmXSBFIKI1cmUCHgZE+0S0dI0YfegdHkK0gXabIELWtwEsaSatCLo9zze3bx6rf//+IUf/6QOQQ6C8KlAMOMyGVCQFjICQQLaOmgXthpfrIZQ/KdL8somZ5wGlvW1IQk4lFkY1RicgtJVBVdaoYXTbZCpfS/18WXedb5rk+KE/SpV069DL9f7/dvmr7r32/Vm///////pq9DnjIalRQlwM63GmASKaQjlIDKDcIAFyIexY0EtoQpAkAVULASZYyBYQtTYQHJquqhtL4GjSq5dYRwRCeOxEEkTEWTREuOaFrCssHtph1huxxHTljlFFFQRkKwdGTjq1rIahSI31anvVlo9Ld+///9f//////3dduhTOllbkRCoZyrchqh0IcjBzpqEKMAb5QLWgqsOkEW5glmmmgOIlgc+v4OCTqj//ukZA2AE5lnRUspFMJ1LiiFYSKmEEnDEM0YtsmityKlhIohzT2crabEz2gfeLRJ+XpqhQVIVZhc4OtKa6erLyXihKqLqM20wpGBUp7j5tFCuzIzWVSF2RmS/r//2/e/5+zP/1///////63eyn1nc90YwpMQhCCZoIuCAwQByAAR0bUTARQgBMY8BBtzJsExWmscbu/LPX1hqHU+GGpEuy/zvNJXrMTEuGCYGSJMjZSNisSlDo3atoIkDWuVmpHUW+cozTdbUbN6frJ/t/9f9f/R//3+v///JR1tMybFzkc3hVUExFZiinKUccAPQ4UoYYKAFoQfFOAlYKiGYfm2Ahl4x40LAgcaEgSUbpMLLklulAkJKTMTW0yhvpZL3+gl2YxRyzG0/uMuiriHGuHRjSkiOTBJiPg2J3kW6zRSc5RsbpanttbX//9d2/R9L9mX07z7a/u2un/9PRF9mMYxLGRJmLVXOLkqNOhzOQexxEJOETCyDlQA8EBTlMJxEYBKXVeSXUiejsBRXdt4G1dBU0MugzdtjJiYoBpMPkpFN2T0u0ZEKennl6nFlyO8bCw4ljEDGlRiu7o+7v/+3///t/t/p/emn/////+lHuhK2rq9jmzvWpyFPcAK5C3VEGkB//u0ZAGAA85xREuJLFBzTiiJZSKYD2nBES4kUwmJjaQ1h7EcGVEOUgYDA5O8wGDC6hCFXEbcKAMWEznI5KsQluUzRuL7NWkMRIh4RFipkEDZAPkINlkOIYRZh4VfhGbcX2syzFmNxn/WR22p6+yf6dtVeaszJZGdPT+v/2pf9f///7vSajZaIi1OkUsqORCCD4gomNQNERxyCZwBoAS4AF/q6hsiNQOFBCMJixIcZQaDj1siglrryyxk6vnzgJh1qzDjAo5IdQNDiVGd0kehViwQkMkKgkSNyBWbUk9y/WZDlS6knr/+v///39//tf/p/////7PIy6MjUOaepzurSRRBJwgtDPAhSGDmFqDHAoZATkAODkRTgcChasEB8xGFwCCgoBUbgCBFJvU1Fx2IM0gN4nFh+VOW6cbjBAFjMQqtpxMSoyfWDCkosMoIQ2HfNEr7adaODUEvOtjPr5l19dHa/u7fr10b0tr6lvp////6f10e0ut1KQ4MjG6RyXQ4kMOiklCDHcPDw3ba7I3a2Qiw6LOKsAMIMBCHYkhIss6cw0RHhb0dAJYcZpi8T44IRCLLcZ2jKlcfjog1ltfa2toRgNJgcpj5Ye6IAcSHA61z0CmtWm1NrGK42j+lD9di///3oo26LUZi1bCaFgjKAHW0NGiQyKCPxrjDQzT2tOi7Lsu6wSNRizMuo9E+MmzR1Y6QsjJ4li1IwvkUJkri/D0zOxnkyhFzls9b+37bNv/vX/Zunq/7dd6qb//97/////ukRCoEk5NxQ7MpPEByThh5YMWWTj3DDE2E24naOGGZsRs5+1KzO0+a62kbqOIOEDDCCoN3d6DYkgmHBHJhcZYowAAECygB9AtQ3wTOLGQc2nZqqVUa6XYVRFgs4We6La312s5lTldj4VhYcgJAMVR6QIw2sE9BiRKtOuosUrbucqtv///7U9vrp9W3Tbb/2Xd9fX////vzJchd72VSoRiOcVZRcRKRRAgrIZjjRQWGgELq2LIAC5CPEpb54iYGbPDMrZou3B7270sBQQ0KDoOxk0OSeG5bS0nJ2U54U87S1q16/HMscN0G8cO/Vs9CNg0kf9K7//35Ga/lyRot8vwGd5cEL7////3spAYgkKTiZphuw+kgM7Wa8NQMPU0NNzf0jQHI2ASE4wJACQStzExQBSREgdQGHVTJkpzO/ATYoHoochr3ViLgSx4pu1ulz5LJ6V4XqeWUOFLjkFFlUGrglohlRGr9P+//9vor7dWe6r36UY11l196f////0+zuQ4tlZ4fRd0Gmcn4N2PyzzyQssqxyJMFAKaiiAgApSgAeYQr7SFhhnxbZs8qbyill6XUL+UsCxl/rdJT3a0xLvlNJY5dwvXaaYi8huVqfdwBAwAQEZqGTW3Lf6/b6//t//ukZCGJk6BwwzNiNnJsTihpPEbODhHDCk0I2cmquOFIwSc4p9Ho3531MqHVHL20+v+m1vp/1qlL5FzlILMDYzI2jkdiXTncLYgeyghJKIKBFPJkCAAAGaQABZTxYWMm4wiTIQONVM8HCtdtTku4sV5Ec26G+kY8MvhP8x3UVqZqRvNcs6qzkVv3////t6p/+ta6PN6rczKRfS0rPT9O/0//bpqjIyXcpBShMdFtyiBb7XlEEPUq0SDIomQkmPLwxCYT+CUI1rMtdhrbUmsv9WsxnduvIqell2MvpK9T6LG3uUR+NyWxLLFvHHHdLYqiRRhxlCsv6bfbf//vQvm5KN6SVetqGmnpI16Jv7v6L+3/pbvb7OQhSqjFAetZhhp1uwvIi5FG2W4/SjRYAWglh548qQAR/PSQeFkcRGHU+iTLEhkeLm3oo6zD8uXr02ztm7LPPV+0KdwSv6f//vb2t6Ky092pfUpN1ToRloroZXq92W/fMu/b//T06rqroqMwCRM4tNUmpHaQOSLoYWQttjjRVgnXLTI0iAhUYlUBUoIhCdQb2C/YNnQ4oT8mizmqLKMj6zI2WqmaorRMjZJbJJMp2el//6//+r+T+w824j5uadI2p0oruhlurolrEqUu//ukRCGP08RwQQJjT8J1bhhCYCueToHG+AaNPQHhuN9A0ado2QshjfNGmfNfkyz888z+GiM4UwaJFOKHMtqhNsmG06JNOvIlySIjEQSiRNh9cs0JWaZLnmpBdAAOazZxXSfF+XCd+d3cjVffKt2zS8x5l3TIqEwwoKYRPh/myLOSr/zmX48pqiyyhmkjeQRfMsmunXMT26zkRfTYY7mZbH8t+Z/6/4rn5bxuqGVMtXrael562ktJGkns2HUVCcePImhidJth4KRtNgPmZ0/UAFIE0JiVDmNzUyfWj6KSSWl9Fv6Lan/////bVjq//G1VS+qvV+f9X2VSZgJqFYwokMBCusYUBElxur6qX59VVU+qX6n9S//vJSlaFChlKW/VRShlJYVPisiRCklyRECQJExVE140iatIKgiCIZUIiZMApNoGUEsamReJYvJki6KqKklopP1P/SSeklR//1vX2+epfqx1SjHWP1L/6X3/pRmbY6UAhR1tVVc7szMfsSgIlSY6x/z/pbMdVquVKVqy2MalK4ylLalaEhRNe40iXFOxoiAMAIEgSDRCFQREqgWDSaGSxNMsTKoQFJtVTEFNRTMuOTkuM1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sUZBIP8AAAKAAAAAgAAATQAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",
	"burst-sm-2.mp3": "data:audio/mp3;base64,//uUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAArAABjAAAJCRAQGhoiIiIqKjIyOjo6QEBGRkxMTFFRV1dcXFxiYmhobW1tc3N5eX9/f4SEioqPj4+VlZuboKCgpqasrLGxsbe3vLzDw8PJyc/P1dXV2trg4OXl5erq7+/19fX6+v////8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAUpjQAAwAAAYwD6Zqr2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vkZAAABRkzxwVh4AJA4hkSpJgAKToRSbndgAuwQmo3MzABMgi7D8pVllzCEs2imy+KVJRDDkM4XYuxiAuY9ZOydk7J2Ts01GyPHjx48ePHivZ37+9379nVisVjx48ePHjO/fv379+/fvHjx48ePHjx+/fv379+/fvHjx48eUgRH79/e973u8ePIgAAAYeHh4eAAAAAAYeHh4eAAAAAAYeHh4eAAAAAAYeHh4eAAAAAAYeHh4eAAAAAAYeHh4eAAAAAAYeHh5krwgIBQFAQFBJEjBAEAwKBQKBQKCQLJkyZMmTJkyBAgQIQ72gg7BM/6gQOf8uD4P4ABD1wfBB3WD5/FAx/5fwQQDAgGA4HA4HAwEAAAAHgNZyYRgOYKCgaFEOcCja38sMVgiMlBEM0DPNJD3dasYIiOYdgaY8AmYrlRPwWambmCgRpEQZXJMwkUYAxIh4YUCGZGJwYUSGMop6dqAGKEJ5iQaYMWmgCk7nrKWK/ZfPTjgkxcIQEWFhYEMQJceX7mG0w6wsBlzERDCgACig0LgUeKC8xAdJQn9/n/cGAprpzqxxiBn4MUEwsPAYZEY4WzMFCCoF///+/+Ns7hppiXjUHHf0KAhEGAkICoqBhYADoECDBg3//////1B6Na7oQI/GPdRgLBhQFgIGRzWy5rXWnv9T/////////YdR937XXGocmIcxile2y1UqQKE52C7yi6YzSVmMbkL7f/////////////////////28886/yOUSy3///////////////z0NyKHZVAzCnnd2lgADAcDgcDgcAAAAAACWV5mRG04dCWPHUXYdeIlzLtwK/ZoumAYgUx/GTBvGBwko2J0uFwuAdYgc0hz1mjmh0vCiAKVAOMaLU0nBlCqQcphhUBgwADQc8Gg9+RMuLTQNgsaGdFpG2I/FJfyKHiIJqJwphf8fYZdFcHLFwBxP+RMWWTRECKHjeGjC3BloMDi4hAEcgUv/6DEgTZXIOZGiBcIuSohUbIg4dwsobpDi7//NCcRN2L5uQdI0UXGGuREZEoEBIIOUZCkh9i5iiQX/////k4ibsTZuQdI0N////kaQEoDGlwZomBcRKnG2AAAAABgG5AxAbuob+qC8hq1hg4p1E56JZgjJvk5iwRv5hlyBiQplh6MhiRBfFD5Qxg4WGlg/CFKvcmnInMmSNLarURuTzTCR+kScraNebZ7WGt25Sshhy+01hqmLzU8pnGtRaRQy0h3ZDGmVX6WGZyRPw4SxmvO9DTrWolRSqJVX1//vEZEEGJx9gVL9rAAB2J2r157AAnn2DQ01l68JeMCo1lhpg0+0PU8FQuAX5mJqtBc5+P5ZZU1mWymGYdqdqyl/ZRS4VrWNLq5b3/75KbOXakqpq9mtGrVLTZzNLcl1r9UtLV5lrLHHHHkql1+rGaCGYdlVqOw7ZkkumItnKYzS1s5TGp7YgABXjbYScgPokYigaQYp1AjQH46B/KJGwjNCIORYJQVEoGwlFowHZg6J3lY2Qj1UlQmjkfWJvkCGzAfX61W2a7XPna0t891OmWrPbW9GF3z1l1bW2uWvF02+Zn5+a17LQrfEsHVlfceiKw76credEoiJDA0KLgAATh6RwCsmROHennHtnlFgkiRnD7mhJAdwyEnQiI1FDYbGtDIwKghrjGW2IxkBIDRMiZEM1kS6TOjUCRoAoQOtAACsg0CmAswQMEQ6zVKCI1BE4ZdWKslIgG8hyNLLXaGcJiIsPUOoQ0pA1SWFhHC4mYMskZYgc4SExAGUWU0SbNBUl8CFD1nmolCcB3Sn8jLJhMmi4L6JOJHsMKIrMQ1bDYnKd+fpiq1t2Pk6y+OJ2K5AJ5RMzG/bIMJSdDpGuO1ssdQpFD4DHEP7fhNyW7DEa081I5hjrUNJIc6X19ig6plmfRnubs0BicobHNLEjyaqndZBkEEAFGOAZXq2kxl6s8AIxuisIZayF10VWHq9fjNlq5WUMSnZpmcaSwjy+YUMiyLQ3JqERSotHwSCeXlheMiCTnyXhGKpVWn3r7LULYbBU1YBHkdLNxPgFSWMFPlrZvpbaHnEnUWfZ7ynKT0m+GoFs5mIY3qdykgnWSZ628dv68+u7Pm1rxetzXQ65PaskjR3m9rK3X9oqMCigxcQzEYQEKVHTCGLozEszQApOrk4w//vkZAwPKHFgzQOZfOCRS2pSYYamn5F5NA3lk8pvLilphhsJYZzEyINYIs2IbjMobMTDkFOsyaLjI5FAIGMrHEzQCBwRgwemFgAKE46kzVpPAMylQBqt8w2yzJhgK9MGQdPEiDBlACh/lE2QesCBE90BpgLAEpZSfzJxo5QIVUB0S9VDAKkFQRLYwCUsE5USguAnUCgCIEBGhx6c7fF/GW3Y6x2AkaV2ByS7ExVBlh3iQ5OMv5qA4ErxMRvZhzYBOkGc6EGKikgXIdRzrQtJ5kAOeOlz6U6BfiajBJTDVBtQnI2V2wJJyYnCdlfoar0k4LMZbuwqhrjMlswH7K8ziFR25rNmFZjQ76mb4UerytrSvZ581+frwbQ9AAA2mxr5ZgrKXaMIkfWYMiX6h3YjDb6SaG2b0qqr+12BQistt3WtwE/w3N2SmpQxKDIsD0pAMAgplMPmg/GtV4nEo2SGBMV3RKUTUAYxAsj8aDyJIpVH+Vyc3pI8rSLlybN6V2ncvvvXn/BUqqoze9/v/3l59abj1ssdnku+ir5881WO6OF0c7S8onJHHLPVg0Z0ZGwPhrC4CCYqppkRWeNkHVM52BYd5AHIYJgmCZ1SGTfg1TmLkplBAApA1IGMxFTVSoIZAqZmEE5MYGDiClTucMJY0AC0xoGGIWbfYEIBkBI4IjCEk14xtE1W09zKhLwmmuZIIKcX2hLCJUuRA6CR1aQE4JAkRamy/h0ceHCwChoQCtFsivWqKXo/JhISyQBW5d0UEgJWtKXNGp4HQEIisNUcZoyhwXrXtAr1seZrDbWlmPC4row247cJileaG3Ld6u72B2HcqIh6ASdwLBLLA0nSRAjLTa9Of/8C9f38rcbRbya1s9l7k8bVZl6jOTHWsHZG1M7Ldpr8PBsQAgAua4WtTnQzL3lAxkQyYDVUJSlGBOkgnRmZY46crw+1dYjh2Xfh+GWUQw21htoDlcOv4ul22+fhjM/BETMQHiUCt1DA1oJIpVf5iijWIbRqRlGmkTjCCiVF3+z4gxiB5azhG+LuUEqtSKtR69RLKz6vmyDw1ct2xHWgh0WEaHJR4SeV0lV0R75L/+MOrzeu6l6RlPDVQjmRwT3AAgAAAAEt7m0I5rxubWEnInhjxoYtfGvFRtbWaeTHDnJmA4ZEDArHGDgxUXJi80Q6TDFg4ycJEAKpen0IGDVwlRKAt0lYgsNAALxWyqoQNIQyGNZEHgZJezQmTK+ShYK2q1XaQ0RMrNbHpQ4I2JEBPlSgDvRjEGrLYXtn//vUZD4EZ/hgUGt4fECIKxpqYYOYX9mBNC5k1dI9K6mpl5l5MQokJIMcAd5pwdIdUn7Ao3i7N9hOUoUyPhahmmeLYoyhVplH+aJCQmxN1SrRdVKuFUnmc/1UhidRyaXlUw8lEVWPPDXGIMddLKVftOZS4N5rjVO0Yj9lOcmSMPWK1MqZYJ7OaUhxT9iKyyhjtDeo1IioMPCrfKxm6kUrWppVtSR8/MSAAAAAASXbie6gYCms8FISKctVIumaQjR0tmmrDypvVhnFmXDh+MNRh5LCEgsORzLw6B+CoJl0lDyUA6LKEEGE4cB0e+wlREhWdQNus1dXS+MufjoCwzNgZcgtTGHIxJi0xBAhI5qRAk4VQjRTnMsimUy7OnwIvRrqfz11nz/Bv3qUFaMvq9qeACY1GZggCGElabCJB59YHCweDrqZxbxtFIGU0Iatthu1NGOA6YlH4IJJhwQmNyIYXFxhAQGXzoPC8iOBKIzAxABo2MCBQREoKCAyQFTFwrFElljXpmOGsa6QBEXkc2wiENtIwAgI4IwgIgYJiYxrglZRoKjgBZlIs0XFzh0K8AqYZIAsAQBIyEixQEj8/ihsrQkTDmsGQCwhn8Wf18Wgvo1plSQiTK8HIT1TqeFoSeKl85Ru+y+Ww9KJhwn7dxuqW7tMritqN2oA39mi+3FaWnl8ojdi5Zs/IpZCaK1ujtUoyE56pgSibt1NJa6otthsglsa16+FzFlWjOxTxrudQAC976iopCEahc4vUWrX+DSFgSoADpidKQL4IcO4DmqR1qEOknLmXxUoWozhMNEoxfsqk8zn8J8WI/2U4ES6as9wcKSLku0AklsswpBKPUbe2jeNmdjCGZZ8XwOoa5Lj+95eIds859t9r3DXu+3yu38nRqRHkNSuHCkkiJzOzXMIN4TvX89oYppipkEry3KqAABjYSQAQhmhEZ+fnBrhnp0Zg/mmABgzaYMYGpqAXaTkR8epjCAkzsCAzAJCRgACVlxiocRBBmQmgahSyQDL4wFl//vUZCEGJz5gThN4ZVSdqzojYSbSXrGBOu3h78JTLGkpl5m5oAMvCQBa4hCnQOtNIk5gdwzPL+iEBjDCQSFRa2lg5zCwyDTxCdmwhTLXRSRW667hu6zVyHNYK4y7FHUHUZ3iYUn0+IhAn6sy+q3Ns6wKILkRB8H6urmlcBRmznG0FCEtkgGSClKxiNiaZclSpSpi5cTDs51vbJj5Cglz1+TG9SvScNJ+ucJVcbl3Vl/T439eZiy1liza0X2UxUfdh1yWYdYZyZT+rAAAClhpV7+lHAAAjW+aERhIDWIyggRVEWhR6LsvPPLpUDd13VOU71MlRsMX60JxY4zmox2HXFbm/1Z/rS8muvtKUCb6xhqsOKw6nSJQHFVURY/Y+VI0Tbc2gwucVIGuQMmO1NmqBqDpWjZ7Om+dnd88d41/SBACbkyy5qc9oVLNH1sNIpL1X6j096ieXWbknmRou7eDO/bs5VHcX3GEBO83USBRuZcBmohhigkbummYgZn8Up86kqOALzFwoeazFxImUjKAIxwHSuG/CQGggYKO0AJFKUBLgCMAaUPTaL8jSl6N2SkYaidYDHrKANlbGPMRWMtFpbgwQqB9k6597E8UbWBu28aqBYEpUncQDSaWu1pp7iIuyl+IeW5EtLFa1SUSybyuJKShcksLqWqeRPN40kPcV5fTzYqxwFyRKJKQ8UqhieOpxkOwXFocCeoMmVzO1O2qVwjyIWjcs6ZirLKTlVPjzUcBhsrUJZoCFabWVZnVs8tIkdlrM4F9lmw8cE8pZ22dVtzIeLIvK7UjFAq+fOIaAgAK+jazGYLIQzgWLQAxULilBAwWqBONycDLNhzLchDYQJVkwTgt0NKwzATioTqVRIfyKQ0+zxOk/W5UM6KVZOG9QO6Io/3iUbWu0aqoyxA9ijeauDxipqscjuHZJ0rMy+h/8bXbNannvMf9OHaUWnxrZmfbmK24AKRGzHbUJLz5Rf1ovJnNO17MIv41agJ4FYKl5QAAYy0QDk5J4FVBr6Ab//vUZAcOZ1tgTZN5ZHCNKWo9ZYOaGuFFOE1l7cJAqej1hg8Z2YG+mht8KaW6g6HNnGDAhIxcMMRHgxHMSLDMyMx8BLUmXAw4GocTFlOW9Ck7ugUGbBQiCLLKeTfHUFUgUSCBzcITtLLnSoIQlBwwlwyFwAgoLJEIDhoMDAFoG1KBwgcGFrJZOl+3cZIUPQ7oUImKHL0hCn2roaFyE9EaEQWvKJLNawtNtm5KZMveWjZC4zXPXYqo/EqjDkKghGQRiGRiVcuFRSTQPlYQSaTh6TNk9tAO1Io41cXSstdhZ7S9ZE7r23apk7dpluGPJj1m0/Wszb57emZ3aTMzN8zbTOR4AAAAAAAAJ11gTUzlJkuqXIbtFHEa8roEhoFtfVSVVfurBLcVIITlOWsNuFJgarCyuElBKA8l4Tx/NCyBsecgHVCdaRgs4TRHBoTG4cd9aDMrpDllfC/zK08xcisvNslAnFC2UBXpABUydnYi+3Jz+RIJIyjgxEJMnpHuHJcZ9+uCCJvdUByR0aL0JtmgDPcEJnh1QwK5HJzmHzGfcmrCAm+ZvKIoJvHi6DWmzGtRZE6Vh4IaNIgTefMy8ZiBI4HCBAQwGCUQmozAhKUSHAJaqpckkQC8CPpFAZLbC0OTIhoM0hXdQnuYxZMMxg3gNcKW5EIZd1niLTjLUCAmrggELQNdJh/E+DbFmKUelCBgpof4emk4DeFvylzKVzQPUULQ+SytM8uahQ5VmSzHGkFy0J18nXkZsVSuTF3pytTLEV8Vu1NiRxeX1mM8i7xC3XfzG9P/Pmv///z9Q5UHHiAoUwDkWooAaAKzHBszwFg6twQh2kMxnQEgCXkwi6avGRNTXM+i3WWrThxhL0tyj7Q4AcJjMNYO7AMWh+KaonjiDOXCYAERYD9SfCMGgmrTNKM/HF9pe8UyfCffW/nCP2L77HpbWcirZlY1W0Fo8yM7idEQekFJF4wml0mHYosJ0+Xh8BqX2H//+X5+w4UnqNHEu6nrcGIQAAAGfJiFiRwV//vUZAUHJl1GTjNZZHB6prpKYYZsF9EFNg1lMcIrpqj1lhopaE01zEy2MEBSIqA15piAsACzsLuxUyGPQssDoZjD7fGMIGrEgAkIdEVwqyZsw0QI7AuG/UlSvHSCgNjBfwHQpFJlCMFVUOJFEUyBpgECJ1lyF2rscRFNKQtPHS/SPjypGPGoo+77oXKmdJmzW1kMZT5ZrViL6QW2BTh12lKxTLVX4ii3ocaPjMuO6cmnnjEl50fh5TCSOQImAelEkWRwGOpFCVO4mxfBS0M5T/r82raVzX5441lCjr6GJFIEiRxO8ShJwAAAADPGYg6jfBFEJBeKw15KMuObBImO04wCTIqFYtjAkp4y62vCksnR0dmIlARWHWIaEIxurHpWVVqg5gMXOSJhSFKYxcJ07rIHdKdzUC3ckqESyntX9ZPfvz88VllFZa+kUe+bU5hYSA7IgudRKjZmdHHB6rQVYwyAkBBR4SaLCJIjCkjQoiqLM6MO4CQkmbOkwMiNggAXRC5smaAaoAD4JIhVVIsRAsPVuKrxgrgFtpiGBjnBCLDjELS7GiDMMUsUqCg42MTBoUkQQgAL1MRIRxGCyRdidRb8iOZzA86JAvemJDCg7J00li0cTfVjlK37O2nS1siwrZKk1LXFgGQM0ksXeKDpA2tqAZiHyixQNrMlSXtEA2OHCyA/hV67cnCpiMaVRVsmpU/Ss21x5U5TVDwkCzpalkAAAAy9Q4FpsOeQCDJFvkl0iakcvR95TI4Ut9qLzNIZNIik8DRYZEsjLD8IDxVInIYkESsYRlk2EtpOSTYegaJxz6ggNo8fQodaupO6Sz1UbiWWp3tpuEJsTnnX0tO93Xps7v29bcgR5BM7TU1Ph6C75Z52/YTpTP3fXyE5ubAt+2JcCAWIdLf/1QABg7QowAcwJIyZ4WeG+oCBgQhDNikOha4CuxACMhGY2IRzAKDlAMkDQgFswAyQxMxnBKKgGReNS1GYQMgokRgJzMnbkLDGCCLLFzmsgVIvfBa6kqJQ//u0ZCsGJY8/ThNZevKGyUo9ZehsVdkhOM1hj8n9KCgphg5pgPRFSJaYmM+gyA3GN+TkPDKrRShZYBsn+YU7MhqaWmkurW2qImq7Q9OLRbmGZFpl0xuTyytuf03fQn+4Ufxm17BntmsS0Z/Srx/41LQrpjRZAZQmd6H9v8LO7+JywDIAAABT3eJrw0wGHFojhHMNwAoNCfRR1RSJEBYKKohLMn3RkJQlhOUNexHzEoI+D+jKxGqkolw1uh8oA7TwUkdePJVol8qzXEQsQAyKDyptsdjBAqF9ynOGShhzvy7kEcjkjen5fva+7/debiEqqVYbu3+VIfG3I9sVYVR4/c/ohnN3FOiA4boWQEDPQAc+MRKMehMQEHQBs1JkjB1jRFdROTAMuhMqnBxUoIAOYGeZjl4UbE2GtiHoUO2yVzIWEk2w6YdhIRfLjl+WctMaOthHlYJm0AQU8zuO7aLjQQOAksDP81VwHBf1hEFV34cGq9sGOCrDDEchqEO1F3QD49IByudMjK3JD5SgIcCHrBwuQ1zfpvXNof40/lafaOPY52nVr+ubalpzq2aydYo3FZbf/9IEoAAA8HddwuWDuiJYQkvMgFR+R2rqxu+w4RmDCP047Y2WYKJuy30TOg7UmKRZAHsLBvAsoXUgglQWE1eNIhiWjJzBkVVz3j/pktUvWUJ29Yg5ytGZa9qqhB+2gzcpnzaqPo3N8+d5YYjQjyERTzk2NBAbJRRgaoHoGqR6FxI0ioAAADgCgNDC5cLg//vEZAWOJUNGzjNYQ/JvR9pfZYNuU1U3Ok0w2lnzpag1lg5pQLxDvo4TARcR6zfFDjhgS/M8/HhBkG5jiJcMtab6IExLJpQXnEmD6RG4GEfguOjUWpXAtYv0sCy1ho05ajZkhi8K5EErjo2N+mDPyVDZi0gUqYa2eIuvJ5iBFnOG/b+uk1OIPvAr4wXLZZL4zQ2ATAEODA6rEeRgTB8MJEWDibOBxSohWKlR58Pas3CpY6fsnmv//UjRLG7+rTs5v1BAQAIAAAABTcIDA0JuicUYfxpJCIt1KKWsIWGBQTwkxM8LKn4kiUgiW6uKGXQ092Dxpvn17TXnTSGmcWrKvxv0WNsUo7AujD8zrt2eRrw0s4RxiuHMFlwmIH7Mpp81qkcx7gG1/CMkVHPdNj07v4AwcIaYYqHMSYokccsqasCZoKBh5MgDHYGnhCMLgCyBZ0aCDUMZAMSdF/QoEHBqtgqBVTgRHdcr4MQXLEV6I1IElgXna2x5zJZStykaYkidqkWFjafgLEMcQfTrbI7iknA2EOJkfjY2oaaT1bO2Qw49ENh1yHs2QuDit/QQB4h3ysiPPuecPeo1395vb7/F7LPj79eZd+flc0ls3QAAAAA8HITcN0o5GBUd3A4gDFgoFAEleLCqoOE3dEtrixnxiNA/zMXxzEq5qBI8TuNL0hJPikVRWHZgPoNRFOHh7VE9WSB1PkrC5EeUXUYjZVxV/vozsEVZgZThZEZn74n2MjM++pf+RHF8gpN5Xy4WlljnKyNRtcK03w1VAAGCLIAlItiSQWQDOSJcwaDrHAugAeJVAUki2nqAkiaFAICCi6jSVA3+SNLfzijpchA8IASretVRGVu7iKftVWsvg3zmwDOuMuxkciboyWtDANwpBoMT//u0ZCuCZMY8zpMsNqZzKbotZYN8USkFQ02w1oIDpWfplg6ZsxCcGw4n4AagqHNqoBbLCZaIY6mygSDVGrYltAP4H1x3ajdGhJCrWa1ZEeHzv5gWYU6OCuE915mwqr26enxX27PvKAMAAAAAF8KNIB0OCchBEZbBkAmICsxMJOUuukW1SmaAviPh4RfA2YluwiCSdj4tYTHqfk4+u7I+FA3hOCchuvME7izZee8z3LI8siVVViw71DJ/61MtMuISQl0+HmX//wvL7fJP8vlBeM9SzIzjg9U0N4gQgDKDixYLhaswMDwcLAJRSYHRRFAGhJestuEAJMGKtU3Xe1tu0Lh9vmZKSTHdlsEvarSv1EJXKlnuEDqkrBm+0iHAdhPJQhnawtJ4iSfIzk5Et1FhIfgsHwomTKBgocWDCQGkmkU11TdSbGG4RJn22zEMzd3+bHL9JPmxUXvNRAY/GKJXpKN3+CAuhMMxQCYs3CyJ5iQIhMZYEqAkkYBKpAGKRajLqIgJbwpnanaPjqSh4nkghW+Yj64eAX0Ib0KINR6B4sPhcjcBUd4yoemA+tlVUrXo1OxuJTkEkewksxhbEEM3NVIdDCI8eGVjDLNG59vuQRsER8KNl8or5x2qioYNSZNHBL6WgAAAAFAc5gcmKtEqJhLDR4CFBT6loKCOAAOLLgrMEJaNCmIVAg0gJUwTFa01iTtkL+xtt7MUUtgVia5U+mcSNeLvuEueHVh2SNJaRDMLZrDchmZE1KYjD3yiN2oG//ukZC6GJLFAzzspHxJoRHoqPYZsEnUzOmww2kmfHei1hg2xfqCiYlaMIBSFgbEehjJAohEZDZY1CMlSJdpU60wg4VjIweWq81CXiCQpblfoU/hTfiKnv7XRvc8dkEAAAAAZQ/jhQgQYgQDqN0DwOQBrLESwT8zlamKhZJyCJRWBwQyQYHLaz4Cf91p6aRulM6KxkPXOn2uLqE1soDO9I3jHF7MPgvBECChphaIECjzjQUBEstNN4DARkKCpi0XYddfos7lBTgt4GMMqgVZCQZSmxKXCIx0UAMGUwtlWpA5aD5L2MZ2kJVvA1lMRcssHhvg/O11vLC1MVDF3vymQsHBMVikOTjX2srdmoS/jwclQ6nIdgvGVGFBqiH4dzMPTYtrlS2Amu86fsYMIJJgZtGvZ2XOEV7BWZLh59e1I5D0xowp8RKeJ8f/Z/+FZZVlYXmuRJsnhk0bBMBJBABd4jfCwdAepu2Vr6PhERrCQs6uuOz9S+Eh0XxyhnwedO7Fs9WpDtStM4jdfqU3XXMY6rVDJdiqBiQ74x2kjdzy0z86JC1//LTIoadGO6tcttzOx4F3ML6S3qn8LI8FeF1WZvD0AABOgmmjI0iMhcSZk6ZkcMmgy0cgaPhjHjhGCQ5KY//u0ZA+OJKZIzptPNbJmhTonPSOYU4TxNm1h6cmLFOio9I3wgIAnazFFdoxEKSudgu00laSiTEZ2XRVMhYN40FE9EhBNjh21opEm+epdEQSRjZhczzLI6FHdBx2ikadbGIxbYXJxVafgsLRJVnkQxFOgIIpVW5bvafc54TKT1LFofMl09XRkxl3iEa+f9fzf+/lHcSfHrnmaqNwAACpxAfDLEMWgWQfwM0AJH8JGW0lSqQ1qTKFJRmYh16ndjsWyJQ6Ijx3lygq/MEVBloquuxNygTPnfbFflLwlIOfQ7xmyzcI+ZviWnX8epg7/ssRISd9HJ6X3vyAcSaem2Sf+fwAwA+48KTojDmxDmRHFCEGkA5EjelaDjL0WMO3BgzGBOUZOVhbkdzpbhylhlerxcsVSiAgET3L8mEkykUzZYEsuXuSFiquoDHKXxJgD83hhmmUwGsdQrEco1h4jGyuTgH6bp1Icj6GkXRFIS4yx1DFmWnbWkHLLMyUX8fsU1sbltjMCNmZ5JW8KuLVrZtk3VY70sA/f9S8pPx9CdiSCIAUoeMLIFoIICNijFOEMaRGwa5/lYdRbUwnRGBzJQbHQcUDgjGydooOAJMgIxGhEgqkRk0gDhu2WkI0FCW2WiOo97WC1t7ChrZ1ZijJ8w9pwE0AVe1CJp70h54mmTt319CqQGAAAAX+B+Fr7dizoCBYAgmLlihKiySr/tAeRpSccxB7WlUmwIRiRg+UEwQEpkhiEdA3BqTm3CWpLjUJHolYL//ukZCACI+U+0dMsNEB/yMoNYYOoUpjvOGyweomTEqg1h5l446GJ44egBiA9I4jaAqjEWq6pGNVdTtn6VjIU6mdvU/QNkF71S+6Rz+GPNJGEnIp2DWdgiLKnyz1mM82nRQAQAQAAADOEiAYlgSG4WWsCaaEUxSYQovQvdY0CvhIHjW89zY3BppVCo4sLnIZe0YZpC+CJ4IQEUoPD8OKI+LB8OjMV0RydD/PJTlCOi39HzpMzW0xWvi5n5hSI2cDjtq1aGXIUkjTupaZrluDOFHi58Jj8woqhECAnhB9C2NtAPAxFS+4wMCqzSnQxBTYeCOBEo6TaSxnhAE0yQy4r6AwpkqYRkgkwwdAX+SFRAYMm+WhgZ03IDjmHLQL8PYXtbZR1Ds1hT77LxkTdnehlfbKYxQjSEXHSsshd3mxVFLIhGak0Edg4SnCNCfadRMFfNxGeLaupGFGwuhxJCtCTeHaTUcGPO0y3sRp35Qp4uL6aMNd7+dBAAAAAdCAl55t1Eyy/qd6i6SKcbQRpBypE/dvWZBlvOgoCzTDOsTsbK9Rb0/GGZFqRTvjYcEmr2hcRnB1Calp8q9JWhUlj80utZcTUdMPnGAE8KHh50SEKVpW7Yt1Dr+65na/TCAAAAZQe//u0ZAMGJFo2TrssNiJwR7oNZYNuUX0FOm2w1smyneedhg3xoraJniTIN5NUoAqkJYMIIQAqMBmTGILVIS3sVOSLsoFikZ4HTGV5AtIkiqqjtDymDVmqtUb1NB2HSbooZSUrnxc/CtlKOJELQrDKMlNwn5IOxGIZWRyV0hAS+weuGyCvO1gTYGGJYaZGUW1OaqHZlxB1ej8Hm1eDrLRCOFF+5/5uuF/8VoIRgAAAAAK8V4dVINDuu4JsUCkRijmUAtIgDQQuq+DZaPn0JEDyg1HkSB6JaEPnwZCf4cJ4mx+f4prmlLZcXmKXjBZZExRm14uXEEfvyIhPHdafmdNmO56SHW/TIyz0zygx12FZa99W2T4pZMzzt58yrwEh5eYUAlVEKDKBNcAoHAUKCgQXCGQ6NqMqZpkrDKUlnk531UJiCNCz1/4pjr2bM268UubDU4uBsGoDDIZqSGJSEGhWjNj0ciYOJTJ5bTupTkvMVMxLTl9a3tTqVNVt3A0kCwodSWpR40hia6qddLWlsd9tt+oo2Vm9nLbyVo5kX6IpCRpknyb5E3pAOcQNBaNamYUQCDBV7M3HSwaKzV1HdWOx2IrrSDyYAcdBmE0b8pxcmpUilgkCAjEliNMiITQ8mJfcZguTkyowUVXtxOtXbCNkZKpXnaZZsf//hlh7ts+x0tTrZ4zVqNHLnf3d/hv07T6ZvfxAAAAT/ADnNEC4IwqNG4VBw+MjUABEDclYiCi3mlNozVHhnrosDdR1pari1JIp//u0ZBcGZCI8zztMHcJy59ntYSOmUwUlNE09FRl4kCeM9hqQRs6iUbhpYGktri8GSAlYjLZlUwiIJvGaIniYBUixl72GNukTrVtjCPuV1oustLir8XI0mZOts1rmKpSMMmZsnMyMCEu5h4FQPh7IM7cMnGAecy8W//kgSABAAAAD3A8YvbBDJFQphBATVYvCgwy6B+vtAjdXSdSPU1DL25M9eGLN3ctsnppHiNGFD5WlokSYMIBYZKUPBECjEuXjirTT9TAaMVrPQWqMayqUz9//LZFND5y37OAjjCnLDLsGL5QT+ZMh3qfpQt/rjYbssEJCYUZEEZiAbtiBhpE9InxjyBnxBNmMMHAx+CXHXMsdFF7CQIFgiCqfTusgcQcBjgNPsAXkzRZ3DvLEXtXBH3Q+BjrxwVTgejaFlFklNc8FG35iML1gMx8qD0Xr3WHammY46feoXecF4dkNmh6OUqhjiCyjRrE13ZrWukUQ1TIiWrcD5mKrlK7q2+HuOsqlD+DHrPpBlDdDUhpiRhHCEAOIswGuXIuKHjmP6U5TLXT+Rck4b2Yfh5uC5YHiazh4DQ+EIq+yR7QkM1HYYmbYknZaJDw9kruCR5h4GAyDxoTHXlWEinD4nlurZMBJCa7HU/2x6gAADKD4EBQAVARixRvTRpGxMZMWDIlJkRxIJNkAMmLAScoEF1E7HAHExgqjNqXWAohIYKMiEgBC5kI2AruWQsCsmHiYzZJazJq7WI28ElhU68DZXKbV2nhdaMR+//ukZC4GZOtLTJtYQ/BiBMnZPYaIUx0nNO29EYGLkCeo9iXQNUTPLrlz0WkMssUjpwLVv1ZS/lWJxiXBY6Cs4QLRCeCSSmFhQqWhLbjy5RtnMs9yYakRIW7hbmvmK4eL1ofITR10KAAABYD0DRFND2FaC5QwLEtpplIe5fidWNVfO0fTtiKwJBsJB4kEAoqF1kS0AghLVhbEooBIAcYkI7PBzKhMWaWACTPzTCZxnVpmLna9wW5OqTksSA3E/ZTg1j8P1u3uP6EFfxNtHhkMGgcihACOA5jIkYEVoXAYUMHAggCTEJRMwgGU7T2cQVAksF8DMKsTwyA5TFNOKOl+PAnZ4oY3lmMVPHGeprmCUJvIldPWtIH+qy68W47VC5KhDjHXJzMC2pVU2O3z/yakhR4QRMqw6lXTEj0qYKEG4HOhEqo6JGj41klTLTl5ptoVJil733+poYwUUZIyYnK/+iFwq4CpP1EgwgYZAh6QF4OkQA5BsoanEML6iCYCKfn5cODUoi4XFuAYidMaGCULEh4HAkImgq24rQNHUzMRCwk9yVxntuYEXmgEEyoCgtCsKzrwCcb74lAKh1tbl2QmRu4o11VQgAAMvBwQWoeIwIxYDEZKYEDlujARLFfDWCcZ//u0ZA4CJEo7Tbt4SnJ7qbmzYYOaUTU5Nuww1QHnJubdhg7QgoGBTwi+SQ3vcwxk9lhT+RpyYBdyVxdm7Q2Gtjg9gMcjMrkbiUD3nQQCgqDDgu2xJyJlUgsmRcliXklb5oCjKWxskdFVl+NNOut9QoqIt6Azb22ZwUl6mlsmlIG9kjKwrFWpJWXgdhwevR3baIAABXhtGeCIq/kfiFhmG4SP6swIIrLEAKBYyiz7uEy91lClox6knSSQFgHS6WuEUGY+kstAZCmg4gLbLCAkLgkmWIESnTROsdbVIqcuQ+iXfWKtoX/vcY6ToHaXit+acew/IvtTpIDGDZGQUyhXLv8cSSdhUqnewNZ2wnQEDN+WRfQWWDkL1LqFnmCCszK4EGJppcOynkj08TlpoQMwRkywTcERYGj6RlHOASHkaDA+HAuFsAe/HZPSn6YYJVi6lqNJ1x+wpsdRHuMShpnIMOFhUl714cpvphWZt7ye1ZMNqHBmpBi6sumIuzxCL+SUak+bszDN++VrefF58mYfWWFSA8m//rIgZeHgamnSSDUm9IiG3EuGIwpFjTBKXEQHhLhs3aWki8ak2Tu7Bzp13IkDvRpWBxJZA8mJkpEISjhaclIfRmkF8qUlVKcv/b4vfV46JmIiTHjPKdIktyw/TgQKIFyuFMhy2NieKxvYZ3xn5PuXNZHPsDoYKmajFEGKlQAAp8AGHTmaWIyJoCCqKb5n2YCbgKIEDzDGzaoBACCLBhVJiYAQg4RuodIFZEJZ//u0ZBeOJcRJTZtYYvBoh1oKPSOkVEUfMG3hD8mZI+ec9I7Rf9DkaBBd6Ka5jQowOAXEFJ2D1/wI09OtPxHwuIpWr8eAXnUm4y1F0Oa/ZLE0pDmER2FgUH4+CQmSiQvXD2OQHQ7K0B4jUluQDn44iMOgABYivGJjI4LyunE4fBAK5OPR4rEfsIiumXoo6yXB7bMEEfToxPzNefoZ0YEhOfv4vO42DBY5de5oPm6yAAAAACloc19Cw8FyLaUAuChQ1IhQkGhR1KtqO6YyEa2kjVqSSRyurJ5NGjiQoGBVO2DdIyEbRkACItFyZogUJtWq5kZmAGKTrXoJjAAhO74zqegTqhNDuWY0WfR6ad+BYdPk4AEQ+48FQC7mFQAxAcIg0w0qM0FjCwsqkpkBOaCwGXgwYBGAjpCMAgeTHLSmGBYaMAbB4DrQ0yEOGKgcMDKBqDgqqsiv0iRkBMMsktkLgeZHkMC4pdJkyC1dDZG1KlNWaYk/Umftdu2qur8Tj8hybk8MSfqVxFwW9q7kNa/4OA3D1iAdJND4Og+g2BY6DQamxSqrbONiefhham/a9eVqG5X1NphY5oaigvcGXlFEGMgICPSQESUBCF8SxvUh8nQ5K9WGuszmkhq9JAZWB8pj2T0R1HSRNgu/XoRT2CEgF+ihBtdl0VlvJbPY1YqXzU16YZm5TM8i2ZeMdKN//1elD6qCV2OqvVKAQEGIGbFKAAAMAPdJhgHBwcYqjIymfL5hY8LBZoRoY4QmesI8bgoq//u0ZBCOJNo7ypt4S/Bfx1ndYYNuFQVLNGy8z8m7oGeo9IrRLaBgGEIQoSCIFOgiMoCyIgxYtusEDGgTwLkAWgMgOyEBWGLxg4EZ9a4Jm09HwsoAkLgGQrEVCp2p2tOnUEXYnwlfKGXvdeXW4bhy6H4fbPPs7gVia03/uYX5qih0Ln25ptHol0ab5riY7M6lD61rb61KHh6qL4SgyiUrAAAAAAAU4AZdOyuboiwGmw6pbFX/lC5k+WlUoehQPxNPrlIfBIL43kOBJcsuVrT06OluiQilmzieI+UWGhZZcUnVrlaLOy7mUWoEcz3cdOG9t9N4eaf3761PvyCAEisG9gko0Dhcw5LDKAMpkFHEpJJCj8qIBAxwaNSubZXE6qJS4iFE9FzPkoDmELD5KsUkJWnBbB2G6Yx5KYzUyZBGFwch02OFDCwme9ZEMZFY0IlSo0xEanTsUikRicYJUmk3kObb6Elgy2WmFpAijSBC78Y31su9jNd3qPAQgUADbT5MnZNokmnBD99KABoOxicYDpsQLAZpMohIDoEUYg/HPepeQdeSeBgaKIAX4fvAcBBRDhTnw+AfAzzxL6oUTOsI5gLmP57ZrSauTrfNvqA/HpMzLdnWVYRIyJI3MTE6OSBLWmUmGMXXXyBCNOHA4GLVkU9qneRlev7tyXkdE8DAyixZCLZAghR4gfsA2pEHgEdJARpCJ5YPAAAAAHdQfIjiHJiQS7FzjU5lAiE0SuCoAUCN4hWxL1E4tYZxIKMLxmCb//u0ZBWGJQ5QTlMsNiB0yOn9YYOIUo0XNO08dwmXkOg1hhlwcVIu5lcCI0KncnB31B2cjolKyx03zhlwFbS/zUWRjEnhVxbHpWB5IejuPKJPRInMjkrkQhxiIVikVkNMumtT8QFq6RRWXO2Zl3As4WzByiJ9psNlb61FSkgTSm062lFqivNfKt6q9nztfO3+Zvw1QZqfOyWdtlgJGCAAAABbxVtNybGWrLPkRFMhhhaxZa0kznSdm7BKknPbovSEDQ6GFS6sdLcjkhF1ARnErDtoJYH4zUi01DMXYw4Rs1oFB2INI2tM+8Ct2ZU/uf8GchgRgYPZHUSogOwIctu0lJSFarn3LTEleg2Eldt+X9EAdADIBhIRBzAqAYqBDEoaobAQGaIsZEYBACeKXBMRTRCgktKVgLpa5EsIBpYCQwMFMuYsytr8TYA27FQaCRtV5krOyFmUZ5c1edBBhrXbyNsI3inUJbHsWG3nS8UaFthmtqzHZY7g2sU8NqXLEj/hgrWJJLbXlzrroz7SGfbLW8S3TVzISXDpmRluQOKbCvabTpv6AYCiAArxSO26Ct6N4AQWeVmXgspVVTMew8AIO4FA6L6ssHRMGSdRARUqZw1hIhyRjEtKEI4WuNBJAjzKBkQyfRSc+NckYpPGiYeZJGmWLpfJNOkIx7qSRuaFDzWLqDcCSUfAUfhugAAAAHQAAjAQTLMngiCJj0TgcIRJIrAK8S1QTKnK0UBDcyYZDcLAtZTCSZBQ7AlCVA7yggiG//u0ZBsGZL07TLssHxJnJUnnPSN8FQ0TLE081wmFkicI9hnpXmBD00AsUjdDE6TBqHqAQ63VpkCsGXKuluLXXgfiTyDTKXXrSuJTUdYRZflQ4XnEYdCYPbWJHqZqy7RlHyAkif1rLe+dR0V6QgbDtczYxBDi0I+PtAMn/ROQPYsS0tv3tslAAABUwbDKQ4lw3jQAlznCQhmOQ6y6rxUHQpE6uGwRAlGSCkQFh9sbIABEZHAQyQjjUCIRqMEhOGjxU7iTDSXlGDcXsqRVCCj6IhESoYJjYj1pDiGuF3h9xgqMePFn2yVhIgo/mtOgPBp6BARmIgH+qeMezBlMzpwgLm8cmDpAgSxhSQEDmNNvqaAYaYiDEBKKMaYRjHlJtSg4DNIfSNLoFklzIJWIEyYOJMcHG/AsFEDeiDyK4DIWh3HcbQ8zdRI4VCUaUQZiDLQoOiAoEeWzEkVPk5Q40i3ne9JC6P1PGTFSClUrk3QWyT4v38UOe0jT4LOmkp2jCzHedeCVXDX/4fHOmkpl1BYqN+f6Kdqqj4iCEGkMsIoL4DWDHGKTQmp2lAJKQYc6OKE2AqhoD5+yoNyYO/l0+qO4GSckUiWhe68sDO5wP+rkzyYHcAoInGDSU1rEtu7MKIpwOY+wyf/iLRmqnzrXNsxNyL3rkTrf/9oAABTg3kSswBXgQQ0ODqIFQztuHgwOmFIxCqCkzKEDkC0RRDGU7i1zSk1DBLLpKMvOrGKhjwAQOhKX0kEr9AUxNocrFi024MiL//ukZCSOZOtMzJspHxJphNndYek6EyEpNGy800GQnyedhgnx8LBsMmmKQY3GKVH6eFfTdoadXOL47cWYkYVtGQFhUIlwLEZhQw0S00Qj5Pz13e5q+wcgIGgGoMCMwRpwkF+JIkD7xTQr5fYpkA/tQiv1RGHil1RGMBAAAAAABVoWFT7aStMMOHSMAh7B2JosRMGIm5FohOrChRqEuA+DJXZbBOXHS7BKVYI0BCRGgdo6MLBubizBvGyUSzRlZqIupW1V7ly6Bmadx8oJ05UApagBOHikgss0mTOm2OWPoV9T0hTcwGRGAIiykE1xBDUYIxUFGEDglFpAxUoNL6K7XygjQArFcsHCtfVELEExpc0mhQrwgzKPwugNwsY9B1FWOQt47EinYUpPxZB8hbpFSE3eJ5UohsUyQgK90hqibsuCeovu0w5KGI+YtGzG1iOsU7yjXYDhbEinzJ2m8ZGzniC3jDsP7R3299/7jzmXjJMkALFROfNHv9d8JjB3iTXJKr4CFCgVQv011eb+JJqXM9lDBMp83G4mQkx0jmjBZLIloL6uI+IftVWavLUPEhlBKjSdyV/OrtWtve1d2Kk7ginalNit/VtN0fSS/1UisapxOhrny+9pISH7kDuveZsA//u0ZACGZUE7yxN5enZbA9oKPYZaEvlBMO0YfElpD2cdhiVoAYDoYoGyQCBIwbcqR8wAnNAIxq/OJizy4Ovs1jTFJM6MRVGmKIrFrtUMAABft3aeAhyEU5CRuAVDU4LtBdpsLXXgGRUEANFQJF7kErfIhrtH6jA4wqiuOEaAwVWdQhJ+MQrQPBmCXQ1zJQabC6PU6E8XxC3NR4dObK9jtEJQtjx871JAkfw5IOIM+NYr4MXOvTNc5xvVoErA0U65rRLb/fzffoReltL7AAAAATvCubSegB1BgWQHgLpWJYXdKlYVLxBGsFSxZuOIuQHqOxi4djoVsOHmZKLBSDDiwZTEZSY1PJArsxIbvKnngQeXOOFnjXhkbGfLKzCjyX4FJXqnX770QBXg+aIIBKoBFYjAgMkOIxbEc4aEajiji8oC3mAAg4GClYFEBAAZEgYQMi3cTNDgiKoYVX4jaLAC7xaNSDO2tQKkc4q0EvVbUhVbnOm+P7AbY5c/2Vahhcus3WnTkagOJONEgyIEaAqg847hxjKJByMQayX1lrv+DMK8apkPnT0yBcQKlssZjOnxss+CKrl6uF4mCAqPx4OAVwbdlkrRNcpNQQCKwNKU1We3y4S2AMCQI5OsIw6JnA4xaZJicNRGHpKc6YHHqjy7I0TioRrEGKTggf+UJm2wALmGmyrhVGl1ly0pu25e9887WxTrSTtYpdVVAABX+Nan/LMCIZmGAzD+DtU+JJ2gYaoGFplrcFNwInG9qSivBK4W//u0ZBOGJFY8zJsMNiBrx4mXZSO0UMUbNUww1knHoGcphgqZIGBKBJgMXRtVgS5TZVAkOwZYVicDxCHZPBb7t2amHB0BgyE9lYX4xgYVgMUFEW8Z08KqyLYCvG+opbj8bNQkZmIF9pRdnbKTakEe5e+W/13qyKj7IC4SEUqfeVBWFYpuvd//pIAAACuBKmUyh/CRwBahy45ENBoXSxB5Acy5Aa3CKKOtQLXIYI+tDUWcSHXGtqPV28cp9IjDTwko8PoGROFCBkAiNMzNVZ7CXQMiBD81KMj9FoK/MM6rw7q/kRZ55lM5NC97niHHwb/3ZOvRuAAPcJSKVjrDIox4AtBAZAKmEITA96piyQWADnIRNRaTACTDUizapE5ANeXPq57FV0svtLofF5Lo7GAGBDEMcABUxooMSkUGYYzl0R4YYRMkQRIEE3JaWdJk1j74bc1j9Mf/H/5gHTobrwrHid3X5yJo+r1GX1/GcycZ9aFaOT0RyP9x2r+ChKAA7i3AL6ICS56e6TbQAsJOdAAqusCnWmY8tR75OxNnC7FA4uig0Fk8flMqEAHwTFRNAuPZOCQDgngfKxyI5mZGvRnD9st2ncblKb6NMkGpXR3Zm90Zur/2oy9/yQ5yGazEcQq0r9yD61y7+Sbztq21IAAAAAGbAeYweKiwgV1Fce2DmvazAZChJZ6koo43JizdnuqOG6EEqxRo3HkvHK0IR9DwQB/HkSSAOxNWnKCXhxK5g2tRWOVh9Vi9njF+erj61zXU//ukZCoEZIdDzlMMNPKNCNnHYYPWUZ0fMuykeQFujKdoZ7AgbL5YRsL3CcTV1ruHx6dF1YqXV//6NAaLhPKA7GPlk+Kq9xU61DS0ZJXGRs+Y1ECsYlJPBZ+12MGzXklrTJAAAKl4rbX00N0EKR0wqNSCE1vFNnbSXmVPOUuVQcuynMudqLOYOlc1cbqvhczDYktZFVsUMUDMWfNLZxB7ssKXQp93Y1IpmWx4v2bcPiqw1u7tFUNWn3bIj49Om1D0FHmWF8Vq2tNJ73L9j5ZEIaRIGQinTD1WaXqz0bL78s6ygq69DWDy16b81S4iE4AAJ2/BUELEAk8CmgpckQFTDkaNqA1wBE8dlwaYXDdMUOZxF4JRKBAQOcX6v1L6G4yzWAYIflgdE1xoD6rUxwsOlGqtcFU0AJ0KQ0QlGV6zcRjKRh+JkLZgyQn2GoZtDSqxdhqaY89TzhHbshBxyQniZnWK5Csn52lIquROrRdjq/r1MUnBFA1GFmf/rIQM3Bgg7UemBrgqQBsY5eEYkQPvi08EoSG2h6D8G8EFn2VonlgyLwhakjWn5q8OzBsyvsVNQgmoABEgWBSDgSJiIOnU/oSenhExLrlg8lhAcpstXQAFWEqiRwIKAACewB6ZIgkC//u0ZASOJGlEy5tGHqJvRlmHYYOYU8VLKG1gz8F4EOac9hmZmAEGaBjQkBEQYAEDgAFzLCTJAWEqZmSHl8UQl/MadlA1BKwVnyfKoVOFToAH2aBB60XgRoWs5SkmutZjjqx6pFoJgeJQqS3b9YfJEjSMjETiijEiLKxVn1ENAUHjWopDIbIvNeKzU2qPQyvzY6gUhYdxscLJkcOwIeD0bJGlkdUXD9viD4AAKdwhtw2UwY3AQDBMAdACgQtT3cpnV5RZ6m1cBPeOvuqZqOUNDiEnNrSX4KFp9HeAwOkpHMHjUrjZFAs9DYe9rrK5ZWvTvgwRE4ZEO9JllyUj95blGwYsNCe//pSl6/9Srcn+RDSnxH0M+W3focoPa4OoQHlCpzIIQdHMcMBoczqAHRTawwFuLpmJKIPI3gkumGVAmQxiUbJNdAJRZ6Elb7ngKDOZImIq8SEJFYm3WiVNGWHMJfZVkbdxTV55iGJ1+6J3Jmhpqs/PTj6P/JJz8piZiPHiyleVXWoHMu0obvUN58agg65tcLisxK8bdNnzMbud8xpyWltv9698llVfT9O/+M3O9J////7UkLfhRvSaiGIoRVdBiEnOUqH8gyV8PgSJyKJMblN1afuHiseoqCBIZ4xHAJaZGaGmIHMmXZ722d23U994DM+k25krX/52BGrhbzILUFKhk09Zg86Vasn/kWXy4fTyugALw+kZ1AimZ8YSEhRYacKZsYYM0bZidEEVnjDGTNjDNiA4CoC3IEgAM081//u0ZBYOZPw3SRNYM/BiZrmKYYNuUgDlKG3hicGLmOXNhg4otlrUtFhgAovonO1MqDIwMGaQTMS0K1orIzl8VtjyWTumw1yGLr6j0WhUFyp/3SmG5RR+4ch1PZ5ILa9hNutPU8N5x9l8si0Q+yYw8cmm9de/XjtjPYs7H8ZcJ8Tw9hUArFwsZUYrGBIVMlS9lDhdn////rMAAAAAK4CUPynIAqq6aCokWXljIHvf5pjEK4NzQlgfHQFCAH7AQB3ETgQWFgBBU0nj+oRH7jSx/vYOHVnxLa2hptr8cL7QMfOwMxZfq3ZI/J5ex3NbLmGNe07GOC7e+0tjtGSMbxDAiIvGECphxCLFRlo4BQsHDAOXSqEWIYmpCymHk9AQdgzhFQCulXLFdNWVTCTpIsjVaGAXY4bzLSj64GSPyymegZr4mAFNB5KgglsNBCFxXqzBcuCCFaNDWKKHLjSNARVilbkTsdJ2rmdWZyd42btjU+/Se3X781V1hYLhwOidQmDhjTJsCwE1FdH/1qahlkOqOu8/rhhBWoKotebqkkz5T9LOxVezRI6/oisH1yue+qqTqF4bsFVphpZCdrMNYXi2d3UmJNWZfJ/kedYi3qy395/b92vefKIZICMzRcWeLCIMWIOqY8INjK6DslFmpgAAHWDvkcLgQMDDLjMCkpiheYSTEo0ZeCGHF4kjAINS3BAUtdpC4AaCBYBEIQ4zEkATXmWF+y80MNqnC7TPhYIbgxeSrTXbGYJcBgMSuw7Dlldb//ukZCmABKdFSZtsHpBmhFmaYeY+D4D5LOwkdsnKnaW1lg4gvT0UfeUIS6i8iXk4BcuUbbL1jqNEwgUXxe6LjiJhQIts2XUMuw1jlY5kpqumpmoojdaRGbvCvi73EgF5bt////dSVShIBBd3D+fDCiii7yIpgwZBSgAWSsJIXcnRPkSaCEn66RKlNoYYnyEqF/CZEOjMsF2AHPJFPfTJIlSSJlIwjPnTptU74Wx5qSgmk0nJ6NBVgmnAOskKUVXCO6Rih4AnVRSAyQxteiAACpaD7FJ8AXUuA2xDVOEAr8CIGOBEV/pbIIXLWq0lU6tMAK4eRa76Qayx4mmZxFyHVo17OqQkAnFCEDSxAcJ1zCp4+M3c9xvp8iFlpNrTaPFzirRPJ9DuqtUdY8yNbVhJHN4bmWmWY1eXKg6Q6n0mbSq/CAC71+LepOIAAgAAAArsOza5h96CmnpXmFAgqGOIcS7wCJBhawEalSpE7nGbicDkeiSDUWExlKempPWlknnHrFicsl10qrE76JIYPMoAtihBKINXsMIp6FTmXXLWeaF927WIyCCayqiJKiwUZEqXKGk3EiwyqVVokZwAAKWgTXmQRBYyGCQoTRHIBxjzZKBBA0FCTFCGYEoAvEmwwVoQ//u0ZBKOBFU+ShtMNaJvxQl9ZeZoUwEfJG2weMGfH2Yo9I3hCAo+s1R8b9JpmSmvvtFGZrAv4qeIszZMXgaAKQxKLBoTRMShoU4ENxMhKKplhyYnlyKocTYo9UimA5BKvllHtR+mRX+vOu9kiB6mwv/0Ub5jsW+tjNRLKmgOU3cngp1LKr98XwBoCsSQAAAduwhMIZnA5lntnORg5RFDg5RDBDmnMkMgaM9AsCoY0aY0iNZW9lVi4mSTGpmyisXgtgcamQUNH2UZqAFy093LjbfEENMxDS3I27poTZ+PFtzhqQolBbxVaHbQb5PerH2q/+C2Oe9T7+f3RdgPNGTBQoFDQQWGGihQOIIjCi9DEKDZMJoIhYXp2gggCQFytgDJkPnpSsTia8NAIKG0g1AyIJIABUDbxotSrhjrBZ1wXUd6W046jyqA8sLR+rJIwEowJaVG89AuPzMprK6Ypkjy8+pj0bLC9Ipfxzb2z5p8q1hT8jRJqREzDubvAc3NYTSMcTP8IDobIFFHg2Fls////0VECsIAEp/xBV6UIKP0oiKC6EuXouBISXF7JwQN8XcwNgOBYrJFheTeLoSJFOaFq0t/aRI8cOAC0FMAigLZEfQ8SkqS6X80iA2Zz0/zqE2RhCuREOXnwyRjTo4Tb+HMf1CiUyJQyIxvtdUCCAAAVP/weqRAUKEhwCCAYwMixYGY0GaAMW1S7WHSMRkT4aQw59GtLdDRwXgzJQDHxQJANHA6Kg+EMgLLULxcefbubH7V//ukZCMABENDTFNMHHBeZKmdPSNsUnjLIk1hi8GdmGWphg2p6ttGCmx7+1Lolq6TU7qxqW6Z2Kv3Xch9m5Bz9XerbpQYwM6ZbOROvl+dJlXQ7zniUE5ouOCQjSKuUPQGQ2Lf+gMy4rgBAABAb34Qbx4FwAFg7RbA5hiPC9wEU2pkTkJKskaMqwSdNAgSbm4lbF5F27PxOnWIpwxy+dySzS6aqGpM8GDh9nftA93/9fWd6cF8vqvRt6zfd/HOmX4cm5/Wk2wAvw0bJRkxYQywQ+5MLvzIsjjhigEPUwJEAVc7HAiRNoYEHXDCgQqMgphpbTAlwQUhAockGPhBZACQuMzpGYDWfqRrofWqul73Wm3Uii7l1PbDFLi8LAYhysYHkQaYtPm9etBFlcMmHtgPlNVsS5at6r7MdLbzUewZEaeCqDR8XLGu6KJELx7gIdSKCW4o7d////6AAMAAALuwc6NQY4CFhdEcKgoCkrZRvtNdZ4VhDRaRimvA1aImAvcSmDiq+zeFJ04jWQ4XOXYlRhYwctaONBVUBu18z6bH5BDCnZD7M63YG91tZcpOpJS3n6sTU36Za9ibIm0juYC5eAAAnGCcanoxw1YMyUoyrELwzPJTgtDPjDBHk3zCFwcE//vUZBAABRJDSB1rAABjZImtrCQBKHIXFBnegAJ+mqSrM4AAZy4STK5oEHHEzwBcSiBXHdyeZgWXCYmkCtyHNK+S9WFWNPJov5VXlJXWeWLTULvO9YmpbZt/G6KzKaXcSsT89b7y1W/LLu8dUXanddu67yz/d4U/N1as9llhjvPmGHMec7nh3ePOYXf/WOeWtc59xYPOg6ggVmmKcEXn///q709SI+VIBNAAhuSQU7xMBDAPsCFOpBTdGUNDg1oLVHhbG8kSACKxEDpUrQqek9N27EmQvmKjrZCxKcFcvE/GM2UobcYuj891VNlAM8JNaQU1SVC5G84NdSdHsFh1uMHlR6Ua11IOjWCUEGFyaG7A7HEzdG9RuG2aVGL4LlD3GKCkGOLBGVMuGkR+jQamG4NmUwNmbCKGeQxixHGGYsmP5MGoKmGwB/GD5JmFZSGAwCmDIQGAQFGh53ncSpGhrEmR5tGM6iGbpyFAdgIQwMCJjaKhgeLBjoVxgWHrETBsEhIDJGJBYDgMlYkLJl8MhjKJoEAsxQA0xrFADDIYQgUAgQREiKwsNP8riWmEIAs5MLAfCBqLaiwSqxAgH19DQJAEBER5ROQ5M1alODAOQQgYDVVtwMhoshRrGo+0pf7cpwyqYc6l/Eb2cqlkbsNO/Uu1Wtf3//DeP/zL/3/P//y33Wf/+H77rPL//vM8N//////81vXP/+f/67znf7lVpuWLv272X//////////////L+Vje93b+dq5//////////////jdx+W3M98xobwCGACEEAgDAAKCQC1wK2FzSVFpQExNooBFkUJWkDbmBmrenAmc+w4oQFS1WFWALNXI272OVVPLzgMi+cIshChXSauu1Hyq2rixlOZkzEC+ky0AuWoalc4bd2YqDv6p3nQOlAkfhy9Ko6wOaf/cVks/esyrG5uV567ZfufvdqUNav/5ay73///+/kdXAOd7fz3+qz6//etn/1C5Mcn/++G4wBAAAHdqAnCga9KA9UCGyCNrB//u0RAmAQ940ytdp4ACLppkz7eAAD8TlJm0w1QINnmUdlg6gZZb6Vyqc6rYmGpNoDTSYlGiSfB3BMP4J5LpUVhMzIcjknnFyU6/O3PdNR/LzNWrlbV87pn08CLSDSjC3bjy/OMQrs0J7Gkrq2YcervWKUkxq+setp3goBCggGLYPD5c9xWxY0u+kvZcgAAyWQ5IHFgV50VwQJgoTDjtAEHAxfwDA5kYiYAGAoMe8tG4JQGFgLJn3epbREhr6Ra41/zEZopWvuAnWgqnxjtqD40yx+m+avGJHZ3TTuqWpjlV+1aysbu3NYxr93da/WWOsZ3fbPc99r/X19T8N/jzXOU21sLApJwsHkkhjXpPMCxKaD7Z917v2/WACprAdAW/ha0lHApOjsIQqcheBMUZCCRoOOrOT4bq0hlDK34ZaocWzQdXK5L5IYsRvASE9gEk5QLsaAYC49OhKJJ2Hh1ivVDtOMsRUstiyq2F7LLyxf2v6jy9MLzkWRqm1np6l6S1Z/kOr+TmSLGJnjbxwkJuF0D4hpWBBXvCAATugPINlKZwUCASYJHOGQTgIAjnmOqky9jLVL+lQF3CQRawWCLoCxYwChgoKSArFR6htOGLB8KggWADOC8ij+qH4hGpqOxAAvERzCFDsywds/ZTTmK2XspFydj34+/fFvAYOpo0+E9ITHSKas+jxgWRiVtQGKkQqEQ2dPlg5brvZ1+NAAABLljA7ZFOIkTFqDMENznWMU01FwqIMpGeIWeL+J+oBV2v///u0ZBMEBE5CyVMvNKB+ZykaZeOYEiDrIO0w2EHtk+V1pI7QDiPC6nGTFeZHpDi3jrPsjhJVfGZVEVqta4LMdSFsMQAlBSYs9BM0ENUBnIGBaEmnh4oqyFsle3JRFGM3ajxKFS6BVLN7VWzCvlPHT2H0v7fra22h01tEALJdVQVWPs/+yv//rcwAAAAKRiKykA1CXZl0HCUdaJvDmSEFDziHM48EGpKgYQDFISRJHSSaQ48LH3MUtWCe4bDrowMbQ9czrNVcl7JyZJoPZySwn6ulnZ4VWhWtvjRoG79VXpk1mZ5XE8hGxUvMpCqGWhFhz7aEYOC6ybxQViFZKn7DjF////6+1agABTjAbjFRAQkACIzZw0Is0rI34saaBmg2r4RHTKAiwCDABaRXj8LQQ0IAaVBd1TRMaH38dBlcEQt9FyIRwM1mHW3YSyxqjeRGSA+QhAZSnglkxqqxGasGkCGwlUJC00umWJ+Rl84YyEnI/dUVzXvDC2wuMSf5MZsa7PiYjERMoJ3Ba0yaJDU3KSiu7///284uoQQAAAVLrH6TdErZkiIQAAJwzh0705DqhuFybWC0ZatE9kasS9F3tzliRdI47cXepcYEll62o03sljyzQqbJQcEA2JBGfXRUGDYkgXRj6N9QhHRrJW9qXwEXFQGs8FlvNtABoyKBoVjBSJBzjbGIDZMKMWRU9V/f/9ylAALkgEw5HMusVQYGjRiYQYqAmIgQGCjDBkEBbxmABqKKuFhC01h41M0h1hUB//u0ZBaORCo0yJtvNLCAh4kHYeOIEaDlGk2weIHqkiOZlg7QLqLNJYjYxyGdAZA+CFDhJyRhMHXHV0ZMKKPAY5U0+g50ibJNtmUIOJU8fDabHx8t9rEWpqfZ8VQ7DeRmMcsQzwUAbQMtBxCmhtbCRlYCuQlEWSIE////+lEAACkiDT3+GEok05FhjonUR1FlSdEYRufRM1pwWa0RxEOw8goSREKDmLGeZzo9DVaK6KsYKrGyX5E1SpYRGVyq0JXKLVqWeoUcbaHGYCCl6mRgyMwTiUBmpWREDD5ojb4xGEnD1/jfDga6kgJBQycaDooBAUM12cf1///92tz1ouA9EOBIqXvMQATGDczA5FsQx0sMLDCEfMdNWvg06MFGiInQ7oGiwagJDiEv0hUWWhtBKvpokGK7bd6nUdWakLAbjC5iRug0KR0otjLxwU05gTWTtKTViva1O013cijc0uzsD0P3UEIqGbrSXYzLUi4Yo0WmRyqFHsGtTe9IVYE3K///6vTj+SnHjGguexAS9RYcdGMgEQkA7YADE4RvancmAx2cMAUxSEJAEcxCGqRcAY8kKmK0l3INhtNN0maP9HWCvLiv+GBJHdoQC+kNlo5hIJflzzQ3PyotqYrF7tVmuM1lgNNCEDkxK1l4tXhMBgMNB6IBd0eZNn2/v//7Fo+u7IR8PtGC6gQAAzSRkYZEUWIDQEHL0+B5YDpIvA5LXgGSWCbhNQJF3RVsdhI5f7QVNFYYRdi7RpIJ2VkJkTCKKxEt//ukZB2EQ8cvSDtYSeB5pdjTZYakD7i3Gsyk2AGqlGPphhoYzJIlKbdPWapNLNbqfyW2ykkiaIn3O2mTLCpbstedQWX7SBsasdcdN2sadWKhulr4dW33f/d113/2c4yUW1oACjQCWSGTepfoUDEJKAA0gdUaqw1El4LPpFKZJWwXBiGr8Jgl2WUsUiilz+1Ja9iYJzAoiUTxEBoeiK/CbKiQRItklnqhqU10FKX8zO5d1/GSbDyYs4zH1tattjQNGEAmPhxh2l4YqssVOf///+9ZNkWY5ajhs4o+nABvoP8CCwsigBLgG+MBwjbIEkhr84VCE5JISMf9bKqpE6Wel8fbRXD/JWOXAjj0LgQA0N16JtbTRbTrTVqzeph83FdzSFx1IKDFWfKK2a189G0KSr5rbOyidSox8WkoHw0H4WHCyiI2zjRdsYq19H///t6iiZYHUQiQgYQGABgQXIyoHj70IeLCN4DBi0AhiMhiCylBOsCxB2Vctyf11m2H1WQjgrPEw9CEf6BLVwtMD6Y2vEuVkmH8s6NwmpDCvpv/PrWfHMazO1rTYVGBhIxSxwwEExY20SIF9bg8r/+//+rNu7bvWxMAGVpE9AHmJSDREBpy6SIEBDrgTHTWQHS8Qgu0//u0ZA4MU5ksxxssNEB6xPiyZeleETnDFE2YWMm5NuMlhgm4j46jrMzaezQwJhisCk8edUiMEKGRnS6Hg9nLxrQb/qZIOdkVrHEHSJRXSy7LEF2TNNhjycqs4oRJA93gvTxQ6bCZgkA4vUh7qe/V/+3/+oz/eetcRSbKgHSkSdEuDB8Gt+ZOYICZuREFmC4IrggDCW0TsfSHDGBhKURVaGcS4cpOSDLMJyJUjmQ14BPsqMybNUBnzALJ8v0YWEiJNOWzaU1ZwF/4q5K21F0S1MigjY5Z86guYTARAYlZWjH97v/f/002rtUw2EiQaUWDQVcJx4FUAMqAO8JgCGhEBjIoDgQwoYWITEYKCQwbVUAASjwslPqokLMqkhMTThRvXRGo6r1pTqvtefZ+XVm9X4rCHtjcGTqRQhYBCcLwlaEULG6VzAI5I57NdyVNtoz/mPGa2vlNNqWlv3e8qPoj2d6XtZksV///////ffWqL6uy03VyhkVDMzhHMS1AYA0gjQDNRlafBQAClQ5oxBc4UEhORvS9i6grtHZ6IJUNykIAHmhFD0uDIVj40fqUj1kRJbjVLTMybQ7qmk001QovWLPrM1ACqFch0VjS70r7/bq1Hl/5PN9U/t/////////ojVSWqnmpI9Jzuoo0GzYB+YAcayhWAVDEzAuIowF3SEIOIHGTjQ1DhDwGLqWLmXgnM3qWr6reXI6TKWryWHGx3Y4r56Y4IREEhE2yREqJGYeTSWSXaQEORSbtbMITKxMg//ukZCkIBAcmxZN4SfBohPjJYYJ6D1ClG0yw0QGRj2Oo8yZQSSTubeMg8aCUACqAbASocSonsuLqrY/iv/6v/YhDDxk4IhoQgIw4GxUSB4igGTxDBAAF6DBYMZgHARMXonYI1MGGEpQtfWEbyLuYyJXpMKwERUUhIEZk6QZPR4XLYVP1s4yfGLi6sC9Syc2ZsICOmS0lmBHqrzSsCLklsSsJILAaSoEAAjNP5H////opuMUtFlAeooTHoZoABUjbIH9ibmGCMkWTJlwgIuXwEB6BTX2BJMr/eJo7WX5qrSK48DckgXFIFEhbSHohGZd89PnnZc26BZeiVvT8kkDGPMw1/KNjZL2MkpxoLpqC2PAmCoiMpLrWp5JiTRtpiBgIuKWVpV1//66BeXQzMWqY4+fjmNBMNkQSoAnI2AgJRHUYxGUEvDoERajnPoWMvALZUrkkqHKFGlkp2RBJpnjAokTBQkkn3S8TWLAeSH2GTFNkqi8pQ7YHLniKgOZAaQkqOhYcMT5S4zFSqCwpuNrP/////qHTDFXk2JoqAAIABpEPk8iKSpXWGIDIQhUMJCWAcIVHDE17qWoZv+0Vraw88ztjUpcqbYOvKUNldkukkcWjB0YLKI1R06yXDAuvsneo//ukZCKIBB5vRMssFUJkA8i5YYaEEf3FEC2wtsGBjiMlhhnQ2V11jMF3l03qdW7aWpSlv611NOSg85Np2L9/s+6s9O9vX6V2/1/////W9rqq71rRgzEeckpSFQ4qIFVIohgARAgAW0CWNYUsEQX1Q6kgWsIJyKLZlbL7CmZJdLBKOMlfqBXnSUVGAlueUUWNy0VaMCiUYQTBiAMmGoZUFmt9w7AAIy0WqYLjElkn3NV++Qq9yv////sFkzZwUEnDIWQowJSoXHoNSl/OGm6TEBkIuYcJGAi4KWhGHGGDyZKORQSCMFHgtBOtst2XMmmwrwLULtZtXYooYoIweWMrV9ZhSCDYeCIBR0rpnFdWHDOXG7NFt62wQwvvUvChRN7TN3d8g55Xm+10XslTodXXu1/+/7V01bW32///+82zM6pYnGGZ6o4pisgeHsRCnJGnK4fDwK4eKQQgIL8w/UqQINYTqmYbLOCQQMh7mcNNbZTJtGmQYqcGlcnfJ5NLUcB3oRdkjKj2maa8kEEEWUn7UZWD4ZLAyFljTAwvEjULGM2HbtKVdf/3f//3L3wGuVcWEB4OyYhKkwCUQPIk0Gyt3MLEm5hh+CgwiDTCxgyIDIhtGYOFHsL6lBCtlZKHwODS//ukZBSMBIlxRBNpFiBgBDi5YSZoET3DDkywsYFZjGKY9hjo2a/B4KaCviWMlVyyAvlDMOQuN4t8/sEtKapGWv8JBKhkIUUlkkViF0LKNKE9wGRQfXckmhg3GOFR1bqt59u37unudvrZFTuqvTp6dOn///+mxtW+aWdQoNTmcjsUhTsWUgEIDuGFUCuIBgCDcBD8pWk0JtUfQgjLXucN4VmtxQdZ2gFIxY6BoxEUAUJE2mjoZbISVlAocoipJlJnzSTltZkXOfKz+NRDsXxqdKFoGDZdJVHObP///+v9KDSRwQaEVCkHCjAvcOcAyAHmNJh4ZfpikDRRnmIoGSU0gSFFkgcVXV2WtjqfcFw8psAYCAlDyOqM7AIWyeBVheMRi6uEZacuRtMOI1scFmnltHoIv6Jl6sK1p56rju2vM2vz7kOrasmrIlZq2+j01Nv6bbXpf////+jvTPOk1aoPRCkJkZRou6OHwRhcYKCQiJipkEDMKuopoNKIqtOmIhYQ0xRb0xVGB1p4TBeZB4ShEJ5VWrKBCYMFm5TwSSVzHx1MeaYlhgcJyIOMNAYlk7vT/aOWh1qvv9f//8z59bxQM1OUoNCUAhRAAB4FQtUGAEgAGwOimEjwPKp7pnl3BkxX//u0ZAmAFDpwQzMlNnJvDhh2PCbqTeHDFUwkUsmwOGHk8JuoiHFBqA1It3dNtYfdiRSeFslcaXwxUilNH3amLUCzFI/92pSwm5awAYMGlOPMNYeFKg0cOFRECmyGPKzo8rf/eQ5kdHt50pN2ZF1TdzO7tPSqa/p///6/pIqK0pmKTFCkKqLLSnWLtenKOgxgtGiQ3a0JBcnCgDQATRX7gkx+EFFGBLjDVqFnYJ+PouRd4jqEuLNp0PpsMcV9bMRYrSZujPoWpo8Tw3+qRIu5fqFan3vOLesufP/8tfe7HMzLOAz9/U8R8q+l///8u6+hCJMuD2tGUTKVFhucEQemVe3KO3aGFSMAu9gqRIlgTzEZxkTDZWMjZ6FEFyWSQAqdVrM2JPwi29b7QzQwy6UXm1Z9RwyhZR6WaQTKxJYFywbIi3nkmAyktfK6en+v9Er//vrW9aI2n1T/0pKSX20/1///9d9HNqSxKrQQjIZVcQDRFIMcDMLAQGELEa4wkWjTSFsAWkSrELNhKhlDQLjy6MRo4wjGxWSKJgevHUDFqSVr7QJoNZ1Khm1bGzTcGFGf5m3rHtX////d9+bpzeZlrkUss/V//////nkLAEehjJOrqcx9jDejhcUW9ektaD+6w+rVAgsgAE7IenXCWDcp13FYMy2EPYyaWMq3EqaHYrSv0+0uqUcr5ewr3K9DTYXpy/X5TX6hggcQFj0Y5+Zm7f//1T/0+RV3SiT+7JT/TOlzqtfan3//86pq+fKtTCdF//ukRC6JA55xwzMFTnB4TfhmYYV6TgXDCqeJOcnOuGGZhh14bzzhFKLnwptio61y3WbQU0NwWOskTMgBLyghOy5KmBJlqpQBFlJLhVgZRBt9mLTWgszEeNW6FyEKjJQrMEKzpyarFCpXGzFeXk6V584o+/4oR3HCZb/+n/3Xe1LfRO2td+tHK9qV7I6Mi7T+haZNf/00d90RFlYjkMMJM7mchlMZyiR1j0ePQYKIYCnHixUPwIppXbycyHKlTLfNZ0tSbVMmIVWLatzukKz6LFjQ5XLfhatvVKWOKR5lVmdJt+n/TT/6aWl32OyvPaqMfrZ2LM7z6EJRe06rZJf/pd9vuqz1jytdiNhdDqCorL0mwgvHRQJlNICQTLSbPHBSSJMSCuagAEkWdS59UiXgYCYBsRecuszsirimClh/JyGDYeYRIrrqQ+qPRyyh1pRZuOfi08ibgZplvTS7Ta//T7f+tPn5pqfn3Vb3NazzvR36Wbslv///T2roiuPqkese6dSanmmlDzzpQbiw1BcI5AmIUGxzlaUGQAGc5SMSpshLK+YUo8UULFYseTfrLNFxFr/bFycuAKDTLz+z1+V9lLsXqXPp85X0+1vHI1C1bpKtZfdnpvQbFVNbelfU9/fM//ukRCSN06xxQZHhRVBxrjhBPCzcDm3FAgQJl8nTOOBEwSb4XzP1/pNqc0o/ExdjzEMVBYgbjqmhYPiLEriliKC0OA6MPMBSDdxBD0MsIRqWAK58zMUh/FyemGr1ZKp8q2Lh86mvuHJaFGxmzbEvXWMb1aFPqL94tefWdf///5P1nzyaG23VBkjKZCMgzA6RiiiEpDLkwbOzz/+zPoj2AISCpCEjJxqP+sPr1ljqyalaojsncYK3kx+WtQBMPlKAdv4DZVkcWC0VoOTA+mPspYuG2ykvaL4/Xb///9K3b1QuZ/YqGdkdJrkM7FZkFMVUvOM/VrOimYrvI7tdzFR0M8rs5kvZC5mZtnW/qza1s17uj6qVls4Q5is9dKm+E60qni8upNfaPS0YmS4lCmBIUxKJohHowR1vLkQVGK4xu4WlsutblceyOrX2mZ2s9OF/+/sn//09UXo/92MaFRDFRWer1VHDPVmWVFBNMlHhmVLshymKZKkd/27lqdR3+PrfmyW3UMkJw0RQpq4Tc2SAiQGyJODaiIPExswhJnAKJTw+UCoWBIUgGF02VUxBTUUzLjk5LjNVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sUZBqP8AAAQYAAAAgAAAiAAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",
	"crackle1.mp3": "data:audio/mp3;base64,//uUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAABAAACeoAAGDAwSGBgcIiIoLi4yMjU4ODw/P0NGRklNTVJSVlxcYmhobnR0eHh8f3+Fh4eLjo6SlZWYmJufn6Snp6uurrS0t7u7vsLCxcnJzM/P09PW2trd4ODk5+fr6+7y8vX5+fz///8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAU3jQAAwAAAnqDlohDwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vkRAAAAyYcTZUwwAJGgSoXpIwAJ1ITJlnNgAT8QiTLOcAAAABgDjuhCABACANBIEgRyef/k7e8GEEI9nkwAACCGPd2QIECBCIiCd3d3d2QQAAAAAw8PD//gAZ//0PAAAAAAM/+jwAAAP3//////4eHjwAAM/MPD3+wAAAABh4eHh4AAAAAjDwBAgx3fgmTvUIBQKBQSCsnRo0aNGjbBAMQuUBAEMH9QJg+D4Ph/5+IMEPlw+CBwo7//wQBBM/ggCAIAgZE4PvjAQOUrD/6QAAAGADuKGASrOalY1mgDD45MojQxEGDFpOMFEAw4fTEQ6M8ncQg8xcEksxY2mGRuDQSZgSDBeaWHiVOA8U491EgQkPTAAt5TAjUmIAxCASeZCgGBAYBBmYAQWAx075nhGJtpyJ+zJAe0IaBVBJtMJAwFCJMHGgHRnZ8Z4JmsjYsht1WAV2rJBSfTh1V2M/U1hoxoOMHFwcCFUGMgAAaGI/v+1BiK1aWHmvve3jYIaa3KxUVDCcChJUBA4UUESHkr6R2WX8sbUqdt268t7ejq0mvIiPXDM/OPfO2pmm3j8qvcl9+/S6u2rlvKLTFWhznpZlfw3r62P1csq28avf///////9W/3jn3PWGH/llWxxpdZSrHGl/////////////////9f+sf5//////////////UjGGG6exun6sAAACBA6aKDlZDOJj0z0VjHIhNKowDHIHFA2IbzFYNNkCwyWQQqFzFRiMCgwxAYAwdgY5GJhWLA0x6RSEFnEDsbZJZigBGTwEBiSXhSdMAg4eAxkYPGBxI85EGigNlYYAIPQtByRNuFI0mSwqFi7qDwMCSt4iBgcMDAQaZaAQmYcAxnEfGRAeZvMpgsGl7VrpBIuMxaUAQKhmhovNiMQMCh4wGCwwMDIHVwChEzHrks0WpDMpf9t3M3LM6cmAgCD5ggBothwQQaZi/MVo79ql+3DUbm5fFLudAknfUwe1qDX7bsdrzU9Nyqkzv50mUbyleeWfeVYW0PLnJRjLM8f/Lf461lvmPP///////9fX7b/+b/eff7lvmOtZfjz/////////////////1/8/9//////////////1KTWqTe68vYAEAAAAAAAAAKjpDW401cHMwWzwQo0BFMpJTDzc1hINSUTeDYgGgc3GeDQcaGch5kY8NKQ0FgUUaBsa8QARBjgya5pgBowq4zLQTGCwSFME6ASocBI3kQxU5tHoXJGpCIMqxgwOj+aQwZgkCjhexDu2ifwXLlgK//vkZDuACNhg09ZvQADDCrqSzGAAJTV3QVm9AAN5ril3NPABNBxwaNAWtIBEzH8joNBo5g4AZguu0KATFA16JerRYK/bbMttupXj7K23XYzhDRpcYb1i0NQqm+1AVSWX4EizDHUf923XZZD1BMqCyZmLay2xRflUs72v2RlsEUGmQt94u5bO4AcaVtdnHBa7h34h2emfyv5ftp7yTc/A+qSH6CWO/btyqzKHWrRK/2/nTYxHDDL8f/+47x/W+0gIHwz/9R5QVBUABABHWmkCHJYFNozioVzukm6gOHmtffsiU4kOQFDkTaa4zu08xI6QaNWe1dq9YzDCV7O3KULZzGp2RRtx2du+7EpVQLxLGLhRVOanirgqYM0tPpFHEfplrrMxQCw0/ctpKkj7OfP2OQ2/92Gq71y2mpr+9b3z5+WYWLUMPxD9NcZVA28nBpse/nlnjah+XzmHIxDEst6m6WJRruV/HHGly5a5zX/qxT09uHKSxL8869PbjNbPDHlNdDQiBl31AP//kZ0J6oAAAAAAAAGSW48JzMn8muGYJBm6SdfPg63NjpjFpU5PzOZbjXj43dvMaVDc1wxwRAK+ZU2mcHjKIx0RHkEDxUkYAeUdG1ES1OQKlDWCh1AYVAOGjLzAu9XMZY2YYW0wssCTwMwGglGzXm8XFBEObGEBDw0ECi3wNhlDYuixEBIjapBpiaI2OmjEi1qmBEqqsiLWAEEkeyqG1fJoiQBU6cyj6SpIEC4cKBwYIamXTbs8MNObMp6r4QkoaxqHXoBo1MsvQgHh5qNuGrbht1ca7SPy/6c0Cs+Vul0km3SRlL6JpPcnQtV4HJcmLL6ZGi0110G7OKzh/pOWuTWZ9Wd1lT5xGGo0zVprdoBsSeXX7eFzGmimEOyCNV6XmP4Ze8b1Sy9PxGQY16XaLkjTRIAIAAAABATk2wjJGRpqwsrfkyQwwUg1h0lGGLSA4yaMuAAgGCo8JeINGBFARgcQMMNI6h8BhK5C4+FadrpnLcWEv7cLWDDNE8RNQwQHkKoCZNkkivaWLIR4JYoTIWBdBvnyP0VUZPOKOX0YwrlXKI5mCeIh6vQwy1pGxHzVhhcIkFUw1Koe4pY5la1LpXpxug4b3uvHspdxGJxevopTm4jJayQXzO8UZ1ORzwpkOitq0jifKmiuZG61XInZxJRbZ6tjleFreGdvZori8eT0y+1kuWpdwLPcF1vWAEAAAAACQcerM+eNlICqIx1sCAxKEY82ZsSCmgOGkUQw6My1Ii4moOF1E+zS//vkZBaACFtd0j5rQALIS7qKzDwAYfVnQHmtAAMqLmm3MvABAxwagMDIYdbNaFM+YMwHNYQEQsyIYwgwxQIx8Ax70yglAejQRFgcSAhZPo2xsmxm7MDgQeFDxRNstKZQCZFSlEj+aIcZU0FT4ARmSEgYG9Rd+eZQpSp5AIHBTAiQSFW+YgQNDhoMoutldiYcrf9rbOmWU0mEQRKEFAy87Uk6GALnnFK11IJlZ1bY28sXmovbmJ+EP22F/N6ppQkSydtnKiczGeRJ3M5bbp696tSUr5Q3L78U+plTyqHoClmHa+NSen7MD3+3cN399w7X53LLW8t/Z18uluNXV+1Vu1dBQEDHkACAABAQNk30bQPW25DPHCaYAqOOqlUcYZGHDSGTQhUNF6LsGKDLqdAeynUQ0TQNQQBRsivMsbigHbMQlIF8OEBoQaKUR1EALxGFzNJIFgLabydTCFOCXyoz/UiIYWFIHwi0JJyX5X2R6GRXC+J3Ndx0IUBKi7Is4UJclNHnYJpt3liKtnvNT6YHcBec3kztePBPOERkt7Q2x3Hvpd1xEtFUDxsZporXWM8nkt593xilbrKvVuJo/1TSvvHV9WtmzD3uN50gAAAAABKjY1ZM6DNssHvwlhNNPNGNNVZAM42opSJQAMMZDUJwYpqxplQYdfMQbMzTNoMWFNQ6GGh3FYGPm+Mq4OMCMU4MekRtMkKMYvFBZngpljQYbBhwzZw3LUGCzDLzDAy05oBKCQvAbM2kkBkaWoMEkSNtCqTHCwWBjAV3ggCkq4pjzakiYSXvegMOAwEgo2yI6OSOaBpakvwIwrEX/WBBgZTZCUXUXCoPTpBpJIQF8FmTz8sRX+rxVVxJdAL2MQlcNvtL/f+nbVnblwDKLWeDB5p3oxat0kvs378Ryq6lW94fqGqebr0V7GnylFimoqkpp5jHOvljYlljCt+td5nn+F/QEBATtEv//7v/+sAICulJAEAgAAAAmS/aIQA2ztNMi6YheRUC113RIPBMsAqAEIIkKYBYsoSAV8AhPCEnycHUpT8Ql6darS5fQq2tgRZdlpDwKwXYcgaQjpDGhXPCXvDgQhDIJw3PBvUmU8wyzplWoShK7OdcphWs6hY3U6wuXI/IlduCmbLLiA/h6exX1ZLQ3mZ6Wh13HmzuLWLHnPRacIc17w2ZxU8FSQoD/LzNU8suL2TvXb48T+SqHzKttis7jO6rV4xeLGl+NZ1RyZHk02IMtxhBYEJgAAAAAACIkNtMqDWSXaBTERGVsGbJGEBm//vkZA2ACHVd0dZrQADFi7p6zDwAYTUvRbncgAs5Jym3NYABaDBYKCXhRMFjsBGBamBHhjw00owK8wgUxRYGDjRizkDjQERkoakMYoEYAcZAMAvpjjBEqIgwcCAIoaGpxo3jwQwqwyjoAolNRIKPCWTtaIRZiQIhAoAELjUBEHzCglevCj6lcmMg8tGCI8pBiDEFdmQCiMaiKHH3EQHKYvIydrqQrKn+fq+qdia41iTDIhYEIRc+YIAjmnC27tvs3ahpJXIHHXQ1ygp68uijkv/HmrQ9zVpl0Wm5dIZBVoeZNpArXGsQxG6GrT23yg1vGv4vdEL8tl8eltLjzXMu3M8eU9Jzmsse5dsf7cHPbShjN+ksTNPdWNWXoAIUAAAJBKto8UUSfQ3GRsXKK7QiSvCyxqTuuSy9dSZolUA+Icf5fiyofZzJ5LqdCyjVqQPZPl9YDzP6CfSLQbJDQ9eoriEKMRwY4fbKMU+D+V0Rho9LYyNsGZjJWW86yDE8whqhYnznadXrTJE8SI4oo50YfVpjyTqwbrBAbY7UfpysUM51OyTQnBNpVFwp3zVE8sj6FnUV6pJKP9QYEBYb3C9sZ1d5C3W8KTeY/1qt9Uree2PjVMPVYxzx3m3FjpOB6aSNsAEAAAAgECFe5IHWVpmyjGGbgchUMDQ8wjEoLTJYMzOdGDIIUTIkJjFg0zGwRzFYpzBUWTD8IQYDJgWE5iWFJ3PlsQoSOLpLprnycDhzKGDNTEpNoVwUMwhEIrNRUyShmYyiWaMHeRH40SgsCaogZAtUCoIqGCYl2ASlby6I0Opu2pmmApR6ZcNcloAUcSBlmldChql2DKZ6anrSyXFByA4jKJUraFgUkUyS+KHBDFwJG27xO1P2pejFFwUKxJV6YjeOcnNJmlO/DUuwlLd5C6sofeVz8sMABG4IvUvMwEEgwM8EuYa0p+nGSKeNkTtxG65LpX4bdt24xenJXO0uvatzeJvmippZrU21AAiQAAABEtdGgIxMGTAJABJDAGih2TWxnCi0bZMayAeZKHF2XAJEglLXpgLuMAkgnyTlZTKm1iLAYoyGphMu2u5aEsag5ELdODmQvq8bS2DrGiMIWk7sdo6KWy6XNxfeQbfdnz7T8qhTOoxeo7esIKkD84zEUp4W6MajsZiNLhU3navaZU0h7mnNUft66nJa/sAQ7RRqtT0G7OHP49T1Pg7zySKksU9I0qBotRzG7U1rKklVJUl1bHKxjWpq2O6gVjfOx2Pm4mt/+/6+cEJBGJejw02l//u0ZAWABRZI1s5h4ABb5gsZxhgAFOkbWjmMgAlwHKxXHpAAWhdoNGBaosP8hRJV9oWEAYIgAApAT0aVInKYIBgjAEcEGWFyhrYXghAt4iwKJXwYwmAStTBAgzwba41GnbUMCvQ9yqF0MEJCEZQd3skK8sdnSI3y9uBfypNxVHFDzFo+t+i0LFwLgqGxDGZXJRla0MrjG8f/oQdbPu+/pv+ITg6ml/////pq996venb2G24IiNv//LGE1EP/8sMcMEINTz05iQR8Vj4+LiMvZaHJGpodlMZW6kDihiW4WLWkjhy8wkxPTc/sgEBAWlPSV6+f7BMneIT5lDM/b+7Qj/4RSO0wpwddxAAwbAwl/P0XmFtQ/+v4sAB4rpJ9FIDAJRIzv2lUXocYKhfxWFHKMqVoJFB2VKKMjJQASAEDCxZhiRlAkBgErAJKkOZhKzlVyYyNq8dlBIiihkGDNOWAQ3Wu77eU0sjCyYBtrNR9Vhhcdagy6VwiH52bpKkUUanGdNJdqBHrc5+evC9sAXmuRSjsVWxuZDtn3ecGnnqm+2d52//uf/8Yjshpv/LdJ3///5rOpr9/zv/lS70C+dXIGIAANhmBdbmEkliqd0gFp+2QZ2t8SsnziITEA8bxKAGxMR1xD8QquMdRMgk6SmFE5yvTrKR1jxbttzbmVVHrK8iXVWVKQY/9ExD9yTcpVOVf5DN/9M8laBXMrCAFEAAAAAAJOWYyuA2rI0qczRczIkdHGhDmFIgAmWyAJsiMgE0j//vkZBKACBJcUz5rIADSC6qdzDwAYel7T7msgAMfr2s3MPAAKY0QYAAxJJg0wB5lmi9hHGPlHSmaOZgeBUFBlQE7KjhAM4cyBT2BFtzDScQePPtEQAmQUbyRMMCAkEYAHUqAhJdl4YGAShmog0BRAHIEWZtACAIsmhIQBMBVUcZrbBbJathQ89Mx+F1pwvACg0fC9yXr7rxW1PttuHrCa5fduQkJKmjsXgJgl2ltQ5TQqzDsl7jVqtPaS7L3MnlUrpH/hVHN1oVVn7uMScGVbmaHCzbsPNFfnH6llNyaqy6ahMnl8gtyjHcqkMP4//8wyprX8y+xfqYxPCL2FPWz//oYBcCYQAAAAAAABLk2/QOOU3AVWgZHsIIpqOsIuoPAUbAW4F3XFWonoOBaHwK8LmfwYZKylJrVdHvkhZL0igzVGsT1RI4wjHbzLH2XUCCGpN4vUFRpzj/JSHAiTRHqLwjHFDrvrMyXG4/Y1WnHczeZSsLgn47fTKYbYK/OY6sa1SzsEjU8cE/CcotntX183eSRXjInVXWI80f6rf4mcWOaGzWzEe/GzSU6qmcT9kYHj9EJBhUkZD15mX4zdBhK6FFeOnsGDvMKNJDkjRYz3eoDGBciJAAAAAAAAAAACATf2Fq5ktBkkxmixgUIMGHHAg4OShhCTEtAQrBIgEFy44oNIQ4s8NR47UjIbDSgWOXkGJBCcjmgNMdwsDh5hjiGZAWXDYlvhOQFCMQ8SFNqYxnjVPLaFSAVCVaRBhyJhAGYOGcOkaSgWCRWLMCRQcKv5KMvFBCtywxKIXtL+JOMmWdMpdjwQKHagw+BkbHWaOxZfqHV2SEa3B6mAKLgYuW09qiw8FwU1h/7lHUlXG4UjhyCRzVzsGN/YgW1KKSms2pZKMJfbt/pnOc9O42I1alNK/D+9iF6WQ5cyqOnDD7SaU25qYszUnpL8hvSeQU1igjUtls9NdgSAH4yllLPzsNy+UyvK49jgMAgAAAAAAJDW/9ghxOPLKwthfkRQa2oAq2ROeFqA0NJBKxJ4loCGdZ5EEQ4OJKH+plUn0+dCGMDApGzB1oa4JRsYEYhpK2GdMCZrZPVg/2Uv8ZmVsjI6W08yp966PNcF7ZlAjoLBHio5/FVbGzKxpo4wmSEnFY3KSV7IwP2Pen7Kno0WkKzJCeU/xHu9VkK6infyMBkskeHBz5YUCNtR0eOdHjPhlV8d/jF3lHke+210+Vz1hmat6hQGZWOenka+c4eT4iVGCoAAAAAAADZ133ACADEMwIyySa0//vkZAqACA1c1VZnIADES5q6x7wAYfF7TPmtAAMnL2pfHvAAssW/NaEEAKJpoGNMRKCGoxSDJNS/CPzGdIglrAwNVBBw0rBxg1IQqYo8ZIBdskAJiTlBMtkSsCyaM4sij2bZqwyWCCoNAL+jBSNzvPNDT/pgCxSdCG6YgGfThBQygrJ7bY5fi4T4x1XIkG02rIGVTC60XWkEQDFE3WrWNReAJbFluTafbgMQgx3ZakOnDBcLfiA4TALkOu8jk6gi4Xbkzz08DUtyolEoY2zyvW0l9Io8tPK28hvK1A0rtftvoAZE8b1QLDMAasQAyqQwNLoxA8ToIi2r5vxHsa1n/3ukrZd1OdjeOf152XmQxS5WoQAIAAAAAABUk34hYXA+SEK9PE7jGmTU5gjZ+bKSCT9lDZSCiJqsiAiuBYErNJQJ1BqtqSRvG8Wbgh6gQ6RLNKUOYvp9I1FG/HJIhh6s6TC+VByErL42ltPiBqGohJ9pZ7OkCWqI0ySLs4WdW6YVNPl1OwMSw9ZF9kjTSPMvrXvuefNaMx1yKRWKe8BwR7942wcxYrWomFxiSUzAxHpCfQr5xSbyPLvITbDjuDeuZKOC5cp3KPM/3A+bJ5Ip6FO5bu+HLwgAAAAAAAOK6AIYbImBDQOfhi0rKmSHDSFgIGAGLBCYo06QwBUAEB6LLQszRvR8ccsycMYYAAZ84YksARaKZggwk4EYMOrhl0MgmWOo4PYDnBEFMUxATM1AoLJ1rgoiYEoYEchILIl/xYWAigkDJUoRcQLMEPDESdIUArYVEmEgBX0wNTNazaGGFLOAAcmAMrMMFWBZgghTGYayFpDcVkNXXe2eLWEdB4GCAqWzHkcUcnPXdBNJZrU1iWNvGbM/MavtxfxPq3jbl8zIaSKzkrl2/xpnHnpFD9NP2pRLpU9EjoXSi9uPSvUqhOcs1MR6GZudoJVS6h2R0kUkWpRE8btHKvfWvHpuvhPU0xL6a9NoAAAAAAAI7LexXHIMQ9FIhKtT4zkkhpcIRhpJOIYaUQ58iQKwvjLY50qaCkNKIhqjO5OGa5MhgF1KglRbxKoaJmkh6CkepQAmGCLuCeJULq6QlJHttrQhGuCVFpOs/x+mGozigEhRCPdq2WE0Kd9Ajniaxhng7X4U1YHtNGs5Myvh0a47Pt+jUuuz8R0N6sKhVqRz215bCvW3TW3eIyrtVpiPieuoOPW6meuCzI32etXfQZ2JR1P9R7h5hQ2faHR3quZpmZ9NGhUfKlUIEAAAAAAAEJF/BR0KAG4m//vkZAiACI1eU9ZnQADCa8q9zDwAIfV7V/msgAMLryu3MPAAYq4F3NEAfcB3wXegJEMx4DiCA0oDBIETDXAXIqJABUw7QRBxoKZYiZ02BCpnYplzhVMEB0ICGkOgpQbUmDmoBEiik1IYQEQSgL2hU8TCjCjV1r6MQEUvNSKlwoMZUjULSghsOlQUOMcCnEUHyDgZdAaCGBAEhBC4RgGCgECIALHEeUuESYxi2dgCSCTbDFG3NZ4v5ApgLopwOAiqsImkxdt20bAxCEW+/m7EPRFiDoxJ8oTbl1HRwRLKt7J5N0VV8oy/cro6aKYXnlprkqmpNOWJy/utbu2qsqeBWx7X9uOvHIFrPvV+41x4WTOE9L/Q1PPFTwv6WNxm5Ozk1Od5UtUBIbgAAAAAAAAAkZPyp+GUMemIxHm+dMRBe5mcnLbiHQLcBkSp2zvRZsLkkRqxjLQsmpgEBI5cpFkcpy2znGd0M3IRcFYc5eAtR/7iocfbGi1WhjeaZ2kHQ+IeURtTxLYCYZ2ZFH6j8Mr/OUMdPlSoFc5K1iXban21SLusGJE1Lnw3eXOkFWsunzyFuBXen6jeL7tUOGVIWy941rRtYk1hpXn0rVI4204LWmOZzfsbH4FO+xvGrvabxnPiw3u959f6wkREIZEQAAAAAAAAAASbHvjQCSEEBlBqIwEmGhUGEQDYAZHGaQGpKmnFnENmI5AEWYE2FA5aAFIEUAk8AkjGTUXCCTdRLtExI8GZxZVkMFw1SxKAxpAwBPcKAp3mWeeIBpJmOKAkBCAgGRtFpQqApQHHAgNN8xlRIABHI8Fu0hoGTgVtbMIh1WMrSQoENAwZDmrc7c68Bct32jQ9BsXgpnavmwua6taIJqsXflJBFt9nCaxD8ExeWzk7k5VLheqfnfiMAQDEKSTVrMbjsqjdHXh+V8rQE0qO1ICr0sz2XU2FHQ01eVbsW5Q5cbuTEgr2LeNHT9fyPQw5TuvTKZFKo1Latl/aWKxiU4TEsyl8WqTILqOIgAAAAAAAAYLc+kckXHIrCjS6bEoYlzOH4QTix5tzILzEnLMfSHJ05VKV64Q5kYT+0j4jY3O3xgQ4xpn8l1K2sipMJrRLmujuYV2ep0Go2SquPBSrk2q9IrCHUUUEzEcxKxqhR4qdSrVFZ3rme9Z1aotwGdKpGP8x4iuhxZor2vfyR5os7zFYr/MWPWG8tFlgPmK81dajsjbFbok799WWE+j4x57x3mNMsSms4m1W0ta3lgeJfOZt7gHP////9Ta6h1NBIAAA//u0ZAMCBQNBWP9h4AJUQOuf54gAE0VNY+ykeslzkez89hhRAAC5TDVN8W0a2J4GoosB9Uf0I1KW5KULOZG+aX7FSFElN87V8eQiw5zHQQzzuSpyHzARQrh2EtPQXZRMxkDnNBFkJdMygL0grHAqXNLKdhSTa5Hc9nZpITmy0zBle0iPmNmrh9aKvzZjTwfPqJ6wMe2tRqRcZ+fq/9c4rXWr23q0mI6nyVULCrCkUI8KfiYK4mPjdmyXXC8f1V0tLOpAAAAErboSLxHD5Vi0oHKqhTidb4QGIBkbBZjyB/FzgmGIGiQI0oPgi6wabRAkUNnbWf1MpNH2NY5KRKNKwMtKCVhkOzsFYdUbWGlOLHip0SzDqBiIAALvOss1FQAYIjwuMCB0ywxFrqr000W2wxptWZw20mMvbE2sPPDd9+3Laiyp3WNRdlzD3xj9K8zZpE3WKMbdald90Wx4ssnojMWIYAWWAIYEDgZMH4IBEZEirBRrFz28qUNI3H0GzWlyNu1nwvU0zd31I38z/PJDB1i3R6y0yF4v41N22XubnLPPzPwq4HDsbU2gk9tqnZTAQAAAAALwGgLQXweQIgQVpV5NgxSBcl1FpjNx50sqmC7v1sdZ8k4boClH0eltKIBCDGppuyEmVK0MM6LpEwTgEQyRqX5LdIvt91+ysV/6n8dApoUOy/afelR9pkMiIQAAAAE7xO42YgeiCpVkEwRWACAqYRDLRTnTLa8peJCfaDnCLdGgklyhJzC6knTCHFco//ukZBsCJOhVWXsvM3JYRYtPJMNuE0VhZawkfIlrDy28ZgyRoyrSZfR1pw/k8dTGby0ZpICwp98uWg3jrisMFhcYKgVDNSlkYSCTktrIKizkTtTNlFISWQSWpQmiyIwIMs2FTq6to37Xmf5Y3vlPNbM9tyTtfNKr+qf7937XjtWO3LcavU83j8rjaIIzARAAAAAAm5EAWazRCQRlFbcQw6O3TzBkqJnR7Rm7xqxB2CXqElQSAzQaUrR47sU7J8Ms93iEgdl8rhxJag8S0qjWo3L/3qCIoSNDQELwnnVrrtnjD3K8kZBAACuMIxCAonAiH5cRuhMUhCNFtvjYbRU8P5M+mHdpHzZfCWW4QpftIyhzuJpr/ftxngtpjrtjbeMhvM9UBdVgkuhEBO5HYo4UXgO04VDdkEgkplQg77D5OICJFZKeJz7WLFZ4aLGlVC6Stbbji/yu6q/lOv8Msk2vJsZrkfmlSghOxAaRHZLkddKerIyVLWxRDkkODdp7MGSDAAAAFLwohz+eLiu7YtAYVZnHBoLBS3CknR14RhnFIaAgJA8eFCGod4LTjgDP9KjYL309kOn3hIxixH39v0sQW9/6///WlrU02Pp+y39C4JdHSVGIkfYI3aqtQsgAAAAB//u0ZAOCJOdNWWsPM/JchRttMSYqU9E9Z6ww2IlpI+20gw257JZI7l12UQ6MkYYXHSIXCu4Sa/LKU4HcU3d8mReEzQcyMMpUpBTi5GSjmA86kjK0mYFw/UPLcT1gkGmU8s5IzsTZknCcxCy+NQwjUPSRLJ5DGU6HSeWJZWymNPsvFnYAQpHEgWhcCgRaJMsFpFW+dQ3/f/77ZHRrG3Gfb741fe6iFQ9VxS4xfTeCZyvJ0G0hxuys2f857YCCgAAADd1cSwvByDo0hq+n/WJYuPoKMwyJ2Km3xyPQ3DaeIZNaV0dYIwksgTyahG/cP5nsxhisU9WMMTf5vE3db3/7oa5hkF8mL/w+JpcckWJe+pue1oBR0ltW1kgAAGXK2CEKiQWIWTbUu+05bjIEhoedKGl2QTDT6t2WO1Vp6gCerRFMX/d10GQvJSO4xFbz/Q0lw6TgQp+6ZshQCQclgJh86EonAqfImmCwS2kMrEc/a+7o5nHe2X4jE9RNxSRGAgsghandScNKWmGshaHxp+W1nOgeYelacXYh00D4nnPuWQlame9Z7w/1i3vEkSXRIx0Cf+yac/ZoMAAAAVvADyISZeT1cik1agDLUhrHqdTy23lx8Rjezl4JWq9VU2s5dYfFBoc2GNIZHl2yIM5fyKV7+fYR//M09i85c0NPI8rNkcJFGFgydIWjOYqVRyfumlPVpWbYAAAACkwkhMh82NtXXQWtHRuOW7WHSoc92EaTcRZCi+iGnE4NBgJyIP0z6pw0//u0ZBgCBMVbWmsPM3JdQ+t9DYYUUzUfZ7WHgAl7Fa42jDAByZPnAeklTIcjMJVhRy9KiT+OtYgFEn4Tg8SWHamYG2GqnTVCqGCbB2NE6kdg2lDLNAw1MWiyKL62eHo46uoqPXfsyP78Q+Odj01sf9Sr6z+8mX9FXjw06+/WdmfVa2w3p+q4blTqixCkclcQBAAAculIIc1O2VwdFgZILoxvoGZL9WkbXG/leGPMT7VpMsrZNSMfXJwQq8QWxIt/1w3619cCf/Q8FzlarFL1SO1y9uf/DPaV4sW+7psP8Zeoep5a/MGgydmDm2iQAAXIJdVid4kAhUyVBAsC+IOEkPD6+Hua6qg9lMni2GechvJN40rgGMfyePxVqEnpBxb08iESnop/pSKVygRAwUQXMyzlWorMfx8zRlOpZ0zLhj3pTPWx9P2vv2JxxGfQorZL8VzTWYFcW3ikDW9/N/8Y/97y11bOcP6wa+2ayT0rXXtmk/rs2JxFWqX7wZk2/c1ruK87r5NJgAIAJO7mArkrOWfZrlESWzvg5/I0nGZAYe7n8Y0cKKXmEBYxoOYVHFZiDQOJYjdRQI9pApD3/NZst+URUga2ckj5dxtfzvfqiYaludZMpuryvG1QqLlfdhQxhMlV0SJRAAAAAAAAADatu2EjApnULsXcbiFkGLgM82ifE9P00ysmPkt1VygtysMc7SWG6PhKoewxUJRpiISPg2zxNNWNaWywsb8+IBarRz6ZIyulcW6+kIeSSw4cFPuD//ukZC6ABURd3G494AJcxVt5wxgAFJlXab2XgAlzkS3/nmAAtrs3XrCl3Z+6prc12ODGj5gZzD9b6/ZqvqUgV1B1D3X4vWTG7Y/35M294WcW3nVtP3GHZntneM69afH/pNH8GTVZr59vT7v6Y1H47kAAAAAAAAHsooJsk3aJtNsVJ985diizsZ3xE5IABKMlqlLDHCZScBURSBI1YdSi7lempsvFh1mQx6FbGsxRHk2g8OCQP9SLhGZHMeku9scTZNgsAzKTn7l97Hdav2liAAAAAXeNhNMAyJEClUpbC0MngRcAyDFYvL1quGvWWn4MhHE2JChqNQldpEtyvP0M8ghWzHi4ow0UWUAxR+oxWqxXssZXF3QBtnlHOdcODxVvXJVVclQ9bmB6nbI+0d3GxPM8sy2bYcWNWHvvbx3zZnEusSRoV8fWM1/9f8feoVsY1iuq7/xje7W9tY9Me1N73mn3/953jNq/EK/WGrxOvxwVPjQlAAAAAADN92AdwRq8JXOGpj3Jdj2j3q/TiSox7xu5T6Rx9S7NcfVZIMaxkxJcxM5bTqgESEIsuo+fOn0omUtF3DfOQ8MClbEPSAx9olBYZSweWoF2HkOuTeoe2iaYAAAACd6YSCJC1BdqAJEq//u0ZAkCJPxVWWsMHrJc5KtvPYYmUp0zaaww1slhFm10wZkY0vY9oICTMgFhjDxwClRMJlMUblIWBt3kzkoq3F2U0dYW/zcImkWxdo9lm1A7zWW5qxOEy+bYq0aA9RGqYOkUOC0lV1Nz1caHBTseua0asP60YPXouQseh5tcms+zsS5S7SP3ErGuLtm85BWX3oIEOp6nGtmpKkPBeDmZJFtVsReXmWZqIDgK6BuLVR3g10hBNQAAAAAU2tGhdRiGvLGV1n2wEcqPZ27KtLU2/VSu6dHJpdEWMJFlui6LxkjryfMPuxVuxsyAbVFmb/R8RdysRLfczO8yRS63OPf81vzPCM6RdnX47+fhv+3/XsjSAABm5Txr6riZaZw1RXwKKXNS+eUrDAic6uYszWVt9alkYli7INmHVrJ8O+z9iDtMpbJIAXKboqE4DaIHNKhBHYZFlBefL9kQ4P4t+NIoKirkWNLiut9hAZHY0os3ANMqiyRpFHDi07TdTTq/H7+m/drXm92ee+vW52zPswTVRZ7UDvUpdudU8+5X3sHi2o7tWMbPwQAAACumo6AXJARTA65hKtw89T1Hjtc5CWRw8i3bHtoUdmyUeNuKsp0+WedeSlze9JpRD8y1XvT+aeYBxcymaakLG24Dhn+5VAEmzhY20eQ6Vitsc2kYyrVTMjEAAAAAu45CICCF+hUiHF0Bb2JCEIVNxTSGVZU0liLPa09z1SFrz0QQ+z2rugBYGAFLZnT+JkQqBpS12DovOxVn//ukZCICJPpWWftJHxJcyot/LCPoU0UHY4wweolgHW489Iwpa33AazB8MzMvj7rYwAzBft61YmIlfo5SRk4q4rDTJZyFTbQEbGMJNo69qskUpVE4ACQbCjR4/J18irH1PHLIFM5C93hA3OshFSgliczLt6yLviOQPwFshyg/OaUQicQAAAAAUvRKnKGpMNXH3AGAugtMVqn3dKWg+6RRnlzuorfMK0xSGQhTaP3UNa+V3JshhKQoWFzP6bzOE3KfyKU03O5ikFNfst0PnKecvdQPYAI54g8HSbLGCPUigAAH6CYySJAPWTPbAlgIALSSQSTTgayxB52ds0wUuGSZ05e9YyXC/YGVw2NhzQGPsrc5ekMwA0ZVdBPDrEmQQcyhiK0WVvxRMMdlphNKBgrHc0MAmRo1x358XlBfKOobLvpanR80f+rff/qmhs9SJ4MIQkDIQ55elPuLAGzo8xAN4iDDuEILT64HVhZj+f/loAutp3//78vjEhqogAF25DBFWVslb1kRlZCGAdlcIIHryrVM7YGGvwtgGGDxvs3YVoju/reg7M5enyf/8+b8NjXtc+8zPOhpfsgh/svkM+3e+nk/PQj7+doO7q7Rq3D+VcgmmAAAAAlKGCIEWxGBqagM//u0ZAiCZQVKWOsMHrJd5RtfPSNeFBlNX+wkfIliGG08wYqgAF40c5SnbGVcKLI4LuY+mAtFfiE582puM1BOtrSv04mVOEyhl6ws2rUwRPqw87rMsXYyaBYszaPRRbLX4clZmILydoMB6CovH5qVmEZsJi48Kq5DMjAzI6931S1+BYw1z94cu87Y4dcOV3Wfx6c630zwZaFbU3r0iJ+EXmCQXDgYNmpdsc7/RloVXDH+89zcurEQgAAAAAXccx7rxfzgH0xjmjt0bbTOJstw+PVUWmx5budmp3qccvRQfdjMyYQSaI8Ojue1EKYJHpnZR/IEVRWeVCFQJ2344COCbh/0qeEGJQfoMo2pZCA4Sq8k6CACMAAAAc6fospS9IxxHEa6jcWzSWLjJlJhxVnLXlgC+ytKxFbmQKG0Jc1ndx3Gju858qcecZYt9masDYlRpCy+G27sMWivFmTS3eehhLqu7bpJ+rKG2gCLUl0CSKgyOtDAPl4sAVAyiihSYETKJEdFSPE1ZTKjuz1101v/jfuv3IhUC5rGlPfXaGOfZyiUDH1P9ZDLngknFktknJBTm76okMWCe6CDSt4yu2JN0Mgh49SB1lxmzEVIG1rjvTEiiSisEcUYlBLqOMMKCuG8xbKyHUnzHMlZ1ZtiOhj3+gkiAXD3AaQSPCQHJf01lhKRLLHjS+8kR01MuYVzYxAAAAABS4B8GLhcTPwN4IAmiXHToWmlooAtBo7KmqwPDthItrD0xVgcMRDcOsTk7qWW//u0ZBqCJPpaWfsJHrJZhmt/GCOgVFFVabWHgAlqqq5+mCABes3VgYezOKvGyh1ICkkEV6aISj5yA7bOwWWKrE4TRL8kF11EKlYiVIWsWI9sdRyVoxm5K4pThNNflJFVEzk9n6h5zvkju6UFEe9CJOURpBDuLoAjgb17BbnWRPc4mAIVSCEI64dGHh/gY+FUlMgAAAABlvNSbOR7ABKyZq0PHc5DvWYXNxY99NYNJwlHeVhsluR8kI/vXLzwixsIV7vl51iUhybbgu7TB4aj3bx4Bg4Rg5+Dvzf87/jv8Ad4A5wAQ8Pia/rTYAAbuK3JMjAUQEkkHioNraQiolZmnt3UaZa3VsMAOKALMlMhcCVqtWEMq+NcmRMDyaDlTigaTLUqBcywElodKoN9QplLNihZ2hxU0RjVyupuLVsteTOI1o8mO25m3DzrVv7Yze9oUF5KwZvWnrS002a0tGpJFpv7tbMX7heuvmufrMF7EtuWC47tvEK2P8Rt417Qra3uDUHeCsxibLhraCDckdQAAKv9F04iCCPTlaS0npI/+rFcYjuhSrRmRFRTmmS7IcMY5VdFVlshm1vtpz2un/+/0Zfr5StdEe+j2qZ8xQEszgwuVgzIpYZ5ioZ0DDqLhPNirGgrrAr1kyIAgAEBAAAANuSf461wzdwErTcnzGDzGCQQaDCKlyRhjRQWLmVIJIgYgJCRZUtEqpDKNq+wGYcSPyQOCj1gAM9HMHLawRtfxiR5FH2VAARjaAjJmjyFeLIC//vUZC2AB8te125rAACGJ1stx7AAH1V7WVmcgAIkre03GJABPtlAzAxbK2dmQAPyI1BqiBSgbRVcT0sWDdFJBjrv2HIRzkaBGvJVzxKan3qxfp3ZfN2XcfSxK33Ym3RpjfP7HmlZO+wSSvxbtYOm/r2RyG5PcfdoU25FiVUdBSxWmwuxWrQZ2+O3F43K9S+5qXxuWyqnuPFQyqVU81QUFmGbuFSIW5RXqTsbvXJynnqKNyuvhzTlTd2mpLUulONDq9NbAAJAoAAAAAAAAAElxKMXPRfdTmnKq71bWs40/HalWFYFSglM1S06P4j+5WcHlSfihGYUO99GSiSVlxudqx/LKaISDsQlaBW78ZLsq91WDY6PnyUhrGHG/rRTrnU1uN2q5/qxfPzae9zvpvzHLtoggCpZdhcLm8SAyGtAwmpMyQOBgoLYvraHRAAAAAAACTc2/EYBiIgo42wBL4FHhQEyQwCIXODNjpQEKItMiUokZgIXCNkYGipcmqEGNkC4GbBLJiOOCvMlKGvwA4AuDhDQpdEeOgZTVWMmLIkZAzE3khGO9y72XJgrFXUge14DGR8HNtUJpVA34csv3Sp0xxUyTrkO2NDwYymXKBLyYygLdqGpdLlTN1YNK40zKLP6/MuhMql24Uz+GJiW5ZT/JZLqKX/rjLl/Q7VrampZXqxult/2rhVqUE7FoIfWkrdsMXTgd1x34eyLupFXmuQqkmbXb1y1aps8pJGqexSR6bq3JVVjNJCWWv9FX3t3YzUjdLSYuTBAgAAAAAAAEht7XbJyphivjHUC8S09Pd1c9bIt2gUxiTBVRCoUZkRLsQgYSNljhcHj5ZImZJSyQrWOEitlYG0R/aaTVSWvIIEY/CpyQIn5LPVTn//UdmlKm45Hcl89OZewzO/i0KbqL4W0xlsQm1COzyr8HQuFe8/q/CFXGE5eUr87ye42sPVqUbTAAAAABl405pagqHJVpf4uGqsv5d4gGkO+8CrOgltmpKoelFkxOU9zNMswVyxkLRKc//u0ZBmGJOBIWG9h4AJcQ+s94xgAVHFrZbWHgAlaJe22hjABPojjDDFEIDgfTGO3nIwng2GFpWIUrDMTigfrpWrrOVM8XUsBx8ddquM2QWOWrG9jvaTxpFNExuHHxi1qSXvPj+9JPje//8ahZzfG6Yzi9P/f/2rW98+k2N+wyGULrjfz4g3rUhi1t/GVCgTACAAABm/+uYG+XIpi+fqB7lmo4DnuLZlyI1CtJH1BiiDFz7TvUArcIpgdzijbMTZkKU5wGdRlz+aKW0pH/P/1t8D9/fWvmgtzp56ptnwDM1Bf9vHHrKW//wUzzZCd5EohHFA4StBfJ01PLnTveNbb6LrZ81qfcBAHmJK/K0v6OOpuVCZGEX0whwp0vsUuRJDtgC2jsMEgg60vOSBHMJ1IS2qw9ELsXL1Rxwsy4Y8v9vX8jY2rDWwPoEK808J7PBeNusyQ4law6Zxm9fiaNr4tv7xneravr/GffFc/V7Y/+LRqR8YtAvSudf59b6tq3+YWffGcwt2x9bm08tNGxxMRABAU/FJLlAoqZLk+FvQgwGJSkDjw2JVMJHQWFRnBwyYNFY47hA+rZFST1ynn8eZZf/n1dsuy9IuGcKGcvrmX/z5ZY6HqRoPFsoeseXZY3rnOXf+OqtqUACAAAAAAAAAAHFtDDFoaHgCpiAfMooTHGULJyYQCMwcQigiZMKDooYILEoKLAxELgo9QXNMTQDmFBnTSmbEAREY4cDSIc2M4cMMGCpgxQU1sEWug7CYcYKji//vkZC4ACMRd1O5vQADEK4rdx7wAJS17VbnNAANkrur3MvABoIIQhvzpWCEZAdZgYIoMCgbLS9CCyMitIOJlgkhzIGJlUpEdAx4GgUlVQLOCARft0V2uDJUdS5bbmCBJ8l9x0Cu1YkCuhDrPoqtNWMvRIHme2uqN3i0EFlr0NGfNafSjpZDu9nAz+TFS/3dVsVPGZLRT9upLqWheygpqWM2eQ3Lfinzdq5Pa3F5BOYyt35HAktduVS/K7Wl1+MwxYrR2Ww/fvZ543auX9vzd7K9TxONzNPXjBz//93/+s8H8WmIwSAAAAAAAASJXsgh4VcZymNImojxJCZI5EiYgBYBIZjcX4eAnrs9y5JQaiUJO0VOknLMoh3l1KpzhjbL4Ts0xpDvT5+GGQvAlBeqteUBZBQADtEKpLGSTxIRGWG4MBpj7Oc2l3sua0qWWSPAnhu8s879+oUilDTUd7xVLi8eWk8OmYPrB8tLUV7+PM5RfjVI0eN4jqNFmpjUjxvj0pvOKM7+S6q1DiUhU1F1Hmvql6Uxi2d7nmpreNPwfOM/////83ta6kiSAAAACQyZXttsZ2hpkxgmmi6EEkzoVjGQ8Mnn0yINzAg3EBhMqlgxWOjFI/MZkUqicwEFzBQpMYhw4Aw2QwxZg05AWHmaOgZyOjHeDg4gKAkwsCYcUKATTDyh0GCjHtBw6ZYnITGmHTMGEiqAUxRdAMAiIGFjAMQEy6Q8SIgyRIXBMGAToFEpcj+W7QkBw4oHN6sVOVPMs666nTKWuqzI8PpFjDgFCmeMCcJ1UNmvFxmkvC/6aTWHLZk5kEo7NCSEVA41jGXMYYYogrQotKoBZampJM3YswNWlKCJDJOdjKhs8676wQvZjMJZ4wD5K3rKZ6FPSnLHYemZfKq8/BzvSmCY+/l52ZqVVsstfKJRLu1udnoes0u5dIpbUi1m5WxmK12xcHbXXAAQQAAAASCSUpJbXEQfLvmKi0dMsXVNMkwkBggcoMEqwtKC1gbEcBQjtANj3CUgaK2h5+nchRPjaSDGFrLyQJcCiQJ5PS2BSGqjRYSbmKDXHUQY1AMhbT1SRUjfVpbE2uC/mgYGW0WEdRQnipFpsemiXVBmWXdCGQlyHKRPqKDAMY3jpW3FWzwnzyGytqtkhKaMxKFjfystVMzMMmG05k9Bj6tRxY2OakJ5BbfXVlllY6SQotoz2C+WkOeoanZIMsBuYnjVqLGjbvvdPSIusWgR2rUGakWLVlAgAAAABAIDAiWrOgMMGwBV02jAi0miM//vkZAwACGBb0tZrQADFqzqdzDwAYhV7V7msgALtret7NvABmYJGGLGYHm4NGhBBjIxgM1Q8AuwjWBRxlgIcABRsxaMx8IsqY4eFA5iRcDmuHCN0UIQqCYst50UmCqGNSRMgNN+BBScwoEeCQyk40tBCiAZokEMjPCA4kClJMAJgDZC0k4pasZa+dVF4xoNfxMaBRxsZZRlKdrRVDE7HYEgbFkJESvxx4i0d5b6Xi9GSNzed3WmVU6nvf52nka9YhUWilZcbvzEgpqGxaf2ZpbFjPu3xeG3VlcrmLtLyYmXlee1A8o+KV6StLuymrjqpboJbvDKlu52M+7ymoHiFWil9JRyyvRS+5Xt4ZZ/eMh0Q///Yn//aBCSAaBAEAAAAACAwK39YSg3ZUPnFBGdpytanmsrVBPTApuzvQ7BAS8EaA/JEvZbgEg3Q1RuuBMx/KLJzkSlpDfCtJ+eqwC+DeDMRdxbCCJk0SfnOijLSp/p96unJ5HQoXA7k6WNDSstGVzLMbeLP1bG6PTSicFGsua7nY308vS68rHdqvI7yFMzxY8CelLb+tac1CwsbG/eO4zgoIb3Nrau/nezzwI3xWmnzK5t0RbaqbhWxpCE8sq96zMj6Z/BjvMQacMVepcmSgEAAAAACAgG1m/abp4bZAZIScKEyUwIo72YwhQhFGQJNsYE0KMAQrbiPM1XAAWbxpuDFg0SuRtOBEFZjMxgNgQoxwjGCLCBlHp4AoYIcOdMtGJGGeyZrjmgEJZZK6FTE6R4Yv+ARUEgKgaIqitZNZYrlDWi6kJjjtdQpRIUZWa4Swi5osgljFR+X8X0BQ5sdBWklm05iD4u6nPJXLjL2161aBojLA4DS7HbdWP1qeMNblcWqSCbhlnWrj9X60vtSJQSRs8TUfRhjD2gvjG6SedytAlPIpfJPjtetnlnKbs6xeHnLXRAbPn9qPZB76OnfexrD+uPEZO+kalkboof3NVt41ZbUs1I1q1sn//0kPkwAQAQAAAAAAAAFdfza4U6uRMMAzJgxrT/Q3PRqanoam7TXqWOtZaz9Wi6LTf1Mf5Sl8YXUNTnIqyVJtdraKWT0G0eggDwfB7nHosSlHs8RRzHck7o1iQ9+Y7khbxxQwtzHWEtMTal2ZjVlWxrRbW/ibiuUHbLAyytbLKzx9xI8OsN74MsPH1JrNtxITNKyTTw4eKRMTXruk8T/ds23X+kalKavS+838sRjjR5IDBV/LO4QoV85rC2aSLLxBAABAAAAAAhtyYkVOUcBHnwuarZ5//vkZAsACD9e0lZnQADVK9p9zGAAIV1hT1mdAAL5rOrrHvAB2iIkgoUONIQyxSoePECTgqMmwcMZqhizcGG1eLAA1yc+2w8IEmGHAEECAZcc7aU7S4yQRTpLqFNzbqMiQxUYAYYwMzYCAk/k0QcST7LLxIHFoPCBBiQ48Ld9HdPJ3VFFROGlQsVSpzH2fp2TDkUf0+S0YCFhyReqRqwaJsw1GAHVd2RySQyl9VDwgWYwEqxuZZAtI78dpX2lEet/XrRqU0F+7QLUY81h5H/72u7FPHr9WxKqGmp6aGZdD12a7252fsPuyt+5NE4vKZuOzvMrm/+r+sed19zHWt//f9g7iO+/byOm77yTMDupYp/////+EDPYZCIKAAAAAAAAJDj2poiXGgM3qfZeAKAQte9IpNx50sgSBPVPluy/BBJJJWRIoHHTDV6zaNNXdJ4WDrUia+07mHuA8kkdt2y/aiqfz0tAvonOG1tB2QNLaQmAywvXH6CKxaRtgXs/sBvzO22/ld+mron5zNHN0tnD79NSbv3Ui1nvI7bjvxjLn6kdWltZ36W138rWercOc7YsY9np+ftWaf7+edNbtXNY/9zKxcr5cv/Yt9j9DejXJdarduZWt6u7vZb5hzHD90kbl9PNy+3Xp8917etkAAAAAAAAAECpdoGWncmKGBiJqjGmEZG5sJg3Q5kwU4FlDVVPbMObOLcFIQsAUAo0ECUYLESQAhwU+NC5R/MKVNi8MAhMKTLSlwwdNMakDmZk8Rb0WFstRSEQgFfjLAzKAjWDyoENonMQpMMMMWXMmMZkm84LVWmAI2psTDkWRQKWUZiIyDaJpg4SW1YeuLTssgLmGFAIyK+auPApWz56kA6AZcqM1mWU7etBpI9AcBLBMUZzCYHt3eMNh2gkcalcUjMHU9SrvO3k4i5Z2H39f6mxo59/oDszdBel0zT3pierVbuq+F/2Jyh3piOapIvJ37sTUcfqNR2KS2GpvOdlVanvBoPrWkb//9Q6ACAAAAACAiXT8sx3N7EpAMLmtpxD0OQ9GF0LRTF7bBwFGGcrBcztIKXM7iiQqdoZnExXE4g1BgoTRcHGchClgl4u50sSFDuOhTE/Jq9PJCzEL44Giq0idCtOwq2lXWhRVKsn4XE8jHc0ge0xKl0xtCphN7W47vJCM6dzfNErds733RU/Yb5vNXepJ0Yh7O3xlhvdK83avo1ZpZM2r9etPjX6LhsiViJNlcnS576JC0+ewaR7SxIsKWJDpSUDaollViIzMiERAASk//vkZAWACBhN0f5zIADd6ZpNzeAAIAl7S7msgAL9r2p3MvAAil//s0j0JdNNEQ+eeDWkOOunIxcFDIjsMiFoxicDExKNDn0wmMhQXGCxsDQcIAwYKIZj8vmCYdLByzhCxjGjERiDlmCQsM2QeQLMIhTJ51qDRyUpIOW5Aw5dVNpXgYsIhi6Tf4moAgBQQp1r5SLCIUV2rowDSQFBZpBAhCbxVyeyI6I7dmbp+CAVTcUCZ8QiGGcgmYUyqhjLipcvc6q4nUhiPS543ljLav1ACI7gg4FmyObwhAK+2QpWkILcWOkwNE19oTWBgdCSu5OuH2tKY0EGsOdOGXjlsD7nqOBHena1iiwnLNeI3eRTPGzh+r/3AqlixiPlGBK32aWAoAAAAAElSb7tMEGhocIWBVd5kouYqumpqpkZGYUFtFMWCDUi5CkxQpAAQCgUwMQMOKiAIYlpT5jJHZLqpI2E0GkMRkz0MAUKSnTVX4jk/rAI8vwtCXJRFJkwWnAy1MtwHidgZc56Pj2IQ0sFP9GngrscZ3Xp5x3Iap2U3HUXk1qBYah7UafuR6gqzdvP888Zq9mOIbPVG30tyCO3nRd+1SZ6iU66LX0hoNpn6aVLWaNwgKq30bfhjUOvJqWUr+YzdXUOTjotd1FIzRxNyJVl93EXKlQ0vf5CFNEA6BAAAAwAAIDAiGwtZ7RYACGNGGQIBCYHMAiAYJ6YtacYOFR4GclxRAIEg5awMPmcWKYiMMvwMnmTQACUeZALMgEYPOB1h3omOyKzDKMUNUI0SzAVNMAbBD5DPzW23QvexJxjUAARgNDR6HjjJMDVjWUC7ptErtbrFnikK7CgxK9DilsuFbgRGYBQGGQAhD6Q8/DbJ49yKQ6wNhi0marHfeDEEDQEIC07SkakuHmkkXsVZTlNs0YI/9NTdp5cy9rrZ4EpLeE1DNmNX88btNX7LLMYpI/T1KG7anZfXuTl6nwo8NX7eX/rn/3v1KT9WrOeeGGH/G7N+xYu4WrN+vWvMDgMgAEBAMBgUDIfqaQM4NeXT0NGwUKSVHXnHuT1gSBn4vU7BJdc0OtHJA4icJhuSCuZ2KxCDXsiDPGGFABIA+wDENSVh/hrrRNEMHiEEEdBBg21C8YEhHQhIsavZDTbQtQjBBDDVxYkU4XUj5nUcZUMje5vnheGdGo9USSpqZpgQIdMv21miTR8WtGVjGoWd4+dskOeWznS8CI+gQ7ampjrLPN85xSkOv/////9qb8DN/rf/s5KyG9dskmY94Fa9KIQFIQA//vkZAMACIRe1G5rIADAa5qvzDwAYYV7UVmcgALtq+q3MPABAAAAICR1f1NKFOnIMJSOAdHQwAHGFIiwEHJwMyHSpiC481FQQGcGbHmFKBjgQJAt40wzuUBghA6XtDLVNzVjJJQtQRNCW5xLICkZGnkLpuXmesYIpsGi0aKqJuDTHmGsDmHFrgFALKGk8OtCAcmaKwaGQyLF2ZSGDllGYJXoBGsImRd1WLK4aQ4LMMoxEZLDi53gWCZ+3Rwoi9LrMSbxy4ZjTjPBA9LnhjhPuM4sPRqvhVk0UleV+7zKvD9V1aaR08hp7Mgi9FPsMnW3Zw8DtxCPx2pSTtupTYyKXY36O3Swu5erTmS5GxQXHnaZC8TjQDA0DQ7J5FIpRNymgvXr9yVVcf//SA0F//6pVAAEAEAEADAAAACBQOjXUNBdKewEG3HdNM0nu25IOupdLV/QU74QYE2QpCDVJGGmQoFMOscZkFYS5yJ+1hfD/0ki7rm5cB8Kovpik3IVAHOi2IgoTYzI7iYTAzK1lams6UkyoalUG2rirLAvBZcYnSzI4oNULLOzn4kns8eI5P2JjYmtUwHkkPGsZz++mmv4zahaRevaPVdPGs8dObJSHAkhxN/W/jVL5rbeM0z85p8f7xumvTGcQH00fNLzRxAcqhggBAAEQkYp2/an6KnFlDEQR7hBVJSmSJA6AFAWOmEBmDHfO9MSXBkYhUUHOFMZMQ/MocQFshbQ8nhFITWmSMIggMVFXcRXOt8zkzpHWiXcbVkjZ5agBqmcsJfGgU2EScLYoc3cJRmTOovbFQ1pC6jFRTyLxpUI0IaKiSpYi9j3NIYczVhsJl8alaCemSTXwigxCq/0EspYhceeDJNBlWQT1+O1Yf1Zrw7C4xB6mUP3o64EplsmhyM14tLnamIq7Fprk25LjyhzmuRNqDD6Lsim4zK8o1Gr83jlhavfKpFeppdm/SfaVDeLoZm27D4CaY+kRddnMVonimos4N2WxKmpqH//1gQ0g+//602wOAgGAAAAwEAwOBwadpcfcV90dlRod4fjmLahZYIQpu3CHJ4cJbyXjQPsmgvxuAhVOGAW8WJCivMdOpxDzg5wnqWEnR8FvZEYwFQpUmW8R+KXdDXyWUbediMXjqH4fytQs/VmO8VmV58rdyxZu0qBXKyO6ni4iunK0OHt7CxmHvW6bhyRGzT/6vjGJIjqt/jvIMFna4zI+iP4MfcH1xn/5b3bFFcXrNPJiBTLyNEvFj0niZmfyG/oUUS1sSBQAAAAAd5D//u0ZASCZGw6VO894AJxhiqt7CQAEfkfSawxGkmRECo1h6RhgalAIIDsBNDXEeH0dopIjpOTRJMWJaHEMEfJol1LalyyRzGWZPR8m6hqJQCdgqNVIOM4saHJyKl1cgm6MhSebmJnZlctQmKz5qg0lisrbNLGvBbVayva4n+c6/co29wn0Z9G3vNrb3v/Ncb+a1rFZv7A3QUFBVt5BRS9+/Ge/H//5uxQVcmJAAAAAF7druCCVVXdlcCw05bjM+eindydm3FAMsBSyZU3SJQNETZddHZUwhFOE5Cm0cQiMUoQRDJoVTUZK5FNWPh5ec2YsrVK45GPqqzL/rM/+yaeIgaDsRFpUNviU6LgretoTMnlrDpIC2fnQ7+eMTSAAAMwEgMRQ8HvAIKGwBYmk0FfawaM7MHYSEQ2ZFLGCJIKFQ6puXCX+oYLCXbbZ02RIZkESYk8jcXtoU0mBOBBSwyzqeWtOdpuT/PVDwHjk7Dp4raUYz89h6V7i05Ol9uh92QiKcVN3R0GFqo6EGFNRor221zS7Rta2LQz2+3DbXHV2LGNZ+jqE1fH2Y53YzMKcNIeBIcSQqVSLadIvgzhwp1ImigkfpETkiIPNIjwRLGTFpk6NEkChGMgKSJNE5lQHkYpJyAKzgvRYqSNQe1sXd8ENhN+X3X/LaZNveU1b/qh6vxq3nfbSPw41kTDfi7blFW0iAAAAC7wGkYfVLaS1S1uaPDsNXlq7GnzTOqWOufG4nKGvw26TotVsUsqxc2CIcj0//u0RBkGI+I+UusJHiJ8yLptYYN+T7EjSUwwdQnxpGlo8w+BInWurojD5xqWvxYBwVlTYDCyhZYiRoCa7aFKpSor3FpHKDmHkMciO8OTAjR+l3BHeCn8eHdK3ArFhjEFW7obuAW3NPMRCXMqTNcWTIQAAAALnA9RrbQy1rEHkcRcz0SVsEMSWD3egSna+YlsuYNx7GkUpVyEIoMS2TS2hJIw9FgJh8IoFj4tn4htDMDxlC8XzoPkI5Q0N/V17a7Y+be7qZWtAwIHzBPGyZiXw7YNeUjMs/UyMSbkdhZXuX3hYlyzS5omzvxd/BJypwVki5fxiqxUTE6FUmNq4Z0sxujD2+YS7T4tEZTHtPGwuhmVOJZDcvCLyOeCSchQAMXx2LaGwQAgKyYnD6qHEcjxhASVPVsnqWzKJZLJheiE21NqNgYIQbJiIHhswYuS71cjqV0KzyMlnTyPI87SPLdNAMEmhxifBSqxQpQAA5wD9cgAIMQCCABAWhfhXSaHGQEeo7R5kjHkXMgyduXg/z90uySqSKrTzNFibEKRRoOCocLlyqxo1Eos61JDZVGqDEenG/nRUO1I0Eacs0xmRsmzwaRx6TkhNWO0wLoIOROTQDEWENE5lTnrMpt/mfgx0ZYGiOvvFToAkQAAAC6Ax4qYtUt4xHTZDIl9UrFLFxLHeUDCKAqOLuTARZrKAPojUJHTrnK7/QMimulDSDKSiZMsyAWioJm1bpCI4AGXSuOoDx+BEIUEakERFA5IK8dxmBMJ//ukZC2DJHU8UNMMHjBlp3p9PSOaEnT1QLWcAAGilCjqnvAAgnHwqplBbLpifFjj87K2IaxxUthvrXMUpTXdCZDI4b+dbnggmMggLi1Bq1kabBVbh7C3UnA40QAAAZeHk9R6RHhDKsp+FQTk0kOLi5JEyS5sNVpaOFUPMf8JCEnVOqqtKhsuh6REk4MiYIBgnLoxGk0mh2SUIYWYjk5VVX9+NlZ8knrzR3RWq9hpmk/zw5Ntq9VBZrnsvUtCUAA+JIQRgF5TWGNEZGgwgwIM3QSWS/fVeCVg6OgiDghgcqUoFplwSAEPOlKH8iD8sISjc5OSCWlylSqcZ/L2Au4vqAHUZsnNFZW+2T+uy0952uMif6ej0eljjw5K3VhivBOMBzusu9lEuyq9vc5Mdq/+8cvywvfjc/Ln593+GOfP1zD/y724DbRYlYuTD4qibfJU2gQAADIGlyVaHkOGqE0cy+Zw9DqqraUkxk1ujS2IYVSpUhkIl1GbEeq3w0ISdQ45GZPpVZOkehPII/Eya6WSTAj6x2K7ht0oXWGJhV0fxodb7jbrFdbjidKD8UciKB9rVuZSbiptCH1eioBiKQgAAAAAgGB2vYNjjkAQSQFGUGJml7AxUCQ4MDmwADgYxQYQ//vkZBMAB+xeU25rIACIilr9zDQAXml3U1mcAAo8peurGMABiYMNitAQqGzAB1N1LAl80Jgg0QDs4R8iKQoDYNuMHTCXaGy/lfuiRJHKGZUxnDvCBpH9g6LwO+RWYbwwFVIkwU2ITDIISDIRx0HJ3ZU789IgoMpwLAF15GkGztPZKKGGS3JiJWM7XbKQkEp4pjyRqTOF6Rpdj7wa++ctkEXh6lz1L31TgWHg+3XtQ+0qBo1KdZ3r3OWdZ7y3hxSh7FqKVtDcd0J17Ibij/QBPwTVryqev/////////QQqHJXGZ6HJJLX7oaaMTtPSYUl6xSdu53T3//3//6eBgMBwOAgGAgKByg4LVkqJ9z5iTJbN2ruNvTHMaSk8kSKYIjYmBliWEkS5KmxfNyTHgiUCQJzF8+kXhPi4UmHOMcjjkHcxNHoaDkSSNNyAS5Kny4ZGZubmanYwQdLPEuYugplLQa1TUa3QepkFumtk0j6SP/1M3ppqZJX6//5ohHLIJy2S9dFpnxgAQAAAAAC4rt/gwgifImDNDPYMGlBZNTUhBMksMaByRjDl9C97fA0gzUjAtJhItXYw1eBlcqkbXNureW/AsBxpa0RvMrBU6604HbT+ECzEcFZBhwVUZQrla4GA8tImAow7Jd1MGXqHKjUqYMz1rSuIYpYhIWnwasK05k0amHpdVwXVgqMxK/Sw/L79PXd6mi8816rTP3Gn6mcrkTpp+BKtdyH8sSyNWZ3Hd2M3JTGZt+Y9HcI1UjTXHsx7RyznX8pH/eGURGvSxGGflMrhqjlOV2doZbMSnCmvQ4/ksyjEsh+/Yp6fN9Y9aiMSjVumppV6IRwQEAAAAAEhu2W3kV1zFjoFkxTDoln5dqpQGDNKdlczIhIZQlVWywPKwlLCcrEhIobScCRyWQ5fgRKX0g5p23ygSuXRrryvXv5HjeJlryX69vXvTb0q7BV1iF3N62W22qO+l51EtPWK9AyhxbXJrleXvxNvnneeUdgZPaMrXZ1rIOb6yScID+jzMbchTQRVTakiAAAAAXeC6qqqQDwg5CNxe9HFqyCVWhgy+VbXEZ5fWSPxFBgqJQagJRj8uEplckH80Sls7b8tFDS8lcHgfxYlM4QI1MiCZEpwppY4h5PuUtPKD05aRM3fPYsTrYWXaQrezvzOvW09V2ns90zO9Nc9mtaLo+2Zrs/M2+cZ612ctTJtrdovv5vsKx+KxXr/waCHYyQQAAACE78bJUEmMHHRxJBBjqsDum7rW4ZYnT34VaMgmqJplbS//uUZFyCBIpGU29hgAJzROqP7DAAEbEjSa0k2ImxJSn9pI25WqnKcskkwJLywUtnPjFOV4UZvCopGhsHyx60eUoqejTrepdbFFtPddIwCNBU4x0NiZYGvTNMDZI80iytORK1qkSciqxKntU9Cw7Yt9qJgAF38y4GHTZRDPFAMtjL9gUIVAENp9sEVvT4QGNeySMa015S98J6kg29D8ilz9Qy8Ly14rOPs7kfiVGtqenQsEjYjYAoNEYXJ2DOQCyY7BcgE5RErEQa6DLHZaiaQ5Mbev0m3PFu681o5WwzbjV2pGGzO9vPmr3f/H45Z+FILUTENQi9LkX/wl5N/TlnQSAAAAAB7h8YwI5ZiBIUEJaqpOO6Lsy2EOQ6r+KH5sk6rRcKGmXlFRREuRoHFVjzaSQsTAkvxpY4mGXoFW7b3EUY7s4Gmxy0ilyqz+7WZfIzEkNf7N/0uSofIc9lCFDKZF5HMbZ6aqZFdxVxFtAAAAAOYHVgJgQAYuCAgtFQEDGJ//u0ZAsGBEpIUWtsHUJwJRpdYSZsUNkpQ00kfAm6Fihph6V4ZlO0DEqqkFpWtLZ4lbAjSkwrMPrzljzsTX64qpoGd+wBMBoofEkjrj0pVXl10ugNBwDZkalsP1747M4WiVFEVDAsS6fcts5d5TbWcjDghEJhKCoCkLK0AUGYCADGJUBWe89TkqWFW73Wnz1PMSVkFbvZdxd6OIgAAFLcP3GzGIoQrY2ct+PLCCtZdJka9F3SkCQ0BBGAAQjLAVkNh8QMGQ0LkpMKlQ8RCkMoRqDCgIxkRUMCTgowrn3h2n2aCZ0bTXsW7vSFjd+srr8X/z5f9735p0poM+fvsJ2ToB24Nm0HV7ZGYg3AnTOkAig0Bbq4ocYBIKAUlS8sGV4RTQ+yJvG/qthZ0qdhCX6g0RibUExnCTyc9n9pgjLGcR9835ruiwaxH2lqNOzDL0Ndd9Y0evRqUvtR2Y5VnQmVcqIJETRpDtip4EDEWoeGMGbJSdSFTzS6/p5nuGFI4otbT8mKeWcM+xkHRV3Kf3gYiIAAAAcDfx151FlH2ZAqaSrWaJbEPHgRB/PGxEpxQ1LrBRi6TBzGMkB0lGZSqkMJJNimN+OcKuSyGJhVJ05zLKBVvS8AiCIoGGZEBMkfXKQhhI1DBAu683K8vDbZ0DBnUhpZaJWkQPEZtau3XGoVgpAAAAAu8B7y5DREEBZWE8yCFANC0mC/EGuageUEvSmW6dI3i01K2FQ4rIyZ92WMHXAuRvWZNIi8COwq14qWBHRj//ukZCGCJGs80OssNpJsxTpPYYZeELzxQ6ww2InFlSh08w9BFI6l2NLml8Pe98JIY7gugElMcrTwgE1OtTuom0uEVa/ntlYBdN6LnWsjD3RhqF6Ufkqpn+93+xUsc5kyHRmQ7xUe1eVV9cCOZY4NBkhEIAAAAL3AacZOBPmdD+tVcJrCPLUZxxwUPFbQ+kpXAlUBIgoBZJI/HxqyP7JWPHBwJ6s/ufNIaxMtRtriZGtCTtdzU1wap8KR1v3nc95TK0gPpMcONMLHLa4wtxkPLtQava0VjJMVS9L1ihEogATcBMEjSRydjxKFJHkBEyFGk5ndGRQyylnTYUrXcdJnTow+w5TdTZkSvHOpXevRqNs1g2GIvONJajC3VkHIBiFBkWWmxrKp+cjcKzoclilerjbLsVlK944QppFh5GoxzanE83zWwIZGd19K/2P81s01RUQA55Wt3WXDLocY1l/+xycQJlgAB3BrgmkhpOUkHMUQV4GYc49g5S8i+WVOcJ3ngnoCSWWxPNsSAzNpxoUQszcqJvSDgwJ8vczanhtukTHioc3AKBZBENINgc4hQus+ozGnGckC4ZjTRFyRpUr0WGWtVx9x6f52c1H+XXJXd8zP/7UAHQAAAAAvcE+1uinx//u0ZAaGJI5Jz+tJHqJoBHotYYlaEMEfQO09EUm2Eih1h6U5QEOC2xhQIFQKBgcAMMjAAFRxey5qRVjzqAurXdRkalbYIi/MaXu8TEEESz5+AozB0BPLEJqfTCdFgD0M7YVxwnKhFUEwuYFxbQohOmiNMRCcmV03M7B6IiNkTRjFpNPvJt+VXyMCFxjK6Gow761AOb5k4tFcljEpH3NkSuYJMAh7o6mvbDgsIAAAALvDafGpWncibLYaftBOYxOWWD1WnI5dJw7XuYqGwodXoCgdTB46RD2qhDIKAU2yObyjgBCOC7i1cUkqWtNqJzjNjbTExRKhUiHnA6xhiagwpQnsj30Fy+StQQRKuNyx8ZSwcy8D+CdTSgVLFOxCcg7GCzDuKkfFIWjdliKYaGrppjibOD8T6Y0D8FwZZiRnQI4mynL6Qg2E64Jofg/ITOzGiadyxwY6SZSbR2Fugvk5EhA0B88mWEg2SULPcePOHTar3FzS0YHSjKiy53dySj5l+oiJ6dah6mP5/mYEuWiuDdSyFPSDFK4yE0AAHcCQgclZ8Mu21pT6/xAJp5Mj5F8/JcW04johXIPZHryfV8VnYVGhSvdrLXGSzfhFFU+V52kQoB4GQRmdGBGSNRDU2ETBZdUq3CoM0lKThsFOHOxtzSftus31SKw1SAJRt6Pf/7Mlst/xFSDYAAACm4DWJdoxQ5HIIKMlKoVQ1SoFB0jFglrNcVvgBcjT3Pbs6TFXEdlQCCmiTbsKfULaTDaxIzPr//ukZB2CJHVF0FNMHjJrp4oqPYNuUUjDOuy9OEm6Eugo9I9BGfdtnSdd/Im3ItjyNArPR2LyEFPnxcKhwJB0eOKuRyt5hdCpXvws3aTnqtG5A25W+e7mXqAOrggP2ptF3dTNURGQqgqHFXsxVfEsyR6oU/z8traoE8gAAAvcMkDZyoJsAJmNDCwIaMhJh1k6KoD3OLZ6I5WBsfrozkxLvB0XUwdeSVCAPpkNNheXR+HWI/OjtLc0ZPT/oqwnUeNFtxW81sa7FYRf/8OPc9fpdvf3pB4dQft/zeZ1Dtk3P/80sXyRAFMAauPJM/FhTEPQ1SCC7ZOQhshcv0RgF/3BacTItKV4oeiQqaC0BTU0OUP2EKVLEDY07lLGHeeZUzG10TMUSuflODrJyIAW5dxmxQmGmwkxdlpWMp1ISeWWDzYwIG3UUJyxJQw56jMaXQ3C07j763HA+jcSmUt6gYqeN5v+/6vrOvM4vUDEcnlghgALuBwnC4G6IQTwIYPw4hYS8ilDhUaeFvFqIUrxuIQr3FFoYtMTVOyFyhNSLXU1ikZmBohk8MkwFwtkjLynTshsxnAwk3U0COGEs9kYmBTo1iWR++dDYZ1UTX6xv4Tb+5D1mna+zW5PZb379/wUkNoA//u0ZAICJDA80GtJHpBphJodPYN8EMUZP62wWknKGKg1lgm4AAAzcAfvNAQOYoGEHkqFKFeJ7l/lXhA5S0iHkwZamlVaCHHbaw/rOk5nubi+0bhbiN+3OGoU8DxP+/EEyh/ILtQdI5Qyd43FpXffkoPcgEiMuKBwRFy3XUVcOjc6JbFTTaEoc80BK5Q/MAlcBzVi7x56EpBa088qiUDuLEBjmyskHxAQkgAAAA9w+TgMwWM2gtJ1CbI0c6FkmFCky+p8kh0FgnWHddhZCwRjFho/TLFgyOGF5fKFmSsdCO0WqwFEyaMKE/EJ2+xL1lhpUZLijhQOsWjplADOidPacWFjA4cUFXD/NuDQUqc8RLAVIAAAe4ONBgsBJ2OQChwDAQCAjGRcv0ulXMiVy191GBP80CUzLF4Syl+0Y3pWHnaXFkjgN5HFTM5glUUpiT6sRljxvhZZFuG6SHqN7Q5KpiVx0LDIgD6jaVMrNo+ht1lyuqgzOoQGvvblFqp8lqVanCvM51ozFYtmXWQZi1oe0kxhPfRIKLbQQABLxIpW2ilBjhmoGYSQMwFiVBXQdh/4dfpc8DMTgBROJrhyXiCGSxUvVYV0Ify0JIUHo4Az8pAZEpUkfKogElQfFZbchLue8noTpqhmBOU4TUEmbtcyfcIJEx8KqGmJYF3DYtKddS0PtDQaTBFo9ioJQAAAAAAOcHjDNnGCAODAgQZs6a9IYUKPA0D05SsCwwSDp6pRqWkwtIhoT6JUl5moMOR8Y8xh//ukZBuCJLJSTutMRbBnJmoKYYJuEXVBPUwkeomhnahphgm4wHQL3szbnYfiVAuHg5oQ0o3CmCISlQ8AoKk4ckgSyOcF41X4UTpeZt7LaXHVqGmrDHUVpR5iyZqesRGgaYUGHFtB5zx89dVza7vu8okR333GPxEQYlvWe/cre42bVyK3wAAAAB3BG98HOelK8MAVFtmbNDsYcWB4ldKwfCiTCN8SSaqI+qUJ+JCPiYQEz5NGdXRIhiqfIIlDiwLIDO5zqDKai6vSWzIzKt2EtzVz07YchXKUIAnHI/IxY3IWzVZZZpBRGlCi4kcAKXgo+X9M4UjxlDstIDdBUYgKraoaWeWHLVRBQSMOGp2xt6nuUHa67UCPMz2ZafpNGkgGAWfPlSPu9sMxlqEVdtqVWBaKDXxa2E0AQgwESHYsSETMy6aCKLQsvauliMlvUT1ktlkbjB4IhCiw9UgpiLvC7381cvhxjY5nVVShjdPEkSEoYlewOv0/nAG9w89M9juJ/r6h0BNdhNR7YecVWJDqRCEO4GByRgUZSq0gNnR4WFwrJyaeESE5K7Rp3m71B4jE7FlXnXlkvt31rIVdpCUs9YyLCTI710o2Z6aJTZeokMBhcXcWe7TAxOlTQZuWdTUA//u0ZACOZJc/zhtPNbJnZpnnPMLSEijPNnW8AAGrECfqsPABAB3AjAEQQHCi4xjkwWOFCFubymNDhUATCVlqACRBtEG1oxxYFPJDrDbWFMxgAialaqRfo0GVjlLOpKycRYuCMSgmpzKIuBWHgQl4o00bZpN7eJNGZlIllwo1O1p5VPnm0aysK88hsm4aoshAHM+rT97viTcRdJex51p/qO2zl/KqoZOnhE0Rlsh49AAb0i/sTVIoAAAJIGJLJoNWRYd5+BkI0AMBUqcnhfC5nmfy8pj/UJNzORDOxo9QF7RTS8fknV8BXWLkZR1tjYhRbn7OhCyhzO5yOMpIlXMb61grZ86Kcl/JdVVnrv2KBMNEHIDGGxY+2qq/oq/6QpQErhMGKVjByKCrjs4BQYRGAcRqDLcTQSjAwkW6LNAoQVQEECzoguhG840EFPJxBFy4RUEhwV0XfEjsUQ1VpWU4MPxKH7dVYVYztu/t5H+jrxwBfbWXQy/biZv9Joar5xerY7hPSyezs6jOpRdv0393fuXMsK2s9833vOfenkvx5Z1I4m8es4psmXS2BzyREZsYM2DYEtF+KsdyIT6zyAcsfGEOg2PT+ua7agO+WApTlLedBLGp8yrR+HYhaiUTmrzCSkOK8GFZU6Z4BnJV8yPFhNsU7BHy4R8F8nnsQVJAl3UBrj/LemSyao37BUbwv3v/3r7/7uZrfAt/VQCLRAICAwKByKkJDmCzOig1STJTuGDCn0hAwE2oQxNoMNgzBoNO//vUZBMACG5e0VZrQACtqvqtx7wAUaD/S72HgAG1k2m3sJAA4HMxogYvYbeSXMX0n4TETPnjLSWlsSaSimDQZgQBkpxpEZs40YVtloQcMwEIA5g8IOfnSYpn3VxUMDBBMzocRBA4IGGDLyACyDuxmj5jE8e480GySPp7sfDgalDLEKA5oClxgxxESMUBAA98r+MzWqcZW86v2sRRtH/DhAcKBIgu2RAQIDUopaX6Kkzp/n3vfyzIJXbi6o0emZvIymkgZ0v1+f61//DE48kbn5HScnKdqa9VKWWL+UCcNvGGwB////////9+3ScvU/bdT7GfWTsOgOEOzEJFDVPZlNi1//5dg3//ER0yRpTg/FwpEIiFQ5HgEAxIIAyshpUOgSeGPM139wXgSU8BJlamMto8iFLhVHckR9ODLBQ1hTSiSzG/R7IfxmFqsqZttGMQhhvvD8HCAkhsBHxSp30Sz2IqULOuEoFAIaRhgOpI3YY29bxaDHf4iUyoVNCZoOYP+fvWtx2OMyIY1s6jgPVMv3ZW6T////+RwZLx4+NRMuUGDNbFq+v//////jv7RHlY7/FImS2VyWVyQaibAAAABUvCYwgRBM4EoyhhZZ2o8gy1Et84KchdJssVjxOlWO0dD9NEiPK8La6R7KuY7CoVy9b2F4dWoUJFTulMi1nxcXgtzm6fWdUiSNsT18Zi1GYWqerk3xazWrmsLcj2SHFxDcX0t9fFd6xn6tusKWBfGdetL1jd4iBYbKgq4FSP1KfIyRYWyrjNYqddIAAAAKvpaVPZYVtX+bLOIVJUSJmoVUv5usefpyS5CAYqCqELNkSqITEZFYhJAsMGzKSNCNBMhNzFS4sWIx0mWVVZkhzdlFbbjH5GE3aFiVbA1ysVIhIlRSGyLP9bmv0kakD1zo4LAAPP060Aj4LQYKhphshmAQiiSj4HJGKyPPMrR/ROULTYhtBZg4YGKALOBxdGx5KlhzW3mSGb5BIsM4qJzjCQKYyBCiTK0vD03jxQCdLGrh1o//ukZCYCBGk0TYsvTaZvCTo9PSZ6UoVHOu0YfkmLHeho9InwsqFldvlIWI9Zi/HOhDabXQBtC2mMnQq0fRImmSIuKX3aB5KTIpa5qO9r7CTSNDMf8T6WKXf8179Es0yRL833++wIKIiQAAC5eHljEHy+NIOSI/TiFE5RBqEQwJFTjqx1xEwueQGE02NqTxnCB9giIvaJITUQUy2mXMHkMtRL6s+fnfbdTepEmVNdma43af2c0b29T9b4l/9d7zcfKfazZp2+7NEVkTprudfgsJ0lPeuDAuYHpNopKrhyEiOpEAAcIAgGADwcvbD60WVq2s5TSf9gjEVxAojGmRvqXoaejswRWFDJvFdNidFm7wKwQI5UBLBOjnKnVaO+U/G41GXDkLtujBEEySlvzj+23/i0zbmaOh7drTuMjpCz3uEdVqmncrIo0mCm1KCNW8z7SuejQHCwvTh0k1ppOnM46SFEQ7k59mJCzq4AAABdwfR3MK4HUJmhxTjqbVEHLEbzWQsnrePmTLxIIEqLOFb2DIYJ4GZhsXQEKENizkaJqhZCV1Gk5SX+21kpySuU7KVGs1pmS1H+W16WT2S1FHkXOaidZYNIG3HXOhCUcIAAC7wG0bhIBxYOEIuYyLCoQAAR//u0ZAqCJIhSTrtsNiB3qZn9YYNuUjzbOO2wekGvkSfph7FJgqWZd5tEUE6UPWQwW3r9y1+HljbBVhEVJZJWvsZetbDNXGa9BCwbmzkeo5iGGhmAUg+aLCInEg0DxKKPZYOCbE/Y/KVE9SmueQoDl6/njOx0Yyl39rtNc6Zicki97dxrv19jqlvl9nbZf9vPY6wcowt1V+9G6tRcco4qDA1GiQAAAFNxB8sewBNNChbIfovkBhrlckWkqu4eIcwHBLGJ6MlsKVa+VAqrROsN6lkpFWg8GiwgkR4qH4KD2XnFZKQ1J5zVoZrThhgeNVMof+pUAzRzb7hHQ08UYktF+Lv5nqxhGW1Bx0lKrM0zLe8pkYg7aV1XIaAKXhsUBAMaC0dQCKmACBgYEsIBQFLZBtb7eLIKAAID4cX4pewifVIDQRt8Ur1bmHphIztfUVcB4WgrOfqVZsFg15HxXgny7j7wBALY3ZcudouLYkGaQ4iHEqFwdV6wJ1pXaM4IWuhiOgJKINGPOmmQvOQNmrdF0KioWJmgsGyoYAY0YxbwyBTwnGEZ91p9v/6TBoQDvDbu8sG2JVYv2kQ/LKVslUjJy/FmdQwIiiaUjyDNSShLdqWByoWGjkrpj42OA9VmRukLhYuTKE4f4P0gKUjL17/Q9ibpVqtVNn2u9rSO9/0aR/Jd61Xe1cXZvhreXESOIRN1AXg0IG+qAAAToDwIQg5VCQsMDowlSYsQr+KgUAgVQEvgisvZI+kT6WOXimhoXVw1//u0ZBUGBJ02TRtvNiJ3Z9oNYYN8Up0xN0w82EmuJKg08I+ZodCGaK3qPOKoYlSIgBX8jZHaQbaQ5K1Eylvv+MAbYzscxPSlPZufpFnUren1oudx/FhaFYiVOYKrvBgTMT6G2NzySjx7okxrK8Zn/mBJ+K0i0UQ0xuHKwYVHWNYUPz1xOEb61J8F+ROGvDVEyQAAC5+Efi8zvu6Y8I8N8Dis/ZY5NAj6yBlTOmatdBEVgcTFoklBQhHqgpmL54SqMQDIlkwv0LR0nMEM4IpcMmFiY9qeuaxe0xsp1VckhBkgszMtdSK5sbDHNbmUuRF5/SeA0CwWQ1gJpdYBKk+B2fkMCVuaMQKuBk4OrQvAigDFDALJBoSqcqGWgAhNLUWQCrqUDZqrtSkasmUjikYnsstf6qbLEzlzKbsOC4VvqrLEV2qs112o+ziCDHOlEF4ELeoYaSGNapucD867Ixts3ANJIwHRBmcFD45q7RrTfB7zRkVGL3Gw5C9bt8y+9tBZMkqzD6IEzam+z2zvlkpSc7cJzeaglKnmAqkiKIAAAACl4ArGIpzDGoJCrSEBcGmZ5iM6DYl02MaYQUOQ6nFPtNdoepH64V7O6b48BWsKVq7i90znq0bYdQPWM6g+DiTEpmjgvt2NJmCROGRyYERhGwfPqwkFpzbK0RVMnYjSjz3v2Q5pQZVAAAAMuBxA8YIDAIEKAMWKUCxIbEQyWB0IES6661Dy3Co5liQKBFwSsQwzDBPIGArBGAIA7g6WQP9M//vkZB0ABPVPTb1t4AJ1BOnHrDwAKQ3FPbnNgAO2rqi/N5ABkzTpKSU1L8iBXy2oUd6iOawkx7G4cR9o45VUlZkhGaV9ueqJheLNc2i6jup7L+6Qt7rSJE34Ma/mhyZeRH7ff+73erwNVhWxLmnde2q6xjeodr7pmufqe2qxfunm9K739e8xmuUAAAAUoc+24he0v0wVEEyEQ+U+1x7YNWTgryVtTAdHAnh0xFQQBMD+XZuIRs7kJRuySKhCDobiRHSr0Sr25SISqWAuEJXK9RLWYjPqrq7zen8asTGLS18PR0OFMHCzQEcCrKmqrhEswk0wgkBWXBd4Au3uqHMCgAAAAAAAAAECIyKVnZAwZ+ERsAjGQxSasABh0AmZB4bIMhmADmVjuBgWJBUwOHwwTmOBEZzEAcCAADDPw8xImNTeA6nQRlogUgGgEAFJTYE0yp3B4CmKTBaXYQlmojpgBMay7GOvhyYYm6vQuaY4CGgEAVGQEXmRhZtDKZExmzCZm6kYicILDAKqkn2WiIQIMDDBgZYVS9Fcz8SMYLU0TFBskGizKG7srTUYdhAOs+HHKToqvKy8wUMBoCYSGDAaBgQAAqUy92vwqIuxL3H4qNhj8OJen4qDg8uE4a3Ja+MMK29isslMP3bnHftOc5EmdR95915hMgWBwKDJVpQFwV0LWXM81rGH6efws1PvyyMbz3n23UvTl2+ymJtdj0Rjknf6LOzAMVj33rVfd7Lv6w////////////////////////+v3//rIAkAgAcAUAUAoBAAFSqe1Zaw6dYBADCDTIMKAiv2AJWF+zGxcwIKZCpQ8bEgeMLtJmF8lPKoKgDHCQcuenkjzdjK1lUxGCao6RCNpcxRd4lWLCBzxqEOIAAS/YXSEZZjAGAaoIulnTTmZLrjEucCceQVIQfL/NVY4pTVgWH2x00ThufgeUTks20xgzAnvdWGZDYl2qfe84HhuH7Eudy7RQE/sBO+u58XcdmZq3qfdfvIftS+5epL2dmnjkjpsquVWklNy5V7X3z9Y5ZT8swlle3b1hUvacdgUNvlDMhd6tGoNtSmUV8LGNezlYueohgEAAALDkCMxYLMUEVEJogDgwCWMuSMJoqAqWuSpixxnKcoKYTIMobwYSFGkGEZY7wKJBUCsoaIScqpO4zmJUluPIkDMX4T0NSTVIsLmlzumQ4/mLLxRGkqqL6pbFMllUmI7tTPj+RyHF+J0rrUixbT2x3tnz6NesJ8+1iBL/SDBQ0XCfwKBRVX9JkC//ukZEYCNHgyT89t4AJ9STpN7CwAE6FLN0081sGwk+gRhiWwkIFVEyuiIAAACm7uwEATMOApgibSUsCQDEy3zj3WdKHMSa8/QJoEJNLDZZKmk5miQrQ9WudHePJscggx5HaRDyCkLIpmxJNSSxiz7lTpdyiVko6dhdreI9tTX///w3lrW/HtbEW5zZrbM1Lp21DruvmrbUaLUkke0KA0eK+TnUpAYAAF4HgWrWQhiwQJBSEKARGsTECgBOkdBOKqustrcvYwjeWULupfQCmOTEIZlbK25w6yVSgZBRODxQKPg8wXowUmS4/lwGCPpsVJ2iwMhVHsiDiJFpjPo4FETo0jpQ2Gikoi1c8jq11NR8xWiaYEjCjsEuV/5dI0TZfY17a33Pmux0bRb7etmfe7P/jaYcx2+k6QYvSnkyqfP7o+nzFkQANEdks+lIrGr5BwGNXWulPSZdxgcICs5Oh/SxKDwrIRoUzu0FTlh9QMjgeEY9HU2Pj5asQC8Lywp8eQxtEiKxdJNVJReclZ/wjSSwYBpaWcEoOERIpXBJp9zAqpEKLS5wnLMSs8FrEi1QzoAAABm4PinUKWKY8UZIIYcK+xggKRaAsaKs4YSiEmax97leKThiPvUyCDWfLQhlwG//u0ZBkCJK1RztNJNiJxBPn9YYZeUiFDOU48zcmwo2fphg25bpxOosE4Ct96ITDWXdWI7LTnegZgAoJJCoiRBmC6PRHZ0F0YNIhO2RpnA0lhshVpdHxrka1iSLS93EXiRZLcxVypCcPIZ0pfaTSRYDvJpyoTblM9Pl4vla60H9Ixb65b4+2dKkzGAAAAAXeHUir7Dg2QpYKuWwOAWgXae0RyGOoNnRgPBJYMDkVtIalxaIjbQVSQS6S2YkMnElWsPBzLhYSqx1RWDmBxUJFooRTKz5F+8rV9RmXEnbW6qCaAlA9y+qpd1CjnS1P00FBBycE6mpnvt9xwAaAF3gPA4sFi44YBUxzAQAFQGXFBwXHgSsgvwv5pCTQogzjTCqMpbV6CSxsk6JCdBkogloXjmQAGJM5kCICWihUhMz1JfJY+S6Gmdr4/Hzac64bzIjo1UMksjRa3CUVGYmXGzbqL3Pe5dKPo9SztMOtv23I+TndGcb7NF+JQz5X832u5KlbyxG+v3/rrR0rJCAfgCe4Vjg2+3Z/31iavkATTgoNdUQvpWj6U1z4eK32RQYvB2HTZuZyelRGeIlCPHXlTQnrTLCmOBuxJwWXHarY+5qupFinqea6mTGUf7CzI0mmczO/w/9SWuSLVVBN5vFMjMaVuNx/2M7V8oQqgQAAAACpQf6QMvEAmoMEEIhAU9gwUGARTUmCAaCBcAvt3UksO+6QLplo1/CwInsxFS20zpE1FNq82j4ypYMvM152YzLoxASw7//ukZCUGBKxMzetpHqJmxnodPMN8UdEzOU0weInFFGg09I8BKmdsTY1qBOv0y+KSMgyAZGyAAVAiIyUiIzrasAWbeySPUFCNGO4oWQrVc5Tv52DixsAR4nLknllodjrblspLp6w1NIn8+jmrIsersS5kkAAAF38KvI+DqDQJ8eJKEeC+UQ7V9cs6emSQDHVyggQ4ACExICrMHZBZIEBjQAGJqQGyUPUoPeoen290QYXyxRn5rYUWHC6RNlHUQ0BDhQajKPbCjmpb/naJm2j87rBuf8t1ugohO4HXIN6BSRgjQQgSRlYEFsSSUDi7J0NU0oUCBAkDaCoKvFpi0myw4zJ/21TATNjC32tPrAT8MwbK+DY1QMCf1PxpxdIoJBeNh3BiDwnrxIEdOanDR0TscNYlB8YrnWGnm7WhABK31DtCh8zgU3cYhNqTbHwX0KQUCAY4hqRfmf8PcHDqpEhkOsjKTNRUZtJgEAACTcOSlAORFxHCXAnAEhBDrIa9DqNA7jDRiHHkhTxnJM5H+xK+VjZly9USdTDMzL5+HkX0/mtfApEhMAaOlnTuKw4IXksEoDGbpxrOYNAI8y+OvxF2hiSX8gfeHnWb6KZvdvZ/FBRinsrwudsAABSg6mBYWmVA//u0RAUEQ+YxTZssHpJ/R0nqYYaYT70zO00kdwnnH6fdlg7ZgBGiSwM1gtBQrjhlrjNF4zdhORVkJnEZnUkeoBcBHhMJcj3JFrGfKs37L5e6smh+Ky6Hn6hLkQ7DdAzOq/tWBNUtMIkZ+rgO2l5eJaRr5SbzcQVyhQOspsbH7Bvzy3pppv92XHvYf3VWPjeC0rGny17mWFIAAAAPbgB4Vy0gKAQLL7F9nARpS5glUDYk/Uxa1R7IjGXVUZZk+7xRmQ5D0LCeAGMgEHA7sIi7ciByYHZAFJAJB+aiWnHUuHankfRGzbb5Y+wYSd+6WNOIFwkVy7S7OvdZo0ACjZl+fk3zHx8UzAX7//izJu56OVL3FE+31yYGcAAu7gbQUqOqE9XwiBJ7QhgadLirulLrsKjbPYq4UDTECxuIt2cNnajcMLkjrsvc16GJcJgRLkKMKzkJsUGxIGkxMuRTPJoyJpNH7Qy2duVkVkhycrnsW0/8otWU5KQ4HWh8dS1Np+buWJKObFoSXtlzedlOyaGYjftRCaoIACd/AvQ9CW5f9KYLAJKOEy8LAxVWViDnzDmPa8LvPHKJVKnVcqbb+DbStktgGu0KAJ8+QxPOh5LZkkVqisKx3SRafGVb3j2vL3scQY7T7sbuKGK2BMPuNCjHIQx9E8HnOManWK5qquJmbh27HEdqmn4Rfpj8/ffEqgYwAAAAADLQTrivE+AMQmBgYMEDHgFpaNJKOGIBZdJ9GHobKbCMBHggvimLDjKh4Oml//u0ZBkCBK1CzWtsNpJlJPoKPYNsEfkDN03gzcmkkWe09I5YJM8WWtG21hPJPt+U1YYa0nons0pL+DmlrdynYfYEnQ9zzzD0WQzQR1ZQCUgL37vQnfpDMr8dnGH+/ce9Slzi/iP+z+Q7qR/I0hcZN7uz7VmZeS5/+sa5+Hu8jcTgdhPlc8+BUf9oAABc/ClcTAAfRdwPIXwoxMxZwjTbELQdKk1Hcfi2Ym5UvWp5AmjrVDFLx2nhraG/Fw9yxXLqw5PXggJxkgHRI3yLIFfx+UcwacBFCz4T0u+cHDUiaZFmHWNGsIRzQJY0SkRYQCAHNgd0Ky8tGLFyA8oI0mQwaTLMEASgFLqDQJKGzAgSKBaQxjacmMvFW192AIjt6GFbpDqyrScMMsWfepEG+ciHE0IKcBmeK8U6pptYZ9pUUidXs7Qw3fiMHZEw4DGmsIK6DNZTJBMWWbswjGKQxPF1GPtZDvn+enbwSLy7bDm57B1eJmvsK2pUGXA8nUFhAEQAAAAHNgXBSggwhYtAmqsF6RoSInpTxy2owhajHmZBPiwmnGeJEYcamudOm0nEooEi6cwLKitKIIBxQChQOL0wEn2hiJoCwYBOuMhMERYulh1aXUE5Sc0JKISVQaMmnEx6CqqKx1FdAABloO9TZsZYSFAAOrr8MUpMGgUVIlRQKT9QMSOAfmUo2oKoZwgHGEJELxIQY8smXoTyBUGvpmJJYStgiFkyQDa4qRVdqzHPfaMQW9arJC19uFQfT5CgiOlF//ukZC0GJJI3TRtYYvJlRBn9PSOWEjFJN0yweoGNGSf09IooTNEXVAtLZMaM0zNbOr3WKoaz9cYYbmZy1JmjtIb9T6PblfdjtXhCSQO1SoCFAfYj58bbT0IvgWbEABAAAAAU2BCGMfxjjwFqH0KUrycoYujziC4oa3HCeDwhKauhJSloNF0DIyTYGgfZYJQXJXgyaMHRUAbQ6qKadLiwdpKwwSFwpEayLBjUpsroXWKVQoIwqATAFuFWHpVqaKnX0qkBd3BxoGyAAiwE2IShlIKEjQwlIr0YIUCFAlC2xlDYsC5iw6CSAVGlgR0NrSsyYrY2RBgrrtUtPtD6tyupEvt+XLj8CQ9HGDuk/LvP1KY9bK6KM9GolOxSb6epXkmsss9FHemOnjSpeuqtgj/O+Kmqzqx3c1bOkp6qwDBLrtrTBKtMzBtTMiag/Kng9hzKl0oGyTJQAD24FyFgGqQJNhJSAChHrS4cZlE9OkNIarkr2EsaJWJ1AfGW2BxWDayHSAyYWSwKTBlRhzkAKrEJLC7bhJdW4cczI//Y5qBHelf3ZRltAYFuES5uAR9bdzludUGlsWMlFaAAAAABkwMKQgsadgIGIIwAFF3iESaFSRCAsVWmLHy8UIVrMYDBwle6//u0ZBSGZK9SzNNMHqBjQ6n9PekeE2k/Nu2k2oFsE+ho9hV4ANOhYRU0JKB+YYPVVftLlVRGuG15Lcces77KVbn/pF96lEakS7nHaxKl6SuIsKhLWeLkx+UzotGJ4+SCersw4+fXuocrjrdZ+3T/TM+KkZomZ8Pe1H84afJPNz62bGBhlzoQNipK6S+BkYk1DqIFgAAAAPbglKBAegGYDaITBQhlHrCHFzUkVfVimTlywuY/z3fxUgQM6sRNIyM4GImSZDqqzK7ApZlNMQpYihTCh4JmwWJqGtjnhJeRYXHknhh99T3J3HGkqIedcbcgMrsOTsD1/OdH6iuTCSgBJQ8FmjEJjgmYcUGaAphwOkAg2QhCoAETiwEnCWsYWNA6QzA5RDzppiFyRogLoF/kNlb3oUUUYgx0o68TV3hrufap14JVSqq8LiQwQSRgIXQWqqYECBC02K25VSWe5CcgTbaYMQm1sPLLolOXj/SBfc9WS+tuXr5L9237+8+FXrzb3ru+Rb7MUGyEzxU+V/9FdoF/4KshTwR8DCEEPs0qE6Rx1GA1isWcOl/Jhi1kMZBH9kbnqLUyeN5ehLzRdCfMoR2t4+XZcIhCUapzmfP26dg8k3FQiYLmi4FYSQk+XeaXQelT6Ees7E7ewooA9AAADL+DkwZw05jChcGhgkCpUJrAoGZGTEbSysDZ7RM0QDqVJmP68awEFM9RThpW12HDoIBhpuMQZop1LoVPzkcRyba6FxEPSWLWxgmKHHtLlp6N//ukZCqEJE9DzlNsHjJuRxndYYNuUM0xN6y9FImqlWephg4pc8fYwuJR6tW2/p3ZljrrX/f/XdhrekbCMx3Ys9khl8kFBUUqRosjnIgsjtsQvjJ/17kb1xIALhAAAAM+4QOu1n0zUUSTS5Bhh0DohE5BIWpH4SANKxRHt4um5ZvAVSqdFpg6PSckH5A0cjcIWEvLHnG1taOG2Ll3z0wzZIQGSqftaSTdDbJUmV5tfLmldT6DPNjy9G3OPSv1cd/p7W6LshbghJYEQAAW2AmMXRBhQKqMJBMROZNEvo34KYBqqYFIqlNtuyVmKTK8VSueqQHCNowd8oxVP9eeBgnWLcyE8MNeW3FaHQThPI4eCkeQU/Y4IGFCZwUhgNsCkQTFEcdZy1pyHtU2j9a//ml9uNNKoVYpdJnqY+4aFTuyjreIvfR7iKqv4s/OeZzkJu6gJvw1huzbqZA0A6FXj1s8bUiMX8apDTYWstBdqFv25QrOSVc7qpXWLh8hKj4kn8SNolKMQjOzLas/w4cV1+9e27LGikIDYu9MpLFfB0D4bPwwO99iBbNnG7/X9bGz2Sbv6Ot1ZQ1/98TVKDAAAAGXA5aVL4dFg42MAQKLLsDgAw4ZXAOEpsiwFMAvRHQUQSHJ//u0ZBOABJpHzNNMHpJqJDndYYOIUPUjN0wweInIH+cphg3xgyYrRlZWJpwqibGje7AWCw45zzOCyiJs1sTiaTnMqghlyzWuRlwI6z12obf2VnoengglYf06NcZmzuukY6WuL4li92NaFBMKdFrao774kFklG/IUdNcjhT/amhEvkdI5dhJkCc4BUJwvHXJCxAwQyAAAFdw+8ZHCIAYaXwgbG3dfZ0Vmv85ULYi1t/F0RyZC4niYelMivK2iquLTjZHpxYMzke+J6kxV0iYLa9NRZuJORZAtF6SqsX7l9N7Od62nc4CGay/il68P/1br8e9pQNgXRPS9coABAAABe/B/U9I4A0FaQZRER1GgABbrIkaBCkiW6bhNq1tpjFHHcOgfgrE05QJhrckjmUrsqOSo8479q6mnfm8XQfgrHgoL7seJHi86rMLLlrtZRLlyprWYZx9F9qgAYEHUWbB0pOsWCCoZYaBDOpap9IzDIWFQdfIfv0qoslc+jfX9Ms7g7Okh1QAAE9+IXmiulGpgk4DiAYYm8iUoAPCQYmmJTlI1aEgeSTAqE8SAdNnHSwPaskHa4pENpTjZbPx5jLrLoknimachVb7q2ZhEC6sDhlo9OWnkFz4syL+bJlJtlnVL51jOmREKP0Osn8v5FzEjpMkw5FwAAGSg85cLKiEMQwWGMHKiEOMHBjAggOMEvyoDllrIUMDZhjQSoYapusZPFgTXVPyoRjT2SyUzdWQvxLw5Tdpc4io2wujNOjBTqtRe//ukZCYAJHYyy5t4SvJrJanHYYNsUY1HNU4wtsHNJ+b1lg4hCVLteeLVGACEoApQTGh0ygRCVcaGi7IWQo+09KMm7N9mqu4VH7/scqUk4xhtIY0A8QddbcofWlyKO5gtipliyrlKJFgAALfw1aVtZellYG6KBYYyGHkZWcW2xNDD4QCTAtSKxtfi1Uq2HMmiG2kJo1uHJEJzZTViKRklVS8mFW6eBRwAc5RKvf1R//PDBQVqo+Ri5rIK+WO33/pvFzP1H3tiEWe4/oLcbY0ZNfKIQAgAABd3ALABMEAcKF2CoCEgIAiAYAAAODi2C9SQ3VLYYJgAoAsxXylL/wOOANgylTVWuJ6w3LFN36tOGmm1kpAg4fukkcywPI6B4ZmB5EkUlU4Kqlxpw8pMctYc84sP+/YNZMFncxlS9DumKkRGFTslDM7tu9WbvrTdVcemIXW9RUka5BRJSKJFKMoFAJYAD24TMrmbCZrLc0AZmimWehej6vxNFCSwlz4XAEFMzicLKReJeNhKlODErEYnFccDpcDds1QSqOqGTnirZaz32FgQqghGtZIk16eXzEOplD/5kng7/XWgzXE/wrxmpHJD8plFU+JT8vxGWkmlBRjYtRAFAAAAAp9wdYXAYGCi//u0RAcCQ8EyzmtJNSJ9R7nKaYOoTwURN6ywb8nxqGc1lI6gxRjqVpaVO8vgzZj8NugvGPNdhyZn4diLJ4g2sOwSyWbZVGiwbFC0TAJBoNULj6MmQCs6Ri7VOtImOk12pc2TUWaZRx6pYt5Qmec8X21nfH6b1ytG+1+0ZPDphn/zmkuvZlZZdDrTTJA7yhAAAAAGf8HQDrqaADiCPDRlBjEhAqAflty/rBXxYg4jDlMndYrClb1LXFZCwt1X/dZsgdHUZWH40JgtJR0P5OLQ7DNc6BQ7Zt50b6hrKs19fDJnrNbTM9Xq10YTMyl2Ir+8VkFIKpLC8qf9MrGBZ/1NpGkx2tM6UyML8XX/oiaRAAn/B4qsCBAKlCW4UETPgcvBBBcencJpz0Q85TQMWEIdEYoJTEAViGW1ZfVqGIaslcujnCfnxXMoWlL2Lr7B/x3vt1ERXxLHWCHa/TP4QCcjCywhxy88MjkLB4OHVLsckaSzPN4bySWu44U6g2qcbMImyC1gkQhgAB3/85x13IUkgBdpJxV1cVAUVXOwVhixM5m0rBMPw0WJO67TIpVQt3XXJQmQtBmAJmkxGKx8XCYmEQLKkwbYKozb1Pt+OIzFFz6BqME0bFQpewCGIdfeGanwxQ9ItryExmV5qdV6tR3QusWzvSKvf5otOT/zYSlP/9oZAAAAA7bQ8VMfFACSgoDBV/WRkIBR2MFBRK8iBKVSerTWDSiMF+1WLEL+wpgjlOi5KJzC0dlu224yuzEH8p2I//ukZCAGJFk5S9OJHpBxKbmqYYNuUjDPK05h5cmWGSc9hInx22CuhWlFuo/y6Y++sMt7EFVnkjFkwCFm2LKKCqLTla2fvGAUGCJLPZZW8YEYrfUqRkZnAYiMhEeZaTSpynrBdpkxg+HXOFzhz/T1gI4AAAJtw80sfSOMyXQzwKnTha3Dqmy22uxuRENisfiaDGo8KGUZLGwgJz8/SEUkpzJeoHokjskLhdQ2xI6YV69xY5Wtluv0Uaoafw/xT3rZ2z/pgUaEe+vZ5Rv7W/t1z4eURUwSAizJIa7eHggwoVWGDMcBz0DIuKFjIIMAhswGGADiIrzFkqrmgIUAokKkW2pSxAuAwFacUREErICxGERQEjDQBGk/hXAB+HMNIIfIIAFcD7BMC4AIYD0LQHwtxYpzrxhsZBFAL1heodeymgTMipY2Y6F25Ky7JemMxruf3q+KY+L//dL4xrES5M367o95v14m/qfre7ySB87q96ncRSEFEEgAD9xHY4VbiCYUIXDZSytFgAiTNXVYkLK1gGNRYHQuTBY0ETIqpc7qAVEEEaIUJIA8moMOUHUiQUTa2j+b7rKq5I8ium33//6mECwprfzTxm+Xvr7fzPs6vejbMrb+2PkV6kIAABWwAdeV//u0ZAQERG09SztvNGJsp3maPYN8UQkXMu0keMGClOa1pg2wtAwgCQQMDULULBGGgwFSlCAdN5kShqo1PrnXMgFcJVgZpmgdVkCYLgLoYgIwS85ReJsWsqhMUJiDtLolDZNEYChIoOU6UuomUqVKn04nnNwnamHDCyrTLm/Tjfm1fHeg1u8WaY8q3/1EF9i/LnyyfmN9Ktp8Zaf2+oDYS6/l8lDhS8/vQTGMwAAAHtghS4GECNlUP8noynEcwHkIGORxDEOYqjgLAOUF48PHbJHHElnI8eWSt7VpbPiYJSJUTQpKryEhvv42dLm6Ozf5yxdiJjh/Rj5Yata38ylp8tK6fkffwhL/9VwT7s4+D2ZHNmeqF2UBAAV3/CRUCohmHNmRCpnkogmCQMTA2zoJ0glL1cMJX227XV/pXtPbq1RtX8kj7uK6nIfhTXnnZm9cRgiURezO0sXhoy5AfUWQ9puSF9yrlLdFk8IkCk6TjekwxF00ZEtcL18bp3YpZTP86PDlcWqorRAZm6zifsFwyeEIMHQISMhp5sYF//LxakEEAEy3AjJBgJ9CoALyLUUNWvAbqOpIZdCF7WMD0rFgULT5Kh1bWGR82uKBZUHjCqzyY61hzDwfmjN40eNgjWiDJCXMyJlLh/SQRi6Y7Diq9+TbHMqA31rB9SKHmgee9dUAMAAAApIAsyAjMzi8wAMy9Y5to6J40IIwBJLZEULEihA9JjA5pCHLkCUqS6Ph7cDSGeQK8OmTxIik71bILYOg//u0ZCAGBOhNydNYM3JtilmtYYNsEVjjJm3hK8nHlGY1hg25KglRRXy+0HUCMtLqyFhqiiYKwK0FUXmilZu8ae2DYarySPwZHakvoRiwAkYElG5WlFwtTF/KNjYacua2rzWdvL49FTvm4gzqztv1sl7edNe8yPOQ+fM/rDK4NyFdoCbQAAAAm3BGdXDGAqBQctKg6kcjfAa8Ee37b1IYmHgHYEEQQGgRORJFJY89XwoD752a4OVkrS5chn6EnLR7eKq0dhqWlLHPpw/n55KdLSWHr+R6/IhF+fSt17CmbFSr9+fnPI8oXFy8yvL2qEbcAmEEwwYEBCATLojgihCOgYqEkAMEB4OEAVZRVRVlCHMFAU7XQLLnWsRkCxi5AehhSRKt7GpCrE0NdUxKlVWrveslrs689VQ6CKWBX9kzzNsCkBiqYhJ0dG2W2moFknbH2oovFGh7Cccns2rrIw9XsGMuHr5+nXYCynf976in04e2jCHRSVwcaMUoJJYAAALluAiKFDtwbIu5DJL5yXdVuWosctC1JTIch9A0EyYSRoI54fDgUnB2TXE5YHYltmI9ssuDumSMmpTdVPFyVsddLLUEc82wypA5izaw4kEyIwKaycbVuqK+//7V8hv/Vrl0HLh++ReAn14dfPkqACAAAAKygFskQMCHm3QfRfAweX6JhFR1UCcrAFUkg3LRXY47UmnVKF1ReHGsYx5hruPrL4GXhHF3SZrKgLqRind28XB2EAXUPzE/ROwnR4II+16x//ukRCoGRElPydNsHjKDqil6aMPGD2E9K02kdMoEKWVdtg8I1Fd1nrLjLb7P1scsxW6taT+7s52J08TUdzFO/VOA8vUEb3SRjnGIizaEqeQIGtkN6QaBoQ2AcAAACm3xSwZACAUDgEWykOTA4EDAqh6ZKfLlSJrTtIUtRZKja4CdGoPZozJ5mlN1hLXGn0+FZxodljutKfadf5rwCFQgOkHQJhzh9hL9Z9WXmUklU22+XDQ1y+Nv1+3b5VSTmXpSbbbIeQTMnW/nNydAb4cYVZGlWG6dU6eGB85/3ahMXbgcwBvipYPByYJaZAOqNKB7khFQO43NW10Gpv4yyNw63BuMFvLOtZgdjjtkw+VBAQBQQDohEIpFgCIlyQgZGkYnmIwPiuXX2cUM4PYYQJDouxECQJV7WOmXM3y0Npsei0zEWAnL5SJ7mJJjPazQzAV8Ozwga/oD25BAADLqDhAWUQ6YWDF7SICYypikYseHUzFBH6dluLW2bridkHALaSt54ikApjUXo09/3ijrWFOl2synpHah9/JI5hYCQSD0mIcC9BJ4kJ9fgh7749CMAWQxdPTIJSJaLHzYIEz6h6TVysanUlJsxSUk8t832ufdiAfLK+f508hEShoAH8CS4DgG//u0ZAOEBPJHSJOMHqBsiRmNPMO0EXEvKu2wc4HEKWXphI4wYHAwMEBgYXiQWIQsFhYYMAIKCSCNr4QIE6lbUZkNHuCoaXsrEsLEIkqiWAWuchADcwUDTAwFdBnCtxf5GdNldDQUFXSYk+8Wetynbsw63JTZqcoHk7HmMOhGDtS4yiZeQkZfCVYPRqwuiqeqKNsYuyaza2ZfZFP01InTeEcPbvCdre8tLOZ8aRQdJVhkiPDUrPf//+61O0MFgQgAAmf4C0HZk1jcojRJxGxPDcgrtwKoDeByJET1bOWJZlP5mUDtnZFxDZIEqoIgxNEiEBwCCyeWSNuyM8eqTEiOnsZEkYQir+Z5/mty/P0IqeToWxLYZZscQ0zr8R/sj8zhfBid8TmnmqkAATPtg00jKFIODAADBgSKgYQDBgMiGns8DXlByoAuUvh6lWr6f9uLWlluqUx2BwUh3x0PawTRBX7fTJMNJ9aoRkyxVl1pcmf6JjIuLiy0TqL3Tlye2+XLR6fIKlU49SNz5n64oNSeGexyABiwkFgqSMsJOrhXImGuoKGeYZQ2ptAZZJtx553/N0SLz0dQABb24VhfZ5m5jwwKptEmGu0btOjUZindSvCoC4ywLNDAnOAkCgYbBkCCfSGJoCUCpAZQm0o8mAgjlGaHKppinQj43KXL5fZjV19lIFU5/9/UjR5mhQ+1V9I8bmf1v4p6v1XP1CmhuWfcIhIRZOKqBCAAAG8B9qWmQKAQAYYSMgGhcwADMmGCwKrl//u0ZA2EBKZLSEtpHpBziZmNZSN9E2DjHy1hicHApCW1lI3wBIIiqNAwhBx0JWoIQpBdYyKkaFhZGWbSWfx5QIEo8F3G0Wiud1mnL7Z9K1MX5ib7O+/j2WGrMQpYRSvgNoiAFWFRS2jiiJ4SjZWptulHbJUJgZKCfFmTF07MyizSt/Ch8zSVybxFQ07/r1Gy2ITAr0DJH//6e2vF9TJc3ISAQEZJAqmtsyyQaGmqDIBZAIDAwaaFGGAt0V6m8/TxuSIlwUXAq0WLDoWFZ8fikwiBQLkIiWVPIbnJs1NORCUxd9vNLIPgKZ7ln2+VRSNL0o1Z6KRS48MoqHseZQlTWEeRlqRtmcMsiq5rLrgzL7GjjAAB/w3vEz4QjPG6FixQqMjYm2Xhh0QDRozKwsFCoLtHyj0yzybz5iM65yQQVKo8iGVBQSom1Vrokjiy1nuu/iJ6FD7QIvmgnDAnqSYrBiShMUoQjk0ci6BZDLMnoYk5KjV2hgsxVY89K5Yn5+Wuvbrs2mtJma0fa75o1+Xt7xuCYYBIXJLQYOxEBlpEQiLxUCHjah///+ivn3rFCyQAAAMu2Dr0prJHmDVBgZFKYQa0zHLY6hKXOgKi1C9UkwTHh0KhZARChQkLHteIj2SOI00u0TCC9s5hZCiUQJpTi9DS8xAtJSUVVqrk7XMvfv5Z9TLv6FSMUcPUtcqaOvelCybJ1OBVHwniJs+5tQUhAQAAAbtQfqNg4OMCAUDAMArVBwgvFpK4kE7T0hmgo7u1//u0ZBGCBExGymtsHcB85hkdZYOmEXjlIU4YekGunSUphg3xKmlNZdCkU0VqajUcd9GI06+5Q1J04s7L6FQ+IqZWmLpJWHI0Ceh2KqxWTFI5IaxUtXbFWYltHnbXbp9XoSojUKWt6/PVydpamQSnvSYtnKSxPNTnlOkMXIsyOhoPOGmRBSxX///+mABQAAAABSMHmMraqtGyqGTMGyOAlFU0Jjhr3KEXHVobqxRmqQbgzaz2sQ+9kUgl2XCVMRjwOAmEweSgSqo1piuMliQJRyMFQ7LIHkNEfk1ZymOvhHyakZl3MSwPKXsO/zcFWo+bAVYhFB8SB0IlwUecLh/61V4S//+qz/2AQAA5Gz+YQS6MBgtLEBBkSBYXB4IBrwDICGgO1kqAhH9Z6QI4ACIKMvWGaGwKWv4j5eclHBHJljE4FcVHxlr2sMaZAtJTvo+UUlzN34popLLU5TXBhRyUEtY0ZlOlFoy0/6aTXMtfpZXSGKYizsqEpAs9AZM+GxcwVPCYVTNrVRNOQhDP/ZHf3ds29YPXAAAz/UI1RuAWZqlawNES7jzwQuVRRQ5hjQnLtJycTAYpUrNjb1NDhJeEroVhJsztI21Z5a1ZPXpeSQfX72++DcpA2pFfOBQ6AZOW4yg9Yznggc2nOUBNCIaSOqqE8oaP1C5/ab/evdNvxQABG0ToaUMHBEoBRMTTFQIAIfMWhsFBQBHgIEQWASIpZNRR30T1Wqk6XlfJ/k+J1G9EMBA5cqvmHzjUkT2IUr4j//ukZCCABKM1RxuMHaBfplltYSN6Dxy1J01hg8GrlaT1hhlxmDZUIAOHY6BKC5UHlKOhHasymm5yvswnXZIknTYO2wjOhBxzbBFYkmRDsW2XmDWBwEKhYSDAupYHMgiYEwq5hFiKShJRda/+3RrL/LkmAc0AWKIRMEokAAO/6gictB62vpXpcM+lznPA+l2VtZrNQuxswISbn0RRGKWMWVZplaDyNlVkm8TyNZTVtrDBRwDroaChEC6Gll2xmFEb+YDvNrG8zCJCwKUhdr7udUqt2rY5fcgW4QASn9azzDhoKxcECQFRDIxhFgmHwugoCpmposmILMLwRx2IrdeBxnaZ4JIqMS2ZyKh48ovlQxOBHA6S1UY8GrsxnexNoy/bFSxY9a1aKememt5+28lQtrE9l86BoIhM4SedHDp0mMSqliRcQ5ipKK0GY4WpR//cOYyAQASptaHVoT48BPEIy5MVW2VblCkz7601A+VwZpDofxAw1I52+2gy666toe6L4DMYEpESICYDLMDiiR6gycGhOrb/ve7Je+trKy1Oz9jt8dsm4yIQVsuofR3D+8hzX1V7kqm1/5lf2VkgAAAAXG2Cd6J8m1RfYeSHYRtDCoBgN2obKHATgn1xywgVwFkT//u0ZBKEBAYlx1OYeDBvZNktMwwKD2DHHU48ycHhEmOph5lwI+hYjyM0cIcIh6tPV2dRDUJgtx4Io5pVAdLa4tldwWhzju9KeFid9h8zrGOno0tY7ZLFq9ghlBVYPHRomMgNwlmztzRI01MqSmMZQaut7iw7R//flW8cxgulbbyokyCAAH9rAED8OIdVbTaWNl4lvK3JFS9f02+aCfBICI/jASjhISlJM9YYWpZFREjXuY3GcI6rrtMVokbKi1+rb9eq/h6ZLhPcUnW1Xva0o+BzINEWnzCxAWiCHA0XAhI8p5C9utmxqvFcB/////QS0AA5GicgIqdSIa2i9imyAdjRIDKwDiAei9JEa5sFtXjihjfZiUkJiEMcoKyrhDmd0nx8lhP+dvjOCtQ1+cHIoEQtLsU1EjyyTryCSUzdmnUxR1y3vZ+tn9Y+vH3rYJgZFDIEDQFKPh9hKKV2//R/2VotrXkVOQlMURUVWgAATjaCfEfZnMl2UBoCMj6W0TJLNDLiEoeOVSLay3nqfiFNCfTyL28SBooStv1AwIcnHr5OINlQqyNHAeFnJ4UIUoKJOskuUNuWpJCFEUDDYx5ULDXuKPiiiLAG8wwkTDRoPOjFofTdW/q//qsMVz+OgWcLgYSKKpEAAFxpAlxSuLMusg45LFC7iScJXg4EeZ++7gpEIgiKH52qQj0axBO4i8DRMJCg6TiuZCcWg5AIjApRPn6Zkqhb1Ko1urumhere/O+NFBKSQJlsCRHKnooRW4Ta//ukRC6AA5EmRtMsSzB1RKjqZYZ6Du29FS2wUwn6N+KltgphiWV5P1fdZ/2J1pQdYUir4FSo0QHXE/wAADI20IZV1LhWimI2AMEZA2UvTcZYpezlYVXMKkY1DUH4fg8SEhJL5DMglLx8DwuHpGtZLPFEkr2zdeXn13HFnwgJKqyUTRfsq4Wy3xEB1vqZJPcqWNv1OUtzEMGPWh+jGI6f8U8ElPTvRXjziyIFBdSyYswAAXIh6Yki04rNFkKZpurQeJ3W6yqEQMu2A1AocgCH3IjsHMFbMCSswIo9jrZHbBBfVXXlthlxU+utLbEsH6s6TmtJ6sWlMIMpAoCXLWi/e1GZWstf/e1vXv//qvtp1////7PZuvO6qZVpQxZDOYk29JTDi0ggAYAADoA8UeGgdE1OAKgCdUeUoXiuZDSBq61l8wa/yOiCBV8QbCj6slfoEjEWhCC4Qj2HRaLYHmzpKqIY5mJsx8Qcnjxw9EpgP+6ruTTHOENYoQjOsv3VE/9N31OyOZs//r/////////Vnv29XZ3SxzsodqGhh0QMQM5xYNRuqgWUABdQD5skFbYgCuA80qchMFD4uMwejVWYFLoHaU1hvok16XTi6xYoMqjytKTfR3spjLyxnaFk6JZJ//ukZB2AU65wRMtMFLJ4Lih1PCbqDn3HCswE24G8uKEE8JtocMauWFAmeRUHa4CZjjDGd3c236N6p9Ptz9/8n/Xfdv/////+0tmfVzyA67WKOkEOUglVYGsinYPIIBhAFABmJUX5FGkXcoguxkIhImQey7RMVCC4HCYAdTcuS4lgcj9YlMplErrN6Eq57c/l2r3CNCTqpPyBDjavGg6lxbG64tyxF9Rclf/7k+xzjL9cJaWnFKf7Nlnl/5//P82tjFELLS3nM8FRKVX+UjqCch16yVuTgtYGEkQAKJIiorQuM6gGMNaYbJq7kvyvJqbLZU+shmYdlsSl1bOvGeSq1lKb2WEao6XXZTLalSelN7uOqYSEI1J+H//PDPyZTy59Xc8mf/T4vIT/L///+RxGoiNBJMjCFV9jUTcp830RNo1vgViQlDZmLQB08IfqEzKZmjHcJkqoUN6rVa9e6P5wdq2Z82xcQX28wXvxbeYMW2/XEazErp9WzqQv//Nf7rTyunk+mmeuGaE0hgZiCQjFJGj1L+Qf+n74/b9/9zWaXQv5/rTzSrqAl0fXfnI6RIqEqKDnJgRaQ0ktTUxBTUUzLjk5LjNVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sUZBMP8AAAQoAAAAgAAAhAAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",
	"crackle-sm-1.mp3": "data:audio/mp3;base64,//uUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAA/AAClAAAFCwsRFxcdIyMnJyovLzU7O0FBRUtLT1VVWV9fZGRobGxwdHR4eHuAgIWIiIyMkZWVmZycoKSkqqqssLCzt7e7u77CwsfKys7O0dXV2Nvb3uHh5OTn6urt8PD09Pf6+v3///8AAAA5TEFNRTMuOTlyAroAAAAAAAAAADTAJAVDjQAAwAAApQB1+6ngAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vkRAAAA3sWSY0xIAJxBBiyrDAAqFoXFjnNAAUSQuKDOaAAAMAACAiHnNmYliOBwDgNAaA0EQSBIJgJgmAcAYAwBgbJ5CsVo5+EIQbXRo0aNG2nHwAAR+YeHhgAAAAAHh4eHhgAZ8APP/wwAAAAADw8PDwwAABH///rwDwAPDw8PWAAAAd8cPD0gAAAAgPDw9+oAAAEux+KF22duW5amZbMzGNCDMQBEQANMmXba+BwRCZE2vfw4EsSyefvzTV5gYHiw4MDAwc/V5mJYliWDcG4EAaCIYLHKUovu8EDlQIAgGFg+D58RjgQDEEHfggD4PrB8HAQBCCAPg+/qDH8EAQdE4PgARmtg2auK5zx+GNiyauBJtUbmNCeZrF5jBBGJBqYhEZhoUmdwaYWDxgcBGGCGY0ABgQkFRSaJQOJzDhDejQubEdYDewhsJaGKGqMmHAGaBETseDmQAiEGCSxdUO7uKJXbYhLAQYj8HCEJYknUqYHDjYTVhTekwEodctIpbRJSLWWoxaBWkPGzau0hPeHECRbMeLkwdzX7kynmhQ4kHBD4vstJgr+o6pELFvtasJqO6pF327UK1Gyu9Jm4tYgGQOLXbNbe9l7Yom8MO2msOo2WC6eMUMTiTyQZOS+xNUL8WodzrNIxmeyepk/+Gcuys1d6rb5V7WrTNJh+FSWT/fpKelZxD0blkvhizD9qxDEfldWzj2/aq3o7uaj3/////////////+/5rvdYVKfDH/////////////+KUlivcxod4ZTmIPGgGABzLbHQnicmSxgYvmLCKGG0xQOTXAVMftEKlYwGtzKwqGEkYxEpnkKmayqYoSZUWPGzbKTzTTRtjBjjcFjLJjVQiw8BpUFaTPFgE6MkFQQAwYoeYQ4YoGaQAIFIo7AIEwZUWCuIYgCBpAsvAw8ucTBAhWNLwaWAR0aGF8WwodGTLUXumMzqH3LYLFlJu3FU5yI2YcKvBwV0MMcZmBc/J/0uKRDSzJnKVCkBCYJYo9ECMk9+HIcRX8MNxnYozBiLhwFRrDO2oMrx2YxGX4tuo6MvjEetQq1ccBusglUCUkHTEhm5dLW5tp8cwk0ipZbTfKvxq6yrcxxpLf/hunnP+V0nZHAd+MRfGku/yKWp+prKrcqz1bCiv3v/////////////6T888+2sbtW1LP/////////////5ZKKKY12V591nRoAAAgIBpZNYM08EEETKFX5fo5Jk9U4wwEKnF9uIcBsbQkbNsceU+jEDbiRACMc5ORTTneA//vkZBoACG9bz55rQAC8qtpNzDwAYxF7Rbm8gAMcLen/MvAAOCGfYnBjnU0mPXGrPLdcOZN+XPFUOdGNO0LOtUgaps3hQ57M0JcDHxY4BQgMLmgTmoXgkpHIcWo6D/g0CHBzEDDIEgMcMyLM6UM+iWK3jlsBhEYkMHQK1wxYUvWkwpmtcsoYAABgJhBZeYwoQwYRaKpbU21i5qSTAYIMWDLtqxpqTMXXY12u6LWa0NO1VqUtft67d2mIvRTd35+MRjCnjdK/tHFs85mIyq1Xt2Ppq//XutumIsRxGXw/L67tw+yxyIclVXmqtLS6yy/WuZ59z7blL1g+GP/4az0MJajAAAAAAAAAQDK9jVm6djypRAB/2AJoreEshw6V34iDBBgClIOQQxnJSAlhIx0Aqw1ZYS97DrLwXUsaEVSSvLclw6AuI7UXwsAh4uUNdZU4zE/F0wD1nGWDW04hpcU8W4W5Szaiay8LYhAuZO0LLgrDpOWNWVqTzZC8CTWFQt0o/fx9J56rXtv/ne96+6MbOdCGKg62ePEz7e0asF7I+pR5E9Nf9yOhDIkfFKUzT3T0Flr5YO6vYTblPUdLpkTIIDAIBQKLSuf0JAEwInBI+aalqqkJoZIMpDCQGdXRmcoxiBqYmUGThRvMScGZmeCoBPoSl8fVRtGGQ2b0oWBZd7mmskbDh4emW8bIj+tIROAVhzsgZckVMVw4ZnmiXYLhq+aZZmlhhZjAHDMFCS1oqMFBZl3aKnYbHwUhAheBKhXBkimEGYALSkTl1WYFfGTxmCqsOgodNddDyZLoa42BBEuVFVMV6GvRl2WW0VC4sq9xFB13uu/lLL2IS7CgVuYCqViNTOSR2KNepaJ/u9BQC1Ei1jyKc7TtccDF9ZJGn2jMVf2VS6mm6Kre+VXv1Z/cCKDrvgexK6dnDkRR/5f2jrTThQy7sZqdpblNEv//Tl//63PsiANAIkQgQwMQaBJRCZsPqELwJ0EDRf+vPmaE5LElMXqXKzVSlqsXJgACCKUKSIQEcLYym+T8fgqVWLILaPofQkzcTJCAjaDaSXEmEdkJyK65sQh6F5T5OmQ0kvA0pY3ljM/T6jZ1QfyHMLKplLnsUsXW3DagVjgr46hUMaeDGZq4g1x9aqo2efFKKNRapvEK1rQbMMWrDEr1Gz6hvzQQxwf7kfNr2L8wYT6C+v/W1fauPRRq9+oGSbeKP38d9WuM1gg0eV//6IAAAAAAAACqdUMgugYEGAoBMEPLBIEAUFWuGBAWmXK8SdeEQhiy//vkRBMGZtpfTG9rAALai+l57OAAXAF7IC3h7dNUMCSFrCY4oACOEfpSw0ibCFgCS3RBSQ6TXS9ip5bKrSQqyYNCgQhJCVH0tq11mrpihEVxQhdNTRM6Ju92gbO0Zb8CNPdV+nWiDWpxXUoSuTV0uaTJjTbYndU6oKV2otGoZrOi+UTeXCT3nhhzUQhtycYtllV7S26ejuY3KSn5lSwzcpsLfOYXb/ItrOrO0t7KmrX60pu0tLTW8N8+zdvYW8M7NvDLLn5Xa079BXymtXq/9s81//vGms2r42BAAAAAMJyLymGUOGCBELGJNApk2yjVMMAN7jnDHrQUGXjMxxeSEAo84yDDqhFlmxrXFooSy6jNHLSKY8rxbLL/YsmggCEMAaIvmOgHTpnNwV26rAkwYfYghSn6ndAjEmfuaw9liM7fv8rdHYU7CX6iEXZMrxMJdtO2tPAjswNUgaM0z601l/oKmX4YS/0etSn4q8cgmYdm3yo5blaoo18flteKSCexpojvdjPLXK2P95fv85Vq4Z4W8/xxq3t6yy3qrrH/w//+rrDPDHKznez3cyx3z8ss7lNmTCc+EmQDBoKwEPBhxKJNZjCEYsdAZrQRpLmIA40aGACxlQQITIPKlNkDCcPKOgRtEA5RMtOMZgMsLFGjIWBcK2EywalH4HTMWkVHeBBHKWHTpUeGuF+zIYCBZ4zZshUSoegmW7KlLn0T1fR0IC03F/Rp6i4nIhwZxzDjJWtkyEhYzaSzMOs5k0qTsMF8Z7gU2DoJa5l0LNvO9O1IKwGCtKTSKkujWdgcbyvmRVNsGFrcSZrfs8WI2Uno5ZbYmrzbbIMeDWfUfc9NR6X+KVn1XFvbW61r66////w+JM7+qIO0YDpmsTEGg4UAyCoxJ4yjQhBHPYl8REJDgxmDQWbG8SGUWmPBr3NAeMAYFQwpJA8xcSNJhGMalaKIwxB4vMCiKkEJHoCBjI0VVRJvsIVGqovxYEMGRGbu60lYYmSqkJLYI8qa7kMZf90F7w5SrQdqlfxxYS/EDNcf+DYr1zHDom/YdGY/Zl+oddGGYrEpc4oEF8ICFEGUhOFME5MiFKxCYmUPIkJ8kVKbFc8HmTRZCatOPWVRa3qauPKRzxyjEl/5epRY//qm4vYtrp1qV4x/6ljH//42CAAADm3yMYGKZnxfHEQkYEGZjsDCwqJhOCA6ABSY3Eo8OgCIQAEjAwgCwEBgIMIgUFFD754goTnKFiDDwEDzCjFdGkzELBBAMJHmx10GnpXLmXxKF5CE//vkZCuAB/5fxzVzIAD7C/jjreQAISIJQbmqAArJr2m3HvAAZENM5ZAAEChSbiRzjQwnvBcqCAVK2SpPLCpAvSMAwG+uTKmTKZvkruXJ5M7f9vE0nactr0jYm+UP22HR9/XBicaa660gc2KwMz9/4o/jvypoD9NflUHsPkdC+9iHIYm3fe52JG5GUvl1NVp5dTZVLmr8ds1ucl2puzTWabmFa/+GfbNy1LaS9LK1u5Y5/P//pqtnGrZ+7S/Wl3ccv1/7q9704suATScDtAAAAMYUYYbAJjOQG0jAuimDJphAIa+iGNHBjgUZIJComViIYHgwLXQYmMjToPpO4UrSBCSULASZAACJbAIpE9LkIsVaFEG/MFdjCR4cgCCKphKgZ8uqZ7RMWYpgckhQ3gjBAgJiJjwIyDDDxJ5KjR+gOLOi9bvUi0JYtyHHIftwnBbK6L60LK590Jl3GuyGPP1ATswbLJA1i1FoXHLDoR54oNv3avd3nWgCIR+zKIelUcswJSUPZjlvOHrVu1VvS+73Uiv00axnIvZs3Kbt7mFS7VmqXe7NbO5SUe8f1+NLWpq1aXZzUu5KZb9zvO4buUx7wJCj10mRE95EAAjgNhIEhIJhoRDYilFsHDFTmhGg1OWjcdCQEHEBYKTgVWCxBgArGBUCcu6dVaAwQEAQBQAYhA8igAwSKDE2EwQMMvCUQNCHA7loDrSiYHguiE4YmFCgb4sBnQAGugEukS5FFiyCHHy4UwOIcA7rsDQhR6Ayp8+XDQqEySBeLhIk0Q8tAaU+AErAsBAwo0AY2AcgL6x8lwmkzFN0S4TZugH/BsWBkBAAwQQAD8AbCHkTxsy0UUysyDrShaYG/kMGQFxmRBBcbpmKaSnSWtqJcNGKyBqiTQ4AufDLYyZAQ+MR+IAF3/+pBBBb3X5PiyCIMRQihcMiKE4VzA0///////////L6dMzePAAI5DQaEggAIzHo/AwyzrwoDMEbYy/j+QplfAFYCRHYE48TxciWoUIeCnhJeJDTrAXMkjKfaEoA3BMWZLiwOCfOS0d+q2lknncyCAZAggH/O85+3r62bYZlAPWXNVn+/rLNGfwY8TWt4yQcyzgb2dUapLPfH1mJjP/veOoImk4higVesR/r3zrWs3+853emIjPf3338f///////7+vqn/+75fx4l47JTwHlP////+BATg/VBQBvAAAAAAABMECzPE0t4Y4ZAgYMXFTPl0xEcAw4ZaBgodSPOvaDPpk2FnMMGDEAtmhi3Bz6i0mSQcBQ//vkZB4ACCpgz95vQAMD7Gn0zWgAIRVzR/nNAArkKqm/M4ABR29BeUwaZZCZBdgGglozRw7hjnZvGKOCOdZSp6y2Jni4IHmeSmsal5mgGBClt1rqQLssNgtlMda2AA6bylzARkExtw1SKAKtTHQCpgsCQuS9lBiQhaZfQFDGHELRbVWOBWP1KeFSRKpV2cwmM7rLZUvlYrux2K4PrOMgdiBJHEMIboaaZf2AnKn5prLDar6rllUWuxJ/pfR1aenimH4/DTWqWGYd/5Tl2HrkqhrG5Gsb2VWlx5Xp///////q5VsquOP/j/57pbPk2VSc27oAADDjzapEyTEuXYMsFASAMBGvQnuKAUwukydEzV8GDzboQU+Jj6zh7UepUakOZUWZDCYUCQmAd7LptoYUi8TNGbo6joIx5Q0Is0wAxI9nUVFQRm0idKjwJBIYmpGmqKNQZPdTLAoQx4ZA5G4xAkxQuVpellW5QQ4jryKna2pddmnSkTYXmYCyJIZTaad5d79ytx5HKoYYjEo64Luy2MxaAlAi/z6zj/PDIGv0dR95fqLy36Wz+UqqsRazqzS7pZT8pry9rkUszmG8OY3MKahlUav1qZ2ZVaqzUajVaNO1jhGt/nnhhzuvz3+W+f3mOv3ll8zS1d0tL9Xn/63//8lQjAAoAYAAAAAAEASan5f8bsDhrCnGBAEYtDyXKOpwI8GmQSShcwyLLEfMwIAzQJjD4EMIDOZfcKFDfTDIpCZHI4uHEDHEDICjOQzFkgodgWUy1SBmiQYQNIpYSY5HMYRnMygZfrEwgIDnIEEmSJiQAEB5BKaTrrKqpdhABwXHL0AISoAraXBXQlTSyjGAnjkb1tPeRw3nsSsICqPIJVYWRNZdWKxrU9Mymyn23jP2XvwzNt67vPW2r4OC6rpQDD0Sl85LaWmqKZs3cujkX1KjuRh3GtXKOkv4ymrKY3S18b8qt6q1NuRLLrkTteQXaOxjbd2SrCxV4VS0kAvzMRmHaDtN9nn/uzypQBwGwKAAgAgCAAAgEho6x8GwbivYULGC1UXbkupywIAexszAzSYyC1mOToLuhuddysvBn6pnOlsAP8rxTR2FBX3pZVVrNNaRB0YjUfi8sl7pOs785IJiUUViMTkY7EYlJ3RlVjG9zLKHJx3LGMY5JXZxjMt7KbuO9V7/cZZjnhn/Z2ZjNTmHa2HP33/+pYqUl6WWPlnL8prV4zyrS7q5d/fP/H/3LL26TDVixzDDlm7VxuXb1JoLzvUiEAAAACDzVLVIkVI1//vkRAaGZrRSS19nAALY6yl57OAAW005Hgy9PkNGp+RVrD4oSGMLmApRRmsGwpVB3iBNUACeMlg0QBQCuhCwAsB5ioBRcKBNjUwhUGJoWkCVSsxiDCoBLOoUlqV+sqC9gjRdZeFwaEoEYUHMzAwIcBJZ1GaVwoyucu6XRXCXlAwWeIbUKwqAFWFHpMF9H7isujrDYohlGovEXZgW21p0nGsMua1A8YkTXplrLtNOkb+uTFaPVual0psym9LrszGpK/st7+tY0tWW8moao+VdXamWWWNLhj9btX//mNnmW8ccdUvCQYFNQpRWXkP3uQAAAAAMJVGrCIEAFFI5nhDSYgjNycSXGjwMKEDuSbVLQy7zIWmDqTo0SoWuUQNLjORYVy0bkbjbgWGzlEAFSQCpFKzr4QeQXZabohgS1KjZk+B2oW9fgCkMZEAZcpxmtI/QUmWny7KZSEleBZZEZwV2yZhzF1Vi2UKnXFeVzKCBneo7buvLLY1Ep99pPLXJsRxp1yWSytbiD9Q9XmXZf6nlt6xGr8zS/KeVrWrdWzjS43KbdLy5e3d5lvmq3K1/7nd4/9y1dpdd/W96tb/Hn/uzzHlqK3lfGCZIx+FHqIEhnGsdhBq8A1IRmpiA8IO/ClrIwEQVEgsYaibNTOBPlgWOEqxokyjw5UAAGiu2gCLHiFdoYBVuVKiSgCo4AFKjjQi64UBLvB1pFCZJK9twyhqUFmDQhLIQWyMnkCyBQaLgAJeyq7BHBUEYM+rEUxVBX/hhpi7mBKXIUWMdbOYRJjSJuhZD21HlcS0TJSHIiU6fiKNJvULQqlIpFY6uhMjYaT1DYM3FCSoUMRSSIkxAuXiabaUXPWgmrBO6SbiSwLQhNU+BQiJm4LHuoO/jcjvNbFMUe0GJOzBrjvIzAlDTwAxkIiyFwkqMJDCwqXmBChR7KygQNNACKLuAEEZVIYgtADkHF68BUWIFAoERJQAI0jAnCGkDC2XLGQQvyFxAqwIYGHHTgATDQoRvkmjGYLNItJTByUrElWiRNORpyEhfphHSQIdrGW1kM0jfUikZ1Ec6WP9HC5JY8oROkm0MZ1qAl7M4FsOMpKq9qV8Qu6GMsJinrDgRnF6q2d3Fjzb+YsBUxpJIkC94kTt2HN7WFJChvIeI9oesUg5gQyxjlgV8Ff/mN1btqhgAAAAOHRIG4DgiIROzBCgYhMIADiogJBBsuUg2mEAAIKbo9GKGskAQZVl1TVB1LxLFnAQNFgKWzXVxsEmi7zkswfFtUBrDG+jqgM5T//vEZCaGJbRPyTtMNyC0yYkAZePWGBFLIE3h5cJkKKVphJtYM5ZoyKgc56Whs6drOq1SVTEBS6XOhNfRYTRJUFZBEolj4PIgpywoJxVLyGqXWfSlwFkh+Vx0Jy9frMSNBYd47hbWnWX2CSK172ti+lvx/nZmVp/DMQRRVWUcaeWXr4s6lX3cRC4SCn/+kQFCBYBbgx0xT1KhrYOSFcUHBphcZFQOuAM0uyBhkugoG3JEpTUGjDpyYRdcvEDn1hWalzRESZQ4wKLRjxyDLfgkQOEZcllDSOoAAaKa4Tc0GgxVTYtMX2ME1DYE0A5TxEcjTReI94qynswHiimtjuecHpRTvFagEWlWSJEVCmMhhU7UtXseU7a4q5lgVq3RVCpXmYsitUJHfAUBmysMrAhTj6qJL9aiRygZhgoZA3///X9aIwDT1xsFAARbGQkpm4qsOBPjfATo3EMQQPwWeY5JIpkKxp9uqhyawooI3DRCACGZZoGEWBEYQgYJw1gUowR+CkElRhLRuC9QJtGyGCXAixqEkQldoeX14J9GVCgLudS3ljV5zHlGYEoUJykwRtlUS9co9OnSrzpQ3DhdW0TSTUjXaV81Qqt7ptXKT3R24RKwmVqzd7FvbNNa3SLPX/Wr5hZgQYsDWokkzxfgzyS5+rbi1mvSz6PV3/Wrx++wQ2TqnkMpoACVwgOcIAgZcEF0Eyp0hBkbwiyIRaBuSAFK9g1VXldQF4ZYuV2mnrhaCjnEcLFx1ZyIQQxJ1Z2mkEgmFKmVMCisdi73PBD1UDYBigfJxklp9MNRRdAgRKqL02ixlRaWRhHw5/5FKWkRRgRLqwixJaDoubQ3Bd3GY28vYv7nq8zKIwVRK5GBXJEUr5uGH6RqlBI7/I0JSI4AAYOr//u0ZAICNHQ/yZNpHqKDSVltYeNuUP0jMawwdUHqIGXhhhm5AXVBIgHDpgoDA7zgkfL+mHgpcZmzowUl2vduTDHQbEgY9SS7E3EgBiLlucnJZa5NyZvI23ZznfgVlkchhpE24LkxZW3skjLfMDQ/AeJTBC9dUSipkhQgehQGCbTqPEBI4bKCxUnQYQUvyAicpNAqMCB42K2N6OZ6Vd3NRZcBQVdrhqbi+reKFPvh0VoAAAAAAJwMHVYouX4ARhApx2eO22BllIlYyeBSFCLp1VKlwL4dzOe6G6VcFCE4W80lEPYueUWcpMUKcmyCutpk6UlIcqENTPpnhq2BNakayhqMzmJgbtD0qDloumUIqbBSJg4Rgil1BkYi71XgUHUBCDWt5EhLkzXj1gbpyXjIHAiUAFRoAFO4xmHHlcTScEKNiA7KHGjMqR57oJKw7Mt65D0tThtp7NYQoI8E85ENumpYtA6JJ+0D60qEMloyQrLJwpcRl9o+KyUllyqg3ciO3qQ3XV28EbMK/qOHRnU/QTCqJhZLL9b2aqFmpxqMHHRbaFM9xQ0nW8yw/98pXmKUWKNqHjSum//uWA4gDKmRJDvdA3hYCIQehKxqzA2vLwZIAOkHoDwYDUUgqJ5+PK8+H0IiWPg0JwFAgfjqjXh2OY+rwqQTkwSDI9WxoR2Sz66p6GtXzwLMxBi7yIRYlzjFa6GVreJa2PS3LFJmk0qa0oo197zFvMS72xkvszhBmhoiw03+VQQTWQAACU9wAuBx//vUZAWABAlMze1hgAB7KImqp7wAZZlzPfnNAALJKqn3H4ABmUghawirEN5tj6GbB02032tM5jMWZ2KVYhE8eXifhaT3LwfRnh02ubU/77y71tkpi89E/SqxHV2tX+957rstnLdJvFFuureZ2Or0wWvm0//5r3P+XrTTY/rm5t1dGbRsbeGmfM5O70VJ1ljbOXm/2ybvjAhfAw0CAAAEK0RkIJETgFOyBqDEZyGqIkRMk8TZRtZvEiMQ5EMQxDEmjawWJkhGmhqMaFOsnSwMCic1CvvzcqhSqswQn76JWFi1temMfwYEGstqVtv4z8b/taufj6z/uLnX1rVvrG/bXru9H89L1tWJXNf86/ljwx4Y7v/mfqAAhEQAAAgAAAAEAAEipawxknzSkIGhoYrKiYDXTGwQNVn0yuDjBoqBoAU2MiieHjG5KMrlJlkjNmxNaxMIXKyU46J0S5pAxi2JnaRopJxG77P07YGXnAXGYBDywwyM2Dt/36p4ZNQiNAaCDEGG8ahUAhzMs7Maip2Lyl/KhhCAOOGhMmNAqfMiRM2OUrEIIwYgy5oLCXQaLdb1ynwMOHEga1FV01wMIXorwClDCDzGCWuIgmCAu9DMtkD9OFG7peBCQyR+44/Cg4CCqrMvQmpzIrN9UisdnL89Xq0IGFtDTDTHWulY/GLXGsMiQegF/Y4/r+uzLu0UWjVPLbtJapuwhl7X7ix2dxeKXeuQ/kUjMFNaWNEbDpOy/sO1ZTGZyZlna3fu2FHf//3//+7gUHJIDgQBgMAAMCE6U1zOw56bzcAQ1NEK9Cw0yXs7YbtHIktK123TIjnaBbyKSVweX6C6pY9kt5YmK8CRh25+UKnrx6NRLGKRjn+xOB424bjrEpn2lMO3Ij/dVf5ezfyWXqkocmHbsphmJT2s/q/zKBJfcsRunt4SmVT3e/ljd7zX//cc38jF6klFiX9pcd7pcst1qb9fr/x/9WHfjdv69uWWOYYYU35SqrZwBSRUOBGJ1cpYLDgOQwGAQEBC//vkZAWACYJfUW5rYACNK0rNx7QAXeV7R7mcgALLrWo3HvAAtHLQjoY58WVMWFN82OJaMmlMGCKJ5r34bOMmRMUAKFh39JyQJH5PLnDFhA0zgoMUGDJU8zowMrBGJmOgYGODGgowogMYgyIlMpYkymAQgx4GMpJTHxExEvMUOTRUpH4Rgil7aKHKjXOAQEumYwJEBoaMbtzFmAFKrYXQgyOzDEjDARGh14lCAUBmJiYOUVpGMghgAoEEDXYxFm1hbrPaiuutFRdEy/jECy4AClLBCKjQgDQpQ9lTbNqyZzoq7zzNonW/8P26WnpGlBcQQ6g4GQqQC0appNDzlUNND161TXHEisrhuH5ZLM+cY6ruBn5fONzM5AU/nTb5c3h+fOb/CH68XrSyzXzwl8vttwbgsl2mJNJkbOpA60ufmL///4xH/+kSjgechYkEgTAAABAABQkIkuVLC4wIR2QZV6Sc60Unl+JKJkPyATgOUUJMH4bBgykJ+RxYEmPY2ZFMkyiOUepmgePOShcLjnS+cFibJsimgyjQvl9y4J8PMmk5xPVqrVqkoXEE3MBykEhFE8R1Kf7voIIOSBodQdNvdurp6kLrSQZM0Umgkv/++//OKMVFcuUlwAAAAAAAAAAAAkFPag4Q1QwNiDFSL0EPG8eaVqfcFsDdUm1NFZs7eIdl/JlHCo+zG2cqdiLVAGd14YMwFsLVIGmhzwFKmW1E1NFfu7BT6GSSZ7gIRMgwwBXdZw3rzNKZk4C3n0biXsDkhkQoGIAWdrkikWdiJLraDTy15J2yl6SAQCsph6hzM6kPQFQsvuRWCb8ilD00kw/qQsYi1amlMqZ22j+yV7b1qtS1Jdja/KllO6HPVNc5UzjmcPRi9b327nYnpLLaSvZu58emOy2VYPVQyqnh2GZbycnINhXbFummN0s/qrTd3drd7ctfhaJgJAIAAAAAAAAAKcv2XCxKQo5RQSFvBKE6MYkyvfJEuJ6iGjMHYgtbRBuqo72WYu79DlHRYOQRhFKouitJEpjHZjPaTbfnIaaoLjKW08GItp8J1TOaHL1HmnUCA0xsN0Fvip1Uq5udssDdbP71xA8v1FnrA1rdosrnvN7SS4ZoNs18e8bUCLSeR2sv9QKxJ6UzCfvoDc9i3t0NW2XFe/xPnEWrxzq+f29WO+s1i5gvdlB9at7v9s7G3K5JLZLLY2ADmwkNgqk3kMjEYKFmCVRUZEOQCM5qYSmDj6ZLNJk8BGDgiZ5JAFQAQTDFRdM9kcuYMtMCAiZ0KdNB//vkZCOAB1VKTu5zAADlqWm/zeAAI617Qfm9AAISG6u/HvAAJSCJiOXdR0YeF2qUiIS7BrpjEBQjJk3gtMOWpFVM0kbchAFBjJ2nL/SiamDjl5TWd9kHBGYuEuBCpVJQJIVvkHQUJBA/iD44mGwchBG5iV6mZYGjsrc00uMi24buK5ondhhW52FNlTCQ1cqqFooHel9pVCZFDznOwtd1lpUzXXpeVIVE6Tw+4DX3DppTS4ySNVcc73LEpufLs88edz7lu990xHmSs8KyGaoZiBkpNtu2tsAF0CU/soNiAXAgYbzimhGZxjAYUJmtIx4ieZwTmHpxogqMB5jJwZYKF4gZ4qBDGAfBDAFrL8DFh/4FGWfSEQYM5wDJSwaa0TGBhlksM7RGAWhDiF8RIkJSwI4MHAARwstVpqGSTDD6eRt8yVfbTmetpDjRWEpqJxQy6TYk70ZHuXwxmMMgeF64bZnTyGAXIpYkoHRyuDmbvgmin4wl82Kz77vU89ZrjZ1PyxaqO8JmH8cdu01KKfCljWMvr0t2OWtXqbnzV6vXo8rF63VqauYrfQV9A2H72QJAJQSMGEFEGBAERmboHAdAjIiYaBjJyOhgEUTAG4PKSYjCCMwNUMXXB6DFBoyYcXOaa1m0NiaNGZ8mKsDhAT1rIu3RFMDLBZYiMcw6drSZfM984EATEAAFEBIEyechgnQSTLoQM/kTha5FbS6YkLOuvOKeOInM+cNG2lzYXujMNP60xy1L2yLUWYBVZlkxQIM+GAzEzR+M0NSYtUkZb9YiODS4XWh0LlgCZLnhiwFKwESMIBf55pqicKJ1Z5OtUb2XX/rSyHC0wNDIzqYRiNQDE5ilu5Z87ljhE4vB8Uf9t4hIIOl7NU81BlZ0bH2aczVMVn3////////8sbt2//PXOZ+0uVvlFn+htyIq/UMtdkkN//+jL//wKFBY88vMhMhEg7AzhKKxsLQOgGvn4nSfLpNHmTYYIaU0QIgYiMVGIZJ4pisClajwkbGA4GNvgsD2LDiLhDbwm/Ek8lULQt5DhrhifqBxm18/wHjhejgqnFWtTHet9fessbnGgs6ro4O2Z6+hZxnWP//m1JrwRCokD/xOfoBMBHjAqj/+BhZJhdXWSWNlpMgEEBEANuSywJWKIweGDTA6IuADAINJCy6o8U7CtzIgsCodGWsxZgpcJadW8pU2eNGAihxbuJUsZoXRrLEkDUp2NRqGY7IcYw5qaK2KWLSre41qnmotYpqVpLjNs4DXF0U8pu1H+uW5bM0l//vkRDgABiZX025nAADE6tpNzDwAXIEhQfm8gAOSpSe/N5AAPVt3YfltPWfaW37v7+rhSyekl9e1SXm7Q4xOIU8Yr2LWrO96mtWZXbpMs8qncZmjkW38oL92l/8/wyprXct57y/+a/vP/78unamEvwr3OdsHgkWfrSDb1xAIbAABAJEbjltKw1CYwBWmMmoKNS+AGgtgamvc2THaAIZFkVclUbxNgTILZ6/KJOLsUBtE4VCGCHMhBIIE+RtAyyq07U6uCzXx1gJQDSCvT8V6vH6pmPKrYD4WCTw0+K44wJVa2zMWjveK9sjvcLCHxjvTy0h1W3/DbFWlplivE3AZiSFagjLSLchiual0+c5a028j+Es01G3h7HeqtkjvKxnuG22XtdYrp571npXV4HzhXMTOwUzmaHHWOz4Eyk0LNFXcO1Q7KrKvl133/0tBBpaKDm0nV4aOzQwqGgcaMmGzKKowgyOcODgRQyc1MoEjCg00UMAgsww+lzTcHKhC0Bq2cqrFAxkBOOQgGAAgCFB0aC8q0QuEvVBtM9H+wHAqALlBI4sUvhURctTRraFiJpZVW9kzcGLWYLQITjkswWDa4xl1nKdZmEDJUtHQyZsmm57KEW0xVcpupBrvXciQ1vgKKVOhmxFcRZ1fbX2xrMg+ahuHneXw5iakHLCNo6ruWYDizEpTSUsepscO6qf3uUrlc3Fqknln87altJXCYLgCn1T7s7vDMqKiGaGca0lu30kBB29udUaH3iZgQQa+QggBM2ZTTFYRigDBAcvBVTBBiFEEyARNfLEGxJRCmLBzFTNCIABhYokFLTiMMeRUOLOolpJoJ0IkTDEJAzamYgAiSKbvFmljFyFWrcHoBAcXpl6AlbCsTMoOXnSrfgoEhF6FhghJkrYi8KCeKqWuFOOwiuvZIZx3lVScZvaz1sLaE6ziJ9taacpS5Dkx1DWUyZea4IGeKoyuGEBCSZcx7c3IeVxI6xNjjvPLSRDPGW/urW5vLK9P0PdUu+WqS/nq1by+qIf8IHHb1TRJYoM2RmcVVNXI7B69qBQMmDkgK3ISzRmhROdaGcVCiMCohpyJySJnyRrC6a6EBlGBeQIBlvxIMpMwasz9pEgOGUSWJecqAwEoM8CAQd4mdNeQBxlrdgYFAwGXdVvVrZWsLTWm2ZRBhmQJpwoEAJQIsw7Ajzy6ncyG/dy9I3HYsrwFDECy/YYbklho1qehuLO3EZLPvu/k6/lLDcPNcXo/+rMWh+zSymCYrXkM5QyOjwrM4bCrtt4I//vEZFyAB6ReUP5rQACai5p9x7wAILF9RVm9AApOrqu3HrABlkInc7Fir+stZZYztXC3/1ORunylqu0+38vVb//////////////////Dj8Td+3Y5nlYlmL/////8veAEm6nanZKDK667Ba7aBE/iKoJzzHYphwhxbcUy2H4hw6wuGU/F84A0BNzfQUOVUPlAQRCZ53sSmkKQtgetSpeWo7TajipQvJPiEBGJ8497wafEG6vftLx+h+JvDi+LfO97m+IjhfVKwqZ1JufcCLrWd/s7OwMkWMyKjef8/5/+fff//Z77ib3ikTP////////////949L3xSJd6VoUgAQECAAAQEVXBguMMeQaAJjQWYmOgmmMdloBbYKAUfNTQzaDhnaew0FAoZOEzNzGjTYyzKMxioZmoZnEjoUMuRtStbEa82aUgZ46vlgMszcVrxi4Bg2hqRYOsGkU9jkXv+014XNbadC4oVDuOEAS6wVCWpBc48cjgdkjTF90zfFwy1gKEmDCBYCIA4MARJ9ohT0eb8MEet+XbhhUzygIGhUW9U2ZVTzr0zkt7OdvU9enZ6w58n8bnTW2uK7WGSpWkwJp7JGIuNPXqTde/zWG2YPC5Llugzqdh+71kMRYo5ztRt+H9jzp13VdLlPY3jvLLf77t2H0i9mbjEbv5zmONvKIqhLoKAQBALqAYBASUcu3hyQVexgDibSkmBT2kY8ZOkkBBkh6xU8l2t1kthYUGgzPDvNSGBKFMsNTArVuOqD4Sw/EszOLmyqDan/WuYqDyJJUTttfx7T8qUoikgeMh2koxRXfsifJROQTHbaB40J55scTdMa2f7btTKSpZB+mgbEolkhpsiixc2RQpk/x9fkudkU+zmqqWVZ0ZlpzZRQgsUkT//vkZAYACBVeUn5vQACUi9sPx7wAG9l3RbmcgAKxp2kzMvAAba+1nBQiYQBmmG5q7OYQMmpvoFBSqEiEZR3Hqs4iEAAUCQZFciAzupo6JCNczC1kKEEvjy2Tm3UtmVIvNGcnoCbm0WGkRN9LWsw9IugowZsiYkTEX5YG2F2ZNlZwpjQgzXGjHDggoZUS+jSpY15ubi34z2BuUBiwYYHFjiAde4gASiGq0plsOzk/llWp564WQQoMKBAIcWFmIEGEBTMOyF6o5ffWrf5W5W7vBHAtGXjVjLsKkbRY7iQ80qrMy2NvDlhWoMZDT3aWr+Jdst+GBG0dxznYk0DsDptb5+v/fP/f5///////7npEKAL0TDYm19kkYllHgKFDPMpLO7iqvcrhsbr9APqFCZPHO4V1wN4ALEcRgryEHNdiEOFyb4pOzKOp8zMrI/u8oy4dz5eqkf6uVuZoWZJo0fVX953nrm+LY3T19NR73iTwYMW992tjV9d5R/fcSkHON/Ov74/3/Ec76gx9wLXrqFb1zX/H///iafw53lIke/////////////88T38SkePd48o1CoAq63ACAAAAACAUYfigSS+62DsBPI4xXgoGreChzTuJvBECZS6GTvFqxkdOYsiqAkMNEURZBcRCEBFJ2l566wqSgyDaZCX9pbeTLlLnVTpXkBQACAlTKJHP13fiUmgZ9uGACABUbgCAYYyRs3elt+mpqZ/33hyB3iLYgQFNJMJIZrLk5SW1VxodNjj0PV45rTgz0ZuVHad6ZufW7lnXwgSMxyXy6Dr9ZyWcyp/nKiMOxmtTY/vX91zudDbuV6T6356jVnme6WltZU26Wl3//v/////ppjdNazxq93aQ27UUwCAQAAAAAEAFyUQxIFAWXWJTUJYYIGIHEQZgIcGposEmi2Euw3hbw4TELCJUB/DUlkWrIhh7BJRHgWRbk7ELgX9tLuzEuUp1IUklD2xUKiGT0uR+EDVra9s3xYW93zu6ifMStcunkOUp0ltP4nVo0m4t8w4klpsQidJ00S2p45lE10+939/v6jNWcaZWHFce0KC9//+v/9xXsabcS8LvYT59BevREeK/+iqa5u+qSM2jYSCstraMQmQgqATORCIiUYqJ5M2hGIzEAsTqMGgAABw2msQcU0Eo8VzBATOBvE0+P0t2gBcQQADElTf+yzrd0OSmEQd804s7EY1hYcGlpVuwK2FS5cBnDBmjidbjL0RgaQqRhrJ2nMoBSQyYdby6DMkXelEVZcsZ/IZf5+3b//vUZEKACFNe0G5zQACV6zppx7wAXnl3RVmsgAKOreq3MPABgSHjFhy/agkOsvMYEUk2V8XVcCIqW2pZJnpitLBRigSXEKUoUsMSBQXsVp55pbIKTKNUliVzeVaq2dMNAOzdXDiRSYjUTsSKHZVlhXsv9D1rdiIcxl1pORliY7X4fn5XPw5DFrncf1v///y////////+w/8v6/7/y+WYZ0lJh/////32gg/3//X9TRxx6G9bDvJgaEMKEXdmUAj6NFID4La9TafL8Yx/pMDIGoXlbFmmjKwHICkUkqdoyRDwb1GpG19di1CbVbSGh5zrZkW1FxTOdV3msSOdCgZI8GBrVMyV3q2fqBEOtR3fseaf4j/WKb+Kby5slPqmo+fjG/i2frGv84/xffvd5TWKf////////////xH9+h4A6RuZIIEAAAAAoOy6YFITTwizoyJEjgMCHjnA4zLi6Zkwy/wSWNzOhM6BkyuTOpOqN0IaQ1DCggwwlzWdg6YgpJFesoOKswTg4aC5zKMtKkoIVApxppGaNVp4GrTtDXbs+cOwxAQJGL6mACWtnZymiUvisGy54XReKGXBbiIAS9xcpzm7LDWbWUbuxOlgiRV6FqjxPCYYCRrNWxOC5LKW5RrKex/8sG7QUyt3KWEP+6JeqlcprytzWXVs9tX5uUUt6cqZ2sIYel23VdN25ZbiFpwW5LDMur0jtSmGXJlWdLjVsa1l+9/n3szTPtBNWJawyuWRFY4Ap0Jx0AglNAAAJKy/f6fD77WYcolzKUC0QcW7KXRtK5g44gUp7RiXBMobOxu3jDPk/XFseN5wK1Kp0kpfmVhYD9sThkneNraaKgwrVbjalYta1jWL11iHZXRsQmKDFr/j7znxt01uEwuL3Ea+KX+d/+Tybxn7VymVrLEgvWF8++8f/WNdxjbeybpV7iduVyugvYnywwn284/1jX//8G83tuXAdZNDEGAGIGABAIRCYRicRkjXHAMYbkaiMFQZcROFpIsYNEQBIJOZCaqA//vkZBSACB5wVP5rIACNKosfx6wAHtl7WbmsAAJTruy3MMABKlTMgUKgoHRZIETj9NGxW0tav8ILLmHUsBVB7BDtAqJ0sfyPm2mbQJumtnWCZXF2v1pZDggCF0zMSUiCoC7qmLFUqm5TdHX5LOiENM9a6AhZiuGTMBswIwKNYzf3/t3GZt+mG0RajoQzadmhnZVTT2Uq1GqTKN237mct0r/1oHob++6zqym3e5hnYxvXKRwJA7kBwPDckfiIS2zWrWquNmtrLli3/dfzeff4/dDallNSy+7allNZp7f46/WP81vLf/////////////////////9XsMBkz/+OcWBWGcgBwBwCABADAYDgcDAYASNVH6XtsHohUzrMFPLUjJaACMQRHNCaai5EE2mJmBgaHzhtA/jw8xo4fKDA4TBsIEEckoKE57jr11GUQ5MMzR6yp2mOhGT6znZvvitm2eP27Kl9MintfFuu7/4nnfDKmubY6ntP///9v6qb//YuzWD4OAAnLTqrf//UEBPdddnKi0AAAiHSoLZdN6v4yZ8zYgwjQGBDpogMWNGQNcAM4sMMzMaSDgoOHmkLLhJCJlg7/wQfGIqiJZ427bovA097U5y8gESoTBsAvozdItp4JM7pe5n8A6Ze48qQ3ehtJOnEkcj8o+pk/lS1DDmQwZAF0AcAAAdg0Eb9L2GoLXbEZNT2YvLNU7+POj4ttx2HsHazIHBcV4oZkk08UIob0XvTMjTrzjE9Usv+j88SdUNyqtlHrl2Vw1eopfKLl2ck1PB07AUOWYpuHq8al0A1s4juU389Yc/Cms1K1eUWocldNOU9+vAdqX9yopTLalLLZVKeSr6a3YJS4SiCCACWw4ZDbLbEyBEM1tdXqiKpk2LtG8T6u00rVcWiUqWFZPEam9IJdrFwkj/swzq0sLTdR6W6fTsuLXCU0kZqsP/tRWxTF12nobVjfY6ZMIh0cmK9zmVsTNegZtbaW/F9237r82rVctmrM7dyZ283mfzvou+1vta7Uc2rMzOdM9/Up1KS5N927NtWyzzLuMolTSckt0CSAAAAACJbdkCFwpE8AgGjsdRPbgmeRGaCWjAIi5QkFLsYArOLAF/xR06jnrUadqG50mTL1UjNJl1G6UjsQ/Az+Tt67QP5FZFkwtvmI0EGTdfLKzZyhqJ0Htdc6Bn1eZ5pqzurQ7n5i/LtVaaIv82zyQPGqTdLVufZppXSySO8qX+RuNRnKmlue+3sud//q/qby3nzfZ2tL52elVnudTHlXmeH//vEZFQABg5Y0+5jIALFitptzGAAYE17V7msgAIwq6xrEpAAe71em9402VS9je/Hc/arbpsd95d/7GDCrqkg0q2yECQCAAAAwKTrETGXKBGyLY3eUXR3ENkkUwWiHtpAMOGM0Wu+40NIocAUHisNs5bEhwdGFpXyV+nLayIASsMSpSIAxSVSxMNnTT4bhYMEBisCwcmNRymn6kjp6eVXZXRwRHovGJjOzlVwtyTDlJn2pA0ImJvk1N6mtZXfypalaJxqmzlUp3KaDVPrufda1+/tyeJy6liNq1XoLNBU+5rPKar4a///v75H852SvtLJmt3DXbeENTOM1N4cu69Cz51AJxtJyIpkFEBAEooIq2fMEjwQcCx83SsgMD0k0xA2YcyAkKFTxpzqmQAaCEgGIo2mWGGTKumYqo8AkOF0TGeBxYwGaJphEqoIhgGEypwbEHJmWua4ZkG0i0UbTCDLbQEZYqa8bbMXJnYq6saSZL0pNL0W6pWhuu1AG66Q7zsxhiGUVYmTDF8E4VdIUL1ZvKHHjcPwcyt9WQyK9Dr/RZz2WSZ312QA7a139YnF43asajs9bjN/HfVbGfOTEIKlb6Ryll8hr3Ke1UrXpDSwufgOjs26eqpWyBfSjbYlhnBhpnTk9xp+08xDk9GL1Jh8jt2Lv2b/Kla7v6OLS2jnqWjnrNu1etkCCeAAAAAgAoOn89/ARNeGiBQ2GPJMmFZMCYrbJSxDorJ0OoRPBWnqK3A+bIWHw68XT8QLeFAuKZwbSJD6bPj4jBCKUUSFRjfs28r5H21kX5GXb2Gw/Qxz3/sYrOZexD+dMbDIZ7niy9LbiNSr/+Zs8n+pD3uT8qh26petbAYYBwEwgDgqz/////U0VZLIykiUQUQiSAASXFLh//vkZAcABxRe125l4ACnC9tdzDwAHr15VzmcgApRJy43HvABZIRwCA8ULC5JnugLgMvBVBkIhgYCcLiEQMGKLUMrEkBWKgwghgBAJ+AgBjo4/nMOgBHHGI2eoasyU0h5xp0QteJuvFwTxCVCnU4dI4wMAhhYEGZDouCTLGwtiqjp6ZuUioJ2aarZELVyjbjkWkMhqWGsQKwX7OdBkKBHxlYcjpXrCvW2NXbXUeSPB28Oc51WoNbgJdOI9OJRqVkNUQ1ChqhYW6eRRNUZQMirn8N/HiVZ4MfT9469LzZvFtl621gat87vDZFZSzxkQtzllV7n/////3b5s833aZVIG04gUU3d/qSNw+gAjL0VrgddKOlm71OgFTaoZlfYCFD7eUOs/1KuC+jCiWgKVd1MFhTuN7ngxI0SdmWHb7MXM6szGgw/HvmfT2rI4R/R/6Wpqmq4xjeNv48T7ePL6vu+8btC9c514jP/d/HeQImNZpnedvZIL7GL53WJmA8eR/V+/eObxkbomWSG/rH8V7p9uFPj53mDPqHHZHkTcCI/f3uopoIQAEAYuvKjY5OAEyGAsgaLAiPEDQNoJU0yTBEMVg0VDgFPB0OWEBKCqBhktGPoFSBopnBgjko4FeR9HsAoiDQkCYiTMJQkSHgWEKGAwdL5a6bha9JtA5VjNVoJyMYc0KBqbLvLutgRZXSutebCVUFWpgsoXgvpxZlWGCJWzmCF9NyifXagt3XFUFZkyJkTuuLXbq0bJdsES1W10I5SSOHn+vJiswgKVUU7LZp3YhKYrupyemKaG4JgGMSixI5e8ThSlrr+yqNSqrZl0pl9uvy1XtZz0YmLlevXpLFL3v7yzz/treF2//9l9+vWuW/1fte4K17v727X+PRUWnE4pnNamDqaorUdYx1MoIZ1rhoMlyVzdGRxxK9LscYtzo4UHpcZtO6LmPurShW63XJ2MT44FNKwq2y2yahwHkBjllePrX1rbFHhQswnkV25Pppsa3jG/CtI+ltaSG1ywIGv7/Ga13a8bdrfb59m+M1r9WtnX//9vv//6xF3uF5AkFik/KgqYrWt/+7SSiEIYEAIAIRJSCcTduEBozRdaRfocCjoY0YUMlQXTmuAHPCjygyYGNNxMg0NkMRbGkMKYxXDugMkFEcMIay/thvAAEpEwQUxy6EAuzOJhpcLLAoawZdguu1XGMw7jZBSahqV9OgHVIpm2VcCc8LmcKWGorLXKUsc9nDkOw2jtxZiDD5TGJQ6MMxJ05XlFKd5Ibh+Zf+I//vUZEsAB4le1u5rIACZC7s6xjAAX8l5W7msgAIuqay3HpABxqnnI9E4w+3HGf2kj0r+rAy75Uzhs7gRV9JLSPtE4hEq8klUftXv+Zx+3ludl8IhuL0svyt6bA0p6XodqPySHpmpKpnPeVrOtf3z95ZVYci0ssw5jP0tPbp87AwAQAQCaITiciUk0C6AOTstGTbCUdGKNQxCuBCJMNmGfXLXa1LcBo28raZqJZdTPAeIyYlD03DjZQMS0IntvLmVyae3tlhxZz7hzYyZVnzjsb1ZjW6/Cv5fkdHqUeYdcPWedjmVjxg4SFC80+kXuRRuRRzMzltn9bfbfl+jkDh4iRnjsZ5FGsdjc75zJmZya5x5V91fdt+kcm1aSRbaAhDAIAARUktwo5OEGNhGKAoQ6MSgAVgzJURI2PwLGzJCjKHAwubg2IRo8DeY0HjyVAEK1mJghQqkCIxKGHzUPkKDhZwQjAVAQEAUpY4kSuF7ZKX9VUYSghSwTmMAMdAgpS20gDXXEpctlx3rctZzK4eVWYE/bcn+kk6uyMSl+3ntP3C5C49ZuzD37bFAccgeT2X/msncvMdddnDaUzXH0jkJgCG5mXWaeVUdLPYQ3n2wrZLFAIYm10SmG4EobMRim4ZlsZllLEX4nIRRZS+X538ovIZXFuz/287P7xkEZhm5dh2mlOGUZ1WqO5KOYU+5fnlUljv////9G2ABcAIAAAAAAAYESjgwWWOYpIBCl1uMyXhtT1EKtHm4NDSIRAQDFKFEAeMnGUE4sqNKLK1BiOuFLaFNUmzUcJtW+U2UCHUCFiFQrztvxnBCie5q0pt39zGJKIqSRQrFpLNatX8//8XYTXV8ppIk0XTl1fOEa//39SSjqYZhnYjqHquFResbk6t/Hf0OSYpJMkkAgEEgxKy+13SaeIQaVqHOHTdlTxGwcAEAAsuZ8aTZAa4BIAwYJriigzmISCqOYhZEAYpAzSZrAJTMpNI4tcrlCHEzmVNAAUXKYa/LbQNiBVi3ZjhD0aqU//vEZC8AB4paVe5rIACXyftPzLwAXQ1zS1msgAlsmStDGJAApsPq7MBX6OBYQ/CWoOJZSnSio6MahqZnca7w4ypyGdxFH5B5RJv2cwSijNwzKqaHpmldq65sbjkYhktw7rTmTsilUTcq7q9GcJVPXcotRU+NjdKsKibPsFeKu8TJpimhmGZu5bz3zVaHu0sunZ2npKlOl7Gn9aa8Ntdz2wZK3ej7Oa12rS6y7ll+ONXV+tXArprniNYmWZTZgAQMwUAgUlJdd78ds5S5HEyxgYMFJzHGZoIyFrIfxBMjaqZ7Kl4MUcQCTWeHWPSzgptTVKBRyIeoldAYYLhEq+j32/hrK1aNBhb1B9bYxrUa9m/0krbOMV+M/+LuucVtFvmFF1u2Pn/58u4MmM3vDgwKUh5tr2tutf8/EjHenrvUG0r633XEHXCoxl7t/FiwAxUkGUAAAAAAAAJJ20cLGKemJFA42tQHJzEOCAxZRFa+/RuxZ2gilKwQCMQWdEoVsYNbZw6gBvBJJF6ttuLUFuYQsO6NmIRMszpoTLsGRmAsmADngUKYRbcn+lblStnatTuTazxQIFFl6ktSoI3SZfmpE5dbeCije8ZYlkvVE1RZNOB1+0kupIftS+kiM+/kpn6KbZ0yJ24EhmJV8u3q9bt7PsqtxeGIP+5WgWGn2h+KQ7NRu1S03cPprfPs9hixIKSzSYzdjkcwnqV3YIduXRWmqRuzlcnab+46v2cqtyVw3R87rnagkD92EpKQHZeDkmHBugDEdlZ0tH9WA44SoQqPAWKgZgmGtMgdJRSnFB0CRpsBUA2aTh0NoSE5mEJYsbPCnf/DXN/z5EXmy0RL5d+v8vblvUxq0Ab05QkEhcYK/+QFUKqQCAAAAAABlVMVQG+A//vEZAaAB5VbUr5rIABOhYrwxKQAEOTtRBmHgAntnqlXHvABlQgY07J08znvTVrTBEELIWDQBkFgFMhDYww8Qg2dGxGFXDARCEEfpYYxZ5RneYENGSgMHt3feHzkAIsDhBCyilgOKhh1HfNxYCJA1cLGAExTVVVnjD1NpS8bhO62oMHGgggZFFAmjU1mnlDNloo2xqvVidSPJcF201y8BddVFZT+MrZs1lfE7CnklkmfeOS1/m1WrA8J5l8zMzMRiUGQ3CIzAmFJK7NvVqNSB+X6hiKu+7kYldabv0tzLuP/lSU17Oin7GViYmoBpKaA4xEIblTvQ7F62rd6rqv/5Zfv6SrllVChXMoTlnaB4ikoYGxCm2TqjQLiYgXKzQLrlJVZOWFMpiKCshMUjBCiJDFxxbSxAVe82QJI1Ft/9yhfq4lZEzp7lwhKKogCqpMBhaD7r4ts8WY3cbE15orKYgmKkCnwWZiUrBTgUN1LsTZsd6tBvs48DlbiZRTfGylkwzm5DJhhmdrZWm07frhzYXGOgWFPwDoPBlhqlO1Qo0DtNlvlhx2NYT7hDVTLFY3FVK5x6GwZdoVDYYVlQ4qFmf7YmpRQYeMxFNjNc63jDZbOZ0ANOmf6bi3/U4jvW+7vLZAn8JGAqMJ31UoYQR4Y7sjJu8Ol8ziYFqWFDi4JU4h/F/dmkdiXP00lKnYKpSDcvpNFHCdqnV7erXrZV8+7IvHVOyvcQG1vjRr1teDeKw0zRgy/u2wI3kzSf1pfUubZ1ndvNvON5pXOcY+Pm2veEJZFva1/61Do17GNpEJhKAIABQAAIDAaWbN7BCMwCKgKVDUBm6QHv1mUkmHGM0oT24TdpxEZByF5JeDV5z7YELmWFy2jNeJHSprWpAQMIJSg//vEZCKAB59XVG5rQABRZosAwyQAHh1zYfmtgAlLle1XDIAAXIyzMBN0MTCiVbllFrmQORPmdDhDBPcteZgEMCQSMCBwgFhUFuihiu/b+svUgpWjmjQnErbKn1gBpN2et1s3fL7hgMSCLBoVoDJDCXidmpLnia9VrS/OVz+Cm4GGLUm06J132CSVpTXpXDUPZdq5fje/CxAbT1qTLjroope7l7sBVdaqX6ta13CWYVLH857X2SOmweBIm/bqYy93Ks/u5Ko1lKqatau5BUyGIGnEV/cuCHH6HXrEANMahCCYAS6tLozJCZI0E9XpZ+zAwQIA23AE032nTFMRwn1G3O5XKyGV3l7k9xfbbQinqofV/59+ro9tG3hYfl+D/LyJ1f48+uxJhJBNgAwEgBAIBA0HSe08N011NVUiGPUYYMbFGHYkbUzWxjRA0iRRha5fYBEy0BlJSaNCO+jSw5XhEYgkLGQRg7PYgXfQdT7UiNDDKnIbA/S5GtRFegCHKimimiPzztEkTytbXe8DuO4hnDU4W7d6CIXAsauwTVldiVQ5DcZYfHmDPY8CiL8Rqiis3Zr0UnhiAInF4flEPIlIDFA2cF2GBtWpaW1UqWpV/KWNyimsU+1AGfsNbO6bKWh14Zi33KlPOTVe5Wsx6BIxJZ+jjE3LZ9xM5U2lXtJSUOUsr6yzs3MKvbX5fl9Jaq26e1je3YTAAIAB+dL58FHy78gW/aQeFEPR1sSCzpLvImakZ6dSFWSqneGouYqYMmqUb2yRPdomKEUl7FTgDBISBx5NIteXFgQJjzbgsly51yiQEIPqR9XxqbIsBBbFOQtOqpmYCDieEuP2Kr0qLSaJoudy3meoi3K9Xsw8R0jCQkelmU5bxzKUyiUtyFHmjFPH//u0RBwABBQ42C494AB7x5rgx7wAD8jlULj3gAH7HqnDMPAAOpib15XNrKrYyrQhlunFKhLt+rWVijVgwcRO8puA4tTG3x3B5ChSva/wIFHmvSSNPHgYrfH1X23mYoKki44CoWCp0GiWpmpy0sjz3R7iNh9sdQrgGsbpzHKgA6RwiGn25EbKE3lEoTnNJDUYJkSFQqtofnY2CfFtJkMJdrDehaqMtXl0H0vqFWvDzNCk6giGSp0TEUOPvWtMGoCsibVjcxx2NgbKxbwn2a0mjUiXxI7jyxKVtLJChVzXet5/+PKARjQoO/9KrOAAAHw1wuVaai8iDtX1CmR5KuK2q1XIUzp0W1PuandgC1FGmzvITQcjkI6N4OphlVhuFwPUsRBgbyHXzBZ03RSt6EqpnsisMRKmur2R9eK3UeeZuyf0r1q1BpTMHMlmPx65vaLe73X+L03j/+A9GCVIjCjw7e5O9I5NX43+4hCZivy9OoETFgpBOvxLtMqHlBYNtS2AC/GUmysEHaSEkqPvl/aS+KlHjhH0TrLB0oWw6hhIQLcALi4qZnblY6TcNFl9OeALcoWQgy+xwW6PDcFjM2nUBDWJSobJAVrZ8199t9s1vuzKwwZq1i+X239/6rC+t/eXsoVs0KnnZZX7bjb/8gLCBak2CgyOIgFkpwwKBAWcJoBEAsFAKMzBwywBdhjzhClAWJxkHDidaYyOdTJZkylxl4twM1H9UMFGHMd4wJTXWPIqYg5k0WRVw0D2AIHGGEIg//vEZCwAB99dU65rIACGSUrAxjwAE51xY7mGgAmVnWznErAAxQZSgIfMsUkGCDBw4wMy8SEkw4HsKwUCSDrMlD2vhyCpxgEIPawk8psIAY6hq6USaC7y0myswjz3mIA6KXJeOFJ9vois0RSl1VgVhmZvZFZVXxnbUqsq4qyhh8nvOwpQ5rLmlxtdsYuW//LPfO63ILdm3ST/M6LJrUvoYduUFHLaWk1/efr/5//+GVi3Vp/ypObz+mtXeY6zyxuTv//vz//6lT7BxJmnNDghWAIZgkSCeRCZilDVc5rgvI5ZWNeZE5RdKQXKHGX1XRPmsoi4wKvorDO+ZHj0sBvKM5UNw3x5ozEo4TEhkWKpme6dgQIMCJHiVsn1XFgMjnVTN9XuMQs/W9/9+0X89PDg71aFH1B/+N//+PjDz6vu/1e3hV8FH6CC30WBUSqe1u2wGpgGAYDIYBAJOhAjwKrrwh0UgA4LsjleVrEVY8jqsKVaq9c4k8YAkwbYOQbwSRkimaCOB0Ar5JGSZogXyCGME8WopksYGpos3L4l4sA0iwIZs0yOGZJHi4s3MxcHCOUfyYMMdZa66CB5F3lwnjlKZwcxQdSm9tfl8eJTQNjxuYmCn3dS612fUqkgcOprUyC////8+bmDHk0j9KP/zzjDDCTDwAK2IA8XbaQCsHNwnFyHxgPBKDZEqOn4N3ImCiJ41ISjeTpxAkl47M9bnUpBmmShAVzU2ydlXZMHfJ8mMdNfM/X9MN52Mnn/rWh93HT7Yw4Hz//UAGvv//QaPgRgXQqWVTWVNCJEUQJptNp6XXbdphghjuGJBjgwCwTBkBUBVW8OIjIJiJuaCy3iCBA4eQMbWY/EnEQojAR6aU46/FLFDTDrC5puBxGh5PT11C4Q//u0ZCeABwhe2P5rIABjJ4skxiQAD/zpXBj3gAIHn6z3HvAAkLFZVKp5/ZmpnB85OmEMtMWXTfKBZ12qavSym3Ty/uq5dzNfzdW4Q7HK1+vOy2pfjExdtS6iYtBLLV2P2zZwYehq3O55Z3bVPSWIpdt6Wk8TJ5Y3rcKd5rNytlM7xrXMqsvt4V8ft80+Mkfx84q7MkhuLRmrV5W13H/7lvHtvXNYYfrfMtxKs/dmQxCvP1csL9WsNCsABoAAstnYiMrDkppll+qFg7ElhfigqKzDB9RtRGebaI/PWkRnjo0raGWi4aErSIQjIoFZuXuNVHZqXhKiS7B2r//2shf/kv40lt3kq27+f5f+J0vsZLKt/iQm1zP/6/bGeNaHIsniAMBOnKDEBrmkJMhB9hDAlBfRNVMvjuBOAmS3CHKxhXnoGA0RCjNJa0rpzDDDwFWXFdQ6NTKuXCPKHWYImbMLmrldBVqdhbrHa40kYuB9nIsphVPtarLFiT5oyRXaoZ0A3oXEV73FrV1nzUr96354cfQWUjyDjmTM6JQ2NBgIAgCAgCBAY3tIpvn8Bo/ajQY3hcq2JUOgykDR8Ok3VawTQT9PNEOTctw3l08jEioan7jPZ3NVaqiqOUs+nOBE3FrGtaHFx7ezyJSa8StaWt6y6+vn3vm+7+Dj2vJb6r8f/6+PT/VvqsWwNEhWiFRPYwg1AiPTxQNrI3SUmlFFpKWsEgNwkgFApqyfcRBgaVwyoIQSnJepYQAmkECvwQOLAAKk//vUZBKAB5Be1m5nIABSQuuNxiQAHkV5X7msAAJQLC03HpAAw3EnjXNLMFBq9S+wQQFy0VkLgSFBSKRrjlEhinpvo3IjMmEISBx6nhhKQZlIgwggGSpjUFo8vq7AiAMgRWAsgj0sOpcYYTLHJitDg7Wk+IbgSgdht1kKZP+/crnH2faGn+rzXWUL0d5nE5LKFmjYGwytxqSBIZ1VpeYa6xNmbJ4gyeYkFxrM/G4ZpKL88u0mMZu4/jhVh+Wv3136CHJdGI3MzVqM3qW1XxfbCmv9xq485ZxysTsbtv/RyiX0nLF2nsSi5Vi9DLZ2xlfn8cDlNswKBgKAgEDQs2IEq6bzZMar3C4UlzxXVogdWRI0c5lq2c9vxNmEPbrPRKR0Hg0sPABJo8bEZ+WKQMdF7jiFBRNxYUp9MoP1Wzl0+j/STSQ9usrbIAAAICAZDb8v2MhEAoEQLjarS0yFJorRxuJnBRxFZCAhoLCgq9Co4Em4GeQ48R1LRIIc5agUiDBSqiSJf61TUyiqRz0p/tORVz3URmUVbIwFR5RqomE0WO81V5g2F6FstwglRZprPva09Nu7Vv0t71pvojq3R105mMtNdKWQ9Bdd+eYbx1ZxcRgLYHbeKI1pS3Ko8zw07+xLdbL8quqbN4rz/WpmPy2JXIef6Sy6hsUtNajV2ko8Yllcv559nZ2U009HNzlDfh+UXoQ3GUPm4UrgR2YpAzhReHZ3vavccPyzpshSOYf//OhQPHf//XbZa40UQCAACASElHLQxt5uCcHwJsOMMATAFOnU4eplKMysnaACRk2iURhgM44gWjajAi03cVcL8WIkSFllcmlrVxeZQsyWmwrTa39b+1FDHZNRYQ1qy//9/zihSgsncGVHok2I1n/j+QkUjUYqynKTctu7qUo+8ln/+QjrdYxet1A7ZKNKExVclLQFRX/fT/+tgVKqRMZlIALAIBBIBBSLm2mDbJbZAAFggFsXQJQzMGN4IxKzLARNLTn4kZBoiZAWrcaABEkiAE1V//vUZBsAB5deVO5nAACUScsdx7AAHL13W7mcAAlkmCxDEpAAfF6ZeNrBWDD1eAguURp39jSG5eMIOK0BSS+0baS7T7v6/YOmpsvRi4OsXWMIkqy5z9y9/XXgd+V4MsdxvG1UATiQxZlAacsBy+3DdHMX+PFJVqR1284fZS3rXVAWRN1iEP2pZyfpMbkDsr3Zp41TTy7n0d5/5dTYSicwy/uFfv55WM8K1q1+WUjl8ngyVzVePxrK3qUw/I8IEyrVceU16Odpdw7YlGNbDfwzBEZluVWMxWhhiIxg9/////qSopVcgQUCgSJA2JVdtsxl0VqukjCSmiJsXpaaUgPwKoNU+UZEPoVqq5iIq41SbXVtCkhrkzz3pQIDgvLCdt5PGdtM1TRH1UdDBKUyaZ5yNdG81C0rcfo7rCxw8UPHmxs2ZiZqdssTTbuXpCudjjjyHrVm3V9isc3+Pnrv3l/ay68fTZ6C3wPZeaWcc7EkMRBOrSYW9zcRhUBICAIBAIITdt+pKMYqrEnaGEDNTMYIDAuW552MHM2FxB0NuyuTduJX4sgBXC7jboBUOTCkgofcuSFQi0AcpMVG1dEOPJF0bWNp4sfUyettGG526CiomDK3MnY4l62J/3+el9IdzxxuY7gyB2HNhijOXagu/DsSuT01Mxmkq0PXihuHoZfSdh6MzM7TatXe4xSdi9vVSozOH2Wulchp9ZmKw1TQqMxmTS6VT9LA8jpMIxT35+o5LRoCc5/XhikWhqfnYBlFHKrc5S3LVbuNSWW87+GOGe+/uQxm9TSq3ZpcL9YMSRdDRKXwYQi4q1FYwrBERqIylJHWiaiKoD1LKqnC5KmeIHEQ2q9uLDBZhpPTLSz2UMZr5DGVqaVuDcrr9NucPk2ZS2KsCwkCTbkwMSCQPBL/iQJExZX/9otVtaliBAAASm4C0JFo7zhL6VppAtAzAqS4hXFtGYmDlOMPxwC44RFLB8WYcHR4jSwdo6wh5ghiwiklki5hZkS7EC6DaWWh1lmdIUfB//ukZCWCBAxWVG89AAKAynqN56QAUCkFRawwzwnhqim08w4xzFockiykwlnExNwqVKG8rcNzZvcS0KkNUwOaRk1VxPdajUFYRTv4mL7hmvm9NK7sZ35FFH89VvJuEgAAAp39IJcIUDtHqLMkA+wpTzBUjFQSFJ9DEyyFhJALkguwjNmR88bDJoubaI1FRQJyA2RdQtMXMJKyLJyyrhteW0vCNRjsfdXXza3c25S/3NYXqvWbGF9b7v++OZefa2WVL+G//xbhOvK5ZsNr3vz+vtVOUGyONWuDb0yCm2oSiAE5VdIgsxERgqhdCPggCgcwcgArhYdpyOLJ6RwxCXhIOagyGZeH8wHojKC4PaKHx3dcLbzDf2BYpErRhyV4UWhNjq0GmwoJXjJkh5V9lZFzzELXlnoN3gWmYWf8u4XDlWyuVGTstpW7hFkweSLzNGFdq3LKp+vPNa/J1t9v3uJqogAAIu7mEQRzIUIGI+N5iNggjWTMyQ5wF563FuqrEkbqZsmkDCkyZYSSRJpnEh49AfCFkosjScQYWVLU5+GHyQPKdri4zdTac317C/Vh9UzYzZzVp4J0PKUEPE1QKaY5xrip9KN6RjQzRzLKdQKs+zqu9t389OoYSQAAAAncfdAQ//vEZAWABFxIUO1hgAJz6UpfrCAAHrF3TbmsgAlHki23GGAATHSIyrTBFPJW91wwioVNpE4DD3qZHApPGoB5LBgiJgfC1CKjsmy9MQBLJbaDzrKZUIjDxlx8YnVIqpWoPi2HnTzXIpskVMJ18TOQMS7WHHoztitJi/l7VIFqi+vf2c21Sk1mlMgtnwT//ZdO5vT00mc9nQpEzwUirlmo+E3YVvvIKFQzQAAAABzdQZBuDKq0RljEVKYnEnnYjFVpslcJ03EEMcIQciwNSTrGkBNYcmEiKMFTLFhQU/F5YwOShGGsow421l5b1nrlb1dE3n5/S6jvVc01ZqDW+0ub/tDYq/6aamajn7lVvtVkcDlYvJQnUOhU7XUYBQCAgEBAGAwMh2RmUK2/EZM0JMYNmgFobp5wOY8yAtoljRyGgRmS4QjMIMFwkQaWOlmquc5RmJM9Wqzo1SQUCaLJToF5gYlBD81jbHCMBCKUMGdMFQGIpWtShL2gpc1gGAobmgEk2awwtONVhiMGSipnH4eVgh8tY0ynRUCLyJdD0mWSSAoM1Zxpa2p9dFhhi6IpHHcTWVmCB1kLwY8hIl0im4cu9mrUUghnEgoH8sUDOHCXRKIAcSpDFXtnuWdJzenIilqksd/7HHcpIxGPhyWW4pz////////9u5LPfx/LEohyxUjF6B5BG4XSy+/Xl9y2EdPgeLsdiAcDgcDsige6L8/9ghn8w0Jz7s6xpMnjkxJ+Ews9C5l9z3aaBxFafe/7PTcn3zce9979xMQHrZN0oMOHGcCOyn+TGgRJz/84j33kSCqSxFItkAEAAAAAFFJyQGMTMd1EEHSAaElzElzAHzB3jHD1hw4mPNBQIrabpuYkGIw5TqGWESJhVGEMogMhGGCw//vUZCAAB6pX1O5rIAKPBvrpx7wAHRVzUbmcgAqAoSmDHvAAcmLCpzM0JIGIDkDRELcDIRIgAkX9FhEj1QsiXwr6C2pgg2JUxaKB0JAJJVXTCbq46aLBGmqatbW2wVsskYmrpl64liLkiUcYbAMCuZDD+x1o6cjg2lKZFDDxXGptndOeh93q8APtIZU+3UEz1QGvV3W7O++0BvBOUtz53O/A0sfSOT8jkVSYcGMSx3pLyxD1a7N0tm9Y3e1T7pLUnu386GxjO/vbuzsNRbKGZzlNnulgCEBgfqiSCCCCAAACGSgVB8BqsMAsAMdPqFk2Q4hT+DGwjT8TEJmY1hCiTG8pXGGcicsN832+A5KhC1eQlRk/KtKp5ieqZolbM6VCpUNZqQ8KV9tXaWHCszxP6hOFIW7P07BtO+gv30OPPTEalKXj33JW0u6MSkk30KD4EFQmIiphgtfKA+DgIC73NCSTpFbv///kbI0aiSiAAAAAADG9b/jIzOl4FG2E9CaA+7jERMUYtiySGzkVN+wDQgAHr2gKU2hadkcaWGORdE5Oov6kUWidafl4ANNEAFbI/SVokVf6hKDlHkFgCEgagKUNQSqY2LU79ybGiV0Pq8aPK9oBXK/TSmHQ7qXS7slvq1wtyHiZ1DMJlupTDL6z1ZxaCUxSNSqVPojenuoC+ESsyvlnKVRWMxGmm+S2dm5yaxdR6GXuvDLYIKvzsSfq7Lqs1FYrZ+/EJXQU1XClvUuFqNxF/aSJT/5Q1VlO6ONZVKe7M0litnnhaqWv/953ToaSAvMBgLoxwAlkHIjhhnsGUQgSw22WMDYAIQchNDFExExFeCVmKriHD0ifC7joOEhwgQTgOgTJZJSF0foA5FxOonhZFEsG8LCIsEqO89i2iaoIhxrmAYVn6JiIlDWVwfKKMSobx0pRgU6nNFCbStu40SDO2wINXq8xNTVChR30OLBxj+286tXXg61j4xitcQmgsiZEQWEqFLYnEwu17MhqYxIAMQgwIAEACBAJEx3k//vUZAeAB7ld0v5rIAJO4/tNxCAAHS1rU/msAAp+I6w3MPAAtM0wKq4ZVnfzgAqZoGmQxgz4U2BwHBRGGRfVOZwgZYMY8gZ1EDAwoOHpm9EDEzaZtKD0yAw0UTZZNyUQiFom9o7xsgm4oZQyXzdASFIY9TXboKsA05ewt4ZJ5hkCgZiDmEKu7Ggf2IwLNlk0ky7DXJBNMucKPLGQecGK08NT12i6kQpYDg0H1do4Pwul/dv6/MBMSlUiwwsXqbaYCYSJiMCD7X2Dza7pmMwz9XHU1NZU9bCnu5Zqni7sRDCOM4cRU7X4lLtSSNVbd6hx/H+f3//n/9vOntyzDmVSxL7edft/LKml2O6uWObxmTwGAgKAwGJzg2A0JHngWdqHJYQg4496gWITkFsjxzvv5At87uLSuvUdxLNMxKqRLgQFccIllDNINCU7fpCG8RBUA/LvJuocWU87/+iiMwNhIgAgAwBAICAVGSf45Zs30hnBizCukEoQIMqRSrEY4OIlrDJKDMEjEjiEW15hLfgAwFQAnSmHwyCNYUQkuCVCQobu5AKi2DNYRHBokupbOeHEdIs4lYuwQFL7N+DAruopbZwxLkMkZwmIyyYftHlpUHqqsCypbONyqWURIgpMRfkeVUfNgLWoGbi4UivWsJ6Z1itR9GGNcjDEIElDIXChTow9RwDEvq3u5a37+UUohicpJRykpKNwYMo3BlVeI2pnGW441sdb/lh3JzGWXvpN52N5uT8ZnY7GeSmM3JbFamt3K2u76x7fL2+DY7Fialga37/xH0+IgXem1bi6KzmvKXAEiWoGoD8LOjSsLsgOYZmrxpCGBGwqA/wUROj+Utw5AY5nCchahfn7Ccx0AxDwVqRIKzMcR7CrFe8/1edavwXPD7TErsbx816jhGmh+zLdvo2LWxbONY3/CUdoirxEnjNSujvn14Vc1+v/AibxTcTF++ljYzjf330NIKjWLvoly7VwWEvaVVEAAAAACvgeYXZtk1IcbpkjuEnJW4G+EBLc//u0ZA4ABIdIU8494ABviarfzCAAUZkvSb2HgAHUFOk3sMABqV8yi9jXFQYKZQwhQmY8xMDNSLxUSOwHcWcTyAqYtHFvJGPcjRfRwtV1SrsTQHCbn8nRcTKRpo1arS4u9o5zfJpH0eK04qFH6boU+LfO7+DLVQajMk09NfXt8f7h43nH8d549Iken3necYxv//weRRCDTxzVJpKJDARGAAAAAQAACm7dQzIvxqYxegArUyaDPrmrq5UXaAyi9wBYBoPA84KaGVVktZuPeDhcZT8GnniGUU6lyPImndHebm+aiJ4ILJ5mI7+uu6/VWledu46+o3+eNWlY6iohfqLpfjhv6NOpVT1RLujcMIAIKd/ElPukkKALoASagxa5A4YXDQCCnO1FOaHqZmzIPIvriXF6huE8pK3b4cCGpotKRHKDFki5rEj2fwLa1necZYYsJ++pakl83zX+2sPIUsbFc5gQaQouZb1Ys7rjG81pC3auN1ru9syR64xWmba1jUK2q4znNZLVrbWbfWow5xGIvKLji7rljbOyIgAAJTfWi+bOgxJahwxIqco4RKAvEr9Lvruwc5oSLCTUDyxo7RKqJ+I0cvdEgLiuhDk+0WjVo6haY99xqtGbW3bMxfXoNnZrl60ZgVNTFAh0lalOVWjivm+7Z50ormov7/uGYnYrQ6XjZPXuu9X3+/35qnpeUwAAAC7wEGUwYSaxF5hClB07CR2L5NcdAvi6bcIdfld5SA+XjQ4bIQWEwmEornaM8Tr3//u0ZBqABB1K0W1hgAJ5iPodrCQAXi13SbmtAAkul6tXEpAAk1qmq8+O7sv48y/HJ5WKH3Kr76y7FWJuvNQSy+/F9T/75S78cW2pMwMziT5sxSnrJ/Mnd74F8T+OP53TS98/aTT9+frbv+b7AWSDF9c1KfHUUAAAAVMKeSiqTkNRlG1eyCMPChILot66CXz8OW8bgIQIDIqLivocNlEAAEb8YRNsikOk6MhsA5CI8R2qRo32o9Azc10ccnlZcIZPZXLypa09bl9uuzj83H1BK8Uh2syN+PzZ7X2mo/3/f8suqlWpYyeyt+6Pk3lYMxoLBAEAgIAgK1cxI9wADCRcz0RbhnUgquGi5qgR2TZhT5nXQlBElJhsB7FBv0hCvlanB0TpquxnXhtTyE5FJMYHJEWwAMFG5l2RnxC95TKwggt4EBgQpMekBzKWxCieKIhgRs5cxJB8wobMKUDDQiFg0NRwzYf93qytjBHHgh+GDoVJ2pVIrMjVuwmvzpMZitLF100Ua/WTGhTMkinXYc16hxjsqtyy/2MLvn8Gvy++/8DuUzp+o1Kn+7PV8vx1zD/af7v29YUlhyJZEotQWvytynOl/////////kspPpLH0mHMMORm7KZblVlv7lOUXbbAIJDwuXXK1AnRDTLK0qDybwLmwAKKT1A20fFQa9Y5t5GkQSXzc2e9treijHf/52ujnNJFGkUf///PZz2c6LK0iGeBz+eFP84U91WpPVaB8LwMJwHWAVB/R8IkXALotpnm//u0ZAsABBJB0YY94ACCpkpZzDwAELkxQf2mAAnoouh/sLABiNY+A2gX5yKs8UivEFJE4NCylFeacY50STpnjwj2Q9RLtXucQ3kPRTtSuEdxUrYiWpTti5OY5lHFULF7w7RsvXF1GgSKY+UmfkFiYY8CutWs3zzUe13jDc/m8CP84x//95vXGt7/iHnhL+j6vqgAAQAAAEJLNMZyECesxLfAphF0EFhEOtqpqv0RBjUlAOE0N0BhVqNHcXgpDRaVt+/gspME4H6UQgayrGZAoYbjxxCMoKdQsMad7aO9yz3fWV19xu331qtNP5X27a1VmZnG1r2rrH/gt0KywTGgyVAzOHQOAW3hILmQL9ezUGwwHCLSTohAIAAAS9wD6KTxiTAWIVy44oGQ7lBIxAJDomnXWimk/S+YZIZddD4Qj5avMTkcUjY5R3XNx1XHy9hSs+tPRLJl92sGPORTblNmvaiv0/K1z2v3/vus42/al9ihSNVtet43HZnO/Jeszc8a2/baGtYKe918na7l9gvfdn7c9aIvgXSd08kqqIAAAAEu8LYIAwUcrvLMICYUjShmlXHH3gWTQzc6Hgby8PogXGbTdY1Mg4YGzEzaCkuVKVR8HeVlY7jUmk4lHFS+UYi2uY9tmr6mO5teWVf12yfqN0edXdL74rituc4dZyauLa6NPnuLtjbdSeOEVqHAqQNCFg1ZedaQAAAAKvAPsQSEhLsI/shkRMC7iaaaAcejYrNFVNGHtFRoQuLgKjuTjhOb//vEZBaABClKz21lgAJ5yNoNp6QAXmFtRbmtAApELOp3HtABl8KTASURYGMn58kWykaO0a2KxIZNqqoTmfcL2LnzqLGsxJa1Jg6u8tnIso6xB+v5/sxxU++Rw7fqTM17J2WKTaZpNJem89lXP2b0st76U37ywOEAifkplCzcaAAAAKn41UFgABRNhXKEwHeBhEjAnDVUBoK9Wt4iFQsSDwIIDaJkaMD4MiZEHVB8UNSk4DGCIRlT7ohmBppQgQ5jSNrzh6SY/8Ybu1tw+eMbu9nfmwpVJa2vqUau4/Fd3sLR1T+4OdfzfqezfV66AiC8cPK+P7VLu21arS2JS5LRIvntAIBuokDPUVDk4NFm9tg4Gm66QUIm9LnspGlEGXIgpozQ6Vg5xpIQWVg4uWzOe5NWlViQ1V05TCFlmXAmoMGMERl+U6lZk+nKASQ0osum/bhwFKnWeJreTbuEDjZFIMSVBQ8EHFwwy1ihisWa+zpkjYYMpyyCPgCDgIGX7MIAjcPSeGJipJXQom3poepqcyAwIIGNBoA2DpWTNBEZJA9i3S239hmkop+/Le0aPBbBNQwYEwIFDcDCM8e/3X63Vp8r9/vN5/5ggCAwDD0U2TqWRSko6T/////////////////sU8bt0lhHXbZI7TJG5IIxGLAAgK3HRFxkn5+HgW1BhhgaDEQRMvwHQUgRo0C6iehzx7l8drDgKJIgUcAxC6YGZJF4YM0NAWYJOTR0LS+Xz4llM1JcOYMIPAe5sUzzLSY1PLy/QQZNNBSjdnZWp5umXC4aD3HueqWurZfzcehcNC+m7f//+gXEC+X0zRD////NCXTDJwADHnOkuy0ACAAAAgGS49Ry3I0IoJh4HNrTza9sYBoJUHdky0FNIPgg//vkZBMAB5Zd025vIAKWS3rtx7QAGXljWfmcgArzKOo/M6AAiUIZCDgAyQmMaACAE0mXRkhuqmuqWxRuMEK3KLxuinc8cDhilF5TCHnq+AQ4ba5nlmMWKgGCAYIyVNLLMPuAZMziAEQjQAh0HUJLvQ87XMs+W8q4JBDh0DEwJEoVNVqWHWcyp/p3eu41sk1H/ZOgLT7S0Qoa1EYZhm5lW5az/DHe+rERXRTZOg4uxgix32d6OuC5MSdpypTDv653+b1/lr1NxIBhkCO3HKVlbX3JlUupsf/8ccv1////////7B1MFBG0TrYe47EIpII2Wm222sbbZAJBIALbQlGu0JMtrILCOEBigFhJQICW4TRsOptlE/B9JiiwlQkIkwW4kDRMpDgJEOUOETEya5gSg4ScXiaZEkeqkoPcvm5IGxeLpdJEy9clDQvkmfHokkui/+PQoDnHubkoYVKSol1KtvlAe7zymSSS/pf+XEDM3Ny4XDQly+XkUS6pJLX//58ehoaG5u5yGImURkNlaFVVRY6QgE1Lf9wo6RSB3QFXOUU5jTDWBAKnL4l6oOAQJjIx3Nv0cy9z3tDdICkGvsDSlSpVLkBQZb8xwJylaEzFB2FwJGXSR5SBg5kRd5AMpTlD7/w+/jSGGwEzpxmcsNfZcypnRpMKmG9XX1+hjEZclrMSf52pTGd///+8Y1aneVcVyxKHoaq8/me//n/8BTN6h7+qspjNaNQ1KYzGa1NvVe33DDn6vRKrKrdb7uW3aq2ZTl/7yy3jj+GHO/////9LCO63BlTVUACYREwEQAAAJABJTECoRmtukZUzRDBMBwpdEBcHWaF0UNtOU/8N3WkGEkmkAlwEhFKUJKmrcoUgMAIddapWHOU+3HJieDjvDGmZMBa015SppM+/DuSy+1Nr0PU3FitZlVM7VLqil+fxiVS78ZTvcp/G9epoxeu59pMJTLbmdDl9NMxmGa0ajUzzOvb5z9cq3qb8t/GYZpqam3jj/85z/7/93Vpf+t+Xcu41q1NVpaWtTU26XH9IKjTumplWYAAAAApgW+UTRKZi2VBwVBKX00qVszKlLS9ycLt2YbYLQbCWdJTCIzLZFodkUVuniVIlsnVMltIvWx0hpHDT0TW7LdVV1K2jcUS5c9T0leleyy5sVmsegv/83Rhc5uR0913+vtZpSe396u037b1ZtvzedmmWfxs8J+yYFhZG35cqAAAABcjuKdaNZg9ECI4PY+0MLiiEKTbCWJDh0DwX3MR050klQxFAatF4yK5R//uUZFgCJAtH0G9lgAJ+Btn657AATzUrP6wwb4n0KSe9hg3wTwQSXXARVhAXC5CXSfGWFzp4ZuURxVoz91tnX+yDGcrfnmvq+zbL2m2yzOVt7W1tA5v6zZD7aRDX9R3fafTrl5quX6M5G+Amy2ZvzOf/96/FG0QErgUPTkDzgkjCRUSUTrkCWutVdJEdbyvW5r7aqjMRNBumHg9CRgeWCU2mXb9Uy7Ts9OXXGozr1rufahtePqMonvTGEDBg1N3h7sDAQBAIULEwyaOYJydEOkMR7lezZjDgykcKCFEjGVczz2ptWllEmjZ96t+9CEVUQQAEph2UmRxDtcSLxmW9aBgyRD5UpVAlb7HX9iJdCkcBARDCA2qwTqGxw8vLotSrExu3CFQ5LhELyGLTESlTlWE2pq9ar9h5GzimuKF2iQVFZRswIKxCHzDGGjAColWjOU6sNSTYBhHl2xsixxMdBLokUgXTNlq5IIdxeKEAAAFKfI5lzS4yC8YIhFIosQqQ//u0ZAsAA/hPTusMM8J6yRntYSZsT5UZNaekdUH6pWa09I8JRP2mmBnEQFY7aRDVgZm68vmlyaIo5nZidlpJDeGqGS4Dy5+7jEwHKQchDyiYSSV60safNH0kLLtJFkCn/5Ky8Uc1nTNHcoQG3ZXmKVjzj9vulNOv8x8ezszy7zmul6v/Hbsktp03nZ9W1fzZAAAIa3DbEgCZK8XraiqiLfQSjpZAnCFglq29IRCCYKDA6OsoiJkyqgDLljYnpJoUyAYVAfqwrHELyJUYNRu1BR7HApSuu+vd14b5KkBlWU0w+PfNQqbm03vV3q+/l3xuY0VqflKHvdKVMvXrYyb8JwJdQn5FOwg0IlxIgAAAB0AeBkA9UWDGCqDqRYjCJHoJELoCmDGBVkqALg4nohajeFvRy7N1cGktAqD4HYyVrhN4qEwZC7EiNpso8wWEpM6ZDarMS7UZoJduTTKFVWOFdk2mxfYLtyrfmKUwQIMKBNRJrwukrI5mc+w/JlL+sGhU1T1yc/G20iAAAAQ6BdgbIBaJ6Syg4w0QaR2CaleAXkbCSsCgLid6CLAqlOd0RC1EqznUiEnijyVK5dEdGhF4UZ3oU0AKHpBYByQJmhsAQZkuTuhs5SfrjGDgXybrhKBiTSwqbEtImYrcKTMdpfMKWZx4xl5exy/yuZWqQKr05YcCQHIN1pgAAAAKbj7HHCgiFIyqOhCgkSVKhrLltpbk0GuPCztuLgWU5iUXwbIZmwTRiWDMQE/ZCU3Ulz5QOpok//ukZB6CI9ZKTWsMHGB96dmdYeNuT3UZNUwwc4nzJWZ1hg5haTXP8rb1zlWshbmkLr7FOq9F/wPMU2BlaiWYGpHCjEhNxGPSQcdcu8jb8WGuio19/3XhE2CcHAbfFbSDf6hFCkAAAAAnhKGtiFA5BEaASYoNC3JSCymJkQE51bT1GCQgkqsVKErBBTeNVMI1VFEijId5UGHMti0fyEocVzPRWKk44CTes6LodLlPSBWFHrUQmYNFIlPI1zc3eClLlOGCbWmjHVdf9z50HSLyt/8j28mhg05SMic8yBPmZSlcQgXdw9uIsEElbKGgQOLpsiBwISw1iaKMTgqZeltXTQmKoSGWvChrZGLQpIbXrzRAObHhnCWV3WKZVrde2YvLDJxbst6116Ia++Ysuse+fflGVqtV9/nuzL3qQ5hwhrmFQUKhU2iA7SFztZOFdzePIDemvTl1T6zN22JEUQAAAdwkFQmOhi4qmytjW2rxR6oBZQzyKr7vwNCGmNLe2JsG4qEk9AggBiBwICGfEnSYT0FoK1QuJIOmBUD6EHxPjgVwro1+OWOLiIDKGD2fAnHBcCWcO5TfMGNwKKMkiKMovRXZibMAOkaRDr2ZmwSlqfTBEMRQVffH61ZGiSgACE7+//vUZAQABHpKzm1h4ABzpyntp7wAX+F1RbmsgAIooWo3HsAAYAy9AICHoHgqqEgt0sKXfeFSDT2Ep5oVqKQ4bqMQRJAtRCwvIzmqVYyIw11RDOZseMdYcFjeYZnys7Ywxo10IYmVdx7vvFiR9wvDrFxC3fUsb3+tSU1SZ9qDBzqe3tPt9fFMTZ96T+W2LTVlrf5r8a+a73uan3jNb21Bhfe5amyTZg6OP//k5BZUWgACTNw94zy5rlxD2UZijADnG4XkRtVVRbMe6FIQwGCMBnwpHN+o3qudxrRdbeRIENYdQnjU8ltuzk7a48bO80hX1nVb/Ovrd8/dc51rf+f9/7+r5zTz+tLWz773ubENUX2b3njiOuXZ0DD7ceKf3LW6hEBQFAYEIpFI0FhFa9lCTlxzn7iUuaZaudASa4oeFmY4aFiJf5McLkDVGjVGxIylfkf4plVAws1CVg0A6GR+OEaxvWEAAILDEV3tzjp1GGCUcUAJSSNUAhly4AlGBxBAhw5klwmkkY6jgsYMEZ8OwC4FPDkYFlEJYQwKggpNC1HpMZ9mTPS9Viaoopa5SgEFCtRcDBtukOtd+lbaaAWI5vrK+1Lsv5vBYQDLuMnQuN/LqRD+ymHZ3H8rmsOZcsb1/vyutERfaG6eCc6l7es7hqmlUWzmqarWtf///////+677uPqH5iKU0OWIYnM5TurS7x/eVMWPf/+ceT//z1EYDAgFAoFAgFAoAABTgvSSrgIEws76iYYHbhFuuEOIjgEAIUWAVAidlgqEwlerOlblx8K7rRkJTLLqwDYxCcB42suQjFM9ZyekQx3WiXGS3jmYTHb3t8c6f0J8dI6LTHWa9tPmZmZow5J5Fc8yWl32tkzMzMzM1u5mREefW78MggQKJODiTBEWU/vDoAAAAAAACg2YY0jYFUgwEGUhUGb4sMrhUoji2IvkcZINAVVoLlqfSYAJXNLLpYyRPHRhFwYeTXWds0pUJAk8cM12IoqzOVODiS5Thd6XCq0Ey2Mt99F//vEZCwABi5Tz05rAALESwptzWAAEEUrO72GAAH+JWf/sJAAaxl0Qbxl9O/ySEqj0Yzd6rdpprChzeXFS9NeNNIUsZS7Pus+1qgs7q4ZWa0OcYeyd3KSKW6O1KXJrRp2qvc8s+d/7sPxS5LIHwvUlezKZVGrV2M0tbLv/3n9//i9mYilNLM6LP7erFNjZxDozetLrdYk0kCGS02lWrZ+ElzPz4qBBNdrRyUoEQmicofMBVAJTjbHGLgoE46jRb4uBIWjQZOO2AqJ2teRuLtTOcNKnXyXLf+eZTbr9c8HDTaSsiCpXZXbCYAr1qWpm2VNdurT3cjTlT9LKZb37Os+ZORFI+28ufe1ZpJmMxnGzvX4916/I46lPHWX6kk1+qWmv3Mf/n//+5Fi64bryC5FJf2zalUapv7zeP7/XP//9x2aROR09+kz+3j3lLch61S3s61q1jjVbaoBAAAAKVBxYsZf6mTMQQmHEVkbmF6XM60AqYuC5TfLS4FwjFcuA1MQmABJINiiJyZQemLThNouLTLOvyYs4vxHDSGuxt0YgX2glVWatWtZ78va8cDcuS9b2rMrbtWX7nXraz0s/sM2+vVrXs/61yu5n/Ws7M425bqdPyzLCJ+eETwisgCAAAAipo7ZgEa1ISWSpTFljAMHFSNbRddu49EimH5JgLBvgyd0MoUlMWFI6J3vUIkBEWEIpFAaElogts0ZHMumotWqoa5KrpZtFFiWocxSt8ql7yEpfZb/CFV/4bKoy/jlVSaUvHIbfz0tuRzqu6yJ+K3OMeWLFQp3g19Fr+RAAABTAJgyzJDlUY5g3zCAzE9NMyzhJa2nWOAl7QfkR7pVnYf2nqZaG9UMzWul09qZd0w7hw1s62ViU7Q3zvgVZ6a7NlTt//ukRCQCA7M/TdHmHpJ66Dm9YYZuT5UdM6wwbcn9nmXphg8RtD8a+bRrKm0UG9RzLpw9igADCu0Sr0lVS6iDGR21w1ggeiYjeEOMKnojYf2UXm8yiiAAAAVKBZCVYKgdhKsbog9VaShZQNghtkbOBkGwKAYHQ1CqAr3Lw5H5yhhUieZcJ6shHhqekukuFapy2YlhxeORo/S3MMqW1xLKR7MRqdMz0oudbs0BlnO27RhavG8x2fMrP5+FF47QnTeWdHgin8sC2srXY31ef1GOhAgBXAOyrS0BlTQmghwVMWtpw0S6WGTKXxNCQShJDgdR6FATEtIrA0VD4fozwPSYIRZPTktL0rZkhEU+SnKbim6XP2kLC9+847hh1BHJRLBgYw4n1R3CE/H7ClMGCw3RpTtPQzQCIViVFupBnPmFUxnQUPmxiwMRsavksAAAABBUAtVnClqnwUUaKoAp1FEVUeaRQaIvPS3FoqHuainAMSf90VgnvUqfGRMEZJHm+pp54HBhp1WZQ1KGWvnZEA0Zw+KMKRx7JZj3amq2Jk+Vz9bVe7XrAjLuzgzBZHrVoxpAzd0UzSU9SDYQ7YJUnfb7BomeqFaoFbW2+VUKGwEAAAAF0ERH8VsXcjmvBos8gMWH//vERAsAA/06y+1h4AJ+h1l6rDwAV9EbJTmcAAMVnmSzNZAAclkzXGFMimWvNyG7lWGUuNpVJKQ87Hm9TsUyn7Inbp1VXjvcoWrGKMuYsFhVLa8nw+Yo2YLq9sxcSzb2994tYOb41euK1r75i/+v1rVtazi33vdvnHfaRBURc6EGydtj3KDCpLunu802GLwgAAACcBQR1m9aQyNWJniumBQOpqtVr6iU6wV6HRECHwXsvJ0rJeHZbGFJLZbHEzm1sUTYzJ5CG9wcWRWIt5XUC8JSPsR5mplgupWyloeoUsS1q7zq1cW3jP1r6x9a1bMF/mFi7+lvqvt7fEbE+HexYbXZZ2Vz+/BU/Z0rkJEgIiAAAtCgAAPBip7IG2ULoj2KDAmIZohEcLPl4gcYKAtgSHQkjwahLU4ATRQxIkrpLXqcFtF8rPLglqEF3aWTeUEWopsvBLZsLcFHXuhiBGQL/dCVuQ4LX4afhsbrQFYcWXVcZ2FwJIpyWv1PNZf5wn6mphxqKHrMXj8Yi0PQ5BUzQ1n7hdikp8sKet9qrFNT1rHlXlPbxvV9Y2NZ/+////PGr/8/XPqhZFTez9GcMTRROnAn/yo1I8b/8MdyAAEBQEASAArYAAAacEmhmDBUDA5CIi5iRBfISFGCGERsVIJKBUyNDVbQ5SDA6+gRfGwVUsOIxAOSPPAo9azavspAKglYYJAQCBUgeqV4VRV0ptsHFB15JWLtdNfxf1ZNJBpjiMYcFBHKqGD83EgqsqafkszcgCRxuH5ZD8Xlb/Tknik/+E7KJ2Mxi00HJwJ175C+vLmeeOe71BK8rWGuauzeGGdvm7QRkUQQw2plQaY5dmnktSnh8uBKxWr/+fYWSd/8/Ui9IUAAAAAAGkAwgcdWAUWd//vEZAgAB39PSs5rIACXKUo/zDwAEH0JL72mAAn0n6X3sMABICcciYgYbo0GIkyk5zJCE0DIGBZ4IiwBWAAHBhtPB1IJAMsxTNchtkgegz6wwIGnBEyJiEot4d6piJnviFj1AiqXEFqL5GgjXVGkjKEFrzYVT9LKqapUo5uMzpyIGACAOgQQJYFvw5hPkLhUiYyGyZT0w3cjbwWguCGBodwUvLgMG+ygyqtOvlFV2Wct5xr6v44+DTEfGPrkbyUUtPAcCymllX95m5sOu/LsOxdxGnw4rtuiuH6XZCHYkEAu7DLizEzSP9lTTEsd+n7OY3/1bsZ2//V/SDVfn//Z//1f/9zQkzDRRGgkgAIKJRScuukDHgCNIQCqcduoiwA0RwWAwIimPGQ4onpVnvSlem9aZzQLez3Z5Y746yBm3ids3WZ4+Tjx8yRHkKJZXYVCpf3tNDcIbnLCfYtmjZE9/hn2/npangywda1Smb7zusSVziv7w4m8Zxd7ma2vDviIo3ivgaxncseC9rX/5/0/p6Xh3DZcgUAEByvreirZYAAAJjBwxQ0HXuBS4XFpmAUFHzOEjGEUhWurmVFKLjawYBwDQBTArlhostQnZiDVTZc8VoGWD9IUj2YXeeezo+5noerv9CTjL5v9j5pl05dZdWzStWS49FHMbtlU5i5+/d9WVq1ats9a1rWOrLepa86zFnVqzXhHAKChsU3+/4UuZnEQSAASCoHnlUECJhqIAtFmRYoRtEJgzTG7yZ+arpQ4ST0UeJyOVprAZjqpMSCmZ0eVtDaMfxUtOENYkJTDZ9Q/RkJtuhy5i62WtSkMzetaZ1bWrVmLazXt3pn7Wybz+WnWbWnZnZ21rWatZ6wKCgpMGt0UCjGf/wUFxvuS/NkA//u0ZAIAI9pAS2ssM1B+SMk9ZYOKEATpI4w8z4HinyRxhg6YAENXWg4caAMgUPDf0BUCOUzK0sQYCvkmCZumC3HCSAIAlH6+M4hMlJ6vgSwro2TFWWOPX43zYFTS5N2G0jHuIYwgfhNAJKBVLWxA2Jy8en3EiXX+vuYdGAyKR0dDIxqPKTPR3seRZ1U2qxJcgISjHuCuykxp//oUlgRAAAAKkDOkGgCuTItzIATSWBsi0VjNSf+uqsumKOM/UaZ6r1EQwPGtz1DLaEglgRzJCYBUnFZwrHohBbg+iQQHT5565RV9+nZ7FkfhJXIgyR2E+pZupHqimQViBKJATVNW1X9frETOsBODlZD+FPxUHlhQ2mtjU0////6CDUWAAABcBwQhiPCfQWAl0sceqBlMzXhA0Nq4SPVIv5pTogpFnETBcm6qVEhLEPKRja9H9SJItHMxE2P5dRozVbumVzhU34MSZ4r7IzcepIyRQOFIGEXug9WajxxGf+crUWdMmdZmLMdoz/tpwaEAkMoQ40PcGiBnG/////R3N2gBwkAAuMkOJVYDrodG5hUSD5siY6BcajCULks8Zc/7DVsNOkEUhqEyh3J18WgSUEB2VYmTnKkqA2WCItI5oPYA44vMiOpPH+XPrmhP6N2PtDB1YjDM1LQyb1FOWpF79kCTpVt/z5j6w0oJZl8KIKKNqpto///9//pVCkgAAB4EhioVKhGQwITVL0qahcEuc5ZiVbDC8qGKw/TMO04wIgw0mnzXPwyo//u0ZBaCBDo7SEsPQ3B0B3k9ZeVuD+D/IMwxFoG+oGU1hg35pTNgYCeUD5khLKWJWdQ7FlCU6u4jmqWI4VIn3OaWJMzMzNKX9DBUXdYCw5BjniMNUwk5qFJJOhVo1yCGsumiZoYq/HSvMIWfDoBJjx4aSPVQQjmdv////uoFGbS6SQAASowukEFIHoCzHpMkgHNNZWW19VJMFNJylgUBHQKlOxIE3KWdcv2OsE/ymNpDFJ07JmIhqfjpJHQHrxlkgNT5SsMm4zdfOpmOiHLKZVZzjzsCHTEIiiaLluiNojUsdNWIyDjg9rCjhqxRl8+7azqKAWBvBiLBPx0/woJmA0ZfaWCLNQgEsdjbOGnLha+yljURXKxK+97aMNW5F2TKUxmIQDWUH7gkoQNhkjX0kZ2dISVmxCY9xbG2c1ZFSqD0gVFNTWOp6g2MUB0wum72rYy3LQmBsPjoH6xfvavFw2SgINB42ff/////eqogaokK23nUwAAA26wpAypR6RQMgF9osAYseTuZ+rYzcrC6LxPW19afPFVSOrYJrrjwA0vD8gPQHN6woJ6ZkQuM2UFtk91w4gvyq+0z6+41Q9pu2jhm2xtbIgcQDLIFZBTlZkZQymUk1J5g/BExNiK3Vp7r1HAAAWAqEBnFtISAaxeaaCrGDN6/i2GlqDInj8LickjSTFtP+o4DOL6wKJhOpTZPwfirb0Sr0kyJ6ChyrNNPNKjP9gVyvSIsvRPPwvDirepsmkIlI7StzOkfT3k7s/N3//ukRC+GQ99Ax7MPM2B2RrknYYaID0y3HMw9LYHdFmRJhhrQZ367V87/bfZVrlW919/ooi0NLF/////Ts+q5jDxIAAC5Gwg5e8mmulKxAimGmFBRfNw0uVir/L9uc7EMYrwRMHUlkJMFCUwJnl0exLHs7Qmmkx6gn6NlEUh9udLOutuwJEQkxRj7RaLlyeLxlXFJFtEYaVF65pcQZG++SO7VqhQVtBpgRE7GOKV6q3s/p/t937f1BNAXTdkOMl2CAhBDGwiUk9BK0FBk6QwKhQOaifFKPI9DQIWiTrQhNGoYLo7i5ptwTuVCjFtFrhVKJ0K81qY7EbXLA5Ayi60Z0zjS6qbKzNRVqSK0dpEJjFp/mpMsJiQyLAJAMG6goggKBwDExMkRK/////jPvvtOIJEgGvp6RwQ9Mw4RPChUbgDAnE/IK81MUGJtL9BciXyrh1CF468a6wRmSEbspyuLBr2NRfB5o9GqIlQnSocUpzcdUR6KTdlI2TS2fw1O4oHUa6RZFoiWuAk7C7oiZ6+0lqE88JiGOEIwMRStS3gnmGPq////t/u/IjYSqAAAAowkwAAUBEQHJjl+2sA6CwqIxd1UrlqrMDijJ5GOR4PQXBEpI0VAnpUAbpYXNS0ngqZX//vERBuAA+4zSFVh4AByJskqrDAAGXIXGtm6AAM8smOLN1AAnO9aX56LbZp6zsSsbot4bcyfw49tV974tfOvj6tfV4lmG167mxbOs43q+N0g6nHDxQFwkcF1m4+kQ0Od///9f/QNoWqIjLgJwAABkrcDEByBgiYoXKLKBKIZQ+kSG67EiG5Nya2sOzMC56NwAz0UDUaDhWx2aMlsczdUl9NQ1ZJJeZdPiRRuj1lxy/Gnf3a2tHq5qzNqQNvZmM0zr2pe391M2Ynd+l6/lnu6MzUy6xntq9v/9ej//9AQEmkgAAABqQuDCQzQyNegjYhsOlwwXUGMOGDEgAIBkWAAKhQCCgwYmLmEgJhgOL4OTBvoaqDFwbGLYAwAAYCgY4EBllgElAGBQALAhDgLAwsRBsABY+IME6CtCZF8A0QEKBqwdhKB+odGImLJG8G0BqlEYgsgTwLEMqTA+xjBCciwyZTSWSBGl9ZFS6bHUjpopNBM6dRyKGzF1a0nvZTOp0NS7rdTKTa///6v//+3/1q/1/akz1IpnU////XTUcUkymV///7o7TiVZkhsAAAAaUVgJLMmLjnII0yLOxxDBQAUDDMUM2QQNTejAUgwoDJgExoIMlGx6fMILQRBkBo/ganToGSEABjwXgZaEoAQ0C1AXzAzACgMYCYDEopAxKMgbPAiJYnULFxZQWUAoGhAEEARHPD3BOoYUEzFKEFC2QQgYLKBlzQRsQMSgVy+MgQUVoaitRlBlC8SJFjI0WIWLRTKRcNDdEuqPmJUQWt2SdNaB9G6Ctb0l6l2pVWt////3//t/+r/2Vq0NRxBzX/9R42Ps/8icDKAONoEAAWiguV0BdFFSKhrcX9MIAsSIF9XQTqaG5qNSXkzsuY3mEz0OL2O//u0RBQARAg5Rzdh4ACCRnkX7GAADzTdHS0xDYHEl2QxphnoVYJMjTeLul0qYKjLadSphIeQl+wsCgblUx9OUYFJFj28jqDLNa+JN6m36zw43hbrFf71BpnU3/1SNrVaTe24M9dwMXtveJAyxvbs////3/uNLQkXFkuHTxBAAAClYCA8AFcEvKX6HkPSJYiKDS33pLbIDS4QcZTRkSRzCwyCcSQpbpW9tYtHZK4L/J1UjOpiVSzJkrXo1JJXOP9JoEpqCZo4VT6pssr9/Hf537NNlvm7tmru/+87s1dz7Y3vf6wx1Uz5lUzqdprODwSHg0JAa61X7f////77L9fkgUYAAH5h/knODhINEI0rjL5igFxFU2WK2qbJXQ2KbiSHY9FV8tAxEEkF8MgbOkwHkRlczIz61McH5edcLigT1o4Iy0tLCyTVEEM9kuLUw7MErTT00Cwx8zmGeON4d523mmeMsg5wui4Nu7mfT///WVY8zf2XBkaPmhgCEAA/8LqkXR4yyhSJaNK5JgtapWhs0lRcAgG4tdiC5aFkDgfnZieE5OhHyEgKCkiH8uE1QNQZr6GK5IYoysnVLV0ZgbOzj2+TLYp0JiWfyykqSeYw2qx5KKkjBtI6rWwNpS1EtfG/6NbP/b/65BOtDABgAAFlDymkE5UUMYYzXTPGOIRNdDcSRASaECMqzIBSvdhbbJy3jFRuIoeBALkohMl0uCKZJFZ2auJk5gfLXY5Lyh2I5ui6J1nNbm/MnLB3OOrMfXfT//ukZCsEA9InxstZYHB0hdjpYYOYD+S/GS2w0oGSHCR1gw6YJeYcCoPBEq8GxjyQmSlgKmelaOv9V3//sqt0vLUvcprjg4RkQRgAAK5WbLuKKETQuxVNNlXYjOUSdVVqfDPoiylwlKHQUZedarsOsy8KQWQCGgCSNcIjRviE0qEMPhBBxsfR8EsrGsSON06+JPaL97chgkKYRTEYV4b7p4Vd6JzKXqeJQycuUnSsnMI/3///tx32vYZWWWyoAgAqJO0PBYkM5SDXiUI1DHwYwgFDowMQwEOtKLmFxUeEii/44GjoM6qXjLE1m+dB4CAtJDYlVFpKksHIl8vV9AUS2gFYtMf0EwnKXa5Zpc6wMw1ZSyl9F2qiiuZOxtPKz+sjWVDFqxrf9Xi7GatN3/zi2J44mbfZCR0FxCwVNBAMEQAAFSgFzXaKDFyUZIs2VMNalR/GZOcvxschsw/REIS48GwieePUP5RuAidEVg55cIGg4cAjETrMGH+kRimSZsl/UOuZ5rrO4ZRE6jw2jaRYSLIzuufgqj//////f/Z65IIVAKgAFJSJsbpUJRacRnAdICqhd1JgWbVgQyQxUvfYmCbSHlkr9UBbQKRmaDmOY7kxYal99OuVXjcYU2fQHlhx//ukZB+AA78rR9N5YHBmZaktYYZ0Djy9Ia08x8HAl+Nlhg5grp29C21aWqdq36bn277NWXM5bazXVtsWPLBdr0ExVAPAy0e5AnGf/v1/1f+bIJ1e9Au1CC4uYBomEjS0igCrqAF0tJZsmMoK80ZcsSi0uIzytzC2sKPQmDBCEABZYHROvoWTJ1ADXRHCZ+UkFFHBhJwSc5oUmeTKo//MvuQG0mVh9+mPyGhFIhB2pT0xChetwqYe4k7///////U9PehSAAYyAAAE7I0cJOKg0JpEVBANEMKC0gQNcAAgFhgqxIAzmoyojsdRxlA0p5RLhOKlybVNK1Ub3I8bLnU1J1TlvGZUomot0s6eWvnlEDqJttkSB4Y40Cm5q6Tk7B6A8kNjFjlKTMklvTDsELnf//3+r76FAEggBPgM5QBOC3hYEs5NZ4kzyzqzW+aazNgsKjLpN2ZrGGq2IDgVk7WMhYsPrPJUpiVUIczgtLnhxIpgnushXYd3osM163a1wc+v3+/m4CIaC65ECIKgMhYsyMEKGiwF//////Xi1MRocLPMJACyQ1UlXAACVEADty0skDBAwUAWOheXxdtupdRDJOQHCyBkJh2jV9Ai6I8Th8dKrcKsnDQPBMMdxpUXoInD//ukZB0AA4IuRtNsNDB05ajMYYOIDmy1Fy5hgYHKFSLlhhnookMiZLJFmmmzQkZlFZJbHoKhBdNUJl9dtBgsiKRZ4ZmWD745Pbuq/////7le3hsuJxzzCRUFwUAoAAAPKCwgscuMdxtqkei8UPEYFBWuA0YCSWzcR1mE3WdUjPxLLh0hDgUj2xWT4sMyBGwoUFouFmIaFi9orl9Ya48FgsJAEj81pKUDN508IQ+4Ayn4YNhYaJ3NODECtfZ+6jq6v/9KkKDzxiO4yppMyUaLEjQAAOgHBRQlajYPWLAiU6A9sChiapEBRMu8WZgSHHVUiDcFicB4xXrTEeRYlHw9OtWIC4/UNG6lzK8uUtqbW9xvHehW0ylNVZFu7DWXsi1DiZ7nq1y+2jBIOCvxqULb+Mr////W41zJCHklVDEjxcgh4TElwAA9ELVA0Y0MCrTpColws4Ap2LNaWFnwSICReKIonCMyII0wOkwihYZIzg9OXz8uxSk5WZGI8koJV7A7rz0yOYTglJzoXjn2cDJn9OsRdpwDR9GmnHaQsh+5tUa/+r2f///YfrACGXiRyFHCZEebARAS5IAAnGkTdQzDhsFFHtNdCqEeQzZbZlqR6vmaJygDhgvOAPGYLrZEtYpb//ukZBWAA40sRtMMMzBp5DjJYYZIDjSZFy1hJ8HtN2KlhIrZWmiE6tPAgKQRK2kg9DuSxtdItirbPa+YolpAehiGm1DpZm62Wyz4TMZkJBuI4AcxjquJ7bSbf//276b0uOnVpabG2PAg8IEXsoA1IRyBVHgQxi6JhCUv4GEQ9FAAQ+gcEoNE4IGoSjyVKPLgxeWPFiB4BNoLOWAR4MTAAkeKMRNJOEBmDJyx91sbyiDzIQDASkWnFpvCQdNu1EU4S0I9v///sV4cUkYgUIliYNqILMHxYOQg+QDpGTDDEwxkUrNWQ5I2PS/U61IyvIgiECAltVJUT7P5DbNMpt3JdG5q+xNtZZDeMtbZZesLKUiRpSQwZSaeF3e09VRddhVN0Js+/BcBNGzc2PA3uLJGMmP/0f//8o9wuQlTBOgaKlyILkBICooCDgADwAy8iETVVqddJNJdwEsxlTNi3ocQWEFErqXPTPW47d35ce7C4HmtxWWsxuRe1IeoRMMgOfNkgPgewXHXkbZMnEWWXlU5fy2HUZ2ELXb7pgBVLOrrV53RKf+3///6fT//////9a2oh+ZHOesqzFlnmUIUkQwXPAEKASRhABAMRKB1Wmu96UAdtG4TMOlbJgfZlmCA1GQN//u0ZA8AE3IlResPSTB8ThiZYYJ+TvG/Ey0kU0n1uGIJgJupAiAIiJgiAYZSHAUSQFRmIlcToFY+QlQp9taNzf2JNVkWKTxrWFknxShFEJYNCcQTaRZ6h1I+z63q7tHZdbIbP/ZRRXsDYuJXsFj7iZ6WA4cAJQABkALxkzG2WZVTDdyPxYt+nQnioEDlOc+UKnw8wCyMRyuhkMimSwuRlsdaxFYur1qEFq0tFbCZWF9lIpL65e6wvY7aew90UXv5fYP/uob5lSzbdu97ovT2+/+9f7f/////5JFUjy1dWlnIy1yglYoADkCiTkEsCKgVYEmQAGQA4CowwcECAEYLzLqfhEJHBD5lURR6LfAoK6MafhjMba1K4YdaOFggCRA0H0TBMiSYYGkSZcwgggTKLV0nvbyMaUn0VsJp3bVek/ern3s+iLK6t/t/b//T/1//////7pr9a63pMtio5VGMY4NjA0ciNFnnAJDVxVLVvKprxWECkxGZcj1KwyVJledM3FrEMRtqDXoQ0J+YMZk6sYjlx8XSrROWvhXg7KBKsWo8I9IJHTX8aWzHccsOWud/ukITECQzAo3AbCX7HL5ZnP1uXLfdFKpmf//////rwkwUP2Nzdgsrw8tV0QpPpDapnMKlkbH1FUDyAEcSCgRMZW4ulGlJJjqBUi1WPrGwmHGfyFEQlA2RDrJQlGCSIgKBE8VOlmhk8s22eQlMSLLTSsmIhZduEkT9flP3FVYZt+cev03o5O3//069/Zn/W1m2//ukRC0AA7BvxLNpK/J1rgipbYKMTmnBF0ykT4HsuGJZp4l5291////+7a36SkMyvS+ZhzsqiguInGBQkQVFWgVIAAtSAOYLkARKhQpQ05HJDsiZGngYwn019gjrP1BTrxFqQzGZPPHEolsJjx9GbL4V58jNWFka5nXI3cvZ09jra01fSd+VXuQ7Tr33aPK62T1/7+zL7X///6dNddF/////7em93kSxOzMlDq5iBDGVgxjhCMCTFoCo0igeUrNyoI19WaNtOXjhKpRDzcWS35XGnvAYQ04KlhsujesVJWphQyaeqiqjTZURGESpC+y8VmwZNKkZNrQ00pFQXkKaEMSrZK3povWd6t0rp/a35vp7+zLp0////7fZU63rnckqlVHIWch0yFCqHAA4AOk3LvMwXGumBi17T3MepVdOIbKLG+9SIxmcmKHJwTrB5KM73s6qT6wyJ041csUYcnuwLqydfutyKy03BBjsKBMjHxzBlcOBzKLciE3dWZ3dVVm6/+nT/p3b/+//////t2bd6WmSQhlWYOEwxhKnI11AwaOhyC0ZBVaABkAPDBww2AIkXqni7gUAF3FYAiozt9VVJlt1hGDrLUtbZ/2hIEgaWA2kcQqUOxJgDMtAk9NhVDck//ukZB4AI+BwxEtpFEJzbhiZPSKKT03FDs0kUwG3tyIU9JYp02U5eIkCZ6lZCmi2ndlRnEm6VoRN11ZF/3tRe8yP7f/v+vT////8+6uWiTl5VsNQwMSCQs5jIajjIQMDARwFFQFfgAoAAT8oCCbpFnMVwxxYSsNxvFlBjCwicj1J4RZuPBCuZFApc0WeDYymxAycKYYoXXaWRvgKiVDNUkISVEiuE1JZM6lOryx3X//+/+n6n9P/Sv//////+09VPZb0VmdCKjiHQzsk86i8Ipg4IoIUFBrgQBkAD/1gqSBIlhzFI/CG5kAKCp6D2SQ60N/Vyt+xZ1X8hiYtOaTnASJyzZVkk5DSj2sqCqIhNbCKy/teOqag6SziUM7O7O8lu36Vv08qUe30qi/XZq+i6b70/T//9+xc0z8xuQGzIVzsZJgEeFCHAAIIcKQSYQQMotQ0SJcqg2C7MJoOD84zfJIWPq7J5kyVZBUYhzypKBRPE6WKgeYYAcImWRWYLIlzdKCpMnJj7JxlkY1NNyqiXpClmV6O1n0X/6r96/9fr7dLf/17fvX////LsUyHuzot2UZyDLhhmGiDCB2CIw+EwgYCSAAL4FZJgBbu44aEcrc+Xq/tP3MsyeduDaO7AbgS//ukZBABA7lww7NBN1JtrhiaPYKKTyXHDCyE24GvuGIY8Jupmnd15IbjP3JZnO5SKtlM0+M5crVaWVY3c8rX6y/Xc+at/zHRtxaJEyX8//5f9U+XDJT6qci7Nf5P///v80zCzhJNK/nsuZ1gQvryFom0mTSkOfpEmCFrAjVsQoiAAC1Q0eZPjrVsV8xHKXwTw7RDSZxD/SAxlgwV4kKmh4YZTKq4eElu2azDDe65ywVdEtaSrFy+Jec71vnEdGXZaZvf/+//f07X3//p0/////6t7a602YQjMdNbFZEZQgGx1KWlFIO4dFRmd6yBfgBAUaEQhkEK4b9vWSoTGs0LqJAQA0FYNWtFdv5iAmsKkbWJXoDrTUujMriNuVzdeUXKKpY/DLmN7W3RhRrL8Zg01n/Ll/53Ip1zbMGRihe6mh/5/////yNTZCG2EAHLfFq7FIFwVE258jtpSimIciEuTGGaFUTQAP2qqUZ3j7JOtCeToWuRrpZTw0S9NCAjFA6qnVGcz9QNkCWjk/e1ZO4NTKtserQ4TNEiy+W81WTU0SSt2fz3/+X/P/7l/Mu/8sRfvX///+u1BNJ0ZB/aJdCbbdYyGjGp7Un+P6RQWWueLgBIAC9tN4uiFjowPMAAVIut//u0ZAkAA9lwQ7NFNnJxbhh1PCbqTvnFDywVGcG/uKHY9JZgQ5Dq6qoEJ7cXRf1gLSrzuMFaKwmIua6stkkDyOjnJ2O2q1aVSi7ary3BjOqIjKAowWc6ssjKru9v1v/uv7+/6/t6ns39KXWunt+///t3RbI+yuNO4h/8Jrn5rk7L20R27YWSixzzhqlSAQHAUReggw3idAJZvioNENg8lWPQjGVTVO9BGWJsxFyNJpPKdwy3JOdRL0NT1hz63NEYYLrLxnxNGjrqDrVc/H3zfrx++fhJlX6n7rt610uW5//S////9eyGaIDrvjXCTMXbUZN3kxaWlI4Fk9QJoHpAAIUGlADyBdklaA46lrVnrmIU9LoLNT2UtrudAjFIcYIrqHJTK6ackUko52cqcu3JTvG/Xl13ahTkHvIU4xJhDJHPV2cn27uidEk/TXqn0/s30srN+j16f///2/o6IVKlIVsy8mzNiqzA1XLGNkWKmut0QKAsujWD8DAAWLqPI/lhVKRDjWOghBzo5JkuRx0H2PIuJjFtSymUzZGqVskAON2WNBZyy6y5iok7VEWPNZBchlLc1f/ov/T9f99v+nsVOf8v9dc/5PT///oj6u+yoNKSx+0ySu5ReInVTnEiIgTIw0PopwIIVQDIwAASKhwIBWOqZQKsO/0mhxy5G/WUXmIvQSfGKUNFLa+4lTWvzgWrQUdek1f3+dN+pbhrOkwsfCJ0SV//v3n+1LvpX6nRTLcjgiec1z/K/H//ycyHkx7M//ukRCyJg5BwwzMhTuJwjih2YCbcDlXDCkwE20nJOGGVhJWwI2wh6rKexHwxr+EsSc/2Olsg0SNnFaVRjwEBQIAfFoAolLwQmiig5AJfZehyldrDOq/8PMQgV3pRFHud34jG6aenKlSV0stuS6O42au7nbUro52U8l8/9gdYShFf///+Xvv9c+fy13uy/6/3//38iIYcqEHRvD2d1GNlHFc17aaldllqZ4DzmDTlgPSVOUx5akTHsGgLQYGwpus+79TPGliUzKbFWS0e6lqrenamV+iwx7+6GrWzv1bGGE7jXxTL///Lv8vhlX85PKX0Q4zYWKpM5M3tey8vP//f/9tf53ytl4mDcmto3ninq7KtzSZgVtAuDSnghMm2TOMESeADpUOYG5KQrjq8UAf56mL3YFaG/INmA6zyQMoG1RlQhSMNKtsIsNIWI2hMyZJmnyNSjIzJJub9vtI1qN/1/TX99WWx7svu0/olavf/L//+tLt16x5rMcwxVsUQFzmdhhBWICwrPD4fEQsMAYGBxQLZKhgAAfHTvhBt5MZQXWQRP3pG70658pfVwmpRGbkMNPxMW3/nJr6lNWuZ5auU+OeGe8/KKAgI6lRVu///rtpo//Q0hkLQlH3tq6wdZ0Rq//ukZCaJk/xxwhMiTnBtrhhmPEbcTlnDCsyE2YnMuGEE8Sc5WM2RGVVnmuvp///TlmdyhCjsODOUiwPXbRKjSVqRO5lU0SGWGUSFJphhJAZRtiyIFDEQBPoAD8zxtBlPpmZCFehS6YYKdrl9aBpOwWPMj23xM4y41TyOSgZtsMjt+1amgRo++xHkT//9Puuzap7fRLb0petZDzyyLfeXbr///7fsmpNTuMtTGZGs9KDikL835P0OszyIHGAHg0iwkSDEhSWUJ1lvMvU1a4nEuVCS4s9JnegbJ+p50Wm627N7XL9a3VnqbHHf3u/du3r9Sxs4iNSMsuP9f//lzO6m0j3FRn5nQEhSRiI1BIkWM/G5N+v/////try/d7rZZtsS9nd5ii119OtBkR5EQePQElUtFEIcpc1C2qJEoeQLR/DebjRTbhKrYsllc9esWrv2Wm6Xq8u4Wj0tTWoW49QASYsx3dX//7/6P/Z061ad3s7GS5HPXXWM6nSqNS26qqtR1r63/+7yNREczqD9ww7OCWak16WtBAnfOl4oTVkXbVJj4/FdUHlyUmfFAC0BzjKDyh2GKOVK5Y+9+XzUNWrtmvfpbuNezWq3pVftynm7eGGeNXH/uc6fVrFZm/+363+h//ukZBsJ0/lyQasiTnBsLihBMCnaDqHHBimJOdGXuOEEgKcwOt50shnI7Jdm3kZCJpRjKi1dKIttEuOc7kVHkdze2T/dN1ZVaUgfIDFzsANTQryVKJr0jMsF2k0QpXEQgRqqggIirNQEANs0vnQUH0ECWkWl1MseQ0rLpxHiJdjTj3ZNaVZdp8wVTTnW5zXaVgbrO+X/3/3TuWpr1I+2Tj5tkRW3YxjTwgSoomvwM8x/Lv//1/st/jtZ7zxUStiTozTQRLK55W1NLXk0DWoURhNhoR0heQOFCAQHgw8CfxZJTIQfJBSHJHVmBMEXIwzTdzh82crMfMLutfSa7VJO6p901//7S/00tdyo6WWtJAtrK9Z5FKe6nLQlHl0lRaIy0RXv3/fp7IrKajlUyDgYkCE2YlBEnIbaZRFERdJlAKhJOUkKIikpKNkJYThZDPwjAWDgERFuhqGoMPFVkiKRro1XV+xdGlSjbV9bUaJkTYn///P/l1RZHOZlOR95s5GxAqzQQmb5tRF9X5ff7/9e//L5dP+XC5SSbWzYt0YQ6k9oetplFVrS17AoxglBCysiEgDZHlU8BYMcVnU1dzm6KrUguW3r+OW79jedTvQuQ1mRyd5G/L///PyVeyGerMPW//uUZBWN9AVyQIMhTOB7bjgQLEy+DrnFAEONnsA4AGQAAAgEl9g+tu5QjkJt3Osj+unr99Kpxmp4dNfL1WMc88y/KVVu+e///3v3KlC4dTxbQLHYSawnXxlc2zFDQlRICs0wRJhAQoEZxYQhvApIUh3UioXA2AViDWgSgmj0NZ1sOldURFbVOtutsKnem7uY3Q5qS1syK1f//b/v65JVRZ2O2xHdyEKYllMogRZnSODO91YrhzJGzMRJGZ3Z1VmKys6kpWZytp+9e+mzWtKsPu8/A8kyWXdIRmzEjhTCk9ETQaST0qJsOS2Q1h4I/iQD58ckxZYZBqD5QhCWIoksxys8ips003WqP6P+tl9W+v/v23ZeXfuTHw/KgjYhSrypkaxagEYXGcarCJQzPF9rmt++cNr3yNLlSctnNzdqtnt6Bu+xPXcJyWi6bsHzbCcfT1DUrV2EmyQTEFdwgj1G0jVkgexoIw9Ebjl7/////////////////61MQU1FMy45//sUZAOP8AAAQgAAAAgAAAgwAAABAAABpAAAACAAADSAAAAEOS4zVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",
	"lift1.mp3": "data:audio/mp3;base64,//uQRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAATAAAhNAAaGhoaGi4uLi4uOzs7OztLS0tLS0tZWVlZWWZmZmZmc3Nzc3OEhISEhISRkZGRkZ6enp6er6+vr6+8vLy8vLzJycnJydbW1tbW4uLi4uLt7e3t7e329vb29vz8/Pz8//////8AAABQTEFNRTMuOTlyBLkAAAAAAAAAADUgJAQeTQAB4AAAITQD6wMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vQZAAAAkECUdBiAAgp4BoPBAABD8D3RbWGACEyG+i2hjAEAE5+WNxXcAUDFhY4cD5yUffKO4Pn+GFAhk/Uc/+X8EDnt4IAgD4HeXNQxg+D4Pg+DgIAgCAYB8HwfP2FAQcD4PwffwwD4Pn1ujwiNMPPt1swAwIAEicMF8HBo45qW9/E7ln9PrfW+Jz5/BCuko+8Tv+XrN+81tski/4QEUiqEtsXQYOYRu0udGtzUESPask1Tw+9xKD0n18noRqt7KcuOO9qfWWcprvJqV9e9zduWRQW7vy8f1j1RXJbv94Zrbs/Ot9Mzq9+/vdbPykXTOdedpM98ftWTOOggtgsHrDK3HT7bmF0sS6gxYtjnNtkRQsTJDzvssl0rX5519FI7Z6CBD5TyzNCyL8plTIsGTg20keodr9VLNqZqZlFM5EQ0iZdR/jGeZI/ImIF3vFnf/60qcvapTPJp60oqet5sXUAAD5wjcJhAUhEEj0/4GgUwuHDbN1Ojuw9MszZSaMiB4OA5uwbGnhMZ/JhjANmMwWIAIZ/Npm8GGSQwIQihEyUWZgghMACVogoLMLBRCAGllRsQ6diQhgC3Fl7iK4g2BzByEEjJaUx8FR5L2FkViww0ynWHdpfBgYyl8NGACCgCDMSBQUMgBiYAWQSQL5wVEHBHjAaDDGCQrABYKBQoATguALDQiAHAW/Pv3csY0/VMEm4GgVjbZH/TIjNzrIWtQnDGnhd7tvvwEnqzoUAIDLeJgXtzSl0skkDOkxH/sb/mf7//+blAlKMr+ebLizlPGFRO94stqvEQAAAAABgGACgCA4EA4G+2FBEQIoBVGvJFv3eGjqTZTLucmLMtsTR3GeFgDOOQHHi2rf9/abGt598b+fulGTD6LmTfenebZ2RkagmBzn1nwXatg2i/OMX8T/evv1t9Yv1aqlbMvu0Lia7zNq2n2BrqVSEziFNOnew2iuxbWqQpkgAQFGQAAAAvzBh+NawAOOxjIBAoTptkA4MLh4BC4FBkeArlFokYmyJ1Ou4TDAQpFK6EmFbIwI4/VAzmqdQ3wTBLQZwWkVhFh0HOdJbj+JsaiWJSOAdZ0pw6Ua3G8PlCAbx7BhMCGtkq5OFDP/7sGTxAAe7RdBuc2AAf8c5/8w8ABYM80O9x4AhA7Lot54gBYsZZOZ3OW5+yKrDjJh/qFHzq0yTYI56ui5KV+oZ2yr2LldKRVSzYzCgpJoVUJ8e2f1iFY0qh0xMjIZtpvPNeMF54wNw8bAACrbRABIe5hi2wmm2217F3nVYGYutPtrW21r1az6/s/76/qll+v//m/s1bfTv///+3f//pX+9fu+nvRtN42cjCgABNIMiAAAAXgwtgzSNG0AphEQBIEeHl1AcWVnAAJVw8WQkOVQOCuRu0b5ZE9POKf6kS87A9ckMMdHmgI2Sg0hwEEaGJGx38ChLzhOqZTti6BMAAiGRQdWKkYMIxYFxWHxULSDbIXDA+auSIl8MSyanLomGSAZF1VYyVi9yNBCCB012ztUwIyQWTUKG1+ptEYRYpamRIAAXKkSQQTeAyGmChwwJRGdaH3qFrnU0BcDo0ffAdn7X/Uvu12ExH936ZE4iMTFnRUABkhzQgBfxl7igp0rjCwQirSDqSUEVFTOISSwIwRcLDp3hXpNELKpWV9xfKVvgzP7wiiIecKluVagT6KV75qWkcojEMcniDLCilyeCEsdw/TMPYtqfFtY2TGnhYdIRdKVWLJjtDpHNrwM1sw48vxUezZ6bI6MM5SFZEtfEgtHzWuPu/+8VohRYWPsIU/6E+xekAAxOCISAAJH4B4oLBUmnIZqRjIVdu+/tZrr/9PbyZ182dH2vz7L39fnf8IB93HDFqpmwdW18ETlWvmh5CK4un9oCAAAQawUZlyLGcMHjtmwdnUQHiUmsbiZYzSYIQXbFpMVRpUHXuoCjWxRI8aG2//uQZOOCBK080XtPS9gwoFotJGIBEjDxRey9jeEDIOg8oKJ9ky3Fhqd8STSqrVZeuhUpK0WwiqXmWAANC9SfbcY4xpHdKRDF42eDgGXrOX0IgqAoGLtNx2kK2wArcpg7QhGmCspAEl+WlgKCHuTVg90bEZpGXV8KSZqXsH+m5yYiUotvrOv7OUOE1M0mUat6pa1eHprKO0k7hevOut/miwwWDAqRHyg9DWf//7fXrUAAAGipSFJFn8WJxCtqlo7ARBCSHS6JHFn0rkomHJ3K0pkOxia3qrFnO1UVisqswxd7LhPGoPixGiw4sWA4AUf0eAAKW4VSAKpLqezaMQ6gCj1gUPDAKSiY8mjEY/QsQZcWuA8dmIgqSSSicPaxdSA+XCVeMq2WnND5cuefTGzpwum0ELC5pkwR1YpGmLYmdBXDpf0TV8RRkxwJM1CehiyRbL1fOgsjGTFR7U8v7V0n91s+X9X+X9JdLwSrlY+vQAACdKhq0UWvRYEIHYWCdILsqafNDWG38qiM9blkeLoX/c3kX0X1oUmB2tcsH2vItSXI//ugZNWABcs8SrOawDQ9QaofGCk5EDj5Q6ywz+jVBCh8YKSUUf9NAERFhkNCSEX+AKWCdzBSL2A5sqghYASXEjURVLGXIsSdr7P4YWc/TwySTxlsEblBMiEcm2GImOusISbcbEqMo8CImeNsyauOreG1LuojJB4hFUJQ6OOvPBWOxgcxSzJiIDHUCFo52EwVqM1K0OhZzqZ3FV7f0v9/f7p+WdsfoAAruuNNFT4EAKBIeFTJtQIXMGEkNtUFG70miyX196VfY1+/RXJRojcSepU8HwI9YvJrdoL5JHQAmxxTMipJN38ACplAiYVcm1imY1QE1FAPgDQLsC60e2jzkOLCuTBMy4gcR0qKEatlI5nSG5EUkCOpGoDLBAkRnlkKRCsTBS9cSE4oQpGjZ2GQ7qdOdwwqrj057NfNedhfLq90DQrEIpnBnj1ypcOAQqjnvfLzWiHFfOYjUgACKtaosaak/CIS0EufcnRGPi0MnIewDyrGCZhY7aPQaymrb9XA5VsBLEYirMB1qAUaw4MLJvUanWBUMvQlqBIgLZkAMiiURFSKcvwERQw+M1QB4S0xQMd4Ahm6DwkyI1DF0xQE7iwTd4xE+Va4PFJLcJZlc2+Mk3GFIuHsKE8YCmULvGroCIsVYm+aY2gEx0uUPtalZEA7Peniyw75IpI1Ie8q19QxY/ibbVg2sunG//uQZPGAA/Q80XspHNo3oDodJMABD5jzQ+wk0SkMhOh8kawsC9wjKTFpKsXdazKe1sZ8CvEqH5HbW1r1T6f0ACBJSIsIpG38NZQD9nfNrTEgPtda1Uz0pwxgs/oIc3Rb7vrbLgAmG5AMkw5EqgiCoqmVW9cYs2bIJe1pGOLZ40H2AdoAiK8saISTLvggDMjESbKgRihqUExQoCYAACUAwzyqXKzpDOY4rUI7Em5rOZC1eOSGALCNw+dnGSQJxioYFoy1chzIo47Nd7DbhqVsTqEQGQSKOdkLs2hJwYjV3SbwTOomUkWwVp9BmuRsygSfFuY2QWr/0XZXqLzTkO//Wnf08/YAhEcqRKSlb/gQAMYTheSnOPVOIbfRI2ciX1K39/kv3888q5e9a9nC4uWRSCdcL7NpQswYh/qI9NcEajluFsab8v+te4R/FSKFppdEWJOXfggTO4oJmgoHQFFJQGDQjGBBwRe9nCL8XiExEGZgQAQTiQNZBJLiylGCM0fOHy06NkY9KkOmQbx67D118rFxZaU6PqZ+WYvVeJKJhBFB//uQZPUABD8+UHtPS1pEAcofPMgHECDxQeyk0ykZnOg8kI29cXmGoNdUxbHXizY61seyFTJ/zXyN66vxo8RxZzW5m5GBu4vwnWf5Fh/AAyVLZlRNhTfBqV6z771WNqlyykrXOIecvwCK+vTTODkyZO/P/uXf9ss3v9GcIIdhadKa2qQKLpvN2Wnm2SJHa+/6tZb+cqJHZqplNW3Lr8AAQRpBuoONYICswAGpsUDMoGhmXruU2gO9DDpthX47DLnXlV62ku02jRmoJj6pCQsrPdGbaOCF0WTkDTwsDJCH1PkIM0WA9XQKjHUYx1Ey4WTZGmzpETiVdW+jh3xijN5kpMlu+iVVX8q0V/Us6XCTbucEmPI2TJnE5v+InB0itWH41iREa3YvM5a7DV2vNC0udaWNsmcVT7J6OiX4Vhz88R716nykRzg0ct1xgIFXYvc32bYM0ZNc4tbDP8JuQHCqVRF2aLR1aWW/fBOowTBRXrXIW6DFDRqyCVzWjQymA0mYeFnbbT1mBgHMLrMJEFfDkdoSg2YpTha8xE+rPUCzLLeW//uQZOmAA/w60PssM+pHB4oPPCOPT3jPQeyk0yk8Geg9gIn994pFt0wYWbkNaP1rzV3dqx+QyWV2/Al5aveW5ldY21BChbVWCqhOH2LQ5gyocu8u5vHK0fVzv7LX/v5oBhe3kVnj12/wdJS7ATBFAdjYFUw94XaUvcKshxcLC3HGT/d/L7frNhjBEsTEGdpGVu47XiwqaEEOV5ldsxdM9beW9NkfkOk6N4o4DE2yd9ufd1KvzfuSkjJZiVZFll3/4JCpfHEqfJQ8MSLPRLHGlklfvY27X1PQUIjlkBqokJwXhIW5YtpXoyOmB8luSh+GCTQ73huHSzOkzGDQGW0CBUsRGI/BOMBdBrYfW2LqY8dvZ7W/Bis7kn0orJTWMM1qroZC5Z/je6xs/Kr+PQ+8YCGxM5WeTD3dfUCIUEqfiFlSX6xRYTz/2wJRLtUskS4E1h6jqXJ1ljJpNLJHxY+uBSeXFAuhfP01d88ahwafaPLtdae+hAchGlksqlPtd7sxzjfhq6+ar1LfvJQfez7b2AcPVL7Xg839tv6qBCWIlDNk//ugZN8AA+Y+0HsMHHpXxTn/MwM1UPj3Qew9MOlrmKf9hAm1077aAYcBaiYoukTDOyRLPCTAw3Miwq/adPCJR5oYwHs0Vg1FBuelgsk9khL7UKRgVCN8C9nHzn2rO1jtmV6jZfOlzM7W+cfKJrUKSfb5vAJZ1W31GmSJk1J6jv37vdsyC523+aYt0SQ/hmDrsKdr5j9/gjLspcT20rQ8tl/2AhKIpjyRpBMVyh4M0hFDcoS6OIP1QTzCADArDQWLORV5mJulWYlWVlfq3SfdP1RqX8pNy81kYGaCIw2Z+KpUt7Un6db//E80ndndLwL9QJOX/QGsROQzu7rv9gS4CoTiBiIe9YIKhZ0/It1DCFl50GEEb6N0XMu1bsIyUWRjuzqRdpFbVmGhUoVaKryikjWGiETqKMmIp1Gyc80yz5ykYdbMFWIiQOoY8ykkNswYXFG+do2YoxYO+h50tM95lNNCu7PVFgiMiL/z3zOcBU+ORYo4lklXpf/tBz4gImbTCzGQuJd/tfXN8/lXPn+8LFJqeOq2kwsiMTAYQFL4MRtqdKxEJGMNzPKR9k6NCLpdqVXzcY0JA2RC61BiKvaKEwZrLAi6cHA2wGnmf+nd41EzV5y4lomu/3wKHDkDKRnQVKnaIDKuUoIjBZCgiDj8ReGGbOBJ4JjrKgso3AwQE8V/N8AtYiX+r2fR//uQZPYAA9k5TvssM+pbBnn/YQJdT51LP+wkcyl7nOe9gI505Bs5epjFTQonCE3KK6kn5SN3vDtx30rGmrtCWA3Q0HfM94KylNlFBVyqoew4ALDB80sdzkB11rbm/vtSyYgIo7RMo8y5LvrAjDPCtwEIGkx1yqW3vVfRbtiGETY5gAqTz/2n/Jmt381dHUyh/blEBlrf0OfelDeMqvKaGJQYQBwQrMNRaNhRJh7iLxTgBC3MIV2mrNVYzO0st9sBveDCBFsm4JSkIwODZkgGnHXKBBSwSot7xCSfI5Isq8upXCxhI2SgsMagoAGCRAUFTMI5sS4LXgjQGAQILRFKo94DNmL2HL3XITGkGZzZgq8HnGRjIaZfv/C+ckUh7rs2RYC9TNQWH13/Wrtf+/3uKuqm8iKul+2wOH8hRKFYDEhknWaTdLbu7qVNRSeWFfZakV4eWBUfO7r6xHrRUo+noyJ/2niaIqCWv/8910nNe//2vu2qmsbnqPdnF8V2h35Z2MdK81dEeJrqiJ/+/+wP8E4TIQtOQKLwBiUzAqZ1Eei+//uQZNuAA8U9z/sJHGpTxqnPPQNXDwzfOey8yulZEue9kwndBxKPBZ1MQtZEeeaW2BCCq/B1OFdGZEbAUXLmkzdqSZakNPfZ9TWk2WIuLSe/PwIDRTjKyMoUEAkcNy89gQIKFc3fFJcEpmEF622kpfE5edK0p20swa/PU2O02m1ZzUKa3hZVpq2fW3fag7BWcDhs4OowK2d9ozl4BiyBz2KJJCobBcTL4Xp6EOqoJJFlBdFCQupd5XdcsSBMVAREiFZcXQIkPQiVIjyiCb2GXAYBNXeFZDUkt0YMD0wrTBfIlwDgcqawhKTKNIlHMcGhyQOWg114qVn8JpqZ3pVLNNYpysRWSARIDyCZmFQcPR5KcsF7CkQcCTtp2bLiOXledGw5SaHrUpPzLaGqTx+b5K6BW5k3unQCTT4sk0Ves4PGNCb8Ym4W1//+irt/6CEkRXZqTvuNEgQuC5HgsAoogk3usnonHkMTsAgGwLEFZf+GrFIlEcvnlK+gHHxHTj8FQUWdLToTBkDAtBcgEHIBQZCBs04Yhz5Mc5h13QxbXAGR//ugZMyAA+JUz3sJHFhMwVnfYSYTD6DpKezgw8GXjaV9gyR0MOFQkweo+smJlOPeq1a/5P//3CR2isqqf//+2B/DWM4jYGAwm8qYZE4mwjdDRa9OlNOOui0mYatGpmlbCcyd84rtF3EtEW7mHKLOc/C6+JLsaZvfg5t7FqM1ldTmx4MEE+70O2zbEAOOIC5jH0BYK3XhF7udIHmV6zppdZlaKM8+hgXJ1nr7pBb2lWZTWpubjXfa2BgYGQpCxPWKYWSjWOLPMtN+Yg5lZI8JknupREw+5JsTnBEJlVvAjnNDuPg0AxhYXO7S0QLVJIHsYPawqOBSOeRUaaxfHAbPLzUPEt+saBIBLMJeW4LIgBwXUYMlo1+kwmuDRnfaqsIi03gdB4GxcXBcYMacVXJMXQQ0URbNVBaCCKq04sLDkGT6s5IEMix7aeIQIGSndHhyyFNbyzFmx8bdu9UIlCQMGTwRSXBGNAwTHkLy4148ISq7daTFKv//rc0V3eIuJd97ECWIs0GJYtSi0toJeayAQGKFnj4wxexCBVDVucJSgqQHMLC8QG0CwEBk80aFohaxJ40nPWqfzThj3r/qAJt/80kttiBBIf8gCCR1Jo2vEIokIZJRVGAxDDUd4CRtH4oihOpHlsXp3bW4IhVQ0MV6FMKBhqTxdhxKgTng+KH4ZxQSTQJyRKDNlM8o//uQZOmAA8BGzfsMHFhN4am/YCkjD1zHMewkz2ERBqa9hAgUOpWYdCwhwhOYIrNs7TTW2cxzwVeMEp0a4GTrg2pr1EQ6MURmlfGfX///6vNKT23ogFKw8O/218YAd4GiqYWvi5yvaChjcLm4hS6DNCvE4eRKy2W+xK6nTyO+XN/4eGq0DwZPniUTCJWOmJ9bjemnY+TBTRpmHd/ttWiCo4RwC8yBBCtfgoYfmIyl+UT0KQgTWYaUetRoQyWswI+uduxGrsSuON4e3mIVfpzl+A9cX1YWQu1dWPQlNgsr7zfnSsFH2xMldEiprrY462MvtUHU+G3ebrZiqEwXYHhDDUONDxFQoKpS2uKdqP//+oBISVndp/1tZIGSFrHqQ2xHdakaY2NAx20hzwbDQZPsYBQ8CShYslLxgYTCkiDzwwFg8/GBQIozheIRQQdH+xTncV36P/+YTUM3epqajfXaNAAyGQAQpbFPoIOIWBoS9CTACc0hCiHHYi7HH7aO+sXeazJnigO5bj+coJuiWAaIkSAMw8ojKcIgiY1A0E5F2kfJ//uQZOWAA+sySesvMzBB5imfPCNND0DbLewwz6EdiGW8kZg81GwmaTELpJHVkUskbsU9onFxRqCk6cC7AUc7xSLqq+oMD3qFmy4rDgwGlq77uTcYkCrEPM+76sBAqGdm16+mzS2zv4PAgPQfc3iIx/z+EXyxiMWqSITCEVMFxgnBIFFoap7BZUF1+7b/////f1fpNEZpiqmPv9WgSqkvaDFBGi7oJIysHYAgEfF/FoVaXXcKnia2WpshbtZEoWNv86WkrSgNKiYmhEkAGUDOeiUXhQkMtF7oujhB2VSKclJThUs5me7LbLyNre9L6wGPBZTwiyoIDqVneI97P/+7V/l+gzNEZ4iJ+u2gADAqjLHf2faaSSmiOA84x0/yW+2+f72MXX/dLB42vRJlZANrwNnwO0u879OUFjJIiHh77oyAGgAmU2QxsBUhhChwDrjodguIsApMvM0JeNuLAFBcHTISF0SJoA5IhWFBJiOczZEgJwwjLG14MSXmdpEodculNhE9ovG1UGlqhQcepCXcZPPJKDQ5a2ApemrdPpG8x/RR//uQZOOAA8k7y/sGHVg/46l/FMNJDfDDLeww0GDWB2X8MI3F09Cu7tm20HDfvo/RQwJJjf+/3yEEUFDJn58sdTRBQRvT8grvCjR2VFXpeXOxhLmDehg5qQxCEoAswwUATPUxOr///tin/7Hpo3u/r21zqgmaqjvMRDfXSIAFiAggJJL8GIzC06g4ICY3Rsa5C36XT2cDQRCYRgeuGR4zCe1qtabUhKaCEfqUkCKry5cPQY9BDls42FxZOOBhQbQ0Z6X9XDVXYi1VXI84ZD1OPBQcE6df5f9f9P7/0XVRaz/u7niimjPDrH/9oABmBjam5gPQR0+1pBkBMaNhoRPMHgsVCrlgYLjAvIkLmGF3hRAwDPMnv////////t//WjOWZ5eYffaQkAlYXFE2LoTXOghgo9kdAu8n0YyUYdDGj3hY0AeKNT5YRM0UCFgBBcAZAYiWchZpMkSIQaIdI/CCWdhMReS6R/3vjTj63xXrukYBcyLEgG9xU56qky9vv1f///97inr9l/TcIzM3f/9v/GAAWB8Rpa4qOCjgqYck6gBJ//uAZPMAA7IvyXspG+hC5AlNDANBDdDLJ+wwbWDsCGV8EIx8QPCwIhwCEA4eQ0YKqE53kjr2SXb////////v+yr9BlEy9TMx//YACQANcx4q2jKc2jOTQMESWDSagUSEhJWIpCVsphhs8DxtbLyXHpSBkETKCO1AgMnRQ4XRKjDWOcdUmo5UUC+kkkpyW7FoCYJwowUBU2nOlP//p////o4vU7ctnqAlZwcHhx/7EAKh8JqEARN8NKA4OnBXoDs8BjwBOmnARw0JAqcHios0NLQSGVTIAdpZov/////////fi9VVeYiIaY//oAAFSC7R8LJxEMeCoYBhBTDwM0ri3KZIxX8S2MbTJJZlUmeegaKveeXpp2DZbb9a2tpSLgqFRVpRbxGXCTgf/////////+mI5/6+r0qUDcD/D4ABgxiwzpESeUklcj+YQZwpv//////6loF+ns//193+7Q7QztMRDs7bfBMg8rBWQ6j/+4Bk5gADYCrJ+w8ySDVgCU0AAAEMhI0p7CTSoO6DpTwwCQRgGluMGHBClGkixvCFQGxfl0YOWiTn2EvRjtQmlJKgYGQSWfOuPuez//////////p4tX36teoWR1d3AHgAPw4AKAxQeASvjLP+lFaOWnf//////////7P6lWV4l4eGjf4AABwjQkBPYauXquc13prskblY3n0BC8pdAQYSw5R44DLBE8WZZJZFH//////////+mnfy/u1FWlnAABwngAAADAEHIzPPfLs0tZb//////////////T/6/V/f/dof3x9mpjI1tKF5wOnTTShleP8WAiexqWQDgAAAPYH4CLv4LFUf/////6OltL/wBU3o///////1KmhwcAAAAAAADiYKiTyx3///////////iVocHAAcAAAHAAmCok8sd8s//////5JMQU1FMy45OS4zqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7YGTpgRKdG8p7DzHYKEA5TQRAAQikYSfsPGbghQElfCEABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7UGTogyHyD8p7CRI4IiBJXxngAQN4L0XMMQSgfADlOASABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE8I/wwgLKeCYICBXAWV8EwQEAAAH+AAAAIAAAP8AAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==",
	"lift2.mp3": "data:audio/mp3;base64,//uQZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAASAAAfrAAbGxsbGzAwMDAwMD4+Pj4+TExMTExMXV1dXV1ra2tra2t8fHx8fIqKioqKipiYmJiYpqampqamtLS0tLS0wsLCwsLQ0NDQ0NDe3t7e3urq6urq6vT09PT0+/v7+/v7//////8AAABQTEFNRTMuOTlyBLkAAAAAAAAAADUgJALfTQAB4AAAH6z0ZrrUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vQZAAAAjoAUe0EAAgu4Am/oIABGcz9Pfm9AAG7G+p/HvRAAIBdc1v213AIAgNB8HAQOROCAIBiJAQdg+/KHOFwfB/1BgHwfB8H8QAgGH8oCAIAg7/EAPg/gQEHYPg+D4PmhACAIAgD4PvQ0REWYdt9bGAAfB94gBMHw/EAPh+CAJh+IHFAxgmficHwgCAIBj/UCYPg/+XB95kCIFYkseSjqXz9PztgDABpYWACVYcSjjrNI4ZnMIEk1TIAwxUZPBSQSEAaRMECTbz0yE6MYjD0H42ogW2IiKRAYo0wE2CcihuEEGwcVHR5zVZOBNSLWAiTJJSmymgv1H9BQaPmEKGeEOJZfpo7wRd+VJqHsIMybNCXQyGRQkIbTKSWpBKXNbSDW3ZpL13goAYAAEAC9bW4YtQ9O3pPKWsTGFI+7vzzV32VIpYooBhDS5RnvWf45dYJLJujlmFTDAFDIZ9l8ARSvNxf/7imsAUECaN2OKJGP12R6vYAIBKMWZh9jej0fwHDQngA2fp/1jlKF02QtbFwcRvRRhrrV+24fwu/w/+s3fFSq2k7Lag29Ke+1bPaUnjhfePjHve9Pi1NvIkDE/nZ9wNb3/vzRqf6p6Wn2oTGQ9J3f//6VQAAAQagNBMhISAgClZOAADALCO3Ksx/RzYwFMor4BCwxIVDDALM1AQHDoxUR06jGYuBItMIjISEhEZgMMzvAQLlya6NyJgAscpgYAhAnajSqnSJkIJwahH9ZLHhQjNk7qdYZnz6sNZwX2Xmp3EWkwl+4I7Ket89LMYk8653cjbZHDikPw1YZw70dgTkDNKgmIckVeMPhB0w7cOx9tYEppYweJyzFVdkEca9A87Bd2VT1FbmZbvGrtgdN8ipP3/LY8C0gAAABbgpCwkoOmQRn/gAAL5ejYWgDV212c9IdqLRctMSpURldzOtEnZWsrZV3VNHR2nZkVms96z6VXtft67ZD1umtvxJ3ATOzAAL0YAAAAnBluImQCqZiBZksJmTC+YHGQsWhIOBweZkFgVERoEp2KLNmpmHq1CyVpBIJRxViibGyQhiQO87VIej1VoeklY4P1AYibU5ci5aqoVCrW5LH+2oYqICaNrSpf/7sGS1gAYRP9L+cwAASKeq38eIAlPI+0W9x4Ag+gJoa7AABFrXpXDiIUeUbauXTjFwrnrZFgTZbXFWuocVuamKDNHj3VKUk3Nmk25c53n//4+oj16MvZ8s9EqOFHKmRR4nAAuQAAAPgUk2R7ncYdAMmn7InSPD5mtI+kpEyG0qF4owSBmosqYDbDttsKYXbUb7LNZd//KJQqbMtHCp6cFVAADqAAAAAnBxWCDlQDZjaWDvCyRwacaUDQwQzgwIOHkJDX0UliurED3Mk9C7EnVr5CVKwwEOenmJOhBzK9tVhBjRE3OF8RhLGUPdGkJZnDB2D/LwPknw9RTqxLJ5YHpc4aqIcTVQDCL0uGVeaoLj0aqWOfbhTakWqOKWZHrCctdtysSBuqOPWbx6atTV///akj6JgNt2+svNgFQfEKgwx5kACQQAAB+BjPXElaCXLJePsHNuUzX5pJrZknMNHT2plstOUz2ee3T+03+6k//+Kyh0Dg61VWbPva1Kb3kXsAJawABXVNg/gyew2B8z9Y3J05w8CGziAXsZlqqDKEjxAJYedZA4imAmAxNVyBCXFy665BO3QlBYuKVhViAIXyqoQwaGA5H5MMVS4ycJA5jsjL5EbSnExDsdFdQUREGTqdmI+Po7n39hkbY1plZpVerLTz3Hh80wjjjb+9JtMzM1ajgxKth+EuWe+35/1rtnn3xfo7IAAGNyAEAC8DlH8JKXAeSmDI6iHiMVNi7y0OMcWbjq3l2WHL6tTuvz921T/48AmVf6VOiithE9KIUABO2qEAAr8CEHNDIxxpNjize1AVDwchgIkBYWImUrsAksUYan//uQZOiCBQg+0Ot6eGhAh8oqPCVPEjD7Ra1hhSjiAmi096QMswx5oMdh1p965Jaghvsc5PHIo3WBZ2mlTAIkYnWksh5ZyrVpwCxOTWpt1hNmtRm5gVLylW43aLDhVShOtvQ7Jj0nWJRIpZJApmuY97v9e2vefOtmI2Zd0Mz3jLGPtv72frQAACTWBRJXwbkIMISQWGAsM8bAJZs7+YUAjk89Amf2Sp2/T/ZPffZ9f/pOWpn+n9lMgYifue5ikJ2PxRNZADVkkAJSn4SgGUsyWWN5PgE5AACKgB6QscvEGCeALja270CRVkcEMnl8UbhF4vJ4tFRAPbyElWTTwoTWVBhgwJllUV2hJUlUPURblR1E0LLHBUHlUWePhGmlWIfIuy9IKbqXLAieaJZY6BDFlqe3v/70vNik6BUoSg9ujtKg9FygSOEpwQAIR+DWcgMEK1As8N1qsXOP5d4vX7T7hdl9cXi9Mz/fLy4j5e+EDbf833mkcv/kDYh2AQwVRFhRbl9LXVKWkyoAAwxyJElv8KHGKjecSNZhUzHTEBGQeKsY//uQZNEAhDc/0Wt4Sfo8x8otPCJPEGD9Ra3hJaEHH2g88I58aKZ0CSEJaSMPN8xEuSj4mC1xoVBNsBbtME7WEjyyFgXIzTGIrTmRgCMKsOXp0DhV3xqd03S09KwYXpYeYmhyMokA+oS4nN6st2OVKEmoQcrPNpjd9//+15xrWa5e2xt/17bPS53vhBF+W+IAAACAlCooh74YqHB0l4gZCw9FmMYP+VLfLLBABg+Slqrb/9tF9Hon/1//Mp2s7UdbqsBCAwNSjQqRDMYyqlQ4wpRg5NEiAo5Cyr12xU9aqIgASR6U1NJNy/gw70M8hV6e5aFyLQTDFwYC6RA0YEQ0aV4gwLDrTV9QYuSJWBysFjsc2hXwMFdX+LqnUZ5x8gphrSAAzfaziihiG3sqnCJA0ScLzML8KYiJPIUrHL8TlvM9MBWfojxMnND6+f/4dk6d33frK6/30k/XrEnasKfNTUAABtKIzRyWz8CYgkIGQS1UhQIdAI4T3+un2CIQe2pRO/PlulZRAXYwOOHrmnjaJATp/B8LAzHXB1LkKe9bRVq7//ugZMsABCE+0OuZSPpQp8oPYSIfEBUPQ+0w0OkPB+i8wQxE0MqPVQC9vE0So5fgYmYzcNzkbJWyKChATEnjAqwOXQkoVjxL6NkqK/a5Eq1KdNhkVefggHG5mnl+TIMdCRshFNqyJaYUmFRKMhpCiiHkaEuyio5jMmJlPEkzqCTUcJSWZFPi85Y5J4sFzEJXjV//mWzNzx73jViVjAE178f54waLgE60STH9WPQOj4M0Bqs8z2Uj3RnyF9ta1npZrbuR5fVTsiSqtil7krf644RyCwo4a6DGQWERsUA4OOEo0Ue87HAB7XZy5qLgp/d9gJm2plSSs34EQxzRJ8AY4LNl+DEGVYYAr4KXJ+Ogpgr5mLSUftPi8dWIuW19yGZRNCpHIFSaQ8sqNEhDXPI5thcvbbRBEqqwnCDC5mEZjjb2J6aZTuPGHOLeBdTWC0ODFTUSoBhGAdgC9T5vPufp24RAbZMux/P93zK3v0ABWMlspz/4JwPvul5+/2muztctWRYC+rJ/luW89xAtgEyVKZH5jjA3NSFUMoUMlbBEQojAhyDinSjINWVvjCv1TZ4vZdbev/faLf/4jK0AEoqTNUaTu/9X+bsoFAJpEKSBEMjRwEKLgAUYSGXIgsoehikMQsLKUYjUciSWSxaanzq1haP8J6nYijjKw7kIjHCdZFrKIkGpIOjqsDy5//uQZPEAA+k+0GspNFhLRunqMCJvD3zTQ6ykc2k6HGg0wI39ZZNjeubBEHAjDycseCSR5bIZiijbKPpNC4IqJA0JCKVkDZtRJ7khYBnFh8QSrJEsIxlyAoKAD+3d1gAFEVJrVamv/FBAdR2QiwvONhcE8swJAeF43sTYf7MCIfUtjTCEe7QifPjFPBQW6dx1ZoLrWFReNxeWnFxSO1qaosqUoDJUoBAATh3ZlVp6//AqvmRSKwgMQWcacDpmQGKYupJJXCyWYt6zqAaRoGA5n+rEShM0LV2tVob1NHX31sPaOUPc51Ml40jXPHqK82PXZmvFdCVpLnzO8Z1lRL9XI/x8SZoEoPSjNvDREknFatniTL9hOMc6Wwg7Ph1Wvpt1l2DP3gs9/7e6tgGADhAIiADksBCwKqGEDU2h0gR1ncA1LPa94z7e5tXy+4EEj9NMOL+fMjLe4aYbHEiVyy9fcxl9kQ4zR660ivrVp6HhiolDShKlUWki7EhoyDIItDAw6dJChiwitwSaeS/////+9RAAiIIjOFWfagWgPVAARG9U//ugZOYABEc00PssM3hI4fovMChzEJDlQey9LemRGSV1gw14d0gGsAWCrHdBhi0C3AQUuRnPy7o9KNdnJDCWLLnu+KpkMBjs+f367dYFxGiBtJTIQns0wDkQqIEGk8XKLYzDNmxWZVVnOWL3NtudoqqZq4/014f5KVNr+K4gv1+yEHGoNz3usA5Xz7wuz+s82gAAHlgQWBknuoMw9HsG4NyeH6NMS/XsLkgYZSrnp8EH9+/8SVXiHCJBdjnY/23bnn/9NRaiTIJuvrcbs7/v/pLpdOC/X+S3s1U73fH1hFPN6VABOJZiM0pN9sEej4YgYAMW2CwYwwEWGISC9CBosJLdLGa00IOIuzKd5cT6VLu6HKhb+YJuheq2M3uMHTyOozRRhRE2F0NZdsEZ9Aq8D9LC3q1b9WLT2BjmZWFAi5NpF6QtRJPLtRT8dPTfZR1/aH1tjtyrz7ult8vcbCpX+QJePewR6Dd4nlWHDiFIAAU6oJEETfbRACRvAVtE3MBwKHkZQExwdvNSz+sRhcPee+9lrGCY+cHRcqIQqlNtAjHtaYkis+hlhJpmooqblVupeNUAU3l3VDaVvtjMbRMhXBrUGhTNDh60JamIjpBnTLhGBSKToUVZMXmZbHGILHs3X5ZGzRBGrCgGADAoFG10K8BUOl+wsTNuklvVDwEIz4gJCkdT2TLMPKHL//uQZPuAA/I5T3svStpRRWnfMCNTUWUHPe08zekPg2d89JgcGp55eB4GJMnrmxGKTdJQ8iOMeyHSJe3/OedPefZNysNhx6XgfaH0vglUz/+xqbQAwfHN5NJyfVgdhIklAaXBZsiYLKnHGNJ82q9hXfrTIo/eZruyUITKFJZ3Pz6z/fKXIuRk9q7LLkX4ZWnxWIIQiqpZyGvXsT6AAgmGZEWqX/WAyE8S0GRGDzIzUQ5wABMndDiwyBRFS/L+HkqjOHSaKgLcdSYlhp1cuFX0huEGEaNx8/l+932FGoZbSFVS1fKL0wvUrXUV2Xd6/5i/uXQtfnvQ2XNWbfgn485q/UmaXv8NOq7WPMbUHAscHHRVh8HibwtkJD72tSlIAAKtqaLGl/ZAQZVqFoU6FnDvVrUHoGuYJjbGZiJxvaCeRAShBf/OX/vJYRKOpVpuDKLhWIJEp+7HxG0GxOx1aWR6jN8oGmhKQEFbNSoAEIZUNWre31gEMxqhA7CyDgREMHNNshQIhQFEXUYB0DBbzK+F0xmcjT8VUBJz5hGUTkcYtpcl//uQZOqABDZGzntJHOhIxunPPCObECThOe09i2EyFub88I28HhoqMTgZIWbFiTV4u14iJhKWJ61JHGZRue/p7KotIXZ2kJSTGRV9OpEWW2503u82x7+fd2Vvtn0mnjqcNuTHpHK+YX/t/2+I+bYACObIqy5f/rYFSUT9ZMdLjDkkBu2X+5uinDVTjL5x9dvh8zyVxVTrrJT3z7B+tMmINE5U2AwKOLhhhgvCB+UCzAi/uJrclZEUMqHNBUey5QV/07LFmmDVgQHUw8Mvm/JVztkCIjFNMoFSwFXCwYCbHvQYKtJXiV6myYsbaTQ1nSZLR0d05H//jGQ8DkV2ylMKRUtlYWDRTEud2mOSPkmy9fy/rvPS0Mx+xburcRouE06QsFMpJsvWVeZeeXvG1uXgPhvck1fJr//FQAAV5UzNq/asBFDhiqRCmdx1izE3pdQML1Nu7qX0t+vrc5GPogaHxU4g5EO5nVKtP0TzFpImU5amfzZi+5amGCJUaG1bcE6qAjOUZ2Vo9/qwDU0GmzJZNJE0E0TwOMlMEOBQNFVX6hyc//uQZNoBBAc9zfsvSmpYRUnPJeMjDkTnOeyw0WkdG+Z88o280bYA60glL+Oi/6/qkvdMDat1twLSxG/atJTQWtRN7KFj9bJl5s0RHHjBf6mi7WGWtW8vLrraZft7SbJZENmgkxCnsiRPmnMnr8JvtzjQ5Z6uxFqqmqAAJa3GVXpP7AhesgkbMLZ4FiEABQgXSSG+Yr4zmIzTJy39AyzlDU19Ff/27toiomrEKFHknIaxoKDACYeNWPZtn3FHomaP///ronnVgRHMRKs+t/9gAFobAa5RhBggUyhBrtiYQwXpAqF5TtW11litZihWCBEwECghog/bfujHIQfaXlxg4RnjdXnmVjjPTtTtcPjb6Ee5WtJjuNyFztISTevhyrhE6zWvZp4luj0EdxD0R0e33/fYZf/5TgAALNMwq3X8FWyVpZGxTckNwWg2lNCPvsMq5HqN3nZJFVz+aEZz89YXUs6hZIdeGyLDPnM9Cyf+9Mj1pExjPDT2SJFzSNUAI5mXRluv2jAR/OBg1TlDhJASPByrdQoYAAGfsHZkMBPUYg8z//uQZM8AE7Q7TPssNNhMpWmvLeJFDgjJNeywz6kTHea8kI4M0P1p1GRrxwRWMXbXrKhGI8ZUuLdAgR9q1UMixHhuV95Y04GlCgyzQJ9Ro+40AxbOxkIig3c1mKIIwQCYqosmDKJGXNNGoFFJKGTFb0qs////6gACWXeHa//6tAgC4ZTbg/zuTCad26YhBV1ucnv4d5es+ErfLGyZ+1CgjoqXpH0vYoBn2Rh8WMBKEXBY4QB8MKQWmkkT0U3XSW3zv///7RITmZlnbW/6IAL6gIURzCFAMGbAFBZCQk5siQJoGsGbssdqDMQtLgvMfVnByetXQ9Ko7DlBdxZEmPGnrDwDMBrBs9NZfQjQUjRoSJI7BFScmkdwzUj46JVaeXX3WfskOfe2t5f92qWpQGSJ3XtGyLbM8ACDRDxDV/2sAApoOlTNy6mikWJ6Tl9LCMIU9k6l2UzC17coCIk2zUzDPMSyvUfi2Ah4BpCqFC4CWAlgF62kDk+OIM//////1gcXaYpnj2f6MELtRwoY6gLMAoBVKBggACpqwsSCJC2S+rSz//uQZNEAA7gwTHsvG3hOBImfJQN7DjTjL+ywz2EhEKW8kKJUIllJoohKpJJiXBLH+JUuRJTY/U2zOdWtbShaPTKe29d4oCLsMfOP+9dw5FGTzmNo/fjVh4AOPQDpsi4mOYNPgYaPUjKlPGEv///u/RUUgbGbMi+2xkACJYUFNGUinhqmvYQ2m2PEohh1br5je9KgSwfXQdbGpy3oTaq2XBtIVCVYfEkPDyguHkzpay0gp7s/c8Cf/0Wu9/a3/23KtsR/R20HAIWiHhmfX+1AAw0kRuzMAk4iYM1IChEu0MSwFL6ppPa10VAtrwAICaVhGVsF4+LR4ljbdq9C06uQsb6kA9BYVvMarIS1IgBujYWRspeWMo6HcZNnXBBHFz46lATtBcJlZ9+5F5P/q/9Kf/9n///ScSyu8Q8/3/QACMQgMawtAKOLNX42fEnGBlnXC9KO2z1YzqiT9/Yd3U903D0UIxwGw+f9s90FbOxd8L//tQE5h5lnfS+xAAKCBaTEmUj51aQFwAsRPMZ1a0+0rGmIclvwp5An8RBQYC8yTLRz//uQZNAAA4ErzHtMM2hVI1k/ZMkvDdS3K+0wbeDyDqY9gYi9cPGj3G/epXUizHJHoWfBnWhrZ4OgDPLySZbD0j5MIR2XQhVKoLFhMDgnQJ6zziJbPt/s/////ZtYtMz139v1nkQAL7gKxnZRhC+RBIwuiVRU36VyLes/LfIe50z1+fRIJm1MpWOwmnkwIDWPi6A8mOGG5ZDamdX/////7kus//40AR4Z4l10vjIILlACImRsYlsIeC0FtlbTEAvLCW/zlDL4ZfJkTAXAkA08lHDBNPzmHoIbILbGUH3UK7lyWM4oe8WIoqTQd7Ecg1JcqRo8GJjhxGgVMhHRaYFzNJz6P5jojv//fqIvXO//tF7QZkZXB4jffMADkNB43icyMHmKaV/C35uzrmf0rasFpOAd1SRG0Ijo8OA40kaE4PXdLrP//////////+2tAEl5mXiN/5AAEPzYwiBGwYNWMxrCBGdggG14HHLWuWjEDhKBbixOqilGmBM3TKDE2J5uRvGmVTzC0pigLloGe2YqKzHx6VWzNUkwsg0pNAo0SLYM//uQZNYAA0kqSvsMQ9hGpNlNYWMRDXihJ+wkcWDxCmV9gQysLf9H//////2vFVf7e3iyuroCw7BfvIAgjoYxjW3YCzmIlffZwpiAVRzhqCwTFlmgVrcKH1IDjHk03a1w+RJ3f///9Fdv///V//6QV5mXiHjX+MAAcCRPGzAIBqKhPSyAvRRMDiKiZai+46XsAxxmjowDJO8UxCwNI5uQbuPUPJ0nFZi02BVMlQveGyhozbcFC97mpBMCuJAhHviRpjWz////////Yln+yn4rHk8O7Kzw/u4OjUWEsnOQUFmGMSpIZQZlm38yoqtZhSioqM///////////+3//SoTeHmId4/+kAAUAIeAl5XEJUXZCFgwodRliYSVjJYDbxw4swKQyJLZWxQQEr0LIAiutG7YQkMEN2elARkTJQuzIgFLprJZniNhobd8wWsLKDcHAfUSGnPs6f//////vbf/02PsACRmZ4eP+AAALA2Usp28CUjvDtiExhZDDA6hriyiL///////////////FKaBSIV4d3jb2IAAqMGPA3QKmZnh//uAZOiAExUhSnsMSzg74TlPYSITDCyFJ+xlJyC2AqV8wQyEsnrXWFCPw15mb+suX0AYlESyR881jpkAWoXkCo7tbWNoavW0TNm4Kw2mgqp7TLRY/cFjqp7t7P/////+v9KLyTGfcqb16ArWPwB9wAwAWBhRAcY2oHUfqAigrzIsLib///8zI0M///////+z6/jlVSZodnZla70AABMIx4OEwxpDAmMDhhVRtCtZpu4468Pymhjilfe3cs8RxPnDWnDNTRxO0sTPgWDorZ2Vpr7N/////+//1/9P/////////9eqa/ukbYm1WdbNBkUPChYTRlCXCAHwAAQYKIe4SZgGm0t/uYnt///////9X////NXGv/sZjliYiXdwf/gAAEEPRzHknGAR4EgKdOhYsoUAYabrZmSolxsFQ2JXho0xGRBX///////////ZV3v/69UzgB4AHgGRhErt+9bf/eDgAAAAAEEQKMZRMWH/+3Bk9gADICbJ+wkz2CyCGU8YIxsLEHEl7CTM4KeBJTRhAAQIw/EToaqQAAAAAAABwAAVAyAt//////93o8AAAlAHH///////////+j7HzVVMQU1FMy45OS4zVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tQZPcAMvBoyPsGE9gmADlPCCABBzwlKew9JGAwAaf4MIwEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7IGToB+CkBNFzGEgIFEBJjyRAAQB4AU3AAAAoOoBjTAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=",
	"lift3.mp3": "data:audio/mp3;base64,//uQZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAARAAAdiQAdHR0dHTQ0NDQ0NENDQ0NDQ1JSUlJSUmFhYWFhYXBwcHBwcIKCgoKCgpGRkZGRkaCgoKCgs7Ozs7OzwsLCwsLC0dHR0dHR3t7e3t7e6enp6enp8vLy8vLy+vr6+vr6//////8AAABQTEFNRTMuOTlyBLkAAAAAAAAAADUgJAMITQAB4AAAHYnX9w/dAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vQZAAAAmAA0W0EAAojwAltoAABFrjHPfnMkgGqlyh/HvJAbck1d12+2/A/AADAPX/wwAU+OAO/8w8//+AACP/+h4AI8AAw8PH///6Mf/7ADMAADDw8fOAAAAAAYeHh4eAAAAAIw8Pf4AAAAAqHjwNtJXa3o5wBlDihACEoD+CAJh/WCDvrB85ygIBjid/iA5/wfAAJAR1AAhaQkl+0ToEIAADhIYhB5mEpiQaMWPQ6RUDDwWQBCoeFjOcQNhmERhUCmGwWAgMYEGBKXDMQmDB2ul/ICMUVH8Hk3VTExSmjSRE+QLhA7IsYo9c40OJObLgMQ4EDsOi2qeAXFYm+EC0yWhiJCwANBV3DsSYBAzgt0b1ba16J/FV6cFCJ0UTzwB9uth3uOqS5l9ytBydcba+zR9+ib3Xw5TRo/V/T/8If9osQqEf/ijayAAIAUwIHlpNPRvbKAAAIEfAZmcd4GfOMsg60I1TZY4semPFeUjrWBKKdTRL4RIy1Sz3vreHO9EQ4nQYsaMnVirP7/9xYlbARKueJFNxT4XHzfecP3T6XwnCfVLXh8LBACf/////8k8xFBioAAAUyYFl2hQLQyuqf0DAAylsjOK/MFhMWk5vm5GAQIZEYJlEIGGjCyQwaFiQTmVRIKj1aohAhgALkwEBIAWBERVeZjzKwRhUgsjV2AAK2GxrQZ009A8HHQoCBQhuL3sKVjpm0gpNYRCjDW0dXBdctOly87pujiuxrkojbEQCGARiKPKrGwpS0QBYSz7CalLKs69MwRYBhCWEVVJL7VXF2qaj/cqlNm+3XLF3+40mFrn0scAAoJUkv//WAAAAFQEeUsQFClI9vQAAAB3JgokqBBlN5UqbeMPcCfIacxe0URWxGA24LGtpXKd1oqUplbUlIm5MH1UUup6mnX9M9qSp1rutTvosTKJdemklMDzk6QAFu5KACVvgZ3+neO5piuSFzAgUIl6gCDCIDTTMDBU2WtpeM1cGUvGkiXra23wUSwLpwYnNny1wIUNSuMLd8Hwqnj6eO+QZM07MtwE8qu/k1LejxSTPWuuv9wpqVx92pqXXur1f7YgMDN6wd3veFN/XFtOON2+NYv7bxufRx6f/7sGTHAAXRN1F+c0AAVSYqT8fAABFk/0G9t4AhJpnod6AgBQcTBlyaUBJti4SWgeAAFe5TAWv+AaQuIhxmpKi1qDGRmfKi6syIqJbejMjZgEnlb6vv17t03b+r2bufkdmGPv0sMn/Nh99LmOttOS++2fzaDM7YYn9UAAIodVRSAW7+DRrUiYGImHEAGKAh1KAMEiBhIChqHCSH7qqEtga4pe9TdG/jL9LF2RTOKHI0JqO3vY0KY9UtubK6Vkr+mnT1D1A5T01OdKaizxcPezRYwYJ2Nk/an0kO7jEj1w1sNJnidcTKzuIr2WaDphBwOHJZSpr/5fmDZey+IRy5CISaU/qMOUMi7ZeMeOABDzuxAKP/A3r3h3japzg+/mRmpGDlixPT1/Sb9/oVqP///J7eZ6AjfVKmN79zHWUnr+Tpr5zDiPzDWgD+TAAkKwyKMBDEwS2CA4eOAYFjBxG0QGKJkz0GmgAoxMttmqtWXrF1x1Yi4Vsmapo1SMUNocPMptUMkSABmVWA9AAJAsugbQxbh+hGm1ZIjWxlNFnl2JyIiHKRND5x/zalJPkOX1FlZVKFuup5oVjbl40IcmjDWAtFKNg+90tJqUG0AAHptYUmr8ChW0wyxSkVcY0mEwwwKy4JmBNoZufrRrWrq33P6IukC04tapBsuuUIERyzSBdo0YFpCRsqAAN31iBTm+CDxwTZuXZtXKphQYLaYyGgQCAACl2AA0IE+Lspes1RBbFFKFmmAHjIAoocXVydG0Kt4iEM6/TOFkQ4k0eKBNaM3omyRFSqtwX8EKTMaYn871DTY2VavyuXj04qsOucZwlC4wjU//uQZPwBBIxG0HtvHHo+ZnodPGIvUADfQc1hI6jtg2g09IwEmlLeFio0DISTjRAWeFQoii/xwAAAZKkLES5/hAAAAAwocjdky4mVcMcWEeaoTMzetf1/7fmr3X+huZOqK1ER8WhzBJNugneNvJu2x1xp9e1b/bX6/L/2AARO7LKwFy/4MlJajkzPjMYjSNBTI9ABEUgShpD0rSwE1VrOfwXrdICZ5YTm0QDClfUenmSspR1jCHL/sqFWLlEs8y0um00g1mRaqzoJX5XKtoY3Wl2ZIrjCMtrqP+psyggVnOfIo14jkIOBbxt/T9mPq3Oxw/+QeSAAADTDusSWv+C4hRIiiT925xFrRCERTxoCMyIuZT9f8v8vcjM6UOjIkFyssEx4dakokNsWMNPcLnhwoXZNnoZGXjGVqK8KVQAEKXw3eNW/7AUEKYAPEfTw1AoYDj0PBYJmT8hcFfiOzBkxYIjU0ubOzFQ+DkdI7Fiu2vAuJRaTL7LjIsqoarpYLN/esTyo1HkDaRM9DGHWg9sLdAllSaaEySBUlq/spxKANSZu//uQZPSAA/M60GtYSOhEhpoPGCJFTzjbQey9JykaE6g8kI28RBiJW5lXmuXnb/t23vU5+ngojlM713Rksjff2xxcAEWdb5Ny/UIhNYnn5iea3dOdc/kMaCADRhIl4Ii9dUr98V4Mk9aG7Wwuw8zkOTg0tNBSpgWHVges6Vt2YlBqeebOvzo/diswAEqPNnS1u77VlmzkhCrQFnK0GGIJhCMWhX+GAiEFCNYWvTpfNLmWvQn5NCUNoSGKc5M0Kin2lNVoREMshYJGyZAvJdhD0NSQ8Xp4EJIUqRhZILJ8eDiEHHNeRRAqqDPfqMsJDhHHKsdG0ARc8skwgKIDk+IgTGNheLOOf/+gABDRcKVqff2gHAIkpe3bQ3z6dXS8yVLPRlDjohqpl0yaapd0OZEEXRgmYa7L+366UdRgoJshmOkxuRs/C7Dnz8ilyWpnGOUEggI7kc52LQA2ZnlJa23/agc2YpGcwKsIWFWojuFUg4Q8qFlUY8WDYgydmzy3XVkuw2IEyqxIkaUVyT20JlgQ0098qmunBCRFxA5yiezxpbBI//uQZPEABBZCz/ssNFpIKJntLCN/D7z5PeykcWE8Ied8wo389UPRIUpPZ6FEiXbP4w5CouotvjC4IFcZQWRFkRueo1IrBXyovBVDvhnyDIH/7u8fjMZv28wAFVFlJW6Xf7AaRqxylFjBJYUcRUYnqzf5UUEUVj8vn5vSyvw80Kal9aw4qxjMrlrK0ThKFwyJKUwwlbKxoXhbC30n7djkzJBWnXt+9iWAEVSZU4ZyXe2BcI7EiqIEh4MeJDADHFSaFkC8LBG6FxV2skhD1RBzFvYTArhcvOZDKJWVWMBQjdDGJkqzE0mQeU31kWIx9sFxlyH0zUZIll8hcU2ENo2EUS7ErcqhyKG37ij18LI4RdwXLLXPS6fEobbU/7c+qznTu6AAZvLC76zbBmDzNFNnAhcPusClk2XCRMLq+d3NG5SOkjZTyq6R8i65kOxZpnHtwnUZ8AYEZ6+p8FLyI9b8cDWycu72BHghoBFVE1ZoiEl9d/9qBRQVlNQZoaDoqOEAFAyWRZhSaLC9VM2urha416YaU8/URIPisFA0XZI4Silo//uQZOOAE/ZBzvsJHHpOxxnvJCM9Tz0VOeykcekjnSe8MI39hIUL8VJWmmHlSKCxlUtbCqGRFqiofRCcjirgqkiVMQjjSKG+lEyBNEyzGb6hdnSdDtMMKM5Jcn0mIaGk2srMdxHZl10l4WujN5AH6AUNGhzZpN9tYBJz+zLl3QWcVJzmp2I0Ussgq/1zdwVm6HSuDcIWvctTPTmG9Omr5qRvStSGcgjqCzGcdgrPmx6E5UM068YTxQ3/zz3pv1GxI2Zqg5jbX/WgVgACGUydo0pn5qKrCmwJPIgsdf1TKBmcwVG7Tw84PjhCSh+fwmBa1tvnjI/djpRoyRrqQPaaFWrK6n71ezU5Ngvnz23c+Wp1tjqfY/WNdP35/PtcXTfSERtQ++6RSnbEOQpCSH/2UzcnY+TU6bexTEgsSUAFTOrmH12/1gUOW0z0ejq4UlsWB0/9KiCu/Dt/+/CyPpG7HtM+u42R2M9DL7vJHve0+mdmPwsOOAxhgs0gwbInZAe8ERhPDlumIulCIlZ4piiP//5GByhj6ayE1k/gmRA8SGYH//ugZNmABA5FzvspHHpPx0nPGCNrT5lLOewwcekxmec8Jg1UoAggIcF9mvIClNGUPxpTSc5FJVYh1s1qik1ZZ0mhnUA09dGmOn2kbbSDpNiKiFpEkwyucZLsM4+KbEubWv145TUFUrat+t4ozOB5V3JVblJwUbjv5cHnmvICNACWCxz2MEQs8+wyAFJr79b7Y2ZGLU/UXO2qrioCYnlCVhdrCmwZS2fk6TlCHHWEg1JZlcCJpxjfmzObXZ/n3GzGOBogUDZuGiAKCM4cQDsBhsVPPDwbFptYVCqFXmoNjM8BT39Yx3jFARsz3KxH1/0jEWOIsEKoRHBocAlQsBQbWWUBgMFhKJL9KvoGZKbM9VRcmrVdq/SNBi8OODWp4jutKmHDJGMNHVgHizzKQNCU+YS7dOpmGQcCxVkQrGiEmJm2lXeJeu5VzOPmnbhK9dWy8N6rHDunSjENDGRV3+p452+L1+YyqAAaNUTFbT72QNGddnvnM/jM8y9bLwMEe+dd6189qF4k/EHrPUgSkSE8ubRhScnOJAISIY6PqfDT/qBLc/ve2qe7X661vDjNX9bxy/OnmgAnSJkljS+yNAyMcxEkqCw4ULBiUGYkot8CA3+RkSqL+U6ijB7SpcFU5PhT7HojjI8eZXlZCq6jas9etN+9S8jXnSdbXH0zzfwvWOH47DDimNzMqZBT//uQZP8AA+9ETXsJHVhdRamNIGaJD9DDM+0k1qk5lua8wI6leEaGzJk2NM5R4Y9RqWZCYSJPpG8zIkKFSsI80BYA1wAkuvV/8116f//YAARRDtKy32MkBoPWdXJrbW2S3rfONsgUWVPCCx/jdzezXFNZ3i++vB9bJ7TKBWiELPlGGnk7GCFUK6MpUs+xCsI280g6NXUHSFCgIDA0iha+u2cx0VprIrHft/0jWK//9YAatdSbtd9tEgYD6YZEoSVizdJG8OfDwOKP2DIgg6faZadCmsRpb7JXvsYXbDohLOYMfk04SIYm3RBE7ARFEaeTIaddws25jQq1bLSuazLN77BYFGqJ0VkybWalTu52O6x4gLjwdGP5J9UXJbCNBiKRV7EO/6v//9QABk8QrLb9a0QB4bXrTsd0dWPUgNomiCHLwwqKGZJIs3ChBYUIMTh5DgFjyVDkJLHM8FUccaHzQREMXFnMUku4i8wQxeH1MaQoIYG+NZ//6u79tQIkh4dnXa+Vkgc+C/LsNYgMwLiJRK9LuDzS4g0WmVIXFWGbRzqr//uQZOmAA/9Hy/tMHFhhRxlfMMOLDxjXL+1gw+FKFWW8sI2sJZJWQYFwcMLNKh+SAagRLDUzx1yFrIkUOZKBrgSJRAmtHkOVON9Mk1Rf/7/XPyD5LhNtzbKypa3O6Re23bNQNgz1ViqzbKMkcpuNlUsQn/vSmsW1f0DgDLf77v/rEBYamY8ihfe6+fE+b7CzUGrgjgVWZgNwoiKUMJ0Fa11rK2CfC0Rk1lt3q6zY1aoLIznPhvVxTpxjFvqdff////0UAQpLS5w/80iIAh+gfmMkRIgBA73AkKUIQ4iDkgOAKGIQITAqCZo/MxGmR58hiU015nsYr1JU2CkpFzK0bXGCojTnccV2S1a2httCwUy9ba4CMOfklVHsVi2CI+EhBoLGHRKOAIwFEOHmdY94y8Vc5DRbR+z9jeinTe9na76nY4AAUVmhn3lcIABXg8HKVnu/JI8nq4ySmoVUHsIZLdDK21kqRFCs4paR0n7DIi0dis3F+ex51kK2lGetGju4WALoNDJOM6SCqTumhK3pVijniVL+zI2U+xrX09/80wwq//ugZNGAA+Q5yvsJNChIp1l9GCMND+TFKe0kdOF3mCT81I08A1d5qJmf/7ogDEMDaMYS3QIQj+aCKaKZWC4I9ZLVZLbmKeqtfF5LEn1c5zLsV5nP5IKK2GJbi9QAjb10OGKakhx5QI7JVsmoJNVZ3lvD97unIspHx81brNOKKSSYDIRc8NBdpAE3bKmX2N/////WAEcKzy8ffWogJhMS/1wkm2bUVixDLmI5DDkO75BCuUKQ2g6EHNqTNH2kNpWUq3J4YHDZw6ASgkHnAdEXWBCdr2aL98TaKm/T//9XyQsaREysvfvqkQIGAc2Iqlfiyidw8+0YOSUwT7BUI9zzGkPdNELeVR11K9WD6MlGSsrcyvIvhsJzi5qlURpg8pEWGPMkRoJInhHHtAylKUkSmweebwn0xN15gJtsRfmbEqmREHS+wyKElIQpH93/6pECAFRViIlvsRACyPe1Tuh3WpFAyBQEomcZZHUt7VUZk/It2qmao7ZOby95vsdIzM3QhMz1RN8zl7OTMOcTKMGrPAZiEkn1NIrVivt+///utos//6oERYeoZ2/+1RAROOQjwQWqURFRDXVUUMw5TPQcJAEncXsV61lrFhhjfVwyJUZAAiDE1hxWLFwh6XcgJ1RIyjxGUjBJLcRW7djIaDTzKyWhOJVIftGNaVS+f4kDdDyZ6hel6zsWNf+j//uQZPMAA3cxS/sPM0hMRMlfGSNxDfzBK+y9CyFPGGU8Uw3093/9mqtf6AIyh4eIX/e0IAbd66vgVFaWMZsQpwwW351NzeP5GvI5Fk/5zizmHiVG2pSAi5UWDxQdb/8dX5BwtEIb2/8t+tjIABO5vEkVBdYeBYeZowBLIk3yWHUFHh0sX/baSt7OtLZvvR0OUgeo33mSoI4NT8wbHtZFiuJrlzlobPrm3eLMUVJhSGwhhVUDZ2N6KQSPeChApPOIAG8nGCVhS1de96dS/ei9NZ37qFRovKOY5AtXai3pRlKpHLd97v/IgAA8EujxHqQjgzx8oaLQzyaLxiSR0KKVuDCSODXZR6uBA0iBbnpqxWRKrE4MgUgtiZKcFBv/+5n//7a7NotWz/4RsuoJZoiXdXn3kQAJOQhgOHIxwFCtMYTGgEgUeWmF1kRmfo9N3bx0mkJUkwcCTOIRoJgk2qlNNplVdbF5kSO9m5VnFxSuktr2ZGpz3rOjdnIjoY4VLQzJLaZFtQytFQrLHgWHmFN7urNK/9P+52xYtII0M+7s6xRY//uQZPIAA3AwSvsJNEg55DlvGKMVD3SjJaywcSEoD6U08IxEjl2zk2+rIABy6i9H2MmRiOwaRx+guyGxbaHdyiGEBuCz2RDLaDakwKUhNYI1bRTDW0s7ud1f06v7v+n+/JL9noOesFdndYR333jIIBky7J3YiYAZEIg9yC7BmxNtDaUkbgx/YfgquxhzqqbZEIgaWJm0YfiTE8SJMTzcOrNIN3GpYuYpFE6z5c0pF2WxEHwMeRgS5cWKKi9SavXZ+79qtbFf/X0bF/91V+oPPi9+7/2IACEmFqMe4Rkd5IzC/s5PgAJxZooX33cjNlhCS0KC3neQy2ZCCrLFURXNEU9SCzJz//////2/T6fxlQRmiYg1j/+QAALOUsZSSCHIp+BCogxBrKM4EIPIRZDjydnzBFstekOAPonLjI+Xw0x1W0BoTnWIPTgs38XXaW9DtPF18ybkgiJyzG7njmAMYkyb/39n/2////dO7hg/7Fdar9gjluE+33gIAA7qSSntfnLNYampujCnA0JhRTGoVLKB8Srrfkf/72a/9/////+0//uAZPmAA60xSfspHFhC5Ok9ICNPDPCLJ+wk0OEBlCU0EI0sUWz/1EzO0O6m33sYABhyAEseYEIQMKGpRkIxgoetLEVmWnAkWPo1JCHEMKTLByMm7dYtHRni46X3Qst+QJ9u5F3XW1bR6u7wxM0BlMFAm9YlrbHnvp/6////7/usvPkfX/ZJVABws3H1/WGTnXi/KhT+n+CUuwg0XxiMpeV15SCjVP//////////9VfJf/7nqkZod4Z3nf8MAARxRSELFKhQ4cZ9mCnLkSoyiU/vF8JVP3gIQ/BItGUJ7/80YbWyzRrty6yfl1m5rSoU/36WpZ///////1f//1mPAAcfDiAEAkGSASiplE4if7aQyZ/5X///9DNf////91X/6/SjvEzDQziI4osdq8olKCQ4bsgNVEIAM4XuwZLZEMYaGOGPua7tucznylZHZ0Z3mHCwMhZf//////////8bjv1XozsDhAO43ADBgjj/+3Bk7YAzHyDJ+w9KyDICeU0YIhkMOIcl7LBNoKoPZRAwjpSWCEWrXm1KLfA1As+x///////////+z+z/r+iZeHV1d3G+ABQQcBsRskg7qEqBt3nIEf7IcTVzYDTsMBfu/8iZOpnuKf0Xf////2e3/q//9vpt96++hepO54AAAAAAAABrgiJmHVldw4AAJIYSYihxpQbQMhigOnNuqX5VhoqW0Ar/////////////6k9H1WfzEzQAAaAAAOBkxKd9P//////////9rfrotrYAAA4AAAAVQBIiQvREiyxxzf////5rf/T//////////7/+XsanRXQwpZilrLrL69FQ1+6tKVkFKQAAAEAEDjgAAE//81/zz/z7//5Hoyf/9v/sb/vfzf315v6///6L/82xpSIZUmyhllKi//tgZOaDEkUgynsMMdgkgVlNBAM3CAB3KcwwpyCXgaU8IQwEmKy1T3ZyGR4ZjKCPJa+tlmpMQU1FMy45OS4zqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//tQZO2BIeUaSfsjElgKoApOAAABReQpJ+fhAKBegGa8EAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7MGT8j/HNecdpQBY4Qq5YzwQC4UAAAf4AAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg==",
};

var BASE64_MARKER = ';base64,';

function convertDataURIToBinary(dataURI) {
  var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
  var base64 = dataURI.substring(base64Index);
  var raw = window.atob(base64);
  var rawLength = raw.length;
  var array = new Uint8Array(new ArrayBuffer(rawLength));

  for(let i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
  }
  return array;
}

const soundManager = {
	ctx: new (window.AudioContext || window.webkitAudioContext),
	sources: {
		lift: {
			volume: 1,
			playbackRateMin: 0.85,
			playbackRateMax: 0.95,
			fileNames: [
				'lift1.mp3',
				'lift2.mp3',
				'lift3.mp3'
			]
		},
		burst: {
			volume: 1,
			playbackRateMin: 0.8,
			playbackRateMax: 0.9,
			fileNames: [
				'burst1.mp3',
				'burst2.mp3'
			]
		},
		burstSmall: {
			volume: 0.25,
			playbackRateMin: 0.8,
			playbackRateMax: 1,
			fileNames: [
				'burst-sm-1.mp3',
				'burst-sm-2.mp3'
			]
		},
		crackle: {
			volume: 0.2,
			playbackRateMin: 1,
			playbackRateMax: 1,
			fileNames: ['crackle1.mp3']
		},
		crackleSmall: {
			volume: 0.3,
			playbackRateMin: 1,
			playbackRateMax: 1,
			fileNames: ['crackle-sm-1.mp3']
		}
	},

	preload() {
		const allFilePromises = [];

		function checkStatus(response) {
			if (response.status >= 200 && response.status < 300) {
				return response;
			}
			const customError = new Error(response.statusText);
			customError.response = response;
			throw customError;
		}

		const types = Object.keys(this.sources);
		types.forEach(type => {
			const source = this.sources[type];
			const { fileNames } = source;
			const filePromises = [];
			fileNames.forEach(fileName => {
				const binary = convertDataURIToBinary(audioBlobs[fileName]);
				const blob = new Blob([binary], { type: 'audio/mp3' });
				const fileURL = URL.createObjectURL(blob); //this.baseURL + fileName;
				// Promise will resolve with decoded audio buffer.
				const promise = fetch(fileURL)
					.then(checkStatus)
					.then(response => response.arrayBuffer())
					.then(data => new Promise(resolve => {
						this.ctx.decodeAudioData(data, resolve);
					}));

				filePromises.push(promise);
				allFilePromises.push(promise);
			});

			Promise.all(filePromises)
				.then(buffers => {
					source.buffers = buffers;
				});
		});

		return Promise.all(allFilePromises);
	},
	
	pauseAll() {
		this.ctx.suspend();
	},

	resumeAll() {
		// Play a sound with no volume for iOS. This 'unlocks' the audio context when the user first enables sound.
		this.playSound('lift', 0);
		// Chrome mobile requires interaction before starting audio context.
		// The sound toggle button is triggered on 'touchstart', which doesn't seem to count as a full
		// interaction to Chrome. I guess it needs a click? At any rate if the first thing the user does
		// is enable audio, it doesn't work. Using a setTimeout allows the first interaction to be registered.
		// Perhaps a better solution is to track whether the user has interacted, and if not but they try enabling
		// sound, show a tooltip that they should tap again to enable sound.
		setTimeout(() => {
			this.ctx.resume();
		}, 250);
	},
	
	// Private property used to throttle small burst sounds.
	_lastSmallBurstTime: 0,

	/**
	 * Play a sound of `type`. Will randomly pick a file associated with type, and play it at the specified volume
	 * and play speed, with a bit of random variance in play speed. This is all based on `sources` config.
	 *
	 * @param  {string} type - The type of sound to play.
	 * @param  {?number} scale=1 - Value between 0 and 1 (values outside range will be clamped). Scales less than one
	 *                             descrease volume and increase playback speed. This is because large explosions are
	 *                             louder, deeper, and reverberate longer than small explosions.
	 *                             Note that a scale of 0 will mute the sound.
	 */
	playSound(type, scale=1) {
		// Ensure `scale` is within valid range.
		scale = MyMath.clamp(scale, 0, 1);

		// Disallow starting new sounds if sound is disabled, app is running in slow motion, or paused.
		// Slow motion check has some wiggle room in case user doesn't finish dragging the speed bar
		// *all* the way back.
		if (!canPlaySoundSelector() || simSpeed < 0.95) {
			return;
		}
		
		// Throttle small bursts, since floral/falling leaves shells have a lot of them.
		if (type === 'burstSmall') {
			const now = Date.now();
			if (now - this._lastSmallBurstTime < 20) {
				return;
			}
			this._lastSmallBurstTime = now;
		}
		
		const source = this.sources[type];

		if (!source) {
			throw new Error(`Sound of type "${type}" doesn't exist.`);
		}
		
		const initialVolume = source.volume;
		const initialPlaybackRate = MyMath.random(
			source.playbackRateMin,
			source.playbackRateMax
		);
		
		// Volume descreases with scale.
		const scaledVolume = initialVolume * scale;
		// Playback rate increases with scale. For this, we map the scale of 0-1 to a scale of 2-1.
		// So at a scale of 1, sound plays normally, but as scale approaches 0 speed approaches double.
		const scaledPlaybackRate = initialPlaybackRate * (2 - scale);
		
		const gainNode = this.ctx.createGain();
		gainNode.gain.value = scaledVolume;

		const buffer = MyMath.randomChoice(source.buffers);
		const bufferSource = this.ctx.createBufferSource();
		bufferSource.playbackRate.value = scaledPlaybackRate;
		bufferSource.buffer = buffer;
		bufferSource.connect(gainNode);
		gainNode.connect(this.ctx.destination);
		bufferSource.start(0);
	}
};




// Kick things off.

function setLoadingStatus(status) {
	document.querySelector('.loading-init__status').textContent = status;
}

// CodePen profile header doesn't need audio, just initialize.
if (IS_HEADER) {
	init();
} else {
	// Allow status to render, then preload assets and start app.
	setLoadingStatus('Lighting Fuses');
	setTimeout(() => {
		soundManager.preload()
		.then(
			init,
			reason => {
				// Codepen preview doesn't like to load the audio, so just init to fix the preview for now.
				init();
				// setLoadingStatus('Error Loading Audio');
				return Promise.reject(reason);
			}
		);
	}, 0);
}

// Start ws connection after document is loaded
$(document).ready(function() {

  // Connect if API_Key is inserted
  // Else show an error on the overlay
//  if (typeof API_Key === "undefined") {
//    $("body").html("No API Key found or load!<br>Rightclick on the script in ChatBot and select \"Insert API Key\"");
//    $("body").css({"font-size": "20px", "color": "#ff8080", "text-align": "center"});
//  }
//  else {
    connectWebsocket();
 // }

});

function fireRandom() {
	const rand = Math.random();
	
	if (rand < 0.08 && Date.now() - seqSmallBarrage.lastCalled > seqSmallBarrage.cooldown) {
		return seqSmallBarrage();
	}
	
	if (rand < 0.1) {
		return seqPyramid();
	}
	
	if (rand < 0.6 && !IS_HEADER) {
		return seqRandomShell();
	}
	else if (rand < 0.8) {
		return seqTwoRandom();
	}
	else if (rand < 1) {
		return seqTriple();
	}
}


// Connect to ChatBot websocket
// Automatically tries to reconnect on
// disconnection by recalling this method
function connectWebsocket() {
//Botchy Flad code here :) 

    var maxemotes = 20;
    var divnumber = 0;
    var i=0;
	var emotecount=0;

      if ("WebSocket" in window) {
        const ws = new WebSocket("ws://localhost:8080/");
        ws.onclose = function () {
          // "connectws" is the function we defined previously
          setTimeout(connectWebsocket, 10000);
        };




        ws.onopen = function () {
          ws.send(JSON.stringify(
            {
              "request": "Subscribe",
              "events": {
                "Twitch": [
                  "ChatMessage"
                ]
              },
              "id": "123"
            }
          ));
        };
        ws.onmessage = function (event) {
          // grab message and parse JSON
          const msg = event.data;
          const wsdata = JSON.parse(msg);

          // check for events to trigger
          //check for emotes wsdata.data.message.emotes
		  var lowermessage = wsdata.data.message.message.toLowerCase();
          if (lowermessage.includes("fireworks")) {
			fireRandom();
          }
        };
      }
    }
	


//End of botchy Flad code :)
  //-------------------------------------------
  //  Create WebSocket
  //-------------------------------------------
  //var socket = new WebSocket("ws://127.0.0.1:3337/streamlabs");

  //-------------------------------------------
  //  Websocket Event: OnOpen
  //-------------------------------------------
  //socket.onopen = function() {

    // AnkhBot Authentication Information
 //   var auth = {
 //     author: "nate1280",
//      website: "",
//      api_key: API_Key,
//      events: [
///        "EVENT_FIREWORKS",
//		"EVENT_SUB",
//		"EVENT_FOLLOW",
//		"EVENT_HOST",
//		"EVENT_GWSUB"
//      ]
//};

    // Send authentication data to ChatBot ws server
    //socket.send(JSON.stringify(auth));
  //};

  //-------------------------------------------
  //  Websocket Event: OnMessage
  //-------------------------------------------
  //socket.onmessage = function (message) {

    // Parse message
   // var socketMessage = JSON.parse(message.data);
 //   console.log(socketMessage);

    // EVENT_FIREWORKS
  //  if (socketMessage.event === "EVENT_FIREWORKS") {
 //     var eventData = JSON.parse(socketMessage.data);
//	  
//	  if (eventData.action === "pause") {
//		togglePause(true);
//	  } else if (eventData.action === "play") {
//		togglePause(false);
//	  } else if (eventData.action === "mute") {
//		toggleSound(false);
//	  } else if (eventData.action === "unmute") {
//		toggleSound(true);
//	  } else if (eventData.action === "fire") {
//		fireRandom();
//	  }
//    } else if (socketMessage.event === "EVENT_SUB") {
//	  fireRandom();
//    } else if (socketMessage.event === "EVENT_FOLLOW") {
//	  fireRandom();
//    } else if (socketMessage.event === "EVENT_HOST") {
//	  fireRandom();
//	}
  //}

  //-------------------------------------------
  //  Websocket Event: OnError
  //-------------------------------------------
 // socket.onerror = function(error) {
  //  console.log("Error: " + error);
  //}

  //-------------------------------------------
  //  Websocket Event: OnClose
  //-------------------------------------------
  //socket.onclose = function() {
    // Clear socket to avoid multiple ws objects and EventHandlings
    //socket = null;
    // Try to reconnect every 5s
    //setTimeout(function(){connectWebsocket()}, 5000);
//  }




//}




