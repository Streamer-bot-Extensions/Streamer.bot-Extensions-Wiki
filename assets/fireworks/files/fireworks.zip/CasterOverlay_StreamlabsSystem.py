#---------------------------------------
#   Import Libraries
#---------------------------------------
import sys
import clr
import json
import codecs
import os

clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")

#---------------------------------------
#   [Required] Script Information
#---------------------------------------
ScriptName = "Caster Overlay"
Website = "alcoholicninja.com"
Description = "Caster overlay that pulls casters avatar picture from twitch API and displays it on screen"
Creator = "The_Alcoholic_Ninja"
Version = "1.1.6"

# ---------------------------------------
#	Set Variables
# ---------------------------------------
SettingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
ReadMeFile = os.path.join(os.path.dirname(__file__), "ReadMe.txt")
ScriptSettings = None

# ---------------------------------------
#	Script Classes
# ---------------------------------------
class Settings(object):
    """ Class to hold the script settings, matching UI_Config.json. """

    def __init__(self, settingsfile=None):
        """ Load in saved settings file if available else set default values. """
        try:
            with codecs.open(settingsfile, encoding="utf-8-sig", mode="r") as f:
                self.__dict__ = json.load(f, encoding="utf-8")
        except:
            self.CasterCommand = "!caster"
            self.CasterColor = "rgba(255,0,0,255)"
            self.TwitchColor = "rgba(255,0,0,255)"
            self.Permission = "Moderator"

    def Reload(self, jsonData):
        """ Reload settings from the user interface by given json data. """
        self.__dict__ = json.loads(jsonData, encoding="utf-8")

# ---------------------------------------
#	Functions
# ---------------------------------------
def SendUsernameWebsocket(username):
    # Broadcast WebSocket Event
    payload = {
        "user": username
    }
    Parent.BroadcastWsEvent("EVENT_USERNAME", json.dumps(payload))
    return

#---------------------------------------
#   [Required] Initialize Data / Load Only
#---------------------------------------
def Init():
    """ Initialize script or startup or reload. """

    # Globals
    global ScriptSettings

    # Load saved settings and validate values
    ScriptSettings = Settings(SettingsFile)

    return

# ---------------------------------------
# Chatbot Save Settings Function
# ---------------------------------------
def ReloadSettings(jsondata):
    """ Set newly saved data from UI after user saved settings. """

    # Reload saved settings and validate values
    ScriptSettings.Reload(jsondata)

    return


def Execute(data):

    # Check if the proper command is used, the command is not on cooldown and the user has permission to use the command
    if data.IsChatMessage():
        if data.GetParam(0).lower() == ScriptSettings.CasterCommand and not Parent.IsOnCooldown(ScriptName, ScriptSettings.CasterCommand.lower()):
            if Parent.HasPermission(data.User,ScriptSettings.Permission,""):
                if data.GetParamCount() > 1:
                    SendUsernameWebsocket(data.GetParam(1).strip("@"))
                    Parent.AddCooldown(ScriptName, ScriptSettings.CasterCommand, 10)
                else:
                    Parent.SendTwitchMessage("Please enter username after " + ScriptSettings.CasterCommand)
            else:
                Parent.SendTwitchMessage("Sorry " + data.User + ", you don't have permission to do that!")

    return

def Tick():
    return

# ---------------------------------------
# Script UI Button Functions
# ---------------------------------------
def OpenReadMe():
    """ Open the script readme file in users default .txt application. """
    os.startfile(ReadMeFile)
    return
