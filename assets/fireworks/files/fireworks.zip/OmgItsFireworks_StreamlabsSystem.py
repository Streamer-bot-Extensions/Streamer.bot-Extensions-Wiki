#---------------------------------------
#   Import Libraries
#---------------------------------------
import sys
import json
import codecs
import os

#---------------------------------------
#   [Required] Script Information
#---------------------------------------
ScriptName = "OMG! It's Fireworks Overlay"
Website = ""
Description = "Caster overlay that pulls casters avatar picture from twitch API and displays it on screen"
Creator = "nate1280"
Version = "1.0.0"

DebuggingMode = False

def SendUsernameWebsocket(username):
	# Broadcast WebSocket Event
	payload = {
		"user": username
	}
	BroadcastFireworksEvent(payload)
	return

def FireworksPause():
	payload = {
		"action": "pause"
	}
	BroadcastFireworksEvent(payload)
	return

def FireworksPlay():
	payload = {
		"action": "play"
	}
	BroadcastFireworksEvent(payload)
	return

def FireworksMute():
	payload = {
		"action": "mute"
	}
	BroadcastFireworksEvent(payload)
	return

def FireworksUnmute():
	payload = {
		"action": "unmute"
	}
	BroadcastFireworksEvent(payload)
	return

def FireworksFire():
	payload = {
		"action": "fire"
	}
	BroadcastFireworksEvent(payload)
	return

def BroadcastFireworksEvent(payload):
	Log("Broadcasting event")
	Parent.BroadcastWsEvent("EVENT_FIREWORKS", json.dumps(payload))
	return

def Init():
	""" Initialize script or startup or reload. """
	Log("OMG! It's Fireworks initialized...")
	return

def Execute(data):

	if data.IsChatMessage() and data.GetParam(0).lower() == "!fireworks":
		Log(data.GetParam(0).lower())
		
		mainCommand = data.GetParam(1).lower()
		
		if mainCommand == "pause":
			FireworksPause()
		elif mainCommand == "play" or mainCommand == "resume":
			FireworksPlay()
		elif mainCommand == "mute" or mainCommand == "silence":
			FireworksMute()
		elif mainCommand == "unmute":
			FireworksUnmute()
		else:
			FireworksFire()
		


#	# Check if the proper command is used, the command is not on cooldown and the user has permission to use the command
#	if data.IsChatMessage():
#		Log(data.GetParam(0).lower())
#		if data.GetParam(0).lower() == "!fireworks": # and not Parent.IsOnCooldown(ScriptName, ScriptSettings.CasterCommand.lower()):
#			#if Parent.HasPermission(data.User,ScriptSettings.Permission,""):
#			Log("Command happened!")
#			SendUsernameWebsocket("test")
#			Parent.AddCooldown(ScriptName, ScriptSettings.CasterCommand, 10)
#			#else:
#			#    Parent.SendTwitchMessage("Sorry " + data.User + ", you don't have permission to do that!")

	return

def Tick():
	return

# logging function
def Log(message, isDebug = False):
	if isDebug and DebuggingMode:
		Parent.Log(ScriptName, message)
	if not isDebug:
		Parent.Log(ScriptName, message)
	try:
		with codecs.open(os.path.join(os.path.dirname(__file__), 'logfile.txt'), encoding="utf-8", mode="a") as f:
			f.write("{0}: {1}{2}".format(time.strftime('%Y-%m-%d %H:%M'), message, os.linesep))
			f.close()
	except:
		pass

