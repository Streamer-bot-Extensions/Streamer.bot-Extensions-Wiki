const params = new URLSearchParams(window.location.search);
document.getElementById("name").textContent = params.get("user") || "GoWMan";
document.getElementById("image").src = params.get("targetUserProfileImageUrlEscaped") || "https://static-cdn.jtvnw.net/jtv_user_pictures/dd70b1ec-b906-416a-8a56-d067bda64514-profile_image-300x300.png";
document.getElementById("proverb").textContent = params.get("randomLine") || "A crisis is an opportunity riding the dangerous wind.";