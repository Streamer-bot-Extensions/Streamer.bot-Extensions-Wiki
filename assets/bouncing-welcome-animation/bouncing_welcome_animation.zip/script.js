const params = new URLSearchParams(window.location.search);
document.getElementById("text").textContent = params.get("name");

Splitting();

// Replay animation by hiding & showing the element again
let el = document.body;
el.addEventListener("click", function (e) {
  el.hidden = true;
  requestAnimationFrame(() => {
    el.hidden = false;
  });
});