# Interactive Super Mario 

A Pen created on CodePen.io. Original URL: [https://codepen.io/terrierdarts/pen/ZErVvXV](https://codepen.io/terrierdarts/pen/ZErVvXV).

A little Super Mario World Interactive scene. 
Graphics are made with SCSS using box-shadow and code is vanilla javascript.
- Press W or arrow-up for Mario to look up
- Press S or arrow-down for Mario to bend.
- Press Space for Mario to jump and collect coins.
- Press F for Mario to turn into Fire Mario