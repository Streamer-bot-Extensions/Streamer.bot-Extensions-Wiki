const params = new URLSearchParams(window.location.search);

// grabs from url param or falls back to the 2nd string
const title = params.get('title') || 'default goes here and here and here too and here';

// split the text into words
const parts = title.split(' ');

// split the words into 5 chunks
const chunks = chunkArray(parts, Math.ceil(parts.length / 5));

// append each chunk to the spans
chunks.forEach((c, i) => {
   document.getElementById(`part${i+1}`).textContent = c.join(' ');
});

function chunkArray(array, size) {
    let result = []
    for (value of array){
        let lastArray = result[result.length -1 ]
        if(!lastArray || lastArray.length == size){
            result.push([value])
        } else{
            lastArray.push(value)
        }
    }
    return result
}