const params = new URLSearchParams(window.location.search);
document.getElementById("quoteText").textContent = params.get("title");
document.getElementById("nameText").textContent = params.get("nameText");
document.getElementById("quoteNum").textContent = params.get("issueNum");
document.getElementById("pfp").src = params.get("img");

n =  new Date();
y = n.getFullYear();
m = n.getMonth() + 1;
d = n.getDate();
document.getElementById("date").innerHTML = m + "/" + d + "/" + y;