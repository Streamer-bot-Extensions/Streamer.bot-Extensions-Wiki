const params = new URLSearchParams(window.location.search);
document.getElementById("quoteText").textContent = params.get("title");
document.getElementById("nameText").textContent = params.get("nameText");
document.getElementById("quoteNum").textContent = params.get("issueNum");
document.getElementById("pfp").src = params.get("img");

document.getElementById('date').textContent = new Intl.DateTimeFormat('en-US', { dateStyle: 'medium' }).format(new Date());